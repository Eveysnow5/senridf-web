# -*- coding: utf-8 -*-
"""減価償却（月次計上）。償却率は省令 別表第八・第十（data/jp/genka/depreciation_rates.yaml）。

年額を税法の方法で求め、月次は「累計按分」で配る：
  当月分 ＝ 切捨て(年額 × 経過月数/償却月数) − 切捨て(年額 × 前月までの経過月数/償却月数)
こうすると 12 か月の合計が年額にぴったり一致し、端数が最後の月に寄る。

対象は平成19年4月1日以後取得の定額法と、平成24年4月1日以後取得の200%定率法。
それ以前の取得（旧定額法・旧定率法・250%定率法）は未対応 → 要確認。
"""
from __future__ import annotations

import datetime
import pathlib
from decimal import Decimal as D

import yaml

from ..core.money import truncate

RATES = pathlib.Path(__file__).resolve().parents[3] / "data" / "jp" / "genka" / "depreciation_rates.yaml"
_R = None


def rates():
    global _R
    if _R is None:
        _R = yaml.safe_load(RATES.read_text(encoding="utf-8"))
    return _R


def fy_bounds(month: datetime.date, fy_end_month: int):
    """month を含む事業年度の (開始月, 終了月)。"""
    if fy_end_month == 12:
        return datetime.date(month.year, 1, 1), datetime.date(month.year, 12, 1)
    sy = month.year if month.month > fy_end_month else month.year - 1
    return datetime.date(sy, fy_end_month + 1, 1), datetime.date(sy + 1, fy_end_month, 1)


def _months(a: datetime.date, b: datetime.date) -> int:
    """a〜b（両端含む、月単位）。"""
    return (b.year - a.year) * 12 + b.month - a.month + 1


def annual(asset, fy_start, fy_end, acc_at_fy_start):
    """(年額, 償却月数, 推導, 要確認 or None)"""
    cost = int(asset["cost"])
    life = int(asset["life"])
    inservice = datetime.date.fromisoformat(str(asset["in_service"])).replace(day=1)
    acquired = datetime.date.fromisoformat(str(asset.get("acquired", asset["in_service"])))
    first = max(inservice, fy_start)
    if first > fy_end:
        return 0, 0, ["未使用（事業供用前）"], None
    n = _months(first, fy_end)
    book = cost - acc_at_fy_start
    if book <= 1:
        return 0, n, ["償却済み（備忘価額 1 円）"], None
    method = asset["method"]
    R = rates()
    if method == "straight":
        if acquired < datetime.date(2007, 4, 1):
            return 0, n, [], "平成19年3月31日以前の取得（旧定額法）は未対応"
        rate = D(R["straight_line"]["rates"][life])
        amt = int(truncate(D(cost) * rate * n / 12))
        why = [f"定額法 取得価額 {cost:,} × 償却率 {rate}（耐用年数 {life} 年・別表第八）× {n}/12 ＝ {amt:,}"]
    elif method == "declining_200":
        if acquired < datetime.date(2012, 4, 1):
            return 0, n, [], "平成24年3月31日以前の取得（250%定率法等）は未対応"
        row = R["declining_200"]["rates"][life]
        rate, revised, guar = D(row["rate"]), row["revised"], row["guarantee"]
        amt = int(truncate(D(book) * rate * n / 12))
        why = [f"200%定率法 期首帳簿価額 {book:,} × 償却率 {rate}（耐用年数 {life} 年・別表第十）× {n}/12 ＝ {amt:,}"]
        if guar is not None:
            guarantee_amt = int(truncate(D(cost) * D(guar)))
            if int(truncate(D(book) * rate)) < guarantee_amt:
                if "revised_base" not in asset:
                    return 0, n, why, (f"調整前償却額が償却保証額 {guarantee_amt:,} を下回った——改定取得価額"
                                       f"（revised_base）を台帳に入れると改定償却率 {revised} で計算する")
                amt = int(truncate(D(asset["revised_base"]) * D(revised) * n / 12))
                why.append(f"償却保証額 {guarantee_amt:,} を下回ったので 改定取得価額 {asset['revised_base']:,} × "
                           f"改定償却率 {revised} × {n}/12 ＝ {amt:,}")
    else:
        return 0, n, [], f"償却方法「{method}」は未対応（straight / declining_200）"
    if book - amt < 1:
        amt = book - 1
        why.append(f"備忘価額 1 円を残すため {amt:,} に制限")
    return amt, n, why, None


def monthly(asset, month, fy_end_month, acc_at_fy_start):
    """(当月の償却額, 推導, 要確認 or None)"""
    fs, fe = fy_bounds(month, fy_end_month)
    amt, n, why, problem = annual(asset, fs, fe, acc_at_fy_start)
    if problem or n == 0 or amt == 0:
        return 0, why, problem
    inservice = datetime.date.fromisoformat(str(asset["in_service"])).replace(day=1)
    first = max(inservice, fs)
    if month < first:
        return 0, why, None
    k = _months(first, month)
    cur = int(truncate(D(amt) * k / n)) - int(truncate(D(amt) * (k - 1) / n))
    return cur, why + [f"月次按分 {k}/{n} か月目 → {cur:,}"], None
