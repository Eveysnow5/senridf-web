# -*- coding: utf-8 -*-
"""消費税：税抜経理の仕訳分割と、税区分ごとの集計・概算。

会社設定 consumption_tax（作者の決定 A3 に従い、判断記録つき・既定値なし）：
  status      taxable（課税事業者）/ exempt（免税事業者）
  method      general（本則）/ simplified（簡易課税）          ← taxable のとき
  category    1〜6（簡易課税の事業区分）                         ← simplified のとき
  accounting  tax_included（税込経理）/ tax_excluded（税抜経理）

**製品が計算するのは「概算」まで。** 申告額は会計担当者が確定させる（年度末の確認リストにある）。
未対応で、計算せず要確認に出すもの：インボイス制度の経過措置（適格請求書発行事業者以外からの
仕入の控除割合）、2割特例、旧税率の経過措置、令和9年4月からの飲食料品の税率引下げ。

税抜経理の分割は**行ごとに円未満切捨て**で税額を抜き出す。インボイス制度では
「1 枚の請求書につき税率ごとに 1 回」端数処理するので、1 枚の請求書が複数行に分かれていると
数円ずれることがある——前提として要確認に載せる。
"""
from __future__ import annotations

import pathlib
from collections import defaultdict
from decimal import Decimal as D

import yaml

from ..core.model import Line
from ..core.money import truncate

DATA = pathlib.Path(__file__).resolve().parents[3] / "data" / "jp" / "shouhi" / "consumption_tax_r08.yaml"
_CT = None
INPUT_TAX, OUTPUT_TAX = "仮払消費税等", "仮受消費税等"


def table():
    global _CT
    if _CT is None:
        _CT = yaml.safe_load(DATA.read_text(encoding="utf-8"))
    return _CT


def category_of(line, chart) -> str:
    """行の税区分。行に書いてあればそれ、無ければ科目表の既定。"""
    return line.tax or chart[line.account].get("tax", "") or "対象外"


def rate_of(cat):
    info = table()["categories"].get(cat)
    if info is None:
        raise ValueError(f"未知の税区分「{cat}」")
    if info["side"] == "none":
        return None, None
    return info["side"], D(table()["rates"][info["rate"]]["total"])


def tax_in(amount, rate) -> int:
    """税込金額に含まれる消費税等（国＋地方）。円未満切捨て。"""
    return int(truncate(D(amount) * rate / (1 + rate)))


def split_voucher(v, chart):
    """税抜経理：課税仕入・課税売上の行を「本体」と「仮払／仮受消費税等」に分ける（その場で書き換える）。"""
    out, notes = [], []
    for l in v.lines:
        if l.account in (INPUT_TAX, OUTPUT_TAX):
            out.append(l)
            continue
        cat = category_of(l, chart)
        side, rate = rate_of(cat)
        if side is None:
            out.append(l)
            continue
        amt = int(l.debit or l.credit)
        tax = tax_in(amt, rate)
        if tax == 0:
            out.append(l)
            continue
        acc = INPUT_TAX if side == "purchase" else OUTPUT_TAX
        if l.debit:
            out.append(Line(l.account, D(amt - tax), D(0), l.sub, cat, l.memo))
            out.append(Line(acc, D(tax), D(0), cat, cat, "税抜経理"))
        else:
            out.append(Line(l.account, D(0), D(amt - tax), l.sub, cat, l.memo))
            out.append(Line(acc, D(0), D(tax), cat, cat, "税抜経理"))
        notes.append(f"{l.account} {amt:,} → 本体 {amt - tax:,} ＋ {acc} {tax:,}（{cat}、行ごとに円未満切捨て）")
    v.lines = out
    if notes:
        v.derivation = list(v.derivation) + ["税抜経理：" + "／".join(notes)]
    return v


def summary(co, vouchers):
    """税区分ごとの集計（税抜本体・消費税等）と概算納付額。vouchers は集計したい期間のもの。"""
    by = defaultdict(lambda: [0, 0])                      # cat → [本体, 税]
    excluded = co.ct["accounting"] == "tax_excluded"
    for v in vouchers:
        if v.kind == "closing":
            continue
        for l in v.lines:
            if l.account in (INPUT_TAX, OUTPUT_TAX):
                if excluded:
                    by[l.sub][1] += int(l.debit) - int(l.credit) if l.account == INPUT_TAX else int(l.credit) - int(l.debit)
                continue
            cat = category_of(l, co.chart)
            side, rate = rate_of(cat)
            sign = (int(l.debit) - int(l.credit)) if side == "purchase" else (int(l.credit) - int(l.debit))
            if side is None:
                if cat in ("非課税売上", "非課税仕入"):
                    by[cat][0] += abs(int(l.debit) - int(l.credit))
                continue
            if excluded:
                by[cat][0] += sign
            else:
                # 税込経理：行の金額に含まれる税を抜き出す。返品・値引き（負）は符号ごと戻す
                t = tax_in(abs(sign), rate) * (1 if sign >= 0 else -1)
                by[cat][0] += sign - t
                by[cat][1] += t
    sales_tax = sum(t for c, (_, t) in by.items() if c.startswith("課税売上"))
    purchase_tax = sum(t for c, (_, t) in by.items() if c.startswith("課税仕入"))
    res = dict(rows={c: tuple(v) for c, v in sorted(by.items())}, sales_tax=sales_tax,
               purchase_tax=purchase_tax, estimate=None, basis="")
    if co.ct["status"] == "exempt":
        res["basis"] = "免税事業者：納税義務なし（基準期間の課税売上高とインボイス登録の有無は会計担当者が確認）"
    elif co.ct["method"] == "general":
        res["estimate"] = sales_tax - purchase_tax
        res["basis"] = "本則課税の概算：売上の消費税等 − 仕入の消費税等（インボイス経過措置・積上げ計算は考慮していない）"
    else:
        dr = D(table()["simplified"]["deemed_purchase_rates"][int(co.ct["category"])])
        res["estimate"] = int(truncate(D(sales_tax) * (1 - dr)))
        res["basis"] = f"簡易課税の概算：売上の消費税等 ×（1 − みなし仕入率 {dr}、第{co.ct['category']}種）"
    return res
