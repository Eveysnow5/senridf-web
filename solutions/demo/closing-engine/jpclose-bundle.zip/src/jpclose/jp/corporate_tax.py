# -*- coding: utf-8 -*-
"""法人税等の計算表（法人税・地方法人税・法人住民税・法人事業税・特別法人事業税）。

作者の決定（2026-10-09）：自動化した計算表。**利用者の入力が要るところは入力にし、
帳簿から取れる数字は自動で取る。** 表の各行に「自動／入力／出典」を明記する。

  自動  税引前当期純利益（帳簿）、資本金等の額（資本金＋資本準備金の残高）、従業者数（名簿）、事業年度の月数
  入力  申告調整（加算・減算）、繰越欠損金の控除額、中間納付額、出典を読めなかった地方税率
        （大阪府：法人府民税の法人税割率・均等割、事業税の超過税率の適用）
  出典  法人税率・地方法人税率・特別法人事業税率・大阪府の事業税率・大阪市の法人税割と均等割
        （data/jp/hojin/corporate_tax_r08.yaml、原本は data/jp/sources/）

端数：課税標準は千円未満切捨て、確定金額は百円未満切捨て（国税通則法 118・119、地方税法 20 条の 4 の 2）。

**これは概算の計算表であって申告書ではない。** 別表四の加算・減算は会計担当者が入れる。
"""
from __future__ import annotations

import pathlib
from decimal import Decimal as D

import yaml

from ..core.money import truncate

DATA = pathlib.Path(__file__).resolve().parents[3] / "data" / "jp" / "hojin" / "corporate_tax_r08.yaml"
_T = None


def table():
    global _T
    if _T is None:
        _T = yaml.safe_load(DATA.read_text(encoding="utf-8"))
    return _T


def base1000(x) -> int:
    """課税標準：千円未満切捨て。負なら 0。"""
    return max(0, int(x) // 1000 * 1000)


def amt100(x) -> int:
    """確定金額：百円未満切捨て。"""
    return max(0, int(truncate(D(x))) // 100 * 100)


class TaxInputError(ValueError):
    pass


def compute_from(*, pretax, add=0, deduct=0, loss_cf=0, capital, capital_and_reserve,
                 employees, months, pref, city, inputs):
    """純粋な計算。返り値は {lines: [(区分, 説明, 金額, 由来)], total, ...}。"""
    T = table()
    nat = T["national"]
    lines = []

    def line(kind, label, amount, origin):
        lines.append((kind, label, int(amount), origin))
        return int(amount)

    pending = []
    line("所得", "税引前当期純利益", pretax, "自動（帳簿）")
    line("所得", "加算（申告調整）", add, "入力")
    line("所得", "減算（申告調整）", -deduct, "入力")
    income = pretax + add - deduct
    line("所得", "繰越欠損金の控除", -loss_cf, "入力")
    income -= loss_cf
    base = line("所得", "課税標準（所得金額、千円未満切捨て）", base1000(income), "国税通則法118条")

    # 法人税
    ct = nat["corporate_tax"]
    if capital > 100000000:
        raise TaxInputError("資本金1億円超の法人は軽減税率の対象外——この計算表は中小法人だけを扱う")
    thr = D(ct["annual_threshold"]) * months / 12
    low = min(D(base), thr)
    corp = amt100(low * D(ct["reduced_rate"]) + max(D(base) - thr, D(0)) * D(ct["standard_rate"]))
    line("国税", f"法人税（{int(thr):,} 円以下 {ct['reduced_rate']}・超過分 {ct['standard_rate']}、百円未満切捨て）",
         corp, "出典 No.5759／法人税法66条")
    pending.append(("corp_tax_reduced_expiry", "法人税：軽減税率の期限",
                    "年800万円以下 15% は租税特別措置。適用期限を一次資料で確認していない"))
    corp_base = base1000(corp)
    local_corp = amt100(D(corp_base) * D(nat["local_corporate_tax"]["rate"]))
    line("国税", f"地方法人税（法人税額 {corp_base:,} × {nat['local_corporate_tax']['rate']}）", local_corp,
         "出典 国税庁（地方法人税）")

    # 法人住民税
    loc_p = T["locations"].get(pref) or {}
    loc_c = T["locations"].get(city) or {}
    pref_rate = inputs.get("pref_houjinzeiwari_rate")
    if pref_rate is None:
        raise TaxInputError(f"{pref} の法人住民税（道府県分）法人税割率を corporate_tax.yaml の "
                            f"pref_houjinzeiwari_rate に入れる（一次資料を読めていない）")
    p_wari = amt100(D(corp_base) * D(str(pref_rate)))
    line("住民税", f"道府県民税 法人税割（{corp_base:,} × {pref_rate}）", p_wari, "入力（税率）")
    hw = loc_c.get("houjinzeiwari")
    if hw is None:
        raise TaxInputError(f"{city} の法人市民税の税率データが無い（取り込み済み：大阪市）")
    reduced = capital <= hw["reduced_capital_max"] and corp_base <= hw["reduced_tax_max_annual"] * months / 12
    c_rate = D(hw["reduced_rate"] if reduced else hw["standard_rate"])
    c_wari = amt100(D(corp_base) * c_rate)
    line("住民税", f"市町村民税 法人税割（{corp_base:,} × {c_rate}"
         f"{'・資本金1億円以下かつ法人税額が基準以下の軽減' if reduced else ''}）", c_wari, f"出典 {city}")
    pk = inputs.get("pref_kintou")
    if pk is None:
        raise TaxInputError(f"{pref} の法人住民税（道府県分）均等割を corporate_tax.yaml の pref_kintou に入れる")
    p_kin = amt100(D(pk) * months / 12)
    line("住民税", f"道府県民税 均等割（年 {int(pk):,} × {months}/12）", p_kin, "入力（年額）")
    row = next(r for r in loc_c["kintou"]["table"]
               if r["capital_max"] is None or capital_and_reserve <= r["capital_max"])
    c_year = row["le50"] if employees <= 50 else row["gt50"]
    c_kin = amt100(D(c_year) * months / 12)
    line("住民税", f"市町村民税 均等割（資本金等 {capital_and_reserve:,}・従業者 {employees} 人 → 年 {c_year:,} × {months}/12）",
         c_kin, f"出典 {city}")

    # 法人事業税（所得割）・特別法人事業税
    jz = loc_p.get("jigyouzei_income")
    if jz is None:
        raise TaxInputError(f"{pref} の法人事業税の税率データが無い（取り込み済み：大阪府）")
    excess = inputs.get("jigyouzei_excess")
    if excess is None:
        raise TaxInputError("事業税に超過税率を適用するか（jigyouzei_excess: true/false）を入れる——判定表を読めていない")
    if months != 12:
        pending.append(("jigyouzei_months", "事業税：1年未満の事業年度",
                        "所得の区分（400万・800万）を月数で按分した。按分の規定を一次資料で確認していない"))

    def tiered(rates):
        lo_, hi_ = (D(t) * months / 12 for t in jz["tiers"])
        b = D(base)
        parts = [min(b, lo_), max(min(b, hi_) - lo_, D(0)), max(b - hi_, D(0))]
        return amt100(sum(p * D(r) for p, r in zip(parts, rates)))

    std = tiered(jz["standard"])
    biz = tiered(jz["excess"]) if excess else std
    line("事業税", f"法人事業税 所得割（{'超過' if excess else '標準'}税率 "
         f"{'/'.join(jz['excess'] if excess else jz['standard'])}）", biz, f"出典 {pref}（税率）／入力（適用）")
    sp = amt100(D(std) * D(nat["special_business_tax"]["rate"]))
    line("事業税", f"特別法人事業税（標準税率の所得割 {std:,} × {nat['special_business_tax']['rate']}）", sp,
         "出典 東京都主税局（税率）")

    total = corp + local_corp + p_wari + c_wari + p_kin + c_kin + biz + sp
    paid = inputs.get("interim_paid") or {}
    interim = sum(int(v) for v in paid.values())
    line("合計", "法人税等 合計", total, "")
    line("合計", "中間納付額", -interim, "入力")
    line("合計", "未払法人税等（＝合計 − 中間納付）", total - interim, "")
    return dict(lines=lines, total=total, interim=interim, payable=total - interim, pending=pending,
                corporate=corp, local_corporate=local_corp, pref_wari=p_wari, city_wari=c_wari,
                pref_kintou=p_kin, city_kintou=c_kin, business=biz, special=sp, base=base)


def compute(co, led, month, statements):
    """年度末の月に、帳簿から取れる数字を取り、入力と合わせて計算する。入力が無ければ None。"""
    from .depreciation import fy_bounds
    fs, fe = fy_bounds(month, co.fy_end_month)
    inp = co.corporate_tax.get(f"{fe:%Y-%m}")
    if inp is None:
        return None, f"{fe:%Y-%m} 期の corporate_tax.yaml の入力が無い"
    res = [r for r in led.results if r.month == month][0]
    bs = statements(co, res.tb, month, led)
    tax_accounts = {a for a, x in co.chart.items() if x["section"] == "法人税等"}
    pretax = -sum(v for a, v in bs["ytd"].items() if a not in tax_accounts)
    capital = -res.tb.get(("資本金", ""), 0)
    car = inp.get("capital_and_reserve")
    if car is None:
        car = capital - res.tb.get(("資本準備金", ""), 0)
    emps = inp.get("employees_in_city")
    if emps is None:
        end = month.replace(day=28)
        emps = sum(1 for e in co.employees if e.hired <= end and (e.left is None or e.left >= fe))
    months = (fe.year - fs.year) * 12 + fe.month - fs.month + 1
    adj = inp.get("adjustments") or {}
    add = sum(int(x["amount"]) for x in adj.get("add", []) or [])
    ded = sum(int(x["amount"]) for x in adj.get("deduct", []) or [])
    city = inp.get("municipality") or co.municipality
    r = compute_from(pretax=pretax, add=add, deduct=ded, loss_cf=int(inp.get("loss_carryforward") or 0),
                     capital=capital, capital_and_reserve=car, employees=emps, months=months,
                     pref=co.prefecture, city=city, inputs=inp)
    return r, None
