# -*- coding: utf-8 -*-
"""公表料率・税額表の読み込み。データは product/data/jp/（一次資料から自動生成）。

**期間外は必ずエラー。** 最も近い年度の表に黙って落とすと、年度をまたいだ月の
保険料を静かに間違える（いちばん見つけにくい種類の誤り）。表が無ければ取り込む。

期間の判定軸は料率ごとに違う：
  健康保険・厚生年金   「X月分」の X（3月分〜翌2月分で一年度）
  子ども・子育て支援金  令和8年4月分から（表は3月分から有効——表の期間で判定しない）
  雇用保険            年度（4/1〜3/31）。締日基準か支払日基準かは会社設定
  労災保険            年度（4/1〜3/31）
  源泉徴収税額表       支払日の属する暦年
"""
from __future__ import annotations

import csv
import datetime
import pathlib
from dataclasses import dataclass, field
from decimal import Decimal as D

import yaml

from ..core.money import truncate

DATA = pathlib.Path(__file__).resolve().parents[3] / "data" / "jp"


class RateNotAvailable(LookupError):
    pass


def _d(s) -> datetime.date:
    return s if isinstance(s, datetime.date) else datetime.date.fromisoformat(str(s))


@dataclass(frozen=True)
class Shaho:
    """ある都道府県・ある月分の社会保険料率。"""
    pref: str
    month: datetime.date
    health: D
    care: D
    child_support: D            # 0 なら未適用の月
    pension: D
    child_contribution: D
    source: str

    @property
    def health_total(self) -> D:
        """納入告知書の「健康保険料」欄に入る率（介護非該当）。健保＋支援金。"""
        return self.health + self.child_support

    def health_total_with_care(self) -> D:
        return self.health + self.care + self.child_support


@dataclass
class JpRates:
    data_dir: pathlib.Path = DATA
    _kenpo: dict = field(default=None, init=False, repr=False)
    _table: dict = field(default=None, init=False, repr=False)
    _koyou: dict = field(default=None, init=False, repr=False)
    _rousai: dict = field(default=None, init=False, repr=False)
    _wh: dict = field(default=None, init=False, repr=False)
    _wb: dict = field(default=None, init=False, repr=False)

    def __post_init__(self):
        d = pathlib.Path(self.data_dir)
        load = lambda p: yaml.safe_load(p.read_text(encoding="utf-8"))
        # 年度ごとの表を全部読む。どれを使うかは日付で決める（年度をまたぐ月を正しく計算するため）
        self._kenpos = sorted((load(p) for p in (d / "shakai_hoken").glob("kyoukaikenpo_r*_rates.yaml")),
                              key=lambda k: str(k["effective_from"]))
        self._tables = {}
        for k in self._kenpos:
            t = {}
            with open(d / "shakai_hoken" / f"kyoukaikenpo_{k['year'].lower()}_table.csv", encoding="utf-8") as f:
                for r in csv.DictReader(f):
                    t[(r["pref"], int(r["smr"]))] = r
            self._tables[k["year"]] = t
        grades = {y: sorted({smr for (_, smr) in t}) for y, t in self._tables.items()}
        if len({tuple(g) for g in grades.values()}) > 1:
            raise ValueError(f"年度によって標準報酬月額の等級表が違う：{grades.keys()}——等級の判定を年度別にする必要がある")
        self._kenpo, self._table = self._kenpos[-1], self._tables[self._kenpos[-1]["year"]]
        self._koyous = sorted((load(p) for p in (d / "roudou_hoken").glob("koyou_hoken_r*.yaml")),
                              key=lambda k: str(k["effective_from"]))
        self._rousais = sorted((load(p) for p in (d / "roudou_hoken").glob("rousai_r*.yaml")),
                               key=lambda k: str(k["effective_from"]))
        self._whs = {int(x["year"]): x for x in (load(p) for p in (d / "gensen").glob("withholding_monthly_*.yaml"))}
        self._wbs = {int(x["year"]): x for x in (load(p) for p in (d / "gensen").glob("withholding_bonus_*.yaml"))}
        self._koyou, self._rousai = self._koyous[-1], self._rousais[-1]
        self._wh, self._wb = self._whs[max(self._whs)], self._wbs[max(self._wbs)]
        self._commute = yaml.safe_load((d / "gensen" / "commute_nontaxable_r08.yaml").read_text(encoding="utf-8"))
        self._rules = yaml.safe_load((d / "rules_r08.yaml").read_text(encoding="utf-8"))["rules"]

    # ------------------------------------------------------------ 社会保険
    def prefectures(self):
        return list(self._kenpo["prefectures"])

    @staticmethod
    def _pick(docs, day, what):
        hit = [k for k in docs if _d(k["effective_from"]) <= day <= _d(k["effective_to"])]
        if len(hit) > 1:
            raise RateNotAvailable(f"{day} に {what} が {len(hit)} 枚当たる（期間が重なっている）")
        if not hit:
            have = "、".join(f"{k['effective_from']}〜{k['effective_to']}" for k in docs)
            raise RateNotAvailable(f"{day} の{what}が無い（取り込み済み：{have}）。該当年度の一次資料を取り込むこと")
        return hit[0]

    def shaho(self, pref: str, month: datetime.date) -> Shaho:
        m1 = month.replace(day=1)
        k = self._pick(self._kenpos, m1, "協会けんぽ料率表（料率は毎年3月分で改定）")
        if pref not in k["prefectures"]:
            raise RateNotAvailable(f"都道府県「{pref}」が料率表に無い（{len(k['prefectures'])} 県あり）")
        n = k["national"]
        support = (D(n["child_support"]) if "child_support" in n and m1 >= _d(n["child_support_from"])
                   else D(0))
        return Shaho(pref=pref, month=m1,
                     health=D(k["prefectures"][pref]["health"]),
                     care=D(n["care"]), child_support=support,
                     pension=D(n["pension"]),
                     child_contribution=D(n["child_contribution"]),
                     source=f"協会けんぽ {k['year']} 保険料額表 {pref}（sha256 {k['source']['sha256'][:12]}）")

    def grade_row(self, pref: str, smr: int) -> dict:
        """その標準報酬月額の行（公表表の印字値）。合法な等級値でなければエラー。"""
        r = self._table.get((pref, int(smr)))
        if r is None:
            raise ValueError(f"{smr:,} 円は健康保険の標準報酬月額の等級値ではない")
        return r

    def pension_smr(self, pref: str, smr: int) -> int:
        """厚生年金の標準報酬月額。健保 1〜3 等級は厚年 1 等級（88,000）、
        36 等級以上は厚年 32 等級（650,000）。公表表の「（ ）内の等級」から引く。"""
        r = self.grade_row(pref, smr)
        if r["pension_grade"]:
            return int(r["smr"])
        g = int(r["grade"])
        return 88000 if g < 4 else 650000

    # ------------------------------------------------------------ 労働保険
    def koyou(self, kind: str, basis_date: datetime.date) -> dict:
        k = self._pick(self._koyous, basis_date, "雇用保険料率（年度は4/1〜3/31）")
        if kind not in k["kinds"]:
            raise RateNotAvailable(f"雇用保険の事業の種類「{kind}」が無い：{list(k['kinds'])}")
        v = k["kinds"][kind]
        return dict(worker=D(v["worker"]), employer=D(v["employer"]), total=D(v["total"]),
                    source=f"厚労省 {k['year']} 雇用保険料率 {kind}（{v['printed']}）")

    def rousai(self, code: str, basis_date: datetime.date) -> dict:
        k = self._pick(self._rousais, basis_date, "労災保険率（年度は4/1〜3/31）")
        for x in k["industries"]:
            if x["code"] == str(code):
                return dict(rate=D(x["rate"]), name=x["name"],
                            source=f"厚労省 令和8年度労災保険率 {x['code']} {x['name']}（{x['printed']}）")
        raise RateNotAvailable(f"労災の事業の種類番号「{code}」が無い")

    # ------------------------------------------------------------ 源泉所得税
    def withholding_monthly(self, taxable, dependents: int, column: str,
                            pay_date: datetime.date) -> tuple[int, str]:
        """月額表。taxable は「社会保険料等控除後の給与等の金額」。

        返り値 (税額, 推導の説明)。式で求める区間の円未満は切捨て（rules_r08 gensen_formula_rounding、
        未確認の前提——要確認に載る）。
        """
        wh = self._whs.get(pay_date.year)
        if wh is None:
            raise RateNotAvailable(f"支払日 {pay_date} の源泉徴収税額表が無い（取り込み済み {sorted(self._whs)} 年分）。"
                                   f"支払日の属する年の表を使う")
        x = D(taxable)
        if x < 0:
            raise ValueError("社会保険料等控除後の金額が負")
        n = int(dependents)
        if column == "kou":
            th = wh["below_threshold"]["at"]
            if x < th:
                return 0, f"月額表 甲欄：{th:,}円未満は 0（{pay_date.year}年分）"
            for b in wh["brackets"]:
                if b["lower"] <= x < b["upper"]:
                    base = b["kou"][min(n, 7)]
                    extra = max(0, n - 7) * wh["per_dependent_over_7"]
                    tax = max(0, base - extra)
                    return tax, (f"月額表 甲欄 {b['lower']:,}〜{b['upper']:,}未満・扶養{n}人 → {tax:,}"
                                 + (f"（7人超 {n - 7}人×1,610 控除）" if extra else ""))
            anchors = wh["anchors"]
            a = [an for an in anchors if an["at"] <= x][-1]
            base = D(a["kou"][min(n, 7)]) + (x - a["at"]) * D(a["kou_rate"]) / 100
            tax = int(truncate(base)) - max(0, n - 7) * wh["per_dependent_over_7"]
            return max(0, tax), (f"月額表 甲欄 式：{a['at']:,}円の税額 {a['kou'][min(n, 7)]:,}＋"
                                 f"超過分×{a['kou_rate']}%（円未満切捨て・要確認の前提）→ {tax:,}")
        if column == "otsu":
            th = wh["below_threshold"]["at"]
            if x < th:
                tax = int(truncate(x * D(wh["below_threshold"]["otsu_rate"]) / 100))
                return tax, f"月額表 乙欄：{th:,}円未満は 3.063% → {tax:,}（{pay_date.year}年分）"
            for b in wh["brackets"]:
                if b["lower"] <= x < b["upper"]:
                    return b["otsu"], f"月額表 乙欄 {b['lower']:,}〜{b['upper']:,}未満 → {b['otsu']:,}"
            rule = [r for r in wh["otsu_rules"] if r["over"] <= x][-1]
            tax = int(truncate(D(rule["base"]) + (x - rule["over"]) * D(rule["rate"]) / 100))
            return tax, f"月額表 乙欄 式：{rule['base']:,}＋{rule['over']:,}円超過分×{rule['rate']}% → {tax:,}"
        raise ValueError(f"源泉の欄は kou / otsu：{column}")

    def general_contribution(self) -> D:
        """一般拠出金率（石綿健康被害救済）。rules_r08.general_contribution。"""
        return D(self._rules["general_contribution"]["rate"])

    def commute_limit(self, c: dict, pay_date: datetime.date) -> tuple[int | None, str]:
        """通勤手当の 1か月当たり非課税限度額。決められなければ (None, 理由)。

        c = {mode: transit, pass_monthly: 定期代}
          | {mode: car, one_way_km: 片道km, parking: 駐車場代（任意）, toll: 有料道路（任意）}
          | {mode: mixed, pass_monthly: …, one_way_km: …}
        """
        k = self._commute
        if pay_date < _d(k["as_of"]):
            return None, f"非課税限度の表は {k['as_of']} 現在のもの。それより前の支払は未対応"
        mode = c.get("mode")
        def car_part():
            km = D(str(c["one_way_km"]))
            amt = next(b[2] for b in k["car"]["bands"] if D(b[0]) <= km and (b[1] is None or km < D(b[1])))
            if km >= 2:
                amt += min(int(c.get("parking", 0)), k["car"]["parking_cap"])
            return amt, km
        if mode == "transit":
            lim = min(int(c["pass_monthly"]), k["transit"]["monthly_cap"])
            return lim, f"交通機関：定期代 {int(c['pass_monthly']):,}（上限 {k['transit']['monthly_cap']:,}）→ {lim:,}（No.2582）"
        if mode == "car":
            amt, km = car_part()
            if c.get("toll"):
                amt = min(amt + int(c["toll"]), k["car"]["toll_total_cap"])
            return amt, f"マイカー等：片道 {km} km → {amt:,}（No.2585、駐車場・有料道路を含む）"
        if mode == "mixed":
            amt, km = car_part()
            lim = min(int(c["pass_monthly"]) + amt, k["car"]["combined_with_transit_cap"])
            return lim, f"交通機関＋マイカー等：{int(c['pass_monthly']):,}＋{amt:,} → {lim:,}（No.2582）"
        return None, "通勤方法（commute.mode：transit / car / mixed）が名簿に無い"

    def withholding_uses_formula(self, taxable, column: str, pay_date: datetime.date | None = None) -> bool:
        """月額表を「式」で計算する区間か（円未満の端数処理が表に明記されていない区間）。

        説明文に「式」という字があるかで判定してはいけない——乙欄の 105,000 円未満は
        3.063% の式なのに説明文に「式」の字が無く、要確認が出なかった（実例）。
        """
        x = D(taxable)
        wh = self._whs.get(pay_date.year) if pay_date else self._wh
        last = (wh or self._wh)["brackets"][-1]["upper"]
        if column == "kou":
            return x >= last
        return x < (wh or self._wh)["below_threshold"]["at"] or x >= last

    def withholding_bonus_rate(self, prev_month_taxable, dependents: int, column: str,
                               pay_date: datetime.date) -> tuple[D, str]:
        """賞与の算出率。前月の社会保険料等控除後の給与等の金額で引く。"""
        wb = self._wbs.get(pay_date.year)
        if wb is None:
            raise RateNotAvailable(f"支払日 {pay_date} の賞与算出率表が無い（取り込み済み {sorted(self._wbs)} 年分）")
        x = D(prev_month_taxable)
        rows = wb["otsu"] if column == "otsu" else wb["kou"][str(min(int(dependents), 7))]
        for r in rows:
            if (r["lower"] is None or r["lower"] <= x) and (r["upper"] is None or x < r["upper"]):
                return D(r["rate"]), f"賞与算出率表 {column} 扶養{dependents}人 前月 {x:,} → {r['rate']}%"
        raise AssertionError("賞与算出率表に該当行が無い——表の取り込みが壊れている")
