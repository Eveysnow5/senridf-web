# -*- coding: utf-8 -*-
"""営業日と納期限。

⚠️ jpholiday は**年末年始（12/29〜1/3）を休日として返さない**。しかしこの期間は
「行政機関の休日に関する法律」の休日で、納期限の翌営業日繰越しに効く。
既成モジュールをそのまま信じると 12月分・1月分の納期限を静かに間違える。
"""
from __future__ import annotations

import calendar as _cal
import datetime

import jpholiday

GOVT_YEAR_END = {(12, 29), (12, 30), (12, 31), (1, 2), (1, 3)}


def is_business_day(d: datetime.date) -> bool:
    if d.weekday() >= 5:
        return False
    if jpholiday.is_holiday(d):
        return False
    return (d.month, d.day) not in GOVT_YEAR_END


def next_business_day(d: datetime.date) -> datetime.date:
    while not is_business_day(d):
        d += datetime.timedelta(days=1)
    return d


def month_end(year: int, month: int) -> datetime.date:
    return datetime.date(year, month, _cal.monthrange(year, month)[1])


def add_months(d: datetime.date, n: int) -> datetime.date:
    """その月の 1 日を返す（月の加減算だけに使う）。"""
    y, m = divmod(d.year * 12 + d.month - 1 + n, 12)
    return datetime.date(y, m + 1, 1)


def due(base: datetime.date, rule: str) -> tuple[datetime.date, str]:
    """納期限。base はその月（X月分）の任意の日。

    rule:
      next_month_end  翌月末日（社会保険料）
      next_month_10   翌月10日（源泉所得税・住民税の原則）
    返り値の第 2 要素は推導チェーンに残す説明。
    """
    nm = add_months(base, 1)
    if rule == "next_month_end":
        raw = month_end(nm.year, nm.month)
    elif rule == "next_month_10":
        raw = nm.replace(day=10)
    else:
        raise ValueError(f"未知の納期規則 {rule}")
    d = next_business_day(raw)
    note = f"{raw} {'' if d == raw else f'は休日 → 翌営業日 {d}'}".strip()
    return d, note


def age_reached_on(birth: datetime.date, age: int) -> datetime.date:
    """満 age 歳に達する日＝誕生日の**前日**（年齢計算ニ関スル法律）。"""
    try:
        bd = birth.replace(year=birth.year + age)
    except ValueError:                      # 2/29 生まれ
        bd = datetime.date(birth.year + age, 3, 1)
    return bd - datetime.timedelta(days=1)


def is_care_insured(birth: datetime.date, month: datetime.date) -> bool:
    """介護保険第2号被保険者か（その月分の介護保険料がかかるか）。

    満40歳に達した日の属する月から、満65歳に達した日の属する月の前月まで。
    1日生まれは「前日」が前月末なので、前月から該当する。
    出典：rules_r08.yaml care_insurance_age
    """
    m = (month.year, month.month)
    s = age_reached_on(birth, 40)
    e = age_reached_on(birth, 65)
    return (s.year, s.month) <= m < (e.year, e.month)
