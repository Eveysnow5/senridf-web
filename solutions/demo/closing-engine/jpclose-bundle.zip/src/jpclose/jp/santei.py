# -*- coding: utf-8 -*-
"""算定基礎届（定時決定）の計算表（作者 2026-10-14：申告の書類は道具が作り、税理士・社労士が確かめて出す）。

**届書そのものではない。** 届書に要る被保険者整理番号・個人番号（基礎年金番号）はこの道具の資料に無い。
ここで作るのは、届書の数字（4〜6 月の報酬・支払基礎日数・平均・新しい標準報酬月額）を計算した表。

決まり（日本年金機構「算定基礎届の記入・提出ガイドブック」の考え方。この道具が扱う範囲だけ）：
  · 対象：7 月 1 日に被保険者である人。6 月 1 日以後に資格を取った人・6 月 30 日までに退職した人は対象外
  · 4・5・6 月に**支払った**報酬（働いた月ではなく支払った月）
  · 支払基礎日数が 17 日未満の月は除く（月給：その支払の計算期間の暦日数。入社・退社の月は在籍した日数）
  · 残った月の報酬の平均（円未満切捨て）を、その年度の保険料額表の報酬月額の範囲に当てて標準報酬月額にする
  · 3 か月とも 17 日未満なら、従前の標準報酬月額（保険者決定になりうる。表に書く）
この道具が知らないこと（表に「前提」として書く）：
  · 欠勤控除をした月の支払基礎日数（就業規則の所定日数で数える会社がある）→ 暦日数で数えている
  · 短時間労働者（11 日基準）・パート（15 日基準）の扱い → 一般の 17 日基準だけ
  · 報酬は給与明細の支給額の合計（通勤手当を含む）。臨時の支払（慶弔見舞金など）を給与に入れていれば除いてください
  · 随時改定（7〜9 月改定）の人は算定の対象外になる → 判定していない
新しい標準報酬月額は 9 月分（10 月納付分）から。
"""
from __future__ import annotations

import datetime
import html

from ..payroll import closing_date_for
from .calendar import add_months

MIN_DAYS = 17


def _period(co, pay_month: datetime.date) -> tuple:
    end = closing_date_for(co, pay_month)
    prev = closing_date_for(co, add_months(pay_month.replace(day=1), -1))
    return prev + datetime.timedelta(days=1), end


def grade_for(rates, pref: str, pay: int) -> dict | None:
    """報酬月額 → 保険料額表の行（lower ≦ 報酬 ＜ upper）。表は印字値（rates._table）。"""
    for (p, smr), row in sorted(rates._table.items(), key=lambda x: x[0][1]):
        if p != pref:
            continue
        lo = int(row["lower"]) if row.get("lower") not in (None, "") else 0
        hi = int(row["upper"]) if row.get("upper") not in (None, "") else None
        if lo <= pay and (hi is None or pay < hi):
            return row
    return None


def compute(co, rates, slips: list, year: int) -> dict:
    """slips：締めた期間の給与明細（Payslip）すべて。4〜6 月に支払った分を使う。"""
    rows, skipped = [], []
    july1 = datetime.date(year, 7, 1)
    for e in co.employees:
        if not e.shaho:
            continue
        if e.hired >= datetime.date(year, 6, 1):
            skipped.append(dict(eid=e.id, name=e.display, why="hired_june"))
            continue
        if e.left is not None and e.left < july1:                 # 6/30 までに退職＝7/1 には被保険者でない
            skipped.append(dict(eid=e.id, name=e.display, why="left"))
            continue
        months = []
        for m in (4, 5, 6):
            s = next((x for x in slips if x.eid == e.id and x.pay_date.year == year and x.pay_date.month == m), None)
            if s is None:
                months.append(dict(month=m, pay=None, days=None, used=False, why="no_slip"))
                continue
            start, end = _period(co, s.pay_month)
            start = max(start, e.hired)
            if e.left is not None:
                end = min(end, e.left)
            days = (end - start).days + 1
            months.append(dict(month=m, pay=s.gross, days=days, used=days >= MIN_DAYS,
                               why="" if days >= MIN_DAYS else "days"))
        cur = e.smr_for(datetime.date(year, 6, 1))
        current = cur[1] if cur else None
        used = [x for x in months if x["used"]]
        missing = [x["month"] for x in months if x["why"] == "no_slip"]
        if missing:
            rows.append(dict(eid=e.id, name=e.display, birth=str(e.birth), months=months, total=None, average=None,
                             current=current, new=None, pension_new=None, change=None, status="missing", missing=missing))
            continue
        if not used:
            rows.append(dict(eid=e.id, name=e.display, birth=str(e.birth), months=months, total=None, average=None,
                             current=current, new=current, pension_new=rates.pension_smr(co.prefecture, current) if current else None,
                             change=0, status="previous"))
            continue
        total = sum(x["pay"] for x in used)
        avg = total // len(used)
        row = grade_for(rates, co.prefecture, avg)
        new = int(row["smr"]) if row else None
        change = None
        if row and current:
            change = int(row["grade"]) - int(rates.grade_row(co.prefecture, current)["grade"])
        rows.append(dict(eid=e.id, name=e.display, birth=str(e.birth), months=months, total=total, average=avg,
                         current=current, new=new, pension_new=rates.pension_smr(co.prefecture, new) if new else None,
                         change=change, status="ok"))
    return dict(year=year, applies_from=f"{year}-09", rows=rows, skipped=skipped)


L = {
    "ja": dict(title="算定基礎届の計算表（{y} 年）", note="届書そのものではありません。届書に要る被保険者整理番号・個人番号は、この表にありません。"
               "数字を確かめてから、届書（電子申請・紙）に写してください。新しい標準報酬月額は {y} 年 9 月分（10 月納付分）からです。",
               emp="被保険者", birth="生年月日", m="{m} 月", pay="報酬", days="日数", total="総計", avg="平均", cur="従前", new="新しい標準報酬月額",
               pen="（厚生年金）", chg="等級の変化", excluded="除外（17 日未満）", none="給与なし", missing="{ms} 月の給与がこの期間にありません。その月を含めて締め直してください",
               previous="3 か月とも 17 日未満：従前の標準報酬月額（保険者決定になることがあります）", skipped="対象外",
               hired_june="6 月 1 日以後の資格取得", left="6 月 30 日までに退職",
               assume="前提：支払基礎日数は計算期間の暦日数（入社・退社の月は在籍日数）で数えています。欠勤控除をした月・短時間労働者は、"
               "所定の数え方で確かめてください。報酬は給与明細の支給額の合計（通勤手当を含む）です。随時改定の対象者は判定していません。"),
    "zh": dict(title="算定基礎届计算表（{y} 年）", note="这不是届书本身。届书需要的被保险人整理番号、个人番号不在这张表里。"
               "核对数字后，再抄到届书（电子申请或纸质）上。新的标准报酬月额从 {y} 年 9 月份（10 月缴纳）起适用。",
               emp="被保险人", birth="出生日期", m="{m} 月", pay="报酬", days="天数", total="合计", avg="平均", cur="原等级", new="新的标准报酬月额",
               pen="（厚生年金）", chg="等级变化", excluded="排除（不足 17 天）", none="无工资", missing="这次结账期间里没有 {ms} 月的工资。请把那个月也包括进来重新结账",
               previous="3 个月都不足 17 天：沿用原标准报酬月额（可能由保险人决定）", skipped="不在范围内",
               hired_june="6 月 1 日以后取得资格", left="6 月 30 日前离职",
               assume="前提：支付基础日数按计算期间的日历天数（入职、离职当月按在职天数）计算。有缺勤扣款的月份、短时间劳动者，"
               "请按规定的算法核对。报酬是工资单支给额合计（含通勤补贴）。没有判定随时改定的对象。"),
    "en": dict(title="Santei kiso todoke worksheet ({y})", note="This is not the filing itself: the insured person numbers and My Number are not here. "
               "Check the figures, then copy them to the filing. The new standard monthly remuneration applies from September {y} (paid in October).",
               emp="Insured person", birth="Born", m="{m}", pay="Pay", days="Days", total="Total", avg="Average", cur="Current", new="New standard remuneration",
               pen="(pension)", chg="Grade change", excluded="excluded (under 17 days)", none="no pay", missing="Pay for month {ms} is not in this close. Close again including that month",
               previous="All three months under 17 days: the current remuneration stays (the insurer may decide)", skipped="Not covered",
               hired_june="joined on or after 1 June", left="left by 30 June",
               assume="Assumptions: payment days are calendar days of the pay period (days employed in joining or leaving months). "
               "Check months with absence deductions and short-time workers by the prescribed method. Pay is the payslip total, including commuting allowance. Mid-year revisions are not judged."),
}


def html_report(res: dict, company: str, lang: str = "ja") -> str:
    t = L.get(lang, L["ja"])
    y = res["year"]
    esc = html.escape
    yen = lambda n: "" if n is None else f"{int(n):,}"
    head = "".join(f"<th>{esc(t['m'].format(m=m))}<br>{esc(t['pay'])}／{esc(t['days'])}</th>" for m in (4, 5, 6))
    body = []
    for r in res["rows"]:
        cells = []
        for x in r["months"]:
            if x["pay"] is None:
                cells.append(f"<td class='na'>{esc(t['none'])}</td>")
            else:
                mark = "" if x["used"] else f"<br><span class='na'>{esc(t['excluded'])}</span>"
                cells.append(f"<td class='num'>{yen(x['pay'])}／{x['days']}{mark}</td>")
        if r["status"] == "missing":
            tail = f"<td colspan='5' class='warn'>{esc(t['missing'].format(ms='・'.join(map(str, r['missing']))))}</td>"
        elif r["status"] == "previous":
            tail = f"<td colspan='5' class='warn'>{esc(t['previous'])}：{yen(r['current'])}</td>"
        else:
            chg = "" if r["change"] is None else (f"{r['change']:+d}" if r["change"] else "±0")
            tail = (f"<td class='num'>{yen(r['total'])}</td><td class='num'>{yen(r['average'])}</td><td class='num'>{yen(r['current'])}</td>"
                    f"<td class='num'><b>{yen(r['new'])}</b><br><span class='na'>{esc(t['pen'])} {yen(r['pension_new'])}</span></td>"
                    f"<td class='num'>{chg}</td>")
        body.append(f"<tr><td>{esc(r['eid'])} {esc(r['name'])}<br><span class='na'>{esc(t['birth'])} {esc(r['birth'])}</span></td>"
                    + "".join(cells) + tail + "</tr>")
    skipped = "".join(f"<li>{esc(s['eid'])} {esc(s['name'])}：{esc(t[s['why']])}</li>" for s in res["skipped"])
    return (f"<!doctype html><html lang='{lang}'><head><meta charset='utf-8'><title>{esc(t['title'].format(y=y))}</title>"
            "<style>body{font-family:system-ui,sans-serif;margin:24px;color:#111827}table{border-collapse:collapse;font-size:13px}"
            "th,td{border:1px solid #e5e7eb;padding:5px 8px;vertical-align:top}th{background:#f9fafb}.num{text-align:right;white-space:nowrap}"
            ".na{color:#6b7280;font-size:11.5px}.warn{color:#92400e}p{max-width:60em;line-height:1.7}</style></head><body>"
            f"<h1 style='font-size:18px'>{esc(company)}：{esc(t['title'].format(y=y))}</h1>"
            f"<p>{esc(t['note'].format(y=y))}</p>"
            f"<table><tr><th>{esc(t['emp'])}</th>{head}<th>{esc(t['total'])}</th><th>{esc(t['avg'])}</th><th>{esc(t['cur'])}</th>"
            f"<th>{esc(t['new'])}</th><th>{esc(t['chg'])}</th></tr>{''.join(body)}</table>"
            + (f"<h2 style='font-size:15px'>{esc(t['skipped'])}</h2><ul>{skipped}</ul>" if skipped else "")
            + f"<p class='na'>{esc(t['assume'])}</p></body></html>")
