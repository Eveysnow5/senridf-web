# -*- coding: utf-8 -*-
"""労働保険の年度更新（確定保険料・一般拠出金・概算保険料）の計算表と、納付時の仕訳。

作者の決定（2026-10-09）：**会計基準を優先し、合法な範囲で会計担当者に操作の余地を残す。**
  · 計算（申告書の数字）は製品が導出する（rules_r08.labor_annual_*、一次資料の原文あり）
  · 仕訳の方法は会社方針 labor_insurance_expense で選ぶ
      monthly_accrual  発生主義（会計基準に沿う）：毎月の会社負担を未払費用で見積計上し、
                       年度更新の納付は仮払金に置いて、前年度分を確定額で精算する
      on_payment       簡便法（金額的重要性が乏しい場合）：納付時に、前年度に給与から控除した
                       被保険者負担（預り金）を消し込み、残りを法定福利費とする

入力（会社ディレクトリ labor_insurance.yaml。判断・事実なので by・at 必須）：
  fiscal_year            確定する保険年度の開始年（2025 → 2025-04〜2026-03）
  wages_before_start     開始月より前に支払った、その年度の賃金 {koyou, rousai}
  estimate_paid          前年度に申告・納付した概算保険料
  withheld_employee      その年度に給与から控除した雇用保険料のうち開始月より前の分
  accrued_employer       （monthly_accrual のとき）その年度に見積計上した会社負担のうち開始月より前の分
  installment            延納するか（要件を満たすときだけ有効）
  estimate_base          今年度の見込額（前年度の 1/2〜2 倍の外のときだけ書く）
"""
from __future__ import annotations

import datetime
from dataclasses import dataclass, field
from decimal import Decimal as D

from ..core.money import truncate
from .calendar import next_business_day


@dataclass
class AnnualCalc:
    fiscal_year: int
    koyou_base: int
    rousai_base: int
    final_premium: int            # 確定保険料
    general_contribution: int     # 一般拠出金
    estimate_base: int
    estimate_premium: int         # 概算保険料
    estimate_paid: int            # 前年度に納付した概算
    difference: int               # 確定 − 前年度概算（正：不足、負：超過→充当）
    installment_eligible: bool
    installment: bool
    due: datetime.date
    payment: int                  # 7/10 に納める額
    withheld_prior: int           # 前年度に控除した被保険者負担
    accrued_prior: int            # 前年度に見積計上した会社負担
    lines: list = field(default_factory=list)      # 計算表の行（説明, 金額）
    pending: list = field(default_factory=list)


def _premium(koyou_base, rousai_base, r_koyou, r_rousai):
    """両方の基礎額が同じなら合計料率で 1 回切捨て、違えば別々に切捨て（rules labor_annual_premium_rounding）。"""
    if koyou_base == rousai_base:
        return int(truncate(D(koyou_base) * (r_koyou + r_rousai))), "基礎額が同額なので合計料率で計算して切捨て"
    return (int(truncate(D(koyou_base) * r_koyou)) + int(truncate(D(rousai_base) * r_rousai)),
            "基礎額が違うので別々に計算して切捨て")


def compute(co, rates, led, year: int):
    """year の 6〜7 月に行う年度更新。前年度＝(year-1)-04-01〜year-03-31。"""
    inp = co.labor_annual.get(year - 1)
    if inp is None:
        return None
    lo, hi = datetime.date(year - 1, 4, 1), datetime.date(year, 3, 31)
    k_run = r_run = w_run = a_run = 0
    for res in led.results:
        for s in res.slips:
            if lo <= s.pay_date <= hi:
                e = co.emp(s.eid)
                if e.koyou:
                    k_run += s.koyou_wage
                    w_run += s.koyou
                if e.role == "employee":
                    r_run += s.koyou_wage
        for b in res.bonuses:
            if lo <= b.pay_date <= hi:
                e = co.emp(b.eid)
                if e.koyou:
                    k_run += b.amount
                    w_run += b.koyou
                if e.role == "employee":
                    r_run += b.amount
        if lo <= res.month <= hi:
            a_run += res.labor_accrual
    before = inp.get("wages_before_start") or {}
    koyou_base = (int(before.get("koyou", 0)) + k_run) // 1000 * 1000
    rousai_base = (int(before.get("rousai", 0)) + r_run) // 1000 * 1000
    kr = rates.koyou(co.koyou_kind, hi)["total"]
    rr = rates.rousai(co.rousai_code, hi)["rate"]
    final, how = _premium(koyou_base, rousai_base, kr, rr)
    gc = int(truncate(D(rousai_base) * rates.general_contribution()))
    pending = []
    # 概算：見込額が前年度の 1/2〜2 倍なら前年度の賃金総額をそのまま使う
    est_base = koyou_base
    if inp.get("estimate_base"):
        est_base = int(inp["estimate_base"]) // 1000 * 1000
    else:
        pending.append((f"labor_estimate:{year}", "年度更新：概算の見込額",
                        f"今年度の賃金見込額が前年度（{koyou_base:,}）の 1/2〜2 倍に収まる前提で、前年度の額を使った。"
                        f"外れるなら labor_insurance.yaml の estimate_base に見込額を書く（rules labor_annual_estimate）"))
    new_day = datetime.date(year, 4, 1)
    nk = rates.koyou(co.koyou_kind, new_day)["total"]
    nr = rates.rousai(co.rousai_code, new_day)["rate"]
    est, how2 = _premium(est_base, est_base, nk, nr)
    paid = int(inp["estimate_paid"])
    diff = final - paid
    eligible = est >= 400000
    inst = bool(inp.get("installment")) and eligible
    if inp.get("installment") and not eligible:
        pending.append((f"labor_installment:{year}", "年度更新：延納の要件",
                        f"延納が指定されているが、概算保険料 {est:,} は 40 万円未満で延納できない（rules labor_annual_installment）"))
    if inst:
        pending.append((f"labor_installment_split:{year}", "年度更新：延納の各期の額",
                        "3 回分割したときの各期の額（端数の寄せ方）は一次資料で未確認。第 1 期を 1/3（円未満切捨て）とした"))
    first = est // 3 if inst else est
    due = next_business_day(datetime.date(year, 7, 10))
    payment = first + diff + gc
    withheld = int(inp.get("withheld_employee", 0)) + w_run
    accrued = int(inp.get("accrued_employer", 0)) + a_run
    lines = [
        (f"確定 雇用保険 算定基礎額（{lo}〜{hi}、千円未満切捨て）", koyou_base),
        (f"確定 労災保険 算定基礎額", rousai_base),
        (f"確定保険料（雇用 {kr}＋労災 {rr}、{how}）", final),
        (f"一般拠出金（労災基礎額 × {rates.general_contribution()}）", gc),
        (f"概算 算定基礎額（{year}-04〜）", est_base),
        (f"概算保険料（雇用 {nk}＋労災 {nr}、{how2}）", est),
        ("前年度に納付した概算保険料", paid),
        ("差引（確定 − 前年度概算。負なら超過分を今年度の概算に充当）", diff),
        (f"延納：{'する（第1期）' if inst else ('要件を満たすが一括' if eligible else '要件を満たさない（40万円未満）')}", first),
        (f"{due} までに納付する額（概算{'第1期' if inst else ''}＋差引＋一般拠出金）", payment),
        ("参考：前年度に給与から控除した雇用保険料（被保険者負担）", withheld),
    ]
    if co.policy["labor_insurance_expense"] == "monthly_accrual":
        lines.append(("参考：前年度に見積計上した会社負担", accrued))
    return AnnualCalc(year - 1, koyou_base, rousai_base, final, gc, est_base, est, paid, diff, eligible, inst,
                      due, payment, withheld, accrued, lines, pending)
