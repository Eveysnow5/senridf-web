# -*- coding: utf-8 -*-
"""「待処理」をこの画面で直す：要確認ごとの小さな入力欄と、その値を会社の資料に書き込む処理。

作者 2026-10-10（工作台 v2）：「住民税の月額が無い」のような事項は、Excel を開かずに画面で埋めたい。
ここで直すのは**事実の入力**だけ（月額・通勤方法・根拠書類・前年度の数字）。性質の判断は回答（decisions）。

書き込み先は作業フォルダの YAML（ブック入力ならブックから変換したもの）。ブック入力なら web.run が
ブックを作り直して返し（回答と同じ道）、YAML 入力なら変えたファイルの中身を返して画面が書き戻す。
値は必ず検証する（負の月額、空の必須欄、知らない選択肢は拒否——黙って入れない）。
"""
from __future__ import annotations

import datetime
import pathlib

import yaml


class FixError(ValueError):
    pass


# 種類 → 入力欄。name は画面の文言キー ce_fx_<name>。kind: int / num / text / select / bool
FORMS = {
    "juminzei_missing": [dict(name="amount", kind="int", required=True),
                         dict(name="until_may", kind="bool")],
    "commute_limit": [dict(name="mode", kind="select", options=["transit", "car"], required=True),
                      dict(name="pass_monthly", kind="int"), dict(name="one_way_km", kind="num"),
                      dict(name="parking", kind="int")],
    "smr_evidence": [dict(name="evidence", kind="text", required=True)],
    "labor_annual": [dict(name="wages_koyou", kind="int", required=True),
                     dict(name="wages_rousai", kind="int", required=True),
                     dict(name="estimate_paid", kind="int", required=True),
                     dict(name="withheld_employee", kind="int", required=True),
                     dict(name="installment", kind="bool")],
}
FILES = {"juminzei_missing": "employees.yaml", "commute_limit": "employees.yaml", "smr_evidence": "employees.yaml",
         "labor_annual": "labor_insurance.yaml"}


def form_for(key: str):
    kind = key.split(":", 1)[0]
    if kind not in FORMS:
        return None
    return dict(kind=kind, fields=FORMS[kind])


def _val(f, v):
    if v in (None, ""):
        if f.get("required"):
            raise FixError(f"{f['name']} が空")
        return None
    k = f["kind"]
    if k in ("int", "num"):
        try:
            x = int(str(v).replace(",", "")) if k == "int" else float(str(v))
        except (TypeError, ValueError):
            raise FixError(f"{f['name']} が数でない：{v!r}") from None
        if x < 0:                                  # try の外で（FixError は ValueError なので中だと言い換えられる）
            raise FixError(f"{f['name']} が負：{v}")
        return x
    if k == "bool":
        return v in (True, "true", "1", 1, "on")
    if k == "select" and v not in f["options"]:
        raise FixError(f"{f['name']} は {f['options']} のどれか：{v!r}")
    return str(v).strip()


def _load(p):
    return (yaml.safe_load(p.read_text(encoding="utf-8")) if p.exists() else None) or {}


def _dump(p, d):
    p.write_text(yaml.safe_dump(d, allow_unicode=True, sort_keys=False, width=200), encoding="utf-8")


def _employee(d, eid):
    for e in d.get("employees", []):
        if str(e.get("id")) == eid:
            return e
    raise FixError(f"従業員 {eid} が名簿に無い")


def apply(company_dir, key: str, values: dict, by: str, at: str) -> str:
    """一件の修正を作業フォルダの YAML に書く。書いたファイル名を返す。"""
    form = form_for(key)
    if not form:
        raise FixError(f"この要確認は画面で直せない：{key}")
    if not by:
        raise FixError("判断者（by）が空")
    v = {f["name"]: _val(f, (values or {}).get(f["name"])) for f in form["fields"]}
    parts = key.split(":")
    root = pathlib.Path(company_dir)
    name = FILES[form["kind"]]
    p = root / name
    d = _load(p)
    if form["kind"] == "juminzei_missing":          # juminzei_missing:<eid>:<YYYY-MM>
        e = _employee(d, parts[1])
        month = datetime.date.fromisoformat(parts[2] + "-01")
        jm = {str(k)[:7]: val for k, val in (e.get("juminzei") or {}).items()}
        jm[f"{month:%Y-%m}"] = v["amount"]
        if v.get("until_may"):                     # 特別徴収の年度は 6 月〜翌 5 月
            m = month
            while not (m.month == 5):
                m = datetime.date(m.year + (m.month == 12), m.month % 12 + 1, 1)
                jm.setdefault(f"{m:%Y-%m}", v["amount"])
        e["juminzei"] = dict(sorted(jm.items()))
    elif form["kind"] == "commute_limit":           # commute_limit:<eid>
        e = _employee(d, parts[1])
        if v["mode"] == "transit" and not v.get("pass_monthly"):
            raise FixError("公共交通機関なら 1 か月の定期代（pass_monthly）が要る")
        if v["mode"] == "car" and not v.get("one_way_km"):
            raise FixError("マイカーなら片道の距離（one_way_km）が要る")
        c = {"mode": v["mode"]}
        for k in ("pass_monthly", "one_way_km", "parking"):
            if v.get(k):
                c[k] = v[k]
        e["commute"] = c
    elif form["kind"] == "smr_evidence":            # smr_evidence:<eid>
        e = _employee(d, parts[1])
        n = 0
        for s in e.get("smr", []) or []:
            if not s.get("evidence"):
                s["evidence"] = v["evidence"]
                n += 1
        if not n:
            raise FixError(f"{parts[1]} の標準報酬月額に根拠の無い行が無い")
    elif form["kind"] == "labor_annual":            # labor_annual:<年度更新の年>（前年度を確定する）
        fy = int(parts[1]) - 1
        rows = [a for a in d.setdefault("annual", []) or [] if int(a.get("fiscal_year", 0)) != fy]
        rows.append({"fiscal_year": fy,
                     "wages_before_start": {"koyou": v["wages_koyou"], "rousai": v["wages_rousai"]},
                     "estimate_paid": v["estimate_paid"], "withheld_employee": v["withheld_employee"],
                     "installment": bool(v.get("installment")), "by": by, "at": at,
                     "reason": "画面で入力（前年度の賃金台帳・申告書控えから）"})
        d["annual"] = sorted(rows, key=lambda a: int(a["fiscal_year"]))
    _dump(p, d)
    return name


def apply_all(company_dir, edits: dict, today: str) -> list[str]:
    """{key: {値…, by}} をすべて書く。変えたファイル名（重複なし）を返す。"""
    changed = []
    for key, vals in (edits or {}).items():
        name = apply(company_dir, key, vals, str((vals or {}).get("by") or "").strip(), today)
        if name not in changed:
            changed.append(name)
    return changed
