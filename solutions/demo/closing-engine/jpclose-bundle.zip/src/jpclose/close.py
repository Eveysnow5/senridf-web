# -*- coding: utf-8 -*-
"""月次決算。

開始月（company.start_month）から目標月まで**毎回順に計算し直す**。前月の結果を
ファイルに保存して読み戻すことはしない——保存した中間状態は、入力を直したときに
古いまま残って食い違う。月数が少ないうちはこれがいちばん安全で速い。

各月の手順：
  1. 給与（その月に支払う分）→ 給与仕訳
  2. 予定支払を作る：給与振込・社保（納期限がこの月に来る月分）・源泉・住民税
     ※ 納期限は営業日で繰り越すので、「4月分の社保」が 6/1 になって 6 月に来ることがある
  3. 銀行明細を取り込み、残高連鎖を確認
  4. 予定を明細に照合 → 仕訳。残りは銀行ルール → 仕訳。残りは要確認（回答があれば仕訳）
  5. 月末：会社負担社保の未払計上（方針が accrual のとき）、減価償却
  6. 試算表・貸借対照表・損益計算書
  7. 断言
"""
from __future__ import annotations

import datetime
from collections import defaultdict
from dataclasses import dataclass, field

from . import bank as bankmod
from . import journal, payroll
from .core import checks as C
from .core.model import Voucher
from .jp import depreciation as dep
from .jp.calendar import add_months, due, month_end
from .jp.rates import JpRates
from .pending import Pending, PendingBook

def _m(d):
    return d.replace(day=1)


def _fy_start(month, fy_end):
    return dep.fy_bounds(month, fy_end)[0]


@dataclass
class MonthResult:
    month: datetime.date
    slips: list
    vouchers: list
    bank_rows: dict                  # bank_id → rows（この月の分）
    all_bank_rows: dict
    match: dict                      # bank_id → MatchResult
    ruled: dict                      # bank_id → set(row ids)
    pending_rows: dict               # bank_id → set(row ids)
    notices: dict                    # month → Notice
    expected: list
    report: C.Report = None
    tb: dict = None                  # (account, sub) → 借方正の残高
    tb_open: dict = None
    bonuses: list = field(default_factory=list)
    labor_accrual: int = 0           # この月に見積計上した労働保険の会社負担
    labor_calc: object = None        # この月に作った年度更新の計算表
    corp_tax: object = None          # 年度末の月に作った法人税等の計算表


@dataclass
class Ledger:
    co: object
    rates: JpRates
    balances: dict = field(default_factory=lambda: defaultdict(int))
    vouchers: list = field(default_factory=list)
    pending: PendingBook = field(default_factory=PendingBook)
    acc_dep: dict = field(default_factory=dict)          # asset id → 期首累計額（当期首）
    acc_dep_fy: dict = field(default_factory=dict)       # asset id → 当期の償却累計
    withheld: dict = field(default_factory=lambda: defaultdict(int))   # (kind, pay_month) → 額
    notices: dict = field(default_factory=dict)
    results: list = field(default_factory=list)
    opening_balance: dict = field(default_factory=dict)  # 期首残高のスナップショット
    tokurei_opening_used: set = field(default_factory=set)
    booked_rows: set = field(default_factory=set)        # 仕訳になった銀行明細の id（月をまたいで保持）
    labor_calcs: dict = field(default_factory=dict)      # 年度更新の計算表 {年: AnnualCalc}
    paid_early: set = field(default_factory=set)         # 期限の前の月の明細で先に認領された予定の key

    def post(self, v: Voucher):
        for l in v.lines:
            self.balances[(l.account, l.sub)] += int(l.debit) - int(l.credit)
        self.vouchers.append(v)


def _opening(led):
    co = led.co
    o = co.opening or {}
    for b in o.get("balances", []):
        acc = b["account"]
        if acc not in co.chart:
            raise ValueError(f"期首残高の科目「{acc}」が科目表に無い")
        led.balances[(acc, b.get("sub", ""))] += int(b.get("debit", 0)) - int(b.get("credit", 0))
    led.opening_balance = dict(led.balances)
    for a in co.fixed_assets:
        led.acc_dep[a["id"]] = int(a.get("accumulated_at_fy_start", 0))
        led.acc_dep_fy[a["id"]] = 0


PL_SECTIONS = {"売上高", "売上原価", "販売費及び一般管理費", "営業外収益", "営業外費用",
               "特別利益", "特別損失", "法人税等"}

# 年度末に会計担当者が確認すること。製品は導出できないので「済んだか」を記録として求める。
YEAR_END_CHECKLIST = [
    ("inventory", "期末の棚卸", "棚卸資産（商品・製品・貯蔵品）の期末残高を確定し、売上原価との振替を入れる"),
    ("accruals", "見越し・繰延", "前払費用・未払費用・未収収益・前受収益を確認する"),
    ("bad_debt", "債権の回収可能性", "売掛金・未収入金の回収可能性を確認し、必要なら貸倒引当金を計上する"),
    ("fixed_assets", "固定資産の実在", "固定資産台帳と現物を照合し、除却・売却を反映する"),
    ("officer_comp", "役員報酬", "期中に役員報酬を変えていないか（定期同額給与）、事前確定届出給与と一致するか"),
    ("consumption_tax", "消費税の精算", "当期の消費税額を確定し、未払消費税等（または未収）を計上する"),
    ("corporate_tax", "法人税等の計上", "法人税・地方法人税・住民税・事業税（特別法人事業税）を計上する"),
]


def _bank_of(co):
    return {b["id"]: b for b in co.bank_accounts}


def _hint_rows(rows, words, x):
    return [r for r in rows if r.claimed_by is None and any(w in r.desc for w in words)
            and x.in_window(r.date) and (r.outflow if x.direction == "out" else r.inflow)]


# 納期の特例：納期限の月 → (納期限の日, 対象となる支給月の範囲を返す関数)
#   源泉所得税：1〜6月支給分 → 7/10、7〜12月支給分 → 翌年 1/20（rules_r08.gensen_due）
#   住民税    ：6〜11月分 → 12/10、12〜翌5月分 → 6/10（rules_r08.juminzei_due）
SHAHO_EARLY = 25     # 社保の納入告知書は翌月 20 日前後に届く。届いてから期限までに払う会社が多い

TOKUREI = {
    "gensen": {7: (10, lambda y: [datetime.date(y, m, 1) for m in range(1, 7)]),
               1: (20, lambda y: [datetime.date(y - 1, m, 1) for m in range(7, 13)])},
    "jumin": {12: (10, lambda y: [datetime.date(y, m, 1) for m in range(6, 12)]),
              6: (10, lambda y: [datetime.date(y - 1, 12, 1)] + [datetime.date(y, m, 1) for m in range(1, 6)])},
}


def _tokurei_expected(led, kind, sub, label, month, bacc, bsub):
    """納期の特例の予定支払。期首残高は**開始月以後の最初の納期**に全額帰属させる。"""
    co = led.co
    if month.month not in TOKUREI[kind]:
        return None
    day, months_of = TOKUREI[kind][month.month]
    from .jp.calendar import next_business_day
    d = next_business_day(month.replace(day=day))
    period = months_of(month.year)
    amt = sum(led.withheld.get((kind, m), 0) for m in period if m >= co.start_month)
    parts = [f"{period[0]:%Y-%m}〜{period[-1]:%Y-%m} 支給分 {amt:,}"]
    if kind not in led.tokurei_opening_used and period[0] < co.start_month:
        op = -led.opening_balance.get(("預り金", sub), 0)
        amt += op
        parts.append(f"期首残高 {op:,}（開始月前の支給分）")
        led.tokurei_opening_used.add(kind)
    if not amt:
        return None
    return bankmod.Expected(
        f"{kind}:tokurei:{month:%Y-%m}", f"{label}（納期の特例、{'＋'.join(parts)}、期限 {d}）", d, amt, "out",
        make=lambda r, amt=amt: journal.withholding_payment(
            sub, amt, f"{label}（納期の特例）", r.date, bacc, bsub, r.label),
        window=3, early=10, hint=kind)


def close_month(led: Ledger, month: datetime.date, today: datetime.date) -> MonthResult:
    co, rates = led.co, led.rates
    start, end = month, month_end(month.year, month.month)
    pb = led.pending
    main_bank = co.bank_accounts[0]
    bacc, bsub = main_bank["account"], main_bank.get("sub", "")
    new = []

    # ---- 1 給与
    slips = payroll.run_month(co, rates, month)
    for s in slips:
        new.append(journal.payroll(s, co))
        for key, title, detail in s.pending:
            cat = "assumption" if key.startswith("assumption") else (
                "evidence" if key.startswith("smr_evidence") else "payroll")
            pb.add(Pending(key, cat, title, detail, date=s.pay_date))
        led.withheld[("gensen", month)] += s.income_tax
        led.withheld[("jumin", month)] += s.juminzei
    bonuses = payroll.bonus_slips(co, rates, month)
    for b in bonuses:
        if not start <= b.pay_date <= end:
            raise ValueError(f"{month:%Y-%m} の賞与の支給日 {b.pay_date} が月の外")
        new.append(journal.bonus(b, co))
        for key, title, detail in b.pending:
            pb.add(Pending(key, "payroll", title, detail, date=b.pay_date))
        led.withheld[("gensen", month)] += b.income_tax

    # ---- 1b 売上（請求一覧）
    sp = co.root / "monthly" / f"{month:%Y-%m}" / "sales.yaml"
    if sp.exists():
        import yaml
        for i, inv in enumerate((yaml.safe_load(sp.read_text(encoding="utf-8")) or {}).get("invoices", []), 1):
            if not isinstance(inv.get("date"), datetime.date):   # "2026-06-30" と引用符付きで書いても読む
                try:
                    inv["date"] = datetime.date.fromisoformat(str(inv.get("date")))
                except ValueError:
                    raise ValueError(f"{sp}：{i} 件目の日付 {inv.get('date')!r} が YYYY-MM-DD でない") from None
            if not start <= inv["date"] <= end:
                raise ValueError(f"{sp}：{i} 件目の日付 {inv['date']} が {month:%Y-%m} の外")
            new.append(journal.sales(inv, f"{month:%Y-%m}#{i}"))

    # ---- 1c 調整仕訳（決算整理など、会計担当者の入力。判断記録つき）
    for a in co.adjustments:
        if start <= a["date"] <= end:
            new.append(journal.adjustment(a))

    # ---- 2 予定支払
    expected = []
    # 年度更新（6/1〜7/10）：計算表を作り、納期限の月に納付を予定に入れる
    calc_now = None
    if month.month in (6, 7) and (co.labor_annual or any(e.koyou or e.role == "employee" for e in co.employees)):
        from .jp import labor_annual
        if month.year not in led.labor_calcs:
            calc_now = labor_annual.compute(co, rates, led, month.year)
            led.labor_calcs[month.year] = calc_now
            if calc_now is None:
                pb.add(Pending(f"labor_annual:{month.year}", "assumption", "労働保険の年度更新",
                               f"{month.year - 1}年度の確定に要る入力（labor_insurance.yaml：開始月前の賃金・"
                               f"前年度の概算納付額など）が無いので計算表を作れない", date=end))
            else:
                pb.add(Pending(f"labor_annual:{month.year}", "assumption", "労働保険の年度更新",
                               f"計算表を作った（納付 {calc_now.payment:,} 円・期限 {calc_now.due}）。"
                               f"申告書と突き合わせて確認する", date=end))
                for key, title, detail in calc_now.pending:
                    pb.add(Pending(key, "assumption", title, detail, date=end))
        calc = led.labor_calcs.get(month.year)
        if calc is not None and start <= calc.due <= end and calc.payment > 0:
            expected.append(bankmod.Expected(
                f"labor:{month.year}", f"労働保険 年度更新（期限 {calc.due}）", calc.due, calc.payment, "out",
                make=lambda r, calc=calc: journal.labor_payment(
                    calc, r.date, co.policy["labor_insurance_expense"], bacc, bsub, r.label),
                window=3, hint="labor"))
    for s in slips:
        if s.net:
            expected.append(bankmod.Expected(
                f"payout:{s.eid}:{month:%Y-%m}", f"給与振込 {s.eid}", s.pay_date, s.net, "out",
                make=lambda r, s=s: journal.salary_payout(s, r.date, bacc, bsub, r.label), window=3))
    for b in bonuses:
        if b.net:
            expected.append(bankmod.Expected(
                f"bonus:{b.eid}:{month:%Y-%m}", f"賞与振込 {b.eid}", b.pay_date, b.net, "out",
                make=lambda r, b=b: journal.bonus_payout(b, r.date, bacc, bsub, r.label), window=3))
    for m in (add_months(month, -2), add_months(month, -1), month):
        if m < add_months(co.start_month, -1):
            continue
        d, why = due(m, "next_month_end")
        # 期限が来月でも、期限前の納付を認める窓（early）が今月にかかっていれば今月の明細とも照合する。
        # 期限が休日で翌月初に延びる月（1/31→2/2 など）に、月末までに払った納付を拾うため。
        if not (start <= d <= end or (d > end and d - datetime.timedelta(days=SHAHO_EARLY) <= end)):
            continue
        if f"shaho:{m:%Y-%m}" in led.paid_early:
            continue
        n = led.notices.get(m) or payroll.notice(co, rates, m)
        if n is None:
            continue
        led.notices[m] = n
        expected.append(bankmod.Expected(
            f"shaho:{m:%Y-%m}", f"{m:%Y-%m}分 社会保険料（期限 {why}）", d, n.total, "out",
            make=lambda r, n=n: journal.shaho_payment(n, r.date, bacc, bsub, r.label, co.policy),
            # 納入告知書は翌月 20 日前後に届き、届けば期限前にいつでも払える（Pay-easy・窓口）。
            # 期限 ±3 日だけを見ると、早めに払う会社の納付が全部「明細に無い」になる（実在の会社で試して発見、2026-10-09）
            window=3, early=SHAHO_EARLY, hint="shaho"))
    # 源泉・住民税：原則は翌月10日
    for kind, sub, tok_key, label in (("gensen", journal.GENSEN, "gensen_nouki_tokurei", "源泉所得税"),
                                      ("jumin", journal.JUMIN, "juminzei_nouki_tokurei", "住民税")):
        if co.policy[tok_key]:
            x = _tokurei_expected(led, kind, sub, label, month, bacc, bsub)
            if x is not None:
                expected.append(x)
            continue
        pm = add_months(month, -1)
        d, why = due(pm, "next_month_10")
        if not start <= d <= end:
            continue
        if pm < co.start_month:
            amt = -led.balances.get(("預り金", sub), 0)     # 期首残高（貸方）
            src = "期首残高"
        else:
            amt = led.withheld.get((kind, pm), 0)
            src = f"{pm:%Y-%m} 支給分"
        if amt:
            expected.append(bankmod.Expected(
                f"{kind}:{pm:%Y-%m}", f"{label}（{src}、期限 {why}）", d, amt, "out",
                make=lambda r, amt=amt, sub=sub, label=label, pm=pm: journal.withholding_payment(
                    sub, amt, f"{pm:%Y-%m}分 {label}", r.date, bacc, bsub, r.label),
                window=3, hint=kind))

    # ---- 3 銀行
    rows_by_bank, all_rows_by_bank, problems = {}, {}, []
    for b in co.bank_accounts:
        rows, probs = bankmod.load(co, b)
        all_rows_by_bank[b["id"]] = rows
        rows_by_bank[b["id"]] = [r for r in rows if start <= r.date <= end]
        problems += probs
    rows = rows_by_bank[main_bank["id"]]

    # ---- 4 照合 → ルール → 要確認
    mr = bankmod.match(expected, rows)
    new += mr.vouchers
    claimed = {r.claimed_by for r in rows if r.claimed_by}
    led.paid_early |= {x.key for x in expected if x.date > end and x.key in claimed}
    # 期限が来月の予定は、今月に見つからなくてもまだ「無い」とは言えない（来月に照合する）
    mr.unmatched_expected = [x for x in mr.unmatched_expected if x.date <= end]
    words = co.bank_keywords
    for x, cands in mr.ambiguous:
        pb.add(Pending(f"ambiguous:{x.key}", "bank_ambiguous", f"{x.label}：候補が複数",
                       f"{x.amount:,} 円・{x.date}（前 {x.early or x.window} 日〜後 {x.window} 日）に同額の明細が {len(cands)} 件："
                       + "、".join(f"{r.date} {r.desc}" for r in cands) + "。どれかを決めて回答する",
                       date=x.date, amount=x.amount))
    for x in mr.unmatched_expected:
        near = _hint_rows(rows, words.get(x.hint, []), x) if x.hint else []
        if near:
            r = near[0]
            pb.add(Pending(f"mismatch:{x.key}", "amount_mismatch", f"{x.label}：金額が違う",
                           f"計算 {x.amount:,} 円に対し、明細 {r.date}「{r.desc}」は {r.amount_abs:,} 円"
                           f"（差 {r.amount_abs - x.amount:+,}）。標準報酬月額の改定・資格の得喪・料率の誤り等を確認",
                           date=x.date, amount=x.amount))
        else:
            pb.add(Pending(f"missing:{x.key}", "expected_missing", f"{x.label}が明細に無い",
                           f"{x.date}（前 {x.early or x.window} 日〜後 {x.window} 日）に {x.amount:,} 円の"
                           f"{'出金' if x.direction == 'out' else '入金'}が無い",
                           date=x.date, amount=x.amount))
    ruled, pend_rows = set(), set()
    for r in rows:
        if r.claimed_by is not None:
            continue
        hits = bankmod.rule_hits(r, co.rules)
        if len(hits) == 1:
            r.claimed_by = f"rule:{hits[0]['id']}"
            v = journal.bank_rule(r, hits[0], bacc, bsub)
            v.bank_row = r.id
            new.append(v)
            ruled.add(r.id)
            continue
        key = r.key()
        if len(hits) > 1:
            p = pb.add(Pending(key, "bank_ambiguous", f"{r.desc}：ルールが複数当たる",
                               f"{r.date} {r.signed:+,} 円にルール {[h['id'] for h in hits]} が当たる。ルールを直すか回答する",
                               date=r.date, amount=r.signed))
        else:
            p = pb.add(Pending(key, "bank_unmatched", f"{r.desc}",
                               f"{r.date} {r.signed:+,} 円。性質（科目・税区分）と証憑を回答する",
                               date=r.date, amount=r.signed))
        d = co.decisions.get(key)
        if d and d.get("action") == "book":
            p.resolved_by = d
            r.claimed_by = f"decision:{key}"
            v = journal.decided(r, d, bacc, bsub, key)
            v.bank_row = r.id
            new.append(v)
            ruled.add(r.id)
        else:
            pend_rows.add(r.id)

    led.booked_rows |= {r.id for r in rows if r.claimed_by is not None}

    # ---- 5 月末
    if co.policy["shaho_expense"] == "accrual":
        n = payroll.notice(co, rates, month)
        if n is not None:
            led.notices[month] = n
            new.append(journal.shaho_accrual(n, end))
    # 労働保険の会社負担（方針が monthly_accrual のとき）。年度更新の申告で精算する見積り。
    labor_amt = 0
    if co.policy["labor_insurance_expense"] == "monthly_accrual":
        from decimal import Decimal as _D
        from .core.money import truncate as _tr
        # 雇用保険は被保険者の賃金、労災は役員を除く全労働者の賃金（被保険者でない人も含む）
        k_base = (sum(s.koyou_wage for s in slips if co.emp(s.eid).koyou)
                  + sum(b.amount for b in bonuses if co.emp(b.eid).koyou))
        r_base = (sum(s.koyou_wage for s in slips if co.emp(s.eid).role == "employee")
                  + sum(b.amount for b in bonuses if co.emp(b.eid).role == "employee"))
        if k_base or r_base:
            basis = end
            k = rates.koyou(co.koyou_kind, basis)
            rs = rates.rousai(co.rousai_code, basis)
            gc = rates.general_contribution()
            raw = _D(k_base) * k["employer"] + _D(r_base) * rs["rate"] + _D(r_base) * gc
            amt = int(_tr(raw))
            labor_amt = amt
            new.append(journal.labor_insurance_accrual(month, end, amt, [
                f"雇用保険 事業主 {k_base:,}×{k['employer']}＋労災 {r_base:,}×{rs['rate']}（{rs['name']}）"
                f"＋一般拠出金 {r_base:,}×{gc} ＝ {raw}（円未満切捨て {amt:,}）",
                "見積り：年度更新（6/1〜7/10）の確定保険料で精算する"]))
    # 当月分の告知は方針（未払計上か納付時か）に関係なく常に計算できる——C2 の検査対象にする
    if month not in led.notices:
        n = payroll.notice(co, rates, month)
        if n is not None:
            led.notices[month] = n
    fs, fe = dep.fy_bounds(month, co.fy_end_month)
    if month == fs and month != co.start_month:
        # 新年度：期首累計額 ＋ **前年度の年額**。この実行で計上した分（acc_dep_fy）を足すのでは
        # ない——開始月が年度の途中だと、開始月前に前のソフトで計上した分が漏れる。
        pfs, pfe = dep.fy_bounds(add_months(month, -1), co.fy_end_month)
        for a in co.fixed_assets:
            prev_amt, _, _, _ = dep.annual(a, pfs, pfe, led.acc_dep[a["id"]])
            led.acc_dep[a["id"]] += prev_amt
            led.acc_dep_fy[a["id"]] = 0
    for a in co.fixed_assets:
        amt, why, problem = dep.monthly(a, month, co.fy_end_month, led.acc_dep[a["id"]])
        if problem:
            pb.add(Pending(f"dep:{a['id']}", "assumption", f"減価償却 {a['name']}", problem, date=end))
        if amt:
            new.append(journal.depreciation(a, end, amt, why))
            led.acc_dep_fy[a["id"]] += amt

    # ---- 税抜経理なら課税取引の行を本体と仮払／仮受消費税等に分ける
    if co.ct.get("accounting") == "tax_excluded":
        from .jp import shouhi
        for v in new:
            shouhi.split_voucher(v, co.chart)
        pb.add(Pending("assumption:ct_line_rounding", "assumption", "消費税の端数（行ごと）",
                       "税抜経理の税額は仕訳の行ごとに円未満切捨てで抜き出した。インボイス制度では請求書ごと・"
                       "税率ごとに 1 回の端数処理なので、1 枚の請求書が複数行なら数円ずれうる"))
    if co.ct.get("status") == "taxable":
        pb.add(Pending("assumption:ct_not_covered", "assumption", "消費税：未対応の制度",
                       "インボイス制度の経過措置（適格請求書発行事業者以外からの仕入の控除割合）・2割特例・"
                       "旧税率の経過措置は計算していない。該当する仕入があれば申告前に調整する"))

    # ---- 採番（年度ごとに 1 から）→ 記帳
    fy_prev = [v for v in led.vouchers if dep.fy_bounds(_m(v.date), co.fy_end_month)[0] == fs]
    nxt = max([v.vno for v in fy_prev] or [0]) + 1
    order = {"sales": -1, "payroll": 0, "payout": 1, "payment": 2, "bank_rule": 3, "decision": 4,
             "accrual": 5, "depreciation": 6, "adjustment": 7}
    new.sort(key=lambda v: (v.date, order.get(v.kind, 9)))
    tb_open = dict(led.balances)
    for v in new:
        v.vno = nxt
        nxt += 1
        led.post(v)

    # ---- 年度末：確認リスト（要確認）と損益振替（自動）
    if month == fe:
        for item, title, detail in YEAR_END_CHECKLIST:
            pb.add(Pending(f"closing:{month:%Y-%m}:{item}", "closing", title,
                           detail + "。済んだら decisions.yaml に action: done（by・at 必須）で回答する。"
                           "仕訳が要るものは adjustments.yaml に入れる", date=end))
        pl = {k: b for k, b in led.balances.items() if b and co.chart[k[0]]["section"] in PL_SECTIONS}
        if pl:
            v = journal.pl_closing(end, pl)
            v.vno = nxt
            nxt += 1
            new.append(v)
            led.post(v)

    res = MonthResult(month, slips, new, rows_by_bank, all_rows_by_bank,
                      {main_bank["id"]: mr}, {main_bank["id"]: ruled}, {main_bank["id"]: pend_rows},
                      dict(led.notices), expected, tb=dict(led.balances), tb_open=tb_open,
                      bonuses=bonuses, labor_accrual=labor_amt, labor_calc=calc_now)
    # 法人税等の計算表（年度末の月）。損益振替の前の数字で計算したいので、
    # 振替を除いた損益（statements の ytd）を使う。入力が無ければ要確認。
    if month == fe:
        from .jp import corporate_tax
        led.results.append(res)                       # compute が当月の結果を参照する
        try:
            ct, why = corporate_tax.compute(co, led, month, statements)
        except corporate_tax.TaxInputError as e:
            ct, why = None, str(e)
        led.results.pop()
        res.corp_tax = ct
        if ct is None:
            pb.add(Pending(f"corp_tax:{month:%Y-%m}", "closing", "法人税等の計算表",
                           f"計算表を作れない：{why}", date=end))
        else:
            pb.add(Pending(f"corp_tax:{month:%Y-%m}", "closing", "法人税等の計算表",
                           f"概算 {ct['total']:,} 円（未払法人税等 {ct['payable']:,}）。別表と突き合わせ、"
                           f"adjustments.yaml で 法人税等／未払法人税等 を計上する", date=end))
            for key, title, detail in ct["pending"]:
                pb.add(Pending(f"{key}:{month:%Y-%m}", "assumption", title, detail, date=end))

    res.report = run_checks(led, res, today, problems)
    led.results.append(res)
    return res


def run_checks(led, res, today, problems):
    co = led.co
    rep = C.Report()
    vs = res.vouchers
    start, end = res.month, month_end(res.month.year, res.month.month)
    rep.add(C.a1_balanced(vs))
    rep.add(C.a2_total_balanced(vs))
    rep.add(C.a3_accounts_known(vs, co.chart))
    rep.add(C.a4_dates_in_period(vs, start, end, today))
    fs = dep.fy_bounds(res.month, co.fy_end_month)[0]
    fy_vs = [v for v in led.vouchers if dep.fy_bounds(_m(v.date), co.fy_end_month)[0] == fs]
    rep.add(C.a7_vno_contiguous(fy_vs))
    by_acc = defaultdict(dict)
    for (acc, sub), bal in res.tb.items():
        by_acc[acc][sub] = bal
    liab = [a for a, x in co.chart.items() if x.get("liability_control")]
    rep.add(C.a9_liability_no_debit_balance(by_acc, liab))

    for bid, rows in res.all_bank_rows.items():
        rep.add(C.b5_balance_chain(bankmod.chain_rows(rows)))
        mon = res.bank_rows[bid]
        mr = res.match[bid]
        rep.add(C.b12_claims_unique_in_window(mr.claims, 5))   # 認領ごとの窓（前・後）は claims に入っている
        rep.add(C.b4_all_bank_rows_accounted(
            [r.id for r in mon], [c[0] for c in mr.claims], res.ruled[bid], res.pending_rows[bid]))
        b = [x for x in co.bank_accounts if x["id"] == bid][0]
        upto = [r for r in rows if r.date <= end]
        if upto:
            book_bal = res.tb.get((b["account"], b.get("sub", "")), 0)
            c6 = rep.add(C.b6_book_equals_bank([(f"{bid} {end}", book_bal, upto[-1].balance)]))
            if c6.status == C.FAIL:
                c6.details += diagnose_bank_gap(led, b, rows, end, book_bal - upto[-1].balance)
        else:
            rep.add(C.b6_book_equals_bank([]))
    if problems:
        rep.add(C.result("B0", "銀行明細の取り込み", 1, problems))

    # C：給与の内部整合（各明細で 支給−控除＝差引）と、告知の被保険者負担＝控除の合計
    rep.add(C.result("C1", "給与明細の内部整合（支給−控除＝差引、控除はすべて非負）", len(res.slips),
                     [f"{s.eid}：差引 {s.net:,} が負" for s in res.slips if s.net < 0]
                     + [f"{s.eid}：控除に負の値" for s in res.slips
                        if min(s.koyou, s.income_tax, s.juminzei, s.shaho_total) < 0]))
    ns = [n for m, n in res.notices.items()]
    rep.add(C.result("C2", "告知の被保険者負担＝各人の控除額の合計（賞与を含む）", len(ns),
                     [f"{n.month:%Y-%m}分：{n.employee:,} ≠ {sum(x.emp_total for x in n.members + n.bonuses):,}"
                      for n in ns if n.employee != sum(x.emp_total for x in n.members + n.bonuses)]))
    # C3：期首の未払社保（開始月の前月分の会社負担）＝計算
    #   開始月の前月分の社保は、期首時点で「まだ納めていない」。方針の組合せで期首に何が残るかが決まる：
    #     当月徴収          → 前月分の被保険者負担が 預り金 に残っている
    #     月末に未払計上    → 前月分の会社負担が 未払費用 に残っている
    #   それぞれ計算と一致すること。期首残高の転記ミスは、ここで捕まえないと
    #   最初の納付で 1 円単位の残りになって、ずっと預り金に居座る。
    if res.month == co.start_month:
        pm = add_months(co.start_month, -1)
        n = led.notices.get(pm) or payroll.notice(co, led.rates, pm)
        pairs = []
        if co.policy["shaho_expense"] == "accrual":
            pairs.append((f"未払費用（社会保険料）＝{pm:%Y-%m}分 会社負担",
                          -res.tb_open.get(("未払費用", journal.SI), 0), n.company if n else 0))
        own = n.employee if (n and co.policy["shaho_collection"] == "same_month") else 0
        pairs.append((f"預り金（社会保険料）＝{pm:%Y-%m}分 被保険者負担（{co.policy['shaho_collection']}）",
                      -res.tb_open.get(("預り金", journal.SI), 0), own))
        rep.add(C.f_tie("C3", "期首の未払社保（前月分）＝計算", pairs))
    # C4：固定資産台帳の取得価額 ＝ 帳簿の資産科目（補助＝資産 id）の残高。
    #   税抜・税込の取り違え（台帳は税込、帳簿は税抜）や登録漏れはここで出る。
    fa_pairs = []
    for a in co.fixed_assets:
        ins = datetime.date.fromisoformat(str(a["in_service"]))
        if ins <= end:
            fa_pairs.append((f"{a['id']} {a['name']}（{a['account']}）",
                             res.tb.get((a["account"], a["id"]), 0), int(a["cost"])))
    rep.add(C.f_tie("C4", "固定資産台帳の取得価額＝帳簿の資産残高", fa_pairs))

    # C5：年度更新を発生主義で精算した月——精算後の仮払金（労働保険）＝今年度の概算の納付分。
    #   入力の「前年度に納付した概算」と帳簿の仮払金が食い違っていればここで出る。
    for x in res.expected:
        if x.key.startswith("labor:") and any(c[1] == x.label for c in
                                               (c for mr in res.match.values() for c in mr.claims)):
            calc = led.labor_calcs[int(x.key.split(":")[1])]
            if co.policy["labor_insurance_expense"] == "monthly_accrual":
                rep.add(C.f_tie("C5", "年度更新の精算後の仮払金＝今年度の概算の納付分", [(
                    "仮払金（労働保険）", res.tb.get(("仮払金", "労働保険"), 0),
                    calc.payment - calc.difference - calc.general_contribution)]))

    # E：納期限。期限が来月の予定（期限前の納付を拾うために今月も照合したもの）は、
    # 今月に払われていれば数え、払われていなければ来月に回す（今月の「期限」ではない）
    month_end_ = month_end(res.month.year, res.month.month)
    claimed_labels = {c[1] for mr in res.match.values() for c in mr.claims}
    due_now = [x for x in res.expected if x.key.startswith(("shaho", "gensen", "jumin"))
               and (x.date <= month_end_ or x.label in claimed_labels)]
    late = []
    for x in due_now:
        for bid, mr in res.match.items():
            for rid, lab, exp, act, *_ in mr.claims:
                if lab == x.label and act > exp:
                    late.append(f"{lab}：期限 {exp} → 実際 {act}")
    n_e = len(due_now)
    if n_e == 0:
        rep.not_applicable.append((
            "E1", "社保・源泉・住民税を納期限までに納付",
            "当月に到来する納期限が無い（社保は翌月末、源泉・住民税は翌月10日"
            + ("・納期の特例" if co.policy["gensen_nouki_tokurei"] or co.policy["juminzei_nouki_tokurei"] else "")
            + "）。納付予定を落としていれば、その明細が要確認になり B6 が赤になる"))
    else:
        rep.add(C.result("E1", "社保・源泉・住民税を納期限までに納付", n_e, late))
    # F：試算表・貸借
    dr = sum(v for v in res.tb.values() if v > 0)
    cr = -sum(v for v in res.tb.values() if v < 0)
    rep.add(C.f_tie("F1", "試算表の貸借一致", [("試算表", dr, cr)]))
    bs = statements(co, res.tb, res.month, led)
    rep.add(C.f_tie("F2", "貸借対照表：資産＝負債＋純資産（当期損益を含む）",
                    [("貸借対照表", bs["assets"], bs["liabilities"] + bs["equity"])]))
    return rep


def diagnose_bank_gap(led, bank, rows, end, gap):
    """帳簿 − 銀行 の差額を、導出できる原因に分解する（作者の決定 A4：不一致なら原因を探す）。

      差額 ＝ ① 期首の差（帳簿の期首残高 − 開始月直前の銀行残高）
            − ② 銀行にあって帳簿に入っていない明細（要確認のまま）の合計
            ＋ ③ 帳簿にあって銀行明細に対応しない預金の動き（証憑が銀行明細でない伝票）
            ＋ ④ 説明できない残り
    ④ が 0 でなければ、それをはっきり言う。吸収しない。
    """
    co = led.co
    key = (bank["account"], bank.get("sub", ""))
    start = co.start_month
    out = [f"差額 {gap:+,} 円の分解："]
    # ①
    before = [r for r in rows if r.date < start]
    first = [r for r in rows if r.date >= start]
    if before:
        bank_open = before[-1].balance
    elif first:
        bank_open = first[0].balance - first[0].signed
    else:
        bank_open = 0
    book_open = led.opening_balance.get(key, 0)
    d1 = book_open - bank_open
    out.append(f"  ① 期首の差 {d1:+,}（帳簿の期首 {book_open:,} − 開始月直前の銀行 {bank_open:,}）")
    # ②
    # 明細は月ごとに読み直すので、仕訳になったかどうかは台帳側の記録（booked_rows）で判定する
    unbooked = [r for r in rows if start <= r.date <= end and r.id not in led.booked_rows]
    d2 = sum(r.signed for r in unbooked)
    out.append(f"  ② 帳簿に入っていない明細 {len(unbooked)} 件 合計 {d2:+,}")
    out.extend(f"      {r.date} {r.desc} {r.signed:+,}（{r.label}）" for r in unbooked[:10])
    # ③
    stray = []
    for v in led.vouchers:
        if v.date > end or v.bank_row:
            continue
        amt = sum(int(l.debit) - int(l.credit) for l in v.lines if (l.account, l.sub) == key)
        if amt:
            stray.append((v, amt))
    d3 = sum(a for _, a in stray)
    out.append(f"  ③ 銀行明細に対応しない預金の動き {len(stray)} 件 合計 {d3:+,}")
    out.extend(f"      伝票{v.vno} {v.date} {v.narration} {a:+,}" for v, a in stray[:10])
    rest = gap - d1 + d2 - d3
    out.append(f"  ④ 説明できない残り {rest:+,}" + ("" if rest == 0 else
               "  ← 上の三つで説明できない。明細の取り込み漏れ・同一明細の二重計上・日付の月ずれを疑う"))
    return out


def statements(co, tb, month, led):
    """貸借対照表と損益計算書（当月・期首からの累計）。"""
    fs = dep.fy_bounds(month, co.fy_end_month)[0]
    sec = {}
    for (acc, sub), bal in tb.items():
        a = co.chart[acc]
        sec.setdefault(a["section"], defaultdict(int))[acc] += bal
    # 期首からの損益：今期の伝票から集計
    pl_secs = {"売上高", "売上原価", "販売費及び一般管理費", "営業外収益", "営業外費用", "特別利益", "特別損失", "法人税等"}
    ytd = defaultdict(int)
    mon = defaultdict(int)
    # 開始月が同じ年度の途中なら、期首残高に入っている損益科目（開始月前の当期分）も累計に入れる
    if fs <= co.start_month:
        for (acc, sub), bal in led.opening_balance.items():
            if co.chart[acc]["section"] in pl_secs:
                ytd[acc] += bal
    for v in led.vouchers:
        if v.date < fs or v.date > month_end(month.year, month.month):
            continue
        if v.kind == "closing":            # 損益振替は損益計算書の数字ではない
            continue
        for l in v.lines:
            if co.chart[l.account]["section"] in pl_secs:
                ytd[l.account] += int(l.debit) - int(l.credit)
                if _m(v.date) == month:
                    mon[l.account] += int(l.debit) - int(l.credit)
    assets = sum(b for s, accs in sec.items() if s in ("流動資産", "有形固定資産", "無形固定資産", "投資その他の資産")
                 for b in accs.values())
    liabilities = -sum(b for s, accs in sec.items() if s in ("流動負債", "固定負債") for b in accs.values())
    equity_book = -sum(b for s, accs in sec.items() if s == "株主資本" for b in accs.values())
    # 前期以前の損益科目残高（期首に繰越利益へ振り替えていない分）も含めて純資産にする
    pl_all = -sum(b for s, accs in sec.items() if s in pl_secs for b in accs.values())
    return dict(assets=assets, liabilities=liabilities, equity=equity_book + pl_all, unclosed_pl=pl_all,
                net_income_ytd=-sum(ytd.values()), net_income_month=-sum(mon.values()),
                ytd=dict(ytd), month=dict(mon), sections={k: dict(v) for k, v in sec.items()})


def run(co, target: datetime.date, today: datetime.date | None = None, rates=None, progress=None):
    """開始月から target の月まで順に締める。Ledger を返す（results に各月）。

    progress(i, n, "YYYY-MM") を渡すと、各月を締め終えるたびに呼ぶ（ブラウザ版の進捗表示）。"""
    rates = rates or JpRates()
    today = today or datetime.date.today()
    led = Ledger(co, rates)
    _opening(led)
    m = co.start_month
    target = _m(target)
    if target < m:
        raise ValueError(f"{target:%Y-%m} は開始月 {m:%Y-%m} より前")
    n = (target.year - m.year) * 12 + target.month - m.month + 1
    i = 0
    while m <= target:
        close_month(led, m, today)
        i += 1
        if progress is not None:
            progress(i, n, f"{m:%Y-%m}")
        m = add_months(m, 1)
    # 回答の空振りは**全月を通した後**で判定する（6 月分の回答は 4 月の時点では当然使われない）
    stale = led.pending.resolve(co.decisions)
    for k in stale:
        led.pending.add(Pending(f"stale:{k}", "stale_decision", "使われなかった回答",
                                f"decisions.yaml の「{k}」に当たる要確認が無い。古い回答なら消す"))
    led.results[-1].report.add(C.result(
        "X2", "回答（decisions.yaml）がすべて実在の要確認に当たる", len(co.decisions),
        [f"使われていない回答：{stale}"] if stale else []))
    return led
