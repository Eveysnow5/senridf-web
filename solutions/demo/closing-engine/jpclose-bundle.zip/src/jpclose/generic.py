# -*- coding: utf-8 -*-
"""テンプレートの無い書類から、日付・金額・取引先を汎用の規則で読む（作者 2026-10-15：一つのファイルに一行、
数字を出せるなら出す。利用者に手で入れさせない）。

テンプレート（extract）は書類の種類ごとに検算までするが、領収書・請求書・契約書は種類が多すぎてテンプレートが無い。
ここでは書類の言葉の手がかりで読む。**検算はできない**——だから下書きの備考に「汎用の規則で読んだ。原本と照らす」と書き、
どの言葉を手がかりにしたか（why）を残す。下書きは人が確認するまで記帳に使われない。

  金額   手がかりの言葉の強い順（ご請求金額 → 合計（税込）→ 合計 → 領収金額 → 差引支給額 → 賃料・家賃 → 金額）。
         その行か次の行の「￥ 1,234」「1,234 円」。お預り・お釣り・小計は使わない
  日付   発行日・請求日・領収日・日付などの近くの日付を先に。無ければ書類の最初の日付（西暦・和暦）
  取引先 株式会社・有限会社・合同会社などの名前のうち、「様」「御中」の付かないもの（宛名ではないもの）で、
         自分の会社の名前でないもの。登録番号（T＋13 桁）のそばにある名前を先に
OCR の出力（Windows の OCR は文字の間に空白を入れる）でも読めるよう、漢字・かなの間の空白は詰めてから読む。
"""
from __future__ import annotations

import collections
import datetime
import difflib
import re

from .extract import normalize

AMOUNT_KEYS = ["ご請求金額", "請求金額", "お支払金額", "お支払い金額", "支払金額", "合計金額", "税込合計", "合計(税込)", "合計（税込）",
               "総合計", "合計", "領収金額", "金額合計", "差引支給額", "月額賃料", "賃料", "家賃", "金額"]
NOT_AMOUNT = re.compile(r"お預り|お預かり|お釣|釣銭|小計|内消費税|消費税等|税抜|対象")
_NUM = re.compile(r"(?<![\d.,])(\d{1,3}(?:[,.]\d{3})+|\d{3,9})(?![\d,]|\.\d)")
_YEN_BEFORE = re.compile(r"￥\s*(\d{1,3}(?:[,.]\d{3})+|\d+)")
_YEN_AFTER = re.compile(r"(\d{1,3}(?:[,.]\d{3})+|\d+)\s*円")
# 強い順：書類を出した日を先に（「発生年月日 R8.4.6／発行年月日 R8.6.11」の国庫金送金通知書では発行の方）
DATE_KEYS = ["発行日", "発行年月日", "請求日", "請求書発行日", "領収日", "取引日", "ご利用日", "お支払日", "契約日", "日付", "年月日"]
_D_WEST = re.compile(r"(20\d{2})\s*[年/.\-]\s*(\d{1,2})\s*[月/.\-]\s*(\d{1,2})")
_D_WAREKI = re.compile(r"(令和|平成|R|H)\s*\.?\s*(元|\d{1,2})\s*[年/.]\s*(\d{1,2})\s*[月/.]\s*(\d{1,2})")
_CORP = re.compile(r"(株式会社|有限会社|合同会社|合資会社|一般社団法人|税理士法人|司法書士法人|\(株\)|\(有\))")
_REG = re.compile(r"T\s*\d(?:\s*\d){12}")
_SPACE_CJK = re.compile(r"(?<=[^\x00-\x7F]) +(?=[^\x00-\x7F])")


def _clean(line: str) -> str:
    return _SPACE_CJK.sub("", normalize(line)).strip()


def _amount_in(text: str) -> int | None:
    for rx in (_YEN_BEFORE, _YEN_AFTER, _NUM):
        m = rx.search(text)
        if m:
            v = int(re.sub(r"[,.]", "", m.group(1)))
            if 0 < v < 10 ** 10:
                return v
    return None


def _date(text: str) -> datetime.date | None:
    m = _D_WAREKI.search(text)
    if m:
        base = {"令和": 2018, "R": 2018, "平成": 1988, "H": 1988}[m.group(1)]
        y = 1 if m.group(2) == "元" else int(m.group(2))
        try:
            return datetime.date(base + y, int(m.group(3)), int(m.group(4)))
        except ValueError:
            return None
    m = _D_WEST.search(text)
    if m:
        try:
            return datetime.date(int(m.group(1)), int(m.group(2)), int(m.group(3)))
        except ValueError:
            return None
    return None


def _corp_name(line: str) -> str:
    """行から会社名らしい部分（法人の種類の前後 1〜30 字）を取り出す。"""
    m = _CORP.search(line)
    if not m:
        return ""
    before, after = line[:m.start()], line[m.end():]
    head = re.split(r"[:：\s「」()（）]", before)[-1] if before else ""
    tail = re.split(r"[:：\s「」()（）,、。]", after)[0] if after else ""
    name = (head + m.group(1) + (tail if not head else "")).strip()
    return name[:40]


def _core(name: str) -> str:
    """会社名の芯（法人の種類と空白を除き、簡体字を日本の字に）：「架空同风株式会社」→「架空同風」。"""
    return re.sub(r"\s|株式会社|有限会社|合同会社|\(株\)|\(有\)", "", normalize(name or ""))


def _is_own(name: str, line: str, own: set) -> bool:
    """自分の会社か。底稿から作った会社名は簡体字のことがあり、OCR は 1〜2 字読み違える（「千同風」）→
    芯どうしが含まれるか、よく似ている（6 割以上）なら自分とみなす。"""
    c, ln = _core(name), _core(line)
    for o in own:
        if o in c or o in ln or (c and o and difflib.SequenceMatcher(None, c, o).ratio() >= 0.6):
            return True
    return False


def read(lines: list, own_names=()) -> dict | None:
    """読めたものだけ返す：{date, amount, party, why}。何も読めなければ None。"""
    text = [_clean(l) for l in lines if l and l.strip()]
    own = {_core(n) for n in own_names if n} - {""}
    # 金額
    amount, why_amount = None, ""
    for key in AMOUNT_KEYS:
        for i, line in enumerate(text):
            if key not in line:
                continue
            pre, rest = line.split(key, 1)
            if NOT_AMOUNT.search(pre[-6:]):                # 「10%対象合計」「税抜金額」などは使わない
                continue
            cut = NOT_AMOUNT.search(rest)                  # 「合計 ￥1,250（内消費税 ￥113）」→ 内消費税の前まで
            if cut:
                rest = rest[:cut.start()]
            nxt = text[i + 1] if i + 1 < len(text) and not NOT_AMOUNT.search(text[i + 1]) else ""
            v = _amount_in(rest) or (_amount_in(nxt) if nxt else None)
            if v:
                amount, why_amount = v, key
                break
        if amount:
            break
    # 手がかりの言葉が読み違いで見つからない（「合計」→「合Bt」、「お支払い」→「お支キムし」）とき：
    # ￥の付いた金額のうち一番多く出てくるもの（2 回以上、2 番目より多いときだけ）。領収書は合計・お支払・決済の内訳に
    # 同じ額を何度も印字する
    why_most = ""
    if amount is None:
        seen = collections.Counter()
        for line in text:
            for m in _YEN_BEFORE.finditer(line):
                if not NOT_AMOUNT.search(line[max(0, m.start() - 8):m.start()]):
                    v = _amount_in(m.group(0))
                    if v:
                        seen[v] += 1
        top = seen.most_common(2)
        if top and top[0][1] >= 2 and (len(top) == 1 or top[0][1] > top[1][1]):
            amount, why_most = top[0][0], f"金額＝￥の付いた金額で一番多いもの（{top[0][1]} 回）"
    # 日付
    date, why_date = None, ""
    for key in DATE_KEYS:
        for i, line in enumerate(text):
            if key in line:
                d = _date(line.split(key, 1)[1]) or (_date(text[i + 1]) if i + 1 < len(text) else None)
                if d:
                    date, why_date = d, key
                    break
        if date:
            break
    if date is None:
        for line in text:
            d = _date(line)
            if d and 2000 <= d.year <= 2100:
                date, why_date = d, "最初の日付"
                break
    # 取引先
    party, why_party = "", ""
    cands = []
    for i, line in enumerate(text):
        if not _CORP.search(line) or re.search(r"様|御中|殿", line):
            continue
        name = _corp_name(line)
        if not name or _is_own(name, line, own):
            continue
        core = _core(name)                                 # 「は株式会社」（文の途中の「…は株式会社…」）は名前ではない
        if len(core) < 2 or re.fullmatch(r"[ぁ-ゖー]+", core):
            continue
        near_reg = any(_REG.search(text[j]) for j in range(max(0, i - 2), min(len(text), i + 3)))
        cands.append((0 if near_reg else 1, i, name))
    if cands:
        cands.sort()
        party, why_party = cands[0][2], ("登録番号のそば" if cands[0][0] == 0 else "法人名")
    if amount is None and date is None and not party:
        return None
    return dict(date=date, amount=amount, party=party, amount_key=why_amount,
                why="・".join(x for x in (f"金額＝「{why_amount}」" if why_amount else why_most,
                                          f"日付＝{why_date}" if why_date else "",
                                          f"取引先＝{why_party}" if why_party else "") if x))
