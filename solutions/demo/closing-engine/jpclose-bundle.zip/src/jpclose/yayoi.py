# -*- coding: utf-8 -*-
"""締めた月の仕訳を、弥生会計に取り込める形（弥生インポート形式）で書き出す（作者 2026-10-13）。

このエンジンは月次の締めと検査をする道具で、帳簿の本体は利用者の会計ソフトにある。締めた結果の仕訳を
そのソフトへ持っていけるようにする。形式は弥生の公開のサポート情報に従う（ソフトの中身は見ていない）：

  · 仕訳データの項目と記述形式（弥生取り込み（インポート）形式・弥生会計 05 以降）：1 行 25 項目
      https://support.yayoi-kk.co.jp/subcontents.html?page_id=18545
  · 課税方式別税区分・税計算区分一覧（税区分の記述形式）
      https://support.yayoi-kk.co.jp/faq_Subcontents.html?page_id=18111
  · 勘定科目の期首残高データの項目と記述形式：1 行 6 項目（期首残高のファイル。下の opening）
      https://support.yayoi-kk.co.jp/subcontents.html?page_id=18547
  写しは docs/sources/yayoi_import/（sha256 つき）。

決めたこと：
  · 借方 1 行・貸方 1 行の伝票は「仕訳データ」（識別フラグ 2000・タイプ 0）。それ以外は振替伝票
    （1 行目 2110・間 2100・最終行 2101・タイプ 3）。片側が無い行は、科目を空・税区分「対象外」・金額 0
  · 金額は税込。税抜経理の会社は、エンジンが分けた「本体」と「仮払／仮受消費税等」を 1 行に戻し、税額を税金額の欄に書く
    （弥生は税抜処理の税額を自動計算しない＝入力必須）。税区分は「内」（内税）、税込経理の会社は「込」
  · 税率 8% は軽減税率（軽減8%）。簡易課税の売上は事業区分（一〜六）を付ける。免税事業者は全部「対象外」
  · 年度末の損益振替（kind＝closing）は出さない：弥生は繰越処理で自分で行う。出すと二重になる
  · 決算整理の仕訳（第 13 期）は「決算」の欄に「本決」と書く（弥生の決算仕訳）
  · 文字コードは Shift_JIS・改行は CRLF。Shift_JIS に無い字（簡体字など）は「?」に置き換え、数を返す
  · 請求書区分・仕入税額控除は書かない（弥生が取引日・科目から自動判定する。エンジンはインボイスの経過措置を扱わない）

**弥生会計への実際の取り込みは試していない**（手元にソフトが無い）。公開の仕様どおりに書いてあることまでを
tests/test_yayoi_export.py が確かめる。勘定科目・補助科目の名前が弥生の登録名と違えば、弥生の取り込み画面で
対応づけ（マッチングリスト）が出る——エンジンが使った名前の一覧を一緒に返す。
"""
from __future__ import annotations

import csv
import datetime
import io
import re

from .jp import shouhi

FIELDS = 25
ENCODING = "cp932"
KIND = "一二三四五六"                               # 簡易課税の事業区分（第一種〜第六種）
SKIP_KINDS = {"closing"}
# 弥生で前期繰越残高を編集できない科目（含まれるとインポートできない）。繰越利益は弥生が［貸借調整］で計算する
NOT_IMPORTABLE = {"繰越利益剰余金", "繰越利益", "元入金", "事業主貸", "事業主借"}
SIDE = {"debit": "借方", "credit": "貸方"}
NONE = "対象外"


def tax_code(cat: str, co) -> str:
    """エンジンの税区分 → 弥生の記述形式。"""
    ct = co.ct
    if ct.get("status") != "taxable" or not cat or cat == NONE:
        return NONE
    info = shouhi.table()["categories"].get(cat)
    if info is None:
        raise ValueError(f"未知の税区分「{cat}」")
    if info["side"] == "none":
        return {"非課税売上": "非課売上", "非課税仕入": "非課仕入"}.get(cat, NONE)
    mode = "内" if ct.get("accounting") == "tax_excluded" else "込"
    rate = "10%" if info["rate"] == "standard" else "軽減8%"
    if info["side"] == "sales":
        kind = KIND[int(ct["category"]) - 1] if ct.get("method") == "simplified" else ""
        return f"課税売上{mode}{kind}{rate}"
    return f"課対仕入{mode}{rate}"


def _sides(v, co) -> tuple:
    """伝票の行 → (借方の列, 貸方の列)。各要素は (科目, 補助, 税区分, 税込金額, 税額)。
    税抜経理で分けた税の行（直後の 仮払／仮受消費税等・補助＝税区分・メモ「税抜経理」）は、本体の行に戻す。"""
    dr, cr = [], []
    lines = list(v.lines)
    i = 0
    while i < len(lines):
        l = lines[i]
        side = dr if l.debit else cr
        amt = int(l.debit or l.credit)
        cat = shouhi.category_of(l, co.chart) if l.account not in (shouhi.INPUT_TAX, shouhi.OUTPUT_TAX) else NONE
        tax = 0
        nxt = lines[i + 1] if i + 1 < len(lines) else None
        if (nxt is not None and nxt.account in (shouhi.INPUT_TAX, shouhi.OUTPUT_TAX) and nxt.memo == "税抜経理"
                and nxt.sub == cat and bool(nxt.debit) == bool(l.debit)):
            tax = int(nxt.debit or nxt.credit)
            i += 1
        if amt + tax:
            sub = "" if l.account in (shouhi.INPUT_TAX, shouhi.OUTPUT_TAX) else l.sub
            side.append((l.account, sub, tax_code(cat, co), amt + tax, tax))
        i += 1
    return dr, cr


def _cut(text: str, width: int) -> str:
    """Shift_JIS で width バイトまで（弥生の桁数は半角で数える）。"""
    out, n = [], 0
    for ch in text or "":
        w = len(ch.encode(ENCODING, errors="replace"))
        if n + w > width:
            break
        out.append(ch)
        n += w
    return "".join(out)


def rows(co, vouchers) -> list:
    """伝票 → 弥生インポート形式の行（1 行 25 項目の文字列のリスト）。"""
    out = []
    for v in vouchers:
        if v.kind in SKIP_KINDS:
            continue
        dr, cr = _sides(v, co)
        if not dr and not cr:
            continue
        n = max(len(dr), len(cr))
        simple = len(dr) == 1 and len(cr) == 1
        date = f"{v.date:%Y/%m/%d}"
        memo = _cut(" ".join(x for x in (f"jpclose #{v.vno}" if v.vno else "", v.evidence or "") if x), 180)
        for k in range(n):
            d = dr[k] if k < len(dr) else ("", "", NONE, 0, 0)
            c = cr[k] if k < len(cr) else ("", "", NONE, 0, 0)
            flag = "2000" if simple else "2110" if k == 0 else "2101" if k == n - 1 else "2100"
            out.append([
                flag, "", "本決" if getattr(v, "settlement", False) else "", date,
                d[0], _cut(d[1], 24), "", d[2], str(d[3]), str(d[4]) if d[4] else "",
                c[0], _cut(c[1], 24), "", c[2], str(c[3]), str(c[4]) if c[4] else "",
                _cut(v.narration, 64), "", "", "0" if simple else "3", "", memo, "", "", "no",
            ])
    return out


def export(co, vouchers) -> dict:
    """bytes（Shift_JIS・CRLF の CSV）と、取り込む前に知っておくこと。

      rows       行数 / vouchers 伝票の数
      accounts   使った勘定科目の名前（弥生の登録名と違えば対応づけが要る）
      replaced   Shift_JIS に無くて「?」に置き換えた字の数
    """
    rs = rows(co, vouchers)
    buf = io.StringIO(newline="")
    w = csv.writer(buf, lineterminator="\r\n")
    for r in rs:
        assert len(r) == FIELDS
        w.writerow(r)
    text = buf.getvalue()
    data = text.encode(ENCODING, errors="replace")
    replaced = sum(1 for ch in text if ch != "?" and ch.encode(ENCODING, errors="replace") == b"?")
    accounts = sorted({r[i] for r in rs for i in (4, 10) if r[i]})
    return dict(bytes=data, rows=len(rs), vouchers=sum(1 for r in rs if r[0] in ("2000", "2110")),
                accounts=accounts, replaced=replaced)


def opening(co) -> dict:
    """期首残高 → 弥生の「勘定科目の期首残高データ」（［科目残高入力］→［ファイル］→［インポート］で読む形）。

    1 行 6 項目：期首日・勘定科目名・貸借区分（借方／貸方）・補助科目名・部門・前期繰越残高。
      · 貸借区分は科目の本来の側、金額はその側から見た額（反対側の残高はマイナス）。公開の仕様は
        「貸借区分＝残高のある側」とも「科目の属性」とも読める。この書き方ならどちらの読み方でも同じ残高になる
      · 繰越利益剰余金は書かない（弥生では編集できず、含むと取り込めない）。額は skipped で返す——
        弥生で［貸借調整］をした後の繰越利益がこれと合えば、全部の残高が移ったことになる
      · 記帳の開始月が年度の初めでない会社には出さない（ok＝False・why＝midyear）：その期首残高は
        年度の途中の残高で、弥生の「前期繰越残高」ではない
    """
    o = co.opening or {}
    if co.start_month.month != co.fy_end_month % 12 + 1:
        return dict(ok=False, why="midyear")
    bal = {}
    for b in o.get("balances", []):
        k = (b["account"], b.get("sub", "") or "")
        bal[k] = bal.get(k, 0) + int(b.get("debit", 0) or 0) - int(b.get("credit", 0) or 0)
    day = f"{co.start_month:%Y/%m}/01"
    rs, skipped = [], []
    for (acc, sub), n in bal.items():
        if not n:
            continue
        if acc in NOT_IMPORTABLE:
            skipped.append(dict(account=acc, sub=sub, debit=n))
            continue
        normal = co.chart[acc]["normal"]
        rs.append([day, _cut(acc, 24), SIDE[normal], _cut(sub, 24), "", str(n if normal == "debit" else -n)])
    if not rs:
        return dict(ok=False, why="empty")
    buf = io.StringIO(newline="")
    csv.writer(buf, lineterminator="\r\n").writerows(rs)
    text = buf.getvalue()
    replaced = sum(1 for ch in text if ch != "?" and ch.encode(ENCODING, errors="replace") == b"?")
    return dict(ok=True, bytes=text.encode(ENCODING, errors="replace"), rows=len(rs), day=day, skipped=skipped,
                replaced=replaced)


# ------------------------------------------------------------------ 期首残高のファイルを読む（弥生 → この道具）
# 書き出し（opening）と同じ様式を、入力としても受ける（作者 2026-10-14：弥生から来る利用者が期首残高を
# そのまま持って来られるように。行きも帰りも同じ様式）。
ERAS = {"R": 2018, "H": 1988, "S": 1925}            # 和暦：R01＝2019・H30＝2018
_DAY = re.compile(r"(?:(\d{4})(\d{2})(\d{2})|(\d{4})/(\d{1,2})/(\d{1,2})|([RHS])\.?(\d{1,2})/(\d{1,2})/(\d{1,2}))$")
_AMOUNT = re.compile(r"-?\d+$")


def _day(text: str):
    """期首日（西暦 20180701・2018/07/01・2018/7/1、和暦 H30/07/01・R.01/07/01）。読めなければ None。"""
    m = _DAY.match((text or "").strip())
    if not m:
        return None
    g = m.groups()
    if g[0]:
        y, mo, d = int(g[0]), int(g[1]), int(g[2])
    elif g[3]:
        y, mo, d = int(g[3]), int(g[4]), int(g[5])
    else:
        y, mo, d = ERAS[g[6]] + int(g[7]), int(g[8]), int(g[9])
    try:
        return datetime.date(y, mo, d)
    except ValueError:
        return None


def looks_like_opening(rows) -> bool:
    """先頭の行たちが期首残高データの形か：見出しは無く、どの行も 6 項目で、3 項目めが「借方」「貸方」、
    6 項目めが整数、1 行目の 1 項目めが日付。（この様式に必ずある形だけで見分ける。数の「らしさ」では当てない）"""
    rows = [r for r in rows if any(c for c in r)]
    if not rows or _day(rows[0][0]) is None:
        return False
    return all(len(r) == 6 and r[2] in SIDE.values() and r[1] and _AMOUNT.match(r[5]) for r in rows)


def read_opening(raw: bytes) -> dict:
    """期首残高データ → day（期首日）と balances [(科目, 補助, 借方残高＝借方−貸方)]。

    貸借区分の側に金額がある、と読む（「貸方」の 100 は貸方残高 100、「借方」の −100 も貸方残高 100）。
    形が違う行があれば problems に行番号つきで返し、balances は空（半分だけ読んで渡さない）。"""
    for enc in ("cp932", "utf-8-sig"):
        try:
            text = raw.decode(enc)
            break
        except UnicodeDecodeError:
            continue
    else:
        return dict(day=None, balances=[], problems=[(0, "encoding")])
    rows = [(i, [c.strip() for c in r]) for i, r in enumerate(csv.reader(io.StringIO(text)), start=1) if any(c.strip() for c in r)]
    problems, out = [], []
    day = _day(rows[0][1][0]) if rows and rows[0][1] else None
    if day is None:
        problems.append((1, "day"))
    for i, r in rows:
        if len(r) != 6:
            problems.append((i, "fields"))
        elif not r[1]:
            problems.append((i, "account"))
        elif r[2] not in SIDE.values():
            problems.append((i, "side"))
        elif not _AMOUNT.match(r[5]):
            problems.append((i, "amount"))
        else:
            n = int(r[5])
            out.append((r[1], r[3], n if r[2] == SIDE["debit"] else -n))
    return dict(day=day, balances=[] if problems else out, problems=problems)
