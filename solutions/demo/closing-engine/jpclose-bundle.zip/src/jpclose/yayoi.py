# -*- coding: utf-8 -*-
"""締めた月の仕訳を、弥生会計に取り込める形（弥生インポート形式）で書き出す（作者 2026-10-13）。

このエンジンは月次の締めと検査をする道具で、帳簿の本体は利用者の会計ソフトにある。締めた結果の仕訳を
そのソフトへ持っていけるようにする。形式は弥生の公開のサポート情報に従う（ソフトの中身は見ていない）：

  · 仕訳データの項目と記述形式（弥生取り込み（インポート）形式・弥生会計 05 以降）：1 行 25 項目
      https://support.yayoi-kk.co.jp/subcontents.html?page_id=18545
  · 課税方式別税区分・税計算区分一覧（税区分の記述形式）
      https://support.yayoi-kk.co.jp/faq_Subcontents.html?page_id=18111
  写しは docs/sources/yayoi_import/（sha256 つき）。

決めたこと：
  · 借方 1 行・貸方 1 行の伝票は「仕訳データ」（識別フラグ 2000・タイプ 0）。それ以外は振替伝票
    （1 行目 2110・間 2100・最終行 2101・タイプ 3）。片側が無い行は、科目を空・税区分「対象外」・金額 0
  · 金額は税込。税抜経理の会社は、エンジンが分けた「本体」と「仮払／仮受消費税等」を 1 行に戻し、税額を税金額の欄に書く
    （弥生は税抜処理の税額を自動計算しない＝入力必須）。税区分は「内」（内税）、税込経理の会社は「込」
  · 税率 8% は軽減税率（軽減8%）。簡易課税の売上は事業区分（一〜六）を付ける。免税事業者は全部「対象外」
  · 年度末の損益振替（kind＝closing）は出さない：弥生は繰越処理で自分で行う。出すと二重になる
  · 文字コードは Shift_JIS・改行は CRLF。Shift_JIS に無い字（簡体字など）は「?」に置き換え、数を返す
  · 請求書区分・仕入税額控除は書かない（弥生が取引日・科目から自動判定する。エンジンはインボイスの経過措置を扱わない）

**弥生会計への実際の取り込みは試していない**（手元にソフトが無い）。公開の仕様どおりに書いてあることまでを
tests/test_yayoi_export.py が確かめる。勘定科目・補助科目の名前が弥生の登録名と違えば、弥生の取り込み画面で
対応づけ（マッチングリスト）が出る——エンジンが使った名前の一覧を一緒に返す。
"""
from __future__ import annotations

import csv
import io

from .jp import shouhi

FIELDS = 25
ENCODING = "cp932"
KIND = "一二三四五六"                               # 簡易課税の事業区分（第一種〜第六種）
SKIP_KINDS = {"closing"}
NONE = "対象外"


def tax_code(cat: str, co) -> str:
    """エンジンの税区分 → 弥生の記述形式。"""
    ct = co.ct
    if ct.get("status") != "taxable" or not cat or cat == NONE:
        return NONE
    info = shouhi.table()["categories"].get(cat)
    if info is None:
        raise ValueError(f"未知の税区分「{cat}」")
    if info["side"] == "none":
        return {"非課税売上": "非課売上", "非課税仕入": "非課仕入"}.get(cat, NONE)
    mode = "内" if ct.get("accounting") == "tax_excluded" else "込"
    rate = "10%" if info["rate"] == "standard" else "軽減8%"
    if info["side"] == "sales":
        kind = KIND[int(ct["category"]) - 1] if ct.get("method") == "simplified" else ""
        return f"課税売上{mode}{kind}{rate}"
    return f"課対仕入{mode}{rate}"


def _sides(v, co) -> tuple:
    """伝票の行 → (借方の列, 貸方の列)。各要素は (科目, 補助, 税区分, 税込金額, 税額)。
    税抜経理で分けた税の行（直後の 仮払／仮受消費税等・補助＝税区分・メモ「税抜経理」）は、本体の行に戻す。"""
    dr, cr = [], []
    lines = list(v.lines)
    i = 0
    while i < len(lines):
        l = lines[i]
        side = dr if l.debit else cr
        amt = int(l.debit or l.credit)
        cat = shouhi.category_of(l, co.chart) if l.account not in (shouhi.INPUT_TAX, shouhi.OUTPUT_TAX) else NONE
        tax = 0
        nxt = lines[i + 1] if i + 1 < len(lines) else None
        if (nxt is not None and nxt.account in (shouhi.INPUT_TAX, shouhi.OUTPUT_TAX) and nxt.memo == "税抜経理"
                and nxt.sub == cat and bool(nxt.debit) == bool(l.debit)):
            tax = int(nxt.debit or nxt.credit)
            i += 1
        if amt + tax:
            sub = "" if l.account in (shouhi.INPUT_TAX, shouhi.OUTPUT_TAX) else l.sub
            side.append((l.account, sub, tax_code(cat, co), amt + tax, tax))
        i += 1
    return dr, cr


def _cut(text: str, width: int) -> str:
    """Shift_JIS で width バイトまで（弥生の桁数は半角で数える）。"""
    out, n = [], 0
    for ch in text or "":
        w = len(ch.encode(ENCODING, errors="replace"))
        if n + w > width:
            break
        out.append(ch)
        n += w
    return "".join(out)


def rows(co, vouchers) -> list:
    """伝票 → 弥生インポート形式の行（1 行 25 項目の文字列のリスト）。"""
    out = []
    for v in vouchers:
        if v.kind in SKIP_KINDS:
            continue
        dr, cr = _sides(v, co)
        if not dr and not cr:
            continue
        n = max(len(dr), len(cr))
        simple = len(dr) == 1 and len(cr) == 1
        date = f"{v.date:%Y/%m/%d}"
        memo = _cut(" ".join(x for x in (f"jpclose #{v.vno}" if v.vno else "", v.evidence or "") if x), 180)
        for k in range(n):
            d = dr[k] if k < len(dr) else ("", "", NONE, 0, 0)
            c = cr[k] if k < len(cr) else ("", "", NONE, 0, 0)
            flag = "2000" if simple else "2110" if k == 0 else "2101" if k == n - 1 else "2100"
            out.append([
                flag, "", "", date,
                d[0], _cut(d[1], 24), "", d[2], str(d[3]), str(d[4]) if d[4] else "",
                c[0], _cut(c[1], 24), "", c[2], str(c[3]), str(c[4]) if c[4] else "",
                _cut(v.narration, 64), "", "", "0" if simple else "3", "", memo, "", "", "no",
            ])
    return out


def export(co, vouchers) -> dict:
    """bytes（Shift_JIS・CRLF の CSV）と、取り込む前に知っておくこと。

      rows       行数 / vouchers 伝票の数
      accounts   使った勘定科目の名前（弥生の登録名と違えば対応づけが要る）
      replaced   Shift_JIS に無くて「?」に置き換えた字の数
    """
    rs = rows(co, vouchers)
    buf = io.StringIO(newline="")
    w = csv.writer(buf, lineterminator="\r\n")
    for r in rs:
        assert len(r) == FIELDS
        w.writerow(r)
    text = buf.getvalue()
    data = text.encode(ENCODING, errors="replace")
    replaced = sum(1 for ch in text if ch != "?" and ch.encode(ENCODING, errors="replace") == b"?")
    accounts = sorted({r[i] for r in rs for i in (4, 10) if r[i]})
    return dict(bytes=data, rows=len(rs), vouchers=sum(1 for r in rs if r[0] in ("2000", "2110")),
                accounts=accounts, replaced=replaced)
