# -*- coding: utf-8 -*-
"""年度の確定（作者 2026-10-14）。

申告を済ませた年度は、数字を動かさない。あとで誤りが見つかったら、**当期に更正の仕訳を入れる**
（日本の過年度修正の一般的なやり方。作者の決定）。

確定すると、その年度を 1 つのファイル closed/FY<年度末 YYYY-MM>.yaml に書き残す：
  · 年度末の残高（損益振替のあと：貸借対照表の科目だけが残る）と、固定資産ごとの償却累計額
  · その年度の仕訳すべて（あとで年度をまたいで調べるため）
  · その年度の入力の指紋（銀行明細・毎月の資料・調整仕訳・回答）：あとで変わったら気づくため
  · ファイル自身の sha256（書き換えに気づくため）

確定したあとの締めは、**次の年度の初めから**、確定した残高を期首残高として計算する（記帳を始めたばかりの
会社と同じ道。何年分たまっても、毎回最初から計算し直さない）。確定した年度の入力があとで変わっていたら、
計算には使わず、要確認で知らせる（「確定した年度の数字は変えません。当期に更正の仕訳を」）。
"""
from __future__ import annotations

import datetime
import hashlib
import json
import re

import yaml

from .jp.calendar import add_months, month_end

DIR = "closed"
KIND = "jpclose-closed-year"
VERSION = 1
SOURCES = ("bank", "monthly", "adjustments", "decisions")
_DAY = re.compile(r"(\d{4})-(\d{2})(?:-(\d{2}))?")


class ClosedYearError(ValueError):
    pass


def _canon(obj) -> str:
    return json.dumps(obj, ensure_ascii=False, sort_keys=True, default=str, separators=(",", ":"))


def _sha(obj) -> str:
    return hashlib.sha256(_canon(obj).encode("utf-8")).hexdigest()


def name(fy_end: datetime.date) -> str:
    return f"{DIR}/FY{fy_end:%Y-%m}.yaml"


def load_all(root) -> list[dict]:
    """closed/ の確定ファイル（年度末の順）。中身の sha256 が合わないものがあれば止める（黙って使わない）。"""
    d = root / DIR
    out = []
    for p in sorted(d.glob("FY*.yaml")) if d.exists() else []:
        doc = yaml.safe_load(p.read_text(encoding="utf-8")) or {}
        if doc.get("kind") != KIND:
            raise ClosedYearError(f"{DIR}/{p.name} は年度の確定ファイルではありません")
        body = {k: v for k, v in doc.items() if k != "sha256"}
        if _sha(body) != doc.get("sha256"):
            raise ClosedYearError(f"確定ファイル {DIR}/{p.name} の中身が、確定したときから変わっています。"
                                  "確定したファイルは書き換えないでください（控えがあれば戻してください）")
        out.append(doc)
    ends = [d["fiscal_year"]["end"] for d in out]
    for a, b in zip(ends, ends[1:]):
        if add_months(datetime.date(a.year, a.month, 1), 12) != datetime.date(b.year, b.month, 1):
            raise ClosedYearError(f"確定した年度が続いていません（{a:%Y-%m} の次が {b:%Y-%m}）")
    return out


def apply(co) -> None:
    """確定ファイルがあれば、締めを次の年度の初めから始める（期首残高・償却累計額を確定の値に）。
    co.first_month に、もともとの記帳の開始月を残す。"""
    co.first_month = co.start_month
    co.closed = load_all(co.root)
    if not co.closed:
        return
    last = co.closed[-1]
    end = last["fiscal_year"]["end"]
    co.start_month = add_months(datetime.date(end.year, end.month, 1), 1)
    co.opening = dict(as_of=end, balances=[dict(b) for b in last["balances"]])
    acc = last.get("assets") or {}
    co.fixed_assets = [dict(a, accumulated_at_fy_start=int(acc[a["id"]])) if a["id"] in acc else a
                       for a in co.fixed_assets]


def closed_until(co) -> datetime.date | None:
    closed = getattr(co, "closed", None) or []
    return closed[-1]["fiscal_year"]["end"] if closed else None


def key_in_closed(key: str, co) -> bool:
    """回答のキーの日付（YYYY-MM-DD か YYYY-MM）が確定した年度の中か。"""
    until = closed_until(co)
    m = _DAY.search(key)
    if until is None or not m:
        return False
    y, mo, d = int(m.group(1)), int(m.group(2)), m.group(3)
    try:
        day = datetime.date(y, mo, int(d)) if d else month_end(y, mo)
    except ValueError:
        return False
    return day <= until


# ------------------------------------------------------------------ 入力の指紋
def fingerprints(co, fs: datetime.date, fe: datetime.date, rows_by_bank=None) -> dict:
    """年度（fs〜fe）の入力の指紋 {source: sha256}。中身を読んで正規化してから取る（ファイルの書き方の違いでは変わらない）。"""
    from . import bank as bankmod
    if rows_by_bank is None:
        opening = {}
        for b in (co.opening or {}).get("balances", []):
            k = (b["account"], b.get("sub", "") or "")
            opening[k] = opening.get(k, 0) + int(b.get("debit", 0) or 0) - int(b.get("credit", 0) or 0)
        rows_by_bank, _ = bankmod.load_all(co.root, co.bank_accounts, opening)
    bank = sorted((bid, str(r.date), r.desc, str(r.signed), str(r.balance))
                  for bid, rows in rows_by_bank.items() for r in rows if fs <= r.date <= fe)
    monthly = {}
    m = datetime.date(fs.year, fs.month, 1)
    while m <= fe:
        d = co.root / "monthly" / f"{m:%Y-%m}"
        for p in sorted(d.glob("*.yaml")) if d.exists() else []:
            monthly[f"{m:%Y-%m}/{p.name}"] = yaml.safe_load(p.read_text(encoding="utf-8"))
        m = add_months(m, 1)
    adj = [a for a in co.adjustments if fs <= _as_date(a.get("date")) <= fe] if co.adjustments else []
    dec = {k: v for k, v in co.decisions.items() if _in(k, fs, fe)}
    return dict(bank=_sha(bank), monthly=_sha(monthly), adjustments=_sha(adj), decisions=_sha(dec))


def _as_date(v) -> datetime.date:
    if isinstance(v, datetime.date):
        return v
    try:
        return datetime.date.fromisoformat(str(v)[:10])
    except ValueError:
        return datetime.date.min


def _in(key, fs, fe) -> bool:
    m = _DAY.search(key)
    if not m:
        return False
    y, mo, d = int(m.group(1)), int(m.group(2)), m.group(3)
    try:
        day = datetime.date(y, mo, int(d)) if d else month_end(y, mo)
    except ValueError:
        return False
    return fs <= day <= fe


def changed_sources(co, rows_by_bank=None) -> list[tuple]:
    """確定した年度ごとに、指紋が変わった入力：[(年度末, source)]。"""
    out = []
    for doc in getattr(co, "closed", None) or []:
        fy = doc["fiscal_year"]
        now = fingerprints(co, fy["start"], fy["end"], rows_by_bank)
        for s in SOURCES:
            if now.get(s) != (doc.get("inputs") or {}).get(s):
                out.append((fy["end"], s))
    return out


# ------------------------------------------------------------------ 確定する
def build(led, fy_end: datetime.date, by: str, at: str, note: str = "") -> dict:
    """直前の締め（led）から、年度末 fy_end の確定ファイルの中身を作る。確定できなければ ClosedYearError。

    確定できないとき：年度末まで締めていない／年度末の月でない／もう確定している／その年度に残っている要確認がある
    （申告した年度に、答えていない事項を残したまま固めない）／検査に通っていない月がある。"""
    from .jp import depreciation as dep
    co = led.co
    if not by:
        raise ClosedYearError("by")
    fs, fe_m = dep.fy_bounds(datetime.date(fy_end.year, fy_end.month, 1), co.fy_end_month)   # どちらも月の初日
    if fe_m != datetime.date(fy_end.year, fy_end.month, 1):
        raise ClosedYearError("not_fy_end")
    fe = month_end(fe_m.year, fe_m.month)
    until = closed_until(co)
    if until is not None and fe <= until:
        raise ClosedYearError("already")
    months = [r for r in led.results if fs <= r.month <= fe]
    if not months or months[-1].month != datetime.date(fe.year, fe.month, 1):
        raise ClosedYearError("not_closed")
    if fs < co.start_month:
        # 記帳を年度の途中から始めた最初の年度：開始月から年度末まで
        fs = co.start_month
    if datetime.date(fs.year, fs.month, 1) != months[0].month:
        raise ClosedYearError("not_closed")
    # 前提のお知らせ（assumption:）は答える事項ではない（画面でも「お知らせ」の欄）——確定を止めない
    open_items = [p for p in led.pending.open_items() if (p.date is None or p.date <= fe)
                  and not p.key.startswith("assumption:")]
    if open_items:
        raise ClosedYearError("open:" + "、".join(f"{p.qid} {p.title}" for p in open_items[:10]))
    bad = [f"{r.month:%Y-%m}" for r in months if not r.report.ok]
    if bad:
        raise ClosedYearError("checks:" + "、".join(bad))
    last = months[-1]
    # 年度末の残高：その月の試算表（損益振替のあと）。0 の行は書かない
    bal = sorted(((acc, sub), int(b)) for (acc, sub), b in last.tb.items() if int(b))
    balances = [dict(account=a, **({"sub": s} if s else {}), **({"debit": n} if n > 0 else {"credit": -n}))
                for (a, s), n in bal]
    vouchers = [dict(date=v.date, vno=v.vno, kind=v.kind, narration=v.narration, evidence=v.evidence or "",
                     **({"settlement": True} if v.settlement else {}),
                     lines=[dict(account=l.account, sub=l.sub, debit=int(l.debit), credit=int(l.credit),
                                 tax=l.tax or "", memo=l.memo or "") for l in v.lines])
                for r in months for v in r.vouchers]
    first = months[0]
    opening = [dict(account=a, **({"sub": s} if s else {}), **({"debit": int(n)} if n > 0 else {"credit": -int(n)}))
               for (a, s), n in sorted((first.tb_open or {}).items()) if int(n)]
    body = dict(kind=KIND, version=VERSION, company=co.name,
                fiscal_year=dict(start=fs, end=fe), closed_by=by, closed_at=str(at), note=note or "",
                opening=opening, balances=balances, assets=_acc_dep_at_next_start(led, fe),
                vouchers=vouchers, inputs=fingerprints(co, fs, fe, last.all_bank_rows))
    body["sha256"] = _sha(body)
    return body


def _acc_dep_at_next_start(led, fe) -> dict:
    """次の年度の初めの償却累計額：この年度の初めの累計（led.acc_dep）＋この年度の年額。
    close.close_month が新年度の初めにすることと同じ計算（開始月が年度の途中でも、前のソフトで計上した分を含む）。"""
    from .jp import depreciation as dep
    pfs, pfe = dep.fy_bounds(datetime.date(fe.year, fe.month, 1), led.co.fy_end_month)
    out = {}
    for a in led.co.fixed_assets:
        amt, _, _, _ = dep.annual(a, pfs, pfe, led.acc_dep[a["id"]])
        out[a["id"]] = int(led.acc_dep[a["id"]] + amt)
    return dict(sorted(out.items()))


def dump(doc: dict) -> str:
    head = ("# 年度の確定ファイル（月次決算エンジン）。書き換えないでください——中身の sha256 が合わなくなり、締めが止まります。\n"
            "# 確定した年度の誤りは、当期に更正の仕訳を入れて直します。\n")
    return head + yaml.safe_dump(doc, allow_unicode=True, sort_keys=False, width=200)
