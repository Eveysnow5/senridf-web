# -*- coding: utf-8 -*-
"""判断の記録（誰が・いつ・なぜ）。

製品の前提（作者の決定 2026-10-09 A3）：
  **関键な判断にはすべて電子記録を残す。誰が、いつ決めたか。理由を書いたなら理由も。**

関键な判断とみなすもの：
  方針        会社設定 policies（事務所の既定 office.yaml を会社が上書きできる）
  回答        要確認への回答 decisions.yaml
  銀行ルール  摘要 → 科目 のルール bank_rules.yaml
  固定資産    耐用年数・償却方法 fixed_assets.yaml

`by` と `at` が無ければ読み込みを止める（記録の無い判断で帳簿を作らない）。
`reason` は任意だが、書かれていれば底稿の「判断記録」にそのまま出す。

底稿の表紙には全判断の**ハッシュ**を載せる。後から判断を書き換えると、
同じ底稿を再生成してもハッシュが変わるので、「この底稿はどの判断で作られたか」を固定できる。
"""
from __future__ import annotations

import datetime
import hashlib
import json
from dataclasses import asdict, dataclass


class JudgmentError(ValueError):
    pass


@dataclass(frozen=True)
class Judgment:
    kind: str           # 方針 / 回答 / 銀行ルール / 固定資産
    key: str
    value: str
    by: str
    at: datetime.date
    reason: str = ""
    source: str = ""    # 方針なら「事務所既定」「本社」

    def row(self):
        return (self.kind, self.key, self.value, self.source, self.by, self.at, self.reason)


def audit(d: dict, where: str):
    """(by, at, reason)。by・at が無ければ JudgmentError。"""
    if not isinstance(d, dict):
        raise JudgmentError(f"{where}：判断の記録（by・at）が無い——値だけの書き方は受け付けない")
    by = str(d.get("by") or "").strip()
    if not by:
        raise JudgmentError(f"{where}：誰が判断したか（by）が無い")
    at = d.get("at")
    if at in (None, ""):
        raise JudgmentError(f"{where}：いつ判断したか（at）が無い")
    if not isinstance(at, datetime.date):
        try:
            at = datetime.date.fromisoformat(str(at)[:10])
        except ValueError:
            raise JudgmentError(f"{where}：at「{at}」が日付（YYYY-MM-DD）でない") from None
    return by, at, str(d.get("reason") or "").strip()


def digest(judgments) -> str:
    """全判断の正規化 JSON の sha256。順序に依存しない。"""
    rows = sorted(json.dumps(asdict(j), ensure_ascii=False, sort_keys=True, default=str) for j in judgments)
    return hashlib.sha256("\n".join(rows).encode("utf-8")).hexdigest()
