# -*- coding: utf-8 -*-
"""証憑と銀行明細の突き合わせ（作者 2026-10-10：midday の打分の構造を借りる。重みは借りない）。

midday（docs/inbox-matching.md）から借りたもの：
  · 信号を分けて点をつけ、理由を言えるようにする（名前・金額・日付。通貨は円だけなので無い）
  · 2 つの線：候補として見せる線と、自動で付ける線。自動は「点が高い」だけでなく安全条件を満たすときだけ
  · 確認された組（取引先 ↔ 明細の摘要）を覚え（alias）、次から名前の信号にする
  · 断られた組は二度と出さない（declined）
借りないもの：重み（彼らのデータで調整した値）と金額の許容幅。**金額は等しいことが条件**（このエンジンの判断は
相等で、差を「小さい」で済ませない）。

自動で付けるのは、確認済（または検算が通った）の証憑で、候補の明細が**ちょうど 1 行**、日付が近いか覚えた組の
とき。候補が 2 行以上なら選ばせる（推測しない）。候補が無ければ「銀行に無い」——誰が払ったか（立替・現金・
カード・使わなかった納付書・別の口座）を利用者に聞く（close の要確認）。

複数の証憑の合計が 1 行の明細になる（3 か月分の給与をまとめて振り込んだ等）ことがある → 同じ取引先の証憑の
組合せで合計が一致する明細を**候補としてだけ**示す（自動にはしない）。
"""
from __future__ import annotations

import datetime
import itertools
import re
import unicodedata
from dataclasses import dataclass, field

from . import evidence as ev

NEAR, MID, FAR = 3, 10, 40                       # 日付の差（日）
AUTO_DATE = 0.8                                  # 自動で付ける日付の点の下限（覚えた組なら日付を問わない）


def _kana(s: str) -> str:
    s = unicodedata.normalize("NFKC", s or "")
    s = "".join(chr(ord(c) + 0x60) if "ぁ" <= c <= "ゖ" else c for c in s)       # ひらがな → カタカナ
    return re.sub(r"[\s・()（）\-ｰー.,]", "", s).upper()


def desc_core(desc: str) -> str:
    """明細の摘要から振込の種類の語を除いた「相手」。hints._core と同じ考え（循環 import を避けて薄く持つ）。"""
    from .hints import _core
    return _kana(_core(desc))


def date_score(doc: datetime.date | None, bank: datetime.date, received: datetime.date | None = None) -> float:
    """証憑の日付（取引日・納期限）と明細の日付。証憑に日付が無ければ取込日の前 120 日〜後 30 日を広く見る。"""
    if doc is None:
        if received is None:
            return 0.0
        d = (bank - received).days
        return 0.3 if -120 <= d <= 30 else 0.0
    d = abs((bank - doc).days)
    return 1.0 if d <= NEAR else 0.8 if d <= MID else 0.5 if d <= FAR else 0.0


@dataclass
class Candidate:
    bank_key: str
    date: datetime.date
    desc: str
    amount: int
    date_score: float
    name_score: float
    why: list = field(default_factory=list)


@dataclass
class Outcome:
    no: int
    status: str                     # auto / choose / none / done（確認済で照合先あり）/ skip（金額が無い等）
    candidates: list = field(default_factory=list)
    groups: list = field(default_factory=list)       # [{"bank_key":…, "nos":[…], "amount":…}]（合計で一致）


def learn_aliases(index: ev.Index, rows) -> set:
    """確認済で照合先のある行から（取引先, 明細の相手）の組を覚える。"""
    by_key = {r.key(): r for r in rows}
    out = set()
    for e in index.entries:
        if e.status == ev.CONFIRMED and e.bank and e.bank in by_key and e.party:
            out.add((_kana(e.party), desc_core(by_key[e.bank].desc)))
    return out


def candidates(e: ev.Entry, rows, aliases=frozenset(), declined=frozenset(), direction: str = "out") -> list:
    if e.amount is None:
        return []
    out = []
    for r in rows:
        if r.amount_abs != e.amount or bool(r.outflow) != (direction == "out"):
            continue
        if (e.no, r.key()) in declined:
            continue
        ds = date_score(e.date, r.date, e.received)
        named = (_kana(e.party), desc_core(r.desc)) in aliases
        if ds == 0 and not named:
            continue
        why = [f"金額 {e.amount:,} 円が一致"]
        why.append(f"日付の差 {abs((r.date - e.date).days)} 日" if e.date else "証憑に日付がありません（取込日の前後で探しました）")
        if named:
            why.append("前に同じ取引先をこの摘要の明細に付けました")
        out.append(Candidate(bank_key=r.key(), date=r.date, desc=r.desc, amount=r.amount_abs,
                             date_score=ds, name_score=1.0 if named else 0.0, why=why))
    return sorted(out, key=lambda c: (-(c.name_score + c.date_score), c.date))


def match(index: ev.Index, rows, *, declined=frozenset(), trusted=frozenset(), direction_of=None) -> list:
    """索引簿の各行の行き先。trusted＝検算が通った下書きの連番（確認前でも自動の対象にしてよい）。
    direction_of(entry) → "in"/"out"（既定は out：支払の証憑）。同じ明細を 2 枚の証憑が取り合うときは自動にしない。"""
    aliases = learn_aliases(index, rows)
    taken = {e.bank for e in index.entries if e.bank and e.status != ev.VOID}
    free = [r for r in rows if r.key() not in taken]
    outs = []
    for e in index.entries:
        if e.status == ev.VOID:
            continue
        if e.bank:
            outs.append(Outcome(e.no, "done"))
            continue
        if e.amount is None:
            outs.append(Outcome(e.no, "skip"))
            continue
        cs = candidates(e, free, aliases, declined, (direction_of or (lambda _: "out"))(e))
        sure = e.status == ev.CONFIRMED or e.no in trusted
        if not cs:
            outs.append(Outcome(e.no, "none"))
        elif len(cs) == 1 and sure and (cs[0].date_score >= AUTO_DATE or cs[0].name_score):
            outs.append(Outcome(e.no, "auto", cs))
        else:
            outs.append(Outcome(e.no, "choose", cs))
    # 同じ明細を自動で 2 枚が取ったら、両方とも選ばせる
    autos = [o for o in outs if o.status == "auto"]
    dup = {k for k in (o.candidates[0].bank_key for o in autos)
           if sum(1 for o in autos if o.candidates[0].bank_key == k) > 1}
    for o in autos:
        if o.candidates[0].bank_key in dup:
            o.status = "choose"
    _groups(index, free, outs)
    return outs


def _groups(index: ev.Index, rows, outs, max_n: int = 4, span_days: int = 120):
    """一致する明細の無い証憑で、同じ取引先の 2〜max_n 枚の合計が 1 行の出金になるもの（候補だけ）。"""
    lonely = {o.no for o in outs if o.status in ("none", "choose")}
    by_party = {}
    for e in index.entries:
        if e.no in lonely and e.amount and e.status != ev.VOID:
            by_party.setdefault(_kana(e.party), []).append(e)
    found = {}
    for party, es in by_party.items():
        if len(es) < 2 or not party:
            continue
        es = sorted(es, key=lambda e: e.no)[:12]                 # 組合せの爆発を防ぐ
        for n in range(2, min(max_n, len(es)) + 1):
            for combo in itertools.combinations(es, n):
                total = sum(e.amount for e in combo)
                ref = max((e.date or e.received) for e in combo)
                for r in rows:
                    if r.outflow and r.amount_abs == total and abs((r.date - ref).days) <= span_days:
                        g = dict(bank_key=r.key(), date=str(r.date), desc=r.desc, amount=total,
                                 nos=[e.no for e in combo])
                        for e in combo:
                            found.setdefault(e.no, []).append(g)
    for o in outs:
        if o.no in found:
            o.groups = found[o.no]
