# -*- coding: utf-8 -*-
"""結果画面の「次にすること」。要確認・落ちた検査ごとに、どこで何をすればよいかを一行で示す。

作者 2026-10-10：「哪项检查没过只是列出来，不告诉客户该补哪份资料、该改哪张表」。
how（どこで直すか）：
  answer   この画面の「回答」で済む（判断の記録になる）
  sheet    入力（Excel の表／YAML）を直して締め直す
  both     どちらか（状況による。本文に書く）
  contact  エンジン内部の検査。客の入力では直らない → 底稿を添えて連絡
表の名前は workbook.ORDER のもの（テストで突き合わせる）。YAML のファイル名は web.CHECKLIST から引く。
"""
from __future__ import annotations

ANSWER, SHEET, BOTH, CONTACT = "answer", "sheet", "both", "contact"

# (区分 or None, キーの頭, how, 表, {言語: 文})。上から順に最初に当たったもの
PENDING_RULES = [
    ("bank_unmatched", "bank:", BOTH, ["银行规则"], {
        "ja": "「回答」で科目を選んで仕訳する（性質が分からなければ処理済み＋理由）。毎月同じ明細なら「银行规则」表にルールを足すと次から自動で仕訳",
        "zh": "点「回答」选科目入账（性质不明可标已处理并写理由）。每月都有的流水，在「银行规则」表加一条规则，以后自动入账",
        "en": "Use Answer to book it to an account (or mark done with a reason). If it recurs monthly, add a rule in the 银行规则 sheet"}),
    ("bank_ambiguous", "bank:", BOTH, ["银行规则"], {
        "ja": "「银行规则」表のルールを直して 1 つだけ当たるようにする。今回だけなら「回答」で科目を選ぶ",
        "zh": "修改「银行规则」表，让这笔只命中一条规则；只是这一次的话，点「回答」选科目",
        "en": "Fix the rules in the 银行规则 sheet so only one matches, or use Answer for this row"}),
    (None, "ambiguous:", ANSWER, [], {
        "ja": "候補の明細のどれが該当かを「回答」の理由に書いて処理済みにする",
        "zh": "在「回答」的理由里写明是哪一笔流水，标为已处理",
        "en": "Use Answer: say which row it is in the reason and mark it done"}),
    (None, "mismatch:", BOTH, ["标准报酬"], {
        "ja": "金額差の原因を確かめる：標準報酬の改定なら「标准报酬」表に新しい月額を足して締め直す。理由が分かって直す必要がなければ「回答」で処理済み＋理由",
        "zh": "先查差额原因：标准报酬改定的话，在「标准报酬」表加上新的月额后重新结账；原因清楚、不需要改的，点「回答」标已处理并写理由",
        "en": "Find the cause: if the standard remuneration changed, add it in the 标准报酬 sheet and run again; otherwise answer done with the reason"}),
    (None, "missing:payout:", ANSWER, [], {
        "ja": "まだ払っていないなら「回答」で処理済み＋支払予定日。払ったのに出ないなら、明細が月末まで入っているか確認",
        "zh": "如果还没付，点「回答」标已处理并写预计支付日；已经付了却没对上，检查流水是否下载到月末",
        "en": "If not paid yet, answer done with the expected pay date; if paid, check the statement reaches month end"}),
    (None, "missing:bonus:", ANSWER, [], {
        "ja": "まだ払っていないなら「回答」で処理済み＋支払予定日。払ったのに出ないなら、明細が月末まで入っているか確認",
        "zh": "如果还没付，点「回答」标已处理并写预计支付日；已经付了却没对上，检查流水是否下载到月末",
        "en": "If not paid yet, answer done with the expected pay date; if paid, check the statement reaches month end"}),
    (None, "missing:", BOTH, ["调整分录"], {
        "ja": "この口座以外で払った（他の口座・立替）なら「调整分录」表に納付の仕訳を入れ、「回答」で処理済み。未納なら早く納める（延滞金に注意）",
        "zh": "如果是从别的账户付的或有人代付，在「调整分录」表记一笔缴款分录，再点「回答」标已处理；如果确实没缴，请尽快缴纳（注意滞纳金）",
        "en": "If paid from another account or by someone else, enter it in the 调整分录 sheet and answer done; if unpaid, pay soon (late fees)"}),
    (None, "decision_sum:", ANSWER, [], {
        "ja": "「回答」の各行の金額を直して、合計を明細の金額に合わせる",
        "zh": "修改「回答」里各行金额，让合计等于流水金额",
        "en": "Edit the answer so the lines add up to the row amount"}),
    (None, "stale:", SHEET, ["回答"], {
        "ja": "「回答」表のこの行を消す（もう当てはまる要確認が無い）",
        "zh": "删除「回答」表里这一行（已经没有对应的待确认）",
        "en": "Delete this row from the 回答 sheet (nothing matches it any more)"}),
    (None, "juminzei_missing:", SHEET, ["住民税"], {
        "ja": "「住民税」表にこの月の月額を入れる（特別徴収が始まる前の月は 0）",
        "zh": "在「住民税」表填入这个月的月额（特别征收开始前的月份填 0）",
        "en": "Enter this month's amount in the 住民税 sheet (0 before collection starts)"}),
    (None, "juminzei_leaver:", ANSWER, [], {
        "ja": "一括徴収か普通徴収かを決めて「回答」の理由に書く",
        "zh": "决定一次征收还是改普通征收，写在「回答」的理由里",
        "en": "Decide lump-sum or ordinary collection and write it in the answer"}),
    (None, "commute_limit:", SHEET, ["员工"], {
        "ja": "「员工」表に通勤方法（transit / car / mixed）を入れる",
        "zh": "在「员工」表填写通勤方式（transit / car / mixed）",
        "en": "Fill in the commute mode (transit / car / mixed) in the 员工 sheet"}),
    (None, "proration:", SHEET, ["每月工资"], {
        "ja": "日割りするなら「每月工资」表にこの月の支給額を入れる。満額でよければ「回答」で処理済み",
        "zh": "需要按日折算的话，在「每月工资」表填这个月的支付额；全额没问题就点「回答」标已处理",
        "en": "To prorate, enter this month's pay in the 每月工资 sheet; if full pay is right, answer done"}),
    (None, "smr_evidence:", SHEET, ["标准报酬"], {
        "ja": "「标准报酬」表に根拠（決定通知書など）を書く",
        "zh": "在「标准报酬」表写上依据（决定通知书等）",
        "en": "Record the document (notice of determination) in the 标准报酬 sheet"}),
    (None, "labor_annual:", SHEET, ["劳动保险"], {
        "ja": "「劳动保险」表に前年度の賃金総額・前年度に納めた概算保険料・控除した雇用保険料を入れる。計算表ができていれば申告書と照合して「回答」で処理済み",
        "zh": "在「劳动保险」表填上年度工资总额、上年度已缴的概算保险费、从工资里扣的雇用保险；已出计算表的，和申报书核对后点「回答」标已处理",
        "en": "Fill last year's total wages, the estimate paid and employee insurance withheld in the 劳动保险 sheet; once the worksheet is built, check it and answer done"}),
    (None, "labor_", SHEET, ["劳动保险"], {
        "ja": "「劳动保险」表の見込額・延納の指定を確認する。前提でよければ「回答」で処理済み",
        "zh": "确认「劳动保险」表里的预计额、分期设置；前提没问题就点「回答」标已处理",
        "en": "Check the estimate and instalment settings in the 劳动保险 sheet; if the assumption is fine, answer done"}),
    (None, "dep:", SHEET, ["固定资产", "折旧分摊"], {
        "ja": "「固定资产」「折旧分摊」表の取得日・耐用年数・償却方法を確認する",
        "zh": "检查「固定资产」「折旧分摊」表的取得日、耐用年数、折旧方法",
        "en": "Check acquisition date, useful life and method in the 固定资产 / 折旧分摊 sheets"}),
    (None, "corp_tax:", SHEET, ["法人税", "法人税调整", "中间纳付", "调整分录"], {
        "ja": "「法人税」「法人税调整」「中间纳付」表を入れる。計算表を別表と照合し、「调整分录」表で 法人税等／未払法人税等 を計上",
        "zh": "填写「法人税」「法人税调整」「中间纳付」表；把计算表和别表核对后，在「调整分录」表计提 法人税等／未払法人税等",
        "en": "Fill the 法人税 / 法人税调整 / 中间纳付 sheets, check against the schedules, and accrue in the 调整分录 sheet"}),
    (None, "closing:", BOTH, ["调整分录"], {
        "ja": "済んだら「回答」で処理済み。仕訳が要るものは「调整分录」表に入れて締め直す",
        "zh": "做完后点「回答」标已处理；需要分录的写进「调整分录」表再重新结账",
        "en": "When done, answer done; put any entries in the 调整分录 sheet and run again"}),
    (None, "shaho_switch:", BOTH, ["调整分录", "期初余额"], {
        "ja": "返金するなら「调整分录」表で 預り金 → 未払金（本人）に振り替え、「回答」で処理済み。前期も翌月徴収だったなら「期初余额」表を直す",
        "zh": "要退还的话，在「调整分录」表把 預り金 转到 未払金（本人），再点「回答」标已处理；如果上期其实也是翌月征收，改「期初余额」表",
        "en": "To refund, move 預り金 to 未払金 (the person) in the 调整分录 sheet and answer done; if last period was also next-month, fix the 期初余额 sheet"}),
    (None, "opening_withholding:", BOTH, ["调整分录", "期初余额"], {
        "ja": "納付済みなら納付の明細を「回答」で消し込む。年末調整で本人に返す分なら「调整分录」表で 未払金（本人）へ振替。期首の誤りなら「期初余额」表を直す",
        "zh": "已缴的话，用「回答」把缴款流水冲销；属于年末调整要退本人的，在「调整分录」表转入 未払金（本人）；期初有误就改「期初余额」表",
        "en": "If paid, clear it by answering the payment row; if refundable after year-end adjustment, move it in the 调整分录 sheet; if the opening is wrong, fix 期初余额"}),
    # 前提の確認（一次資料で未確認／製品が扱わない制度）：読んで了承すれば済む
    (None, "", ANSWER, [], {
        "ja": "内容を確認し、問題なければ「回答」で処理済み（理由に確認したことを書く）",
        "zh": "确认内容，没问题就点「回答」标已处理（理由里写明已确认什么）",
        "en": "Review it; if fine, answer done and note what you checked"}),
]

CHECK_RULES = {
    "B0": (SHEET, ["银行账户"], {
        "ja": "bank/ の明細ファイルと「银行账户」表の列名（日付・金額・残高）が合っているか確認",
        "zh": "检查 bank/ 里的流水文件，以及「银行账户」表的列名（日期・金额・余额）是否和文件一致",
        "en": "Check the files in bank/ and that the column names in the 银行账户 sheet match them"}),
    "B5": (SHEET, [], {
        "ja": "bank/ の明細ファイルに抜け・重複が無いか。期間の切れ目なくダウンロードし直して置き換える",
        "zh": "bank/ 里的流水文件有缺漏或重复——请把整个期间连续地重新下载并替换",
        "en": "The files in bank/ have gaps or duplicates — download the whole period again and replace them"}),
    "B6": (BOTH, ["期初余额"], {
        "ja": "下の差額の分解を見る：①期首の差 →「期初余额」表、②帳簿に入っていない明細 → 要確認を「回答」、④説明できない残り → 明細の取り込み漏れ・二重計上を疑う",
        "zh": "看下面的差额分解：①期初差额 → 改「期初余额」表；②未入账的流水 → 回答对应的待确认；④无法说明的剩余 → 怀疑流水漏导入或重复入账",
        "en": "See the breakdown: ① opening difference → fix 期初余额; ② unbooked rows → answer the pending items; ④ remainder → suspect a missing or doubled row"}),
    "A9": (BOTH, ["调整分录"], {
        "ja": "借方残高の理由を確かめる（前払い・払い過ぎ・立替）。振り替えるなら「调整分录」表、そのままでよければ理由を記録",
        "zh": "查明借方余额的原因（预付、多付、代垫）。需要重分类的在「调整分录」表处理；保持不动也要记下理由",
        "en": "Find why there is a debit balance (prepaid, overpaid, advanced). Reclassify in 调整分录, or record why it stays"}),
    "A3": (SHEET, ["追加科目"], {
        "ja": "使っている科目を「追加科目」表に足す",
        "zh": "把用到的科目加进「追加科目」表",
        "en": "Add the account to the 追加科目 sheet"}),
    "A4": (SHEET, ["调整分录", "每月工资"], {
        "ja": "「调整分录」「每月工资」表の日付を確認（締める月の中か、未来でないか）",
        "zh": "检查「调整分录」「每月工资」表的日期（是否在结账月内、是否是未来日期）",
        "en": "Check the dates in the 调整分录 / 每月工资 sheets (inside the month, not in the future)"}),
    "C1": (SHEET, ["每月工资", "固定工资"], {
        "ja": "「每月工资」「固定工资」表の支給・控除を確認（差引が負・控除が負）",
        "zh": "检查「每月工资」「固定工资」表的支付和扣除（实发为负或扣除为负）",
        "en": "Check pay and deductions in the 每月工资 / 固定工资 sheets"}),
    "C2": (SHEET, ["标准报酬"], {
        "ja": "「标准报酬」表の月額と年金事務所の告知額を照合",
        "zh": "把「标准报酬」表的月额和年金事务所的缴费通知核对",
        "en": "Compare the 标准报酬 sheet with the pension office notice"}),
    "C3": (SHEET, ["期初余额", "方针"], {
        "ja": "「期初余额」表の未払社保・預り金を前月分の告知で確認。徴収方法（方针）も確認",
        "zh": "用上月的缴费通知核对「期初余额」表里的未付社保和預り金；同时确认「方针」表的征收方式",
        "en": "Check unpaid social insurance in 期初余额 against last month's notice, and the collection policy"}),
    "C4": (SHEET, ["固定资产", "期初余额"], {
        "ja": "「固定资产」表の取得価額と「期初余额」表の資産残高を合わせる（税込・税抜の取り違えに注意）",
        "zh": "让「固定资产」表的取得价和「期初余额」表的资产余额一致（注意含税/不含税）",
        "en": "Make the 固定资产 cost match the 期初余额 balance (watch tax-inclusive vs exclusive)"}),
    "C5": (SHEET, ["劳动保险"], {
        "ja": "「劳动保险」表の前年度の概算納付額を確認",
        "zh": "核对「劳动保险」表的上年度已缴概算",
        "en": "Check the estimate paid last year in the 劳动保险 sheet"}),
    "E1": (ANSWER, [], {
        "ja": "期限後の納付。延滞金・督促の有無を確認し、要確認があれば「回答」に記録",
        "zh": "属于逾期缴纳。请确认有无滞纳金或催缴通知，如有待确认请在「回答」里记录",
        "en": "Paid after the due date — check for late fees or reminders and record it"}),
    "X2": (SHEET, ["回答"], {
        "ja": "使われていない回答を「回答」表から消す",
        "zh": "从「回答」表删除未被使用的回答",
        "en": "Delete unused answers from the 回答 sheet"}),
}
# 客の入力では直らない（エンジンの内部整合）
for _cid in ("A1", "A2", "A7", "B1B2", "B4", "F1", "F2", "X1"):
    CHECK_RULES[_cid] = (CONTACT, [], {
        "ja": "エンジン内部の検査。客の入力では直らない——底稿を添えて連絡してください",
        "zh": "这是引擎内部检查，无法通过修改资料解决——请附上底稿联系我们",
        "en": "Internal engine check — not fixable from your input. Please contact us with the workpaper"})

GENERIC = (ANSWER, [], {"ja": "内容を確認し「回答」する", "zh": "确认内容后点「回答」", "en": "Review it and answer"})


def _files(sheets):
    from .web import CHECKLIST
    out = []
    for s in sheets:
        for c in CHECKLIST:
            if s in c["sheets"] and c["path"] not in out:
                out.append(c["path"])
    return out


def _pack(rule, lang):
    how, sheets, text = rule
    return dict(how=how, sheets=list(sheets), files=_files(sheets), text=text.get(lang) or text["ja"])


def pending_rule(key: str, category: str):
    for cat, prefix, how, sheets, text in PENDING_RULES:
        if (cat is None or cat == category) and key.startswith(prefix):
            return (how, sheets, text), prefix
    return GENERIC, None


def for_pending(key: str, category: str, lang: str) -> dict:
    return _pack(pending_rule(key, category)[0], lang)


def for_check(cid: str, lang: str) -> dict | None:
    rule = CHECK_RULES.get(cid)
    return _pack(rule, lang) if rule else None
