# -*- coding: utf-8 -*-
"""結果画面に出す「結果」：汇总の数字・貸借対照表・損益計算書・これから納めるもの・事項の三分類。

作者 2026-10-10（工作台 v2）：客はまず結果（汇总 → 貸借対照表 → 損益計算書）を見て、そのあと事項を
「待確認／待処理／疑似錯誤」の三つで片付ける。エンジン内部の検査の一覧は客には見せない（会計向けの概要に残す）。

数字はすべて試算表（res.tb）と close.statements から取る。ここで新しく計算するのは並べ方と符号だけ。
"""
from __future__ import annotations

import datetime

from . import close, journal
from .jp.calendar import add_months, due, month_end, next_business_day

BS_ORDER = [("流動資産", "asset"), ("有形固定資産", "asset"), ("無形固定資産", "asset"), ("投資その他の資産", "asset"),
            ("流動負債", "liab"), ("固定負債", "liab"), ("株主資本", "equity")]
PL_ROWS = [  # (区分, 符号: 収益は +1、費用は -1)
    ("売上高", 1), ("売上原価", -1), ("販売費及び一般管理費", -1), ("営業外収益", 1), ("営業外費用", -1),
    ("特別利益", 1), ("特別損失", -1), ("法人税等", -1)]

# 事項の三分類（キーの頭）。どれにも当たらなければ「待確認」（内容を確かめて答えるもの）
ERR_PREFIX = ("mismatch:", "decision_sum:", "shaho_switch:", "opening_withholding:", "debit_balance:")
TODO_PREFIX = ("missing:", "juminzei_missing:", "commute_limit:", "smr_evidence:", "labor_annual:", "corp_tax:",
               "stale:", "dep:")
# 客の事項に二重に出さない検査：B7（暫記が残る＝待確認の明細そのもの）、A9（借方残高は一件ずつ debit_balance の要確認になる）
CUSTOMER_HIDDEN_CHECKS = {"B7", "A9"}


def bucket(key: str) -> str:
    if key.startswith(ERR_PREFIX):
        return "err"
    if key.startswith(TODO_PREFIX):
        return "todo"
    return "ask"


def _line(co, acc, amount):
    return dict(account=acc, cn=co.chart[acc].get("cn", ""), amount=amount)


def balance_sheet(co, res, st):
    out = []
    for sec, kind in BS_ORDER:
        accs = st["sections"].get(sec) or {}
        sign = 1 if kind == "asset" else -1
        lines = [_line(co, a, sign * b) for a, b in sorted(accs.items(), key=lambda x: co.chart[x[0]].get("code", 0)) if b]
        if kind == "equity" and st["unclosed_pl"]:
            lines.append(dict(account="当期純損益（未振替）", cn="本期损益（未结转）", amount=st["unclosed_pl"]))
        if lines:
            out.append(dict(section=sec, kind=kind, lines=lines, total=sum(l["amount"] for l in lines)))
    return dict(sections=out, assets=st["assets"], liabilities=st["liabilities"], equity=st["equity"])


def income_statement(co, st):
    rows = []
    for sec, sign in PL_ROWS:
        accs = sorted({a for a in list(st["month"]) + list(st["ytd"]) if co.chart[a]["section"] == sec},
                      key=lambda a: co.chart[a].get("code", 0))
        # 試算表は借方正。収益（貸方）は符号を返して正に、費用はそのまま正
        lines = [dict(_line(co, a, -sign * st["month"].get(a, 0)), ytd=-sign * st["ytd"].get(a, 0)) for a in accs]
        if lines:
            rows.append(dict(section=sec, sign=sign, lines=lines, total=sum(l["amount"] for l in lines),
                             total_ytd=sum(l["ytd"] for l in lines)))
    return dict(sections=rows, net_month=st["net_income_month"], net_ytd=st["net_income_ytd"])


def upcoming(co, led, res):
    """これから納めるもの（月末残高から。金額は帳簿の預り金・未払の残高で、告知書・納付書と照合すること）。"""
    m = res.month
    out = []
    n = led.notices.get(m)
    if n is not None:
        d, _ = due(m, "next_month_end")
        out.append(dict(what="shaho", label=f"{m:%Y-%m}分 社会保険料", date=str(d), month=f"{m:%Y-%m}", tokurei=False,
                        amount=n.health + n.pension + n.contribution))
    for kind, sub, pol, label in (("gensen", journal.GENSEN, "gensen_nouki_tokurei", "源泉所得税"),
                                  ("jumin", journal.JUMIN, "juminzei_nouki_tokurei", "住民税")):
        amt = -res.tb.get(("預り金", sub), 0)
        if amt <= 0:
            continue                                   # 借方（先払い）なら今は納めるものが無い
        if co.policy[pol]:
            nxt = next(add_months(m, i) for i in range(1, 13) if add_months(m, i).month in close.TOKUREI[kind])
            day = close.TOKUREI[kind][nxt.month][0]
            d = next_business_day(nxt.replace(day=day))
            out.append(dict(what=kind, label=f"{label}（納期の特例）", date=str(d), month=f"{m:%Y-%m}", tokurei=True, amount=amt))
        else:
            d, _ = due(m, "next_month_10")
            out.append(dict(what=kind, label=label, date=str(d), month=f"{m:%Y-%m}", tokurei=False, amount=amt))
    return sorted(out, key=lambda x: x["date"])


def summary(co, led, res, st):
    banks = {(b["account"], b.get("sub", "")) for b in co.bank_accounts}
    cash = sum(res.tb.get(k, 0) for k in banks)
    rev = lambda d: -sum(v for a, v in d.items() if co.chart[a]["section"] == "売上高")
    sus = [(journal.SUSPENSE[k], res.tb.get((journal.SUSPENSE[k], journal.SUSPENSE_SUB), 0)) for k in ("out", "in")]
    b6 = [c for c in res.report.checks if c.id == "B6"]
    return dict(revenue_month=rev(st["month"]), revenue_ytd=rev(st["ytd"]),
                profit_month=st["net_income_month"], profit_ytd=st["net_income_ytd"],
                cash=cash, bank_ok=bool(b6) and b6[0].status == "PASS",
                suspense_amount=sum(abs(b) for _, b in sus),
                suspense_rows=sum(1 for p in led.pending.open_items() if p.category == "bank_unmatched"),
                as_of=str(month_end(res.month.year, res.month.month)))


def build(co, led, res):
    st = close.statements(co, res.tb, res.month, led)
    return dict(summary=summary(co, led, res, st), bs=balance_sheet(co, res, st), pl=income_statement(co, st),
                upcoming=upcoming(co, led, res))
