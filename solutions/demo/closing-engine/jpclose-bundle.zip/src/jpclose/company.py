# -*- coding: utf-8 -*-
"""会社ディレクトリの読み込みと検証。

## 既定値を置かない、という方針

設定は二種類あり、**どちらにも既定値を置かない**：

  事実      都道府県・労災の業種・従業員の生年月日・標準報酬月額・住民税の月額 …
            既定値を置けば「入れ忘れ」が「入れた」に化ける。
  方針      翌月徴収か当月徴収か・支援金の端数を健保と合算するか・雇用保険料率の年度判定・
            会社負担の社保を月末に未払計上するか …
            製品の利用者は会計の素養がある前提なので、方針は**会計担当者が選ぶ**。
            製品が黙って選べば、その会社の慣行と違っても誰も気づかない。

足りなければ CompanyError で止める。メッセージには「何を・どの選択肢から」を書く。
"""
from __future__ import annotations

import datetime
import pathlib
from dataclasses import dataclass, field

import yaml

from .jp.rates import JpRates
from .judgments import Judgment, JudgmentError
from .judgments import audit as _audit

CHART = pathlib.Path(__file__).resolve().parents[2] / "data" / "jp" / "chart_of_accounts.yaml"

POLICY_CHOICES = {
    "shaho_collection": ("next_month", "same_month"),
    "shaho_rounding": ("deduct_half_down", "cash_half_up", "truncate"),
    "koyou_rounding": ("deduct_half_down", "cash_half_up", "truncate"),
    "support_rounding": ("with_health", "separate"),
    "koyou_rate_basis": ("closing_date", "pay_date"),
    "shaho_expense": ("accrual", "on_payment"),
    "labor_insurance_expense": ("monthly_accrual", "on_payment"),
    "gensen_nouki_tokurei": (True, False),
    "juminzei_nouki_tokurei": (True, False),
}
POLICY_HELP = {
    "shaho_collection": "社会保険料を給与から控除する月：next_month（翌月徴収・前月分を控除）/ same_month（当月分を控除）",
    "shaho_rounding": "被保険者負担分の端数：deduct_half_down（法定・給与控除）/ cash_half_up / truncate（特約）",
    "koyou_rounding": "雇用保険の被保険者負担分の端数（社保と同じ三択）",
    "support_rounding": "子ども・子育て支援金の被保険者負担分を健保（＋介護）と合算して丸めるか、別に丸めるか",
    "koyou_rate_basis": "雇用保険料率の年度を賃金の締日で判定するか支払日で判定するか（一次資料で未確認——会社の運用を選ぶ）",
    "shaho_expense": "会社負担の社会保険料：accrual（その月分を月末に未払費用で計上）/ on_payment（納付時に費用）",
    "labor_insurance_expense": ("労働保険の会社負担（雇用保険の事業主分・労災・一般拠出金）：monthly_accrual"
                                "（毎月の賃金から見積って未払費用に計上）/ on_payment（年度更新の納付時に費用）"),
    "gensen_nouki_tokurei": "源泉所得税の納期の特例（承認を受けているか）",
    "juminzei_nouki_tokurei": "住民税の納期の特例（承認を受けているか）",
}


class CompanyError(ValueError):
    pass



def audit(d, where):
    """判断記録の欠けも設定の誤りとして扱う（呼び手は CompanyError だけ捕まえればよい）。"""
    try:
        return _audit(d, where)
    except JudgmentError as e:
        raise CompanyError(str(e)) from None


def _month(s) -> datetime.date:
    if isinstance(s, datetime.date):
        return s.replace(day=1)
    y, m = str(s).split("-")[:2]
    return datetime.date(int(y), int(m), 1)


def _date(s):
    if s is None or isinstance(s, datetime.date):
        return s
    return datetime.date.fromisoformat(str(s))


@dataclass
class Employee:
    id: str
    display: str
    role: str                       # officer / employee
    birth: datetime.date
    hired: datetime.date
    left: datetime.date | None
    smr: list                       # [(from_month, amount, evidence)]
    shaho: bool
    koyou: bool
    wh_column: str                  # kou / otsu
    dependents: int
    juminzei: dict                  # {month: amount}
    pay: dict                       # 毎月の固定支給 {項目: 額}
    commute: dict = field(default_factory=dict)   # 通勤方法（非課税限度の計算用）

    def smr_for(self, month: datetime.date):
        hits = [s for s in self.smr if s[0] <= month]
        if not hits:
            return None
        return max(hits, key=lambda s: s[0])

    def loss_month(self) -> datetime.date | None:
        """資格喪失日（退職日の翌日）の属する月。"""
        if self.left is None:
            return None
        return _month(self.left + datetime.timedelta(days=1))

    def insured_for(self, month: datetime.date) -> bool:
        """その月分の社会保険料がかかるか：取得月 ≦ month < 喪失月。"""
        if not self.shaho:
            return False
        if _month(self.hired) > month:
            return False
        lm = self.loss_month()
        return lm is None or month < lm


@dataclass
class Company:
    root: pathlib.Path
    name: str
    prefecture: str
    rousai_code: str
    koyou_kind: str
    fy_end_month: int
    start_month: datetime.date
    policy: dict
    pay_items: dict
    pay_day: int
    pay_day_shift: str
    closing_day: str
    bank_accounts: list
    employees: list
    chart: dict
    opening: dict
    rules: list = field(default_factory=list)
    fixed_assets: list = field(default_factory=list)
    decisions: dict = field(default_factory=dict)
    judgments: list = field(default_factory=list)          # 判断の記録（誰が・いつ・なぜ）
    bank_keywords: dict = field(default_factory=dict)    # 予定支払の摘要の手がかり（金額不一致の発見用）
    adjustments: list = field(default_factory=list)      # 決算整理など手入力の仕訳（判断記録つき）
    ct: dict = field(default_factory=dict)               # 消費税の設定（status / method / category / accounting）
    labor_annual: dict = field(default_factory=dict)     # 年度更新の入力 {保険年度の開始年: dict}
    municipality: str = ""                               # 本店所在の市区町村（法人住民税）
    corporate_tax: dict = field(default_factory=dict)    # 法人税等の入力 {"YYYY-MM"（事業年度末）: dict}

    def emp(self, eid) -> Employee:
        for e in self.employees:
            if e.id == eid:
                return e
        raise CompanyError(f"従業員 {eid} が名簿に無い")

    def monthly_input(self, month: datetime.date) -> dict:
        p = self.root / "monthly" / f"{month:%Y-%m}" / "payroll.yaml"
        if not p.exists():
            return {}
        return yaml.safe_load(p.read_text(encoding="utf-8")) or {}


JUDGMENT_KEYS = {"value", "by", "at", "reason", "note", "evidence"}


def _only_judgment_keys(d, where):
    """方針・消費税の判断は {value, by, at, reason} だけ。余計なキーは書き間違い。

    一番多いのは理由の中の半角カンマ：{value: exempt, by: A, at: 2026-05-01, reason: 資本金1,000万円未満}
    と一行で書くと YAML は「1」で切り、「000万円未満」という別のキーにする——理由が黙って欠ける
    （製品のサンプル 2 社がこれをやっていた。2026-10-09 発見）。"""
    extra = sorted(str(k) for k in d if k not in JUDGMENT_KEYS) if isinstance(d, dict) else []
    if extra:
        raise CompanyError(f"{where}：判断の記録に知らない項目 {extra}。理由に半角カンマ「,」があると "
                           f"{{…}} の一行書きでは切れる——理由を引用符で囲むか、行を分けて書く")


def _req(d, key, where):
    if key not in d or d[key] in (None, ""):
        raise CompanyError(f"{where} に「{key}」が無い（既定値は置かない設計——明示すること）")
    return d[key]


def load_chart(extra=()):
    doc = yaml.safe_load(CHART.read_text(encoding="utf-8"))
    chart = {a["name"]: a for a in doc["accounts"]}
    for a in extra:
        if a["name"] in chart:
            raise CompanyError(f"科目「{a['name']}」は標準科目表にある（改名・重複追加はできない）")
        for k in ("code", "name", "section", "normal"):
            _req(a, k, f"追加科目 {a.get('name')}")
        chart[a["name"]] = a
    return chart, doc


def load(root, rates: JpRates | None = None) -> Company:
    root = pathlib.Path(root)
    rates = rates or JpRates()
    y = lambda name: yaml.safe_load((root / name).read_text(encoding="utf-8")) if (root / name).exists() else None
    c = y("company.yaml")
    if c is None:
        raise CompanyError(f"{root} に company.yaml が無い")
    co, pr = _req(c, "company", "company.yaml"), _req(c, "payroll", "company.yaml")

    pref = _req(co, "prefecture", "company")
    if pref not in rates.prefectures():
        raise CompanyError(f"都道府県「{pref}」は協会けんぽの料率表に無い")
    if co.get("health_insurer", "kyoukaikenpo") != "kyoukaikenpo":
        raise CompanyError("健康保険組合は未対応（協会けんぽのみ）。組合の料率表を取り込む仕組みが必要")

    # 方針：会社の policies が事務所の既定（office.yaml）を上書きする。どちらにも無ければ止める。
    stray = [k for k in POLICY_CHOICES if k in pr]
    if stray:
        raise CompanyError(f"payroll 直下の方針 {stray} は旧形式。policies: の下に "
                           f"{{value, by, at, reason}} で書く（判断の記録を残すため）")
    office = {}
    if c.get("office"):
        op = (root / c["office"]).resolve()
        if not op.exists():
            raise CompanyError(f"事務所の既定 {op} が無い")
        office = (yaml.safe_load(op.read_text(encoding="utf-8")) or {}).get("policies", {}) or {}
    own = c.get("policies") or {}
    policy, judgments = {}, []
    for k, choices in POLICY_CHOICES.items():
        if k in own:
            ent, src = own[k], "本社"
        elif k in office:
            ent, src = office[k], "事務所既定"
        else:
            raise CompanyError(f"方針 {k} が会社にも事務所既定にも無い——{POLICY_HELP[k]}。選択肢 {list(choices)}")
        _only_judgment_keys(ent, f"方針 {k}（{src}）")
        by, at, reason = audit(ent, f"方針 {k}（{src}）")
        if ent.get("value") not in choices:
            raise CompanyError(f"方針 {k} = {ent.get('value')!r} は選択肢 {list(choices)} に無い")
        policy[k] = ent["value"]
        judgments.append(Judgment("方針", k, str(ent["value"]), by, at, reason, src))

    chart, _ = load_chart((c.get("accounts") or {}).get("add", []))
    items = _req(pr, "items", "payroll")
    for name, it in items.items():
        for k in ("account", "taxable", "koyou_wage"):
            _req(it, k, f"支給項目「{name}」")
        if it["account"] not in chart:
            raise CompanyError(f"支給項目「{name}」の科目「{it['account']}」が科目表に無い")

    emps = []
    e_doc = y("employees.yaml") or {}
    for e in _req(e_doc, "employees", "employees.yaml"):
        where = f"従業員 {e.get('id')}"
        role = _req(e, "role", where)
        if role not in ("officer", "employee"):
            raise CompanyError(f"{where}: role は officer / employee")
        smr = []
        for s in e.get("smr", []):
            rates.grade_row(pref, s["amount"])              # 等級値でなければここで止まる
            smr.append((_month(s["from"]), int(s["amount"]), s.get("evidence")))
        if "shaho" not in e or "koyou" not in e:
            raise CompanyError(f"{where}: shaho（社会保険加入）と koyou（雇用保険加入）を true/false で明示すること")
        shaho = bool(e["shaho"])
        if shaho and not smr:
            raise CompanyError(f"{where}: 社会保険に加入しているのに標準報酬月額が無い")
        koyou = bool(e["koyou"])
        if role == "officer" and koyou:
            raise CompanyError(f"{where}: 役員は原則として雇用保険の被保険者にならない"
                               f"（兼務役員なら role: employee にして理由を note に書く）")
        wh = _req(e, "withholding", where)
        if wh.get("column") not in ("kou", "otsu"):
            raise CompanyError(f"{where}: withholding.column は kou（扶養控除等申告書あり）/ otsu")
        for item in (e.get("pay") or {}):
            if item not in items:
                raise CompanyError(f"{where}: 支給項目「{item}」が payroll.items に無い")
        emps.append(Employee(
            id=e["id"], display=e.get("display", e["id"]), role=role,
            birth=_date(_req(e, "birth", where)), hired=_date(_req(e, "hired", where)),
            left=_date(e.get("left")), smr=sorted(smr), shaho=shaho, koyou=koyou,
            wh_column=wh["column"], dependents=int(wh.get("dependents", 0)),
            juminzei={_month(k): int(v) for k, v in (e.get("juminzei") or {}).items()},
            pay=dict(e.get("pay") or {}), commute=dict(e.get("commute") or {})))
    ids = [e.id for e in emps]
    if len(set(ids)) != len(ids):
        raise CompanyError("従業員 id が重複")

    banks = _req(c, "bank_accounts", "company.yaml")
    for b in banks:
        for k in ("id", "account", "csv", "files"):
            _req(b, k, f"銀行口座 {b.get('id')}")
        if b["account"] not in chart:
            raise CompanyError(f"銀行口座 {b['id']} の科目「{b['account']}」が科目表に無い")

    opening = y("opening_balances.yaml") or {}
    rules = (y("bank_rules.yaml") or {}).get("rules", [])
    for r in rules:
        for k in ("id", "when", "then"):
            _req(r, k, f"銀行ルール {r.get('id')}")
        acc = r["then"].get("debit") or r["then"].get("credit")
        if acc not in chart:
            raise CompanyError(f"銀行ルール {r['id']} の科目「{acc}」が科目表に無い")
    for r in rules:
        by, at, reason = audit(r, f"銀行ルール {r['id']}")
        w, t = r["when"], r["then"]
        judgments.append(Judgment("銀行ルール", r["id"],
                                  f"{w} → {t.get('debit') or t.get('credit')} {t.get('tax', '')}".strip(),
                                  by, at, reason or r.get("note", "")))
    fa = (y("fixed_assets.yaml") or {}).get("assets", [])
    for a in fa:
        by, at, reason = audit(a, f"固定資産 {a.get('id')}")
        judgments.append(Judgment("固定資産", a["id"], f"{a['name']}：{a['method']}・耐用年数 {a['life']} 年",
                                  by, at, reason))
    # 消費税：事実（課税・免税）と方針（本則・簡易、税込・税抜）。既定値なし、判断記録つき。
    ctd = c.get("consumption_tax") or {}
    ct = {}
    choices = {"status": ("taxable", "exempt"), "method": ("general", "simplified"),
               "category": (1, 2, 3, 4, 5, 6), "accounting": ("tax_included", "tax_excluded")}
    need = ["status", "accounting"]
    if (ctd.get("status") or {}).get("value") == "taxable":
        need.append("method")
        if (ctd.get("method") or {}).get("value") == "simplified":
            need.append("category")
    for k in need:
        if k not in ctd:
            raise CompanyError(f"consumption_tax.{k} が無い——選択肢 {list(choices[k])}（by・at を添えて書く）")
        _only_judgment_keys(ctd[k], f"消費税 {k}")
        by, at, reason = audit(ctd[k], f"消費税 {k}")
        val = ctd[k].get("value")
        if val not in choices[k]:
            raise CompanyError(f"consumption_tax.{k} = {val!r} は選択肢 {list(choices[k])} に無い")
        ct[k] = val
        judgments.append(Judgment("消費税", k, str(val), by, at, reason))
    ct.setdefault("method", None)
    ct.setdefault("category", None)

    # 決算整理仕訳（棚卸・見越し繰延・引当金・法人税等…）。判断そのものなので by・at 必須。
    adjustments = []
    for a in (y("adjustments.yaml") or {}).get("entries", []) or []:
        where = f"調整仕訳 {a.get('id')}"
        for k in ("id", "date", "narration", "lines"):
            _req(a, k, where)
        by, at, reason = audit(a, where)
        dr = cr = 0
        for l in a["lines"]:
            if l.get("account") not in chart:
                raise CompanyError(f"{where}：科目「{l.get('account')}」が科目表に無い")
            if bool(l.get("debit")) == bool(l.get("credit")):
                raise CompanyError(f"{where}：一行に借方か貸方のどちらか一方だけを書く")
            dr += int(l.get("debit") or 0)
            cr += int(l.get("credit") or 0)
        if dr != cr or dr == 0:
            raise CompanyError(f"{where}：借方 {dr:,} ≠ 貸方 {cr:,}")
        a["date"] = _date(a["date"])
        adjustments.append(a)
        judgments.append(Judgment("決算整理", a["id"], f"{a['date']} {a['narration']}（{dr:,} 円）", by, at, reason))
    # 年度更新の入力（開始月より前の賃金・前年度の概算納付額など）。事実と判断なので by・at 必須。
    labor_annual = {}
    for a in (y("labor_insurance.yaml") or {}).get("annual", []) or []:
        where = f"年度更新 {a.get('fiscal_year')}"
        for k in ("fiscal_year", "estimate_paid"):
            _req(a, k, where)
        by, at, reason = audit(a, where)
        labor_annual[int(a["fiscal_year"])] = a
        judgments.append(Judgment("年度更新", str(a["fiscal_year"]),
                                  f"前年度概算 {int(a['estimate_paid']):,}・開始前賃金 {a.get('wages_before_start')}"
                                  f"・延納 {bool(a.get('installment'))}", by, at, reason))
    # 法人税等の計算表の入力（申告調整・繰越欠損金・中間納付・読めなかった地方税率）。by・at 必須。
    corporate_tax = {}
    for a in (y("corporate_tax.yaml") or {}).get("years", []) or []:
        where = f"法人税等 {a.get('fiscal_year_end')}"
        _req(a, "fiscal_year_end", where)
        by, at, reason = audit(a, where)
        key = str(a["fiscal_year_end"])[:7]
        corporate_tax[key] = a
        judgments.append(Judgment("法人税等", key, f"加算・減算 {a.get('adjustments')}・繰越欠損金 "
                                  f"{a.get('loss_carryforward', 0)}・府民税率 {a.get('pref_houjinzeiwari_rate')}"
                                  f"・事業税超過 {a.get('jigyouzei_excess')}", by, at, reason))
    decisions = (y("decisions.yaml") or {}).get("decisions", {}) or {}
    for k, d in decisions.items():
        by, at, reason = audit(d, f"回答 {k}")
        val = d.get("action", "")
        if d.get("account"):
            val += f" → {d['account']} {d.get('tax', '')}".rstrip()
        judgments.append(Judgment("回答", k, val, by, at, reason))

    return Company(
        root=root, name=_req(co, "name", "company"), prefecture=pref,
        rousai_code=str(_req(co, "rousai_code", "company")),
        koyou_kind=_req(co, "koyou_kind", "company"),
        fy_end_month=int(_req(co, "fiscal_year_end_month", "company")),
        start_month=_month(_req(co, "start_month", "company")),
        policy=policy, pay_items=items,
        pay_day=int(_req(pr, "pay_day", "payroll")),
        pay_day_shift=_req(pr, "pay_day_shift", "payroll"),
        closing_day=str(_req(pr, "closing_day", "payroll")),
        bank_accounts=banks, employees=emps, chart=chart, opening=opening,
        rules=rules, fixed_assets=fa, decisions=decisions, judgments=judgments,
        bank_keywords=c.get("bank_keywords") or {}, adjustments=adjustments, ct=ct,
        labor_annual=labor_annual, municipality=co.get("municipality", ""),
        corporate_tax=corporate_tax)
