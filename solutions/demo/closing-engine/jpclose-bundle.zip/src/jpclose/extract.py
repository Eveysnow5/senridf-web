# -*- coding: utf-8 -*-
"""証憑の文字から値を取る（作者 2026-10-10：invoice2data のテンプレートの考え方を借りる）。

テンプレートは 1 種類の書類につき YAML 1 枚：見分ける語（keywords）と、項目ごとの取り方（regex）。
製品の内蔵は data/jp/evidence_templates/（公的機関・公共料金の様式）、会社独自の様式（自社の勤務表など）は
会社フォルダの evidence/templates/ に置く（invoice2data と同じ「内蔵＋利用者のテンプレート」）。

invoice2data に足したもの（このエンジンの断言の考え方）：
  · checks：「健保＋厚年＋子ども・子育て拠出金＝合計」のように、取った値どうしの式。通らなければ ok=False
    （下書きにはするが、自動では使わない）。OCR は桁を落とす・取り違えるので、式で確かめられる書類は必ず書く
  · sum_parts：ラベルと数字が離れて読まれても、「足すと合計になる並び」を数字の列から探す取り方

入力は OCR（またはPDF の文字層）の行の列。OCR 由来の揺れ（全角半角、簡体字に読まれた漢字、桁の間の空白、
「合和」→「令和」）は normalize で吸収してから照合する。
"""
from __future__ import annotations

import datetime
import pathlib
import re
import unicodedata
from dataclasses import dataclass, field

from decimal import Decimal, InvalidOperation

import yaml

BUILTIN = pathlib.Path(__file__).resolve().parents[2] / "data" / "jp" / "evidence_templates"
COMPANY_DIR = "evidence/templates"

# OCR（中国語も読むモデル）が簡体字・別字で返す漢字 → 日本の字。キーワード照合のためだけに使う
_KANJI = str.maketrans({
    "纳": "納", "领": "領", "银": "銀", "额": "額", "证": "証", "险": "険", "构": "構", "务": "務", "费": "費",
    "电": "電", "气": "気", "书": "書", "处": "処", "单": "単", "发": "発", "开": "開", "时": "時", "间": "間",
    "计": "計", "总": "総", "给": "給", "员": "員", "业": "業", "从": "従", "对": "対", "检": "検", "库": "庫",
    "边": "辺", "收": "収", "权": "権", "记": "記", "关": "関", "为": "為", "图": "図", "长": "長", "门": "門",
    "东": "東", "风": "風", "乐": "楽", "价": "価", "众": "衆", "传": "伝", "资": "資", "产": "産", "预": "預", "齐": "斉",
})
_WAREKI = {"令和": 2018, "平成": 1988}


def normalize(text: str) -> str:
    s = unicodedata.normalize("NFKC", text or "").translate(_KANJI)
    s = re.sub(r"合和|今和|令利|合利", "令和", s)
    s = s.replace("¥", "￥").replace("\\", "￥")
    # Windows の文字認識（本機の読み取り助手）によくある読み違い（作者の 35 頁で見たもの、2026-10-15）：
    #   「V12,345」「Y1.122」＝￥（桁区切りのある金額の前のときだけ。英字の続きは除く）
    #   「¥45,OOO」＝0（数字と同じ並びの中の O だけ。「OCR」「(O O H)」のような英字の並びは触らない）
    #   「1′234円」＝桁区切りのコンマ
    s = re.sub(r"(?<![A-Za-z])[VY]\s?(?=\d{1,3}(?:[,.]\d{3})+(?!\d))", "￥", s)
    s = re.sub(r"(?<![A-Za-z])[\dO][\d.,O]*(?![A-Za-z])",
               lambda m: m.group(0).replace("O", "0") if re.search(r"\d", m.group(0)) else m.group(0), s)
    s = re.sub(r"(?<=\d)[′'](?=\d{3}(?!\d))", ",", s)
    # 「￥8 6 7 0 0」のような 1 桁ずつの数字（枠に 1 桁ずつ印字された金額）だけを詰める。
    # 「41230 57340 1150」（別々の数が 1 行に並んだもの）は詰めない
    s = re.sub(r"(?<![\d,])\d(?:[ 　]\d){2,}(?![\d,])", lambda m: re.sub(r"[ 　]", "", m.group(0)), s)
    return s


def _int(s) -> int | None:
    if s is None:
        return None
    t = re.sub(r"[,，.、\s￥円]", "", str(s))
    return int(t) if t.isdigit() else None


def _wareki_year(era: str, y: str) -> int:
    return _WAREKI[era] + int(y)


@dataclass
class Result:
    template: str                       # テンプレートの id
    doc: str                            # 書類の種類（索引簿の「書類」）
    party: str                          # 取引先
    fields: dict
    amount: int | None
    date: datetime.date | None
    ok: bool                            # 必須項目がそろい、checks が全部通った
    problems: list = field(default_factory=list)
    currency: str = ""                  # 外貨の書類なら通貨（CNY…）。このとき amount（円）はテンプレートからは入らない
    foreign: int | None = None          # 外貨の金額（1/100 の単位：1250.00 元 → 125000）
    conversion: dict | None = None      # 書類に書いてあった換算（手書きでも）：{rate, yen}。掛け算が合うものだけ

    def as_dict(self) -> dict:
        return dict(template=self.template, doc=self.doc, party=self.party,
                    fields={k: (str(v) if isinstance(v, datetime.date) else v) for k, v in self.fields.items()},
                    amount=self.amount, date=str(self.date) if self.date else "", ok=self.ok, problems=self.problems,
                    currency=self.currency, foreign=self.foreign, conversion=self.conversion)


@dataclass
class Template:
    id: str
    doc: str
    party: str
    keywords: list
    exclude: list
    fields: dict
    checks: list
    amount: str
    date: str
    required: list
    source: str
    repeat: str = ""                    # 1 頁に同じ書類が何枚も並ぶとき、1 枚ごとの目印（正規表現）
    currency: str = ""                  # 外貨の書類：通貨。金額の項目は foreign に書く（amount は書かない）
    foreign: str = ""                   # 外貨の金額の項目名（type: minor）

    def matches(self, text: str) -> bool:
        return (all(re.search(k, text) for k in self.keywords)
                and not any(re.search(k, text) for k in self.exclude))


def load_templates(company_root=None) -> list:
    dirs = [BUILTIN]
    if company_root is not None:
        dirs.append(pathlib.Path(company_root) / COMPANY_DIR)
    out, seen = [], set()
    for d in dirs:
        if not d.exists():
            continue
        for p in sorted(d.glob("*.yaml")):
            t = yaml.safe_load(p.read_text(encoding="utf-8")) or {}
            tid = t.get("id") or p.stem
            if tid in seen:
                raise ValueError(f"テンプレートの id「{tid}」が重複（{p}）")
            seen.add(tid)
            fields = t.get("fields") or {}
            for k, f in fields.items():
                if not isinstance(f, dict) or not ({"regex", "sum_parts", "value"} & set(f)):
                    raise ValueError(f"{p.name}：項目 {k} に regex / sum_parts / value がありません")
            out.append(Template(id=tid, doc=t["doc"], party=t.get("party", ""), keywords=t["keywords"],
                                exclude=t.get("exclude") or [], fields=fields, checks=t.get("checks") or [],
                                amount=t.get("amount", ""), date=t.get("date", ""),
                                required=t.get("required") or list(fields), source=str(p),
                                repeat=t.get("repeat", ""), currency=t.get("currency", ""),
                                foreign=t.get("foreign", "")))
            if out[-1].currency and (out[-1].amount or not out[-1].foreign):
                # 外貨の数を円の金額として下書きに入れない（￥は元にも円にも使う記号）
                raise ValueError(f"{p.name}：外貨（currency）の書類は amount を書かず、foreign に金額の項目を書いてください")
    return out


# ---- 項目の取り方
def _conv(kind: str, m: re.Match, today: datetime.date | None):
    g = [x for x in m.groups() if x is not None] if m.groups() else [m.group(0)]
    if kind == "int":
        return _int(g[0])
    if kind == "minor":                                  # 小数 2 桁の金額（元・ドル）→ 1/100 の単位の整数
        m2 = re.fullmatch(r"(\d[\d,]*)\.(\d{2})", g[0].strip())
        return int(m2.group(1).replace(",", "")) * 100 + int(m2.group(2)) if m2 else None
    if kind == "text":
        return g[0].strip()
    if kind == "date":                                   # 2026-03-21 / 2026年3月21日 / 2026/03/21
        y, mo, d = (int(x) for x in g[:3])
        return datetime.date(y, mo, d)
    if kind == "wareki_date":                            # (元号, 年, 月, 日)
        return datetime.date(_wareki_year(g[0], g[1]), int(g[2]), int(g[3]))
    if kind == "wareki_month":                           # (元号, 年, 月) → YYYY-MM
        return f"{_wareki_year(g[0], g[1]):04d}-{int(g[2]):02d}"
    if kind == "reiwa_month":                            # (令和の年, 月)：「8-3」「8年03月」
        y, mo = int(g[0]), int(g[1])
        if not (1 <= y <= 30 and 1 <= mo <= 12):
            return None
        return f"{2018 + y:04d}-{mo:02d}"
    if kind == "month":                                  # (年, 月)（西暦）
        return f"{int(g[0]):04d}-{int(g[1]):02d}"
    raise ValueError(f"型 {kind} はありません")


def _regex_field(f: dict, text: str, today, vals=None):
    """最初に当たった値。prefer: <項目> があれば、その項目と等しい値を優先する（同じ数が別の所にも印字されて
    いることの確認に使う：等しい値が無ければ最初の値 → 検算で落ちる）。"""
    pats = f["regex"] if isinstance(f["regex"], list) else [f["regex"]]
    want = (vals or {}).get(f.get("prefer")) if f.get("prefer") else None
    first = None
    for pat in pats:
        for m in re.finditer(pat, text):
            try:
                v = _conv(f.get("type", "text"), m, today)
            except (ValueError, KeyError):
                continue
            if v is None:
                continue
            lo, hi = f.get("min"), f.get("max")
            if isinstance(v, int) and ((lo is not None and v < lo) or (hi is not None and v > hi)):
                continue
            if want is None or v == want:
                return v
            first = v if first is None else first
    return first


def _numbers(text: str) -> list:
    """本文に現れる数（3 桁以上、桁区切りのカンマ可）を順に。"""
    return [int(x.replace(",", "")) for x in re.findall(r"(?<![\d,])\d{1,3}(?:,\d{3})+(?![\d,])|(?<![\d,])\d{3,9}(?![\d,])", text)]


def _sum_parts(f: dict, text: str) -> dict | None:
    """sum_parts: {parts: [a, b, c], total: t}。並んで読まれた数 a, b, c と、別の所にある t で a+b+c＝t のもの。
    候補が 2 通り以上（違う答え）なら取らない（推測しない）。"""
    nums = _numbers(text)
    k = len(f["sum_parts"])
    found = set()
    have = set(nums)
    for i in range(len(nums) - k + 1):
        part = nums[i:i + k]
        if any(p <= 0 for p in part):
            continue
        t = sum(part)
        if t in have and t not in part:
            found.add((tuple(part), t))
    if len(found) != 1:
        return None
    part, t = found.pop()
    out = dict(zip(f["sum_parts"], part))
    out[f["total"]] = t
    return out


_SIDE = r"[a-z0-9_]+(\s*(?://|[+\-*])\s*[a-z0-9_]+)*"
_CHECK = re.compile(rf"^{_SIDE}\s*==\s*{_SIDE}$")


def _check(expr: str, v: dict) -> bool | None:
    """「a + b + c == total」「hours * rate == pay」「tax == total // 11」だけ（左から順に計算）。
    値が欠けていれば None。"""
    if not _CHECK.match(expr):
        raise ValueError(f"検査式の書き方が違います：{expr}")
    names = set(re.findall(r"[a-z_][a-z0-9_]*", expr))
    if any(v.get(n) is None for n in names if not n.isdigit()):
        return None

    def ev(side):
        toks = re.findall(r"//|[+\-*]|[a-z0-9_]+", side)
        acc = v[toks[0]] if not toks[0].isdigit() else int(toks[0])
        for op, name in zip(toks[1::2], toks[2::2]):
            x = v[name] if not name.isdigit() else int(name)
            acc = acc + x if op == "+" else acc - x if op == "-" else acc * x if op == "*" else acc // x
        return acc
    left, right = expr.split("==")
    return ev(left) == ev(right)


_TIMES = re.compile(r"(\d[\d,]*(?:\.\d+)?)\s*[×xX*]\s*(\d+(?:\.\d+)?)\s*=\s*(\d[\d,]*(?:\.\d+)?)")


def written_conversion(text: str, foreign_minor: int) -> dict | None:
    """書類に書いてある換算「外貨の金額 × レート ＝ 円」（多くは手書き）。手書きの字は読み違えるので、
    **掛け算が合うものだけ**取る：左の数が書類の外貨の金額と同じで、積が右の数と 1 未満しか違わない。
    合うものが 2 通り（違う答え）あれば取らない。"""
    want = Decimal(foreign_minor) / 100
    found = set()
    for m in _TIMES.finditer(text):
        try:
            a, r, b = (Decimal(x.replace(",", "")) for x in m.groups())
        except InvalidOperation:
            continue
        if a == want and r > 0 and abs(a * r - b) < 1:
            found.add((str(r), str(b)))
    if len(found) != 1:
        return None
    rate, yen = found.pop()
    return dict(rate=rate, yen=yen)


def apply(t: Template, text: str, today: datetime.date | None = None, page: str | None = None) -> Result:
    """text＝この 1 枚の文字（repeat なら頁の一部）、page＝頁全体（scope: page の項目はここから取る：
    1 頁に複数枚あると、発行者の見出しは最初の 1 枚の前にしか無いことがある）。"""
    vals, problems = {}, []
    for name, f in t.fields.items():
        if "value" in f:
            vals[name] = f["value"]
        elif "sum_parts" in f:
            got = _sum_parts(f, text)
            if got:
                for k, x in got.items():
                    vals.setdefault(k, x)
        else:
            if name in vals:                             # sum_parts で取れている
                continue
            vals[name] = _regex_field(f, page if (f.get("scope") == "page" and page) else text, today, vals)
    for name in t.required:
        if vals.get(name) is None:
            problems.append(f"「{name}」が読めません")
    for expr in t.checks:
        r = _check(expr, vals)
        if r is False:
            problems.append(f"検算が合いません：{expr}")
        elif r is None:
            problems.append(f"検算できません（値が欠けています）：{expr}")
    amount = vals.get(t.amount) if t.amount else None
    date = vals.get(t.date) if t.date else None
    party = t.party or (vals.get("party") or "")
    foreign = vals.get(t.foreign) if t.foreign else None
    return Result(template=t.id, doc=t.doc, party=party, fields=vals, amount=amount,
                  date=date if isinstance(date, datetime.date) else None, ok=not problems, problems=problems,
                  currency=t.currency, foreign=foreign,
                  conversion=written_conversion(page or text, foreign) if (t.currency and foreign and not problems) else None)


def read(lines, templates, today: datetime.date | None = None) -> list:
    """1 頁の文字の行 → 当てはまったテンプレートの結果（無ければ空）。複数当てはまれば全部返す
    （同じ頁に電気と水道の票が並ぶ等）。"""
    text = normalize("\n".join(lines) if not isinstance(lines, str) else lines)
    out = []
    for t in templates:
        if not t.matches(text):
            continue
        if not t.repeat:
            out.append(apply(t, text, today))
            continue
        # 目印ごとに 1 枚：直前の目印の後ろから、この目印の終わりまでを 1 枚の文字とみなす
        start = 0
        for m in re.finditer(t.repeat, text):
            out.append(apply(t, text[start:m.end()], today, text))
            start = m.end()
    return out
