# -*- coding: utf-8 -*-
"""仕訳の型。

ここにあるのは**勘定科目と貸借の型だけ**。金額は payroll / bank / depreciation が計算し、
推導チェーンもそちらが持つ。型の選択（例：会社負担の社保を月末に未払計上するか）は
会社設定の方針で決まり、このモジュールは方針を自分で選ばない。

補助科目の命名（底稿で集計に使う）：
  預り金      社会保険料 / 雇用保険 / 源泉所得税 / 住民税
  未払費用    社会保険料（会社負担・月分）
  未払金      給与:<従業員id>
"""
from __future__ import annotations

from .core.model import Voucher

SI, KOYOU, GENSEN, JUMIN = "社会保険料", "雇用保険", "源泉所得税", "住民税"


def payroll(slip, co) -> Voucher:
    """給与の計上。差引支給額は未払金に置き、銀行の振込で消し込む。"""
    e = co.emp(slip.eid)
    v = Voucher(slip.pay_date, f"{slip.pay_month:%Y-%m} 給与 {e.display}", kind="payroll",
                evidence=f"自制:給与台帳 {slip.pay_month:%Y-%m}",
                derivation=list(slip.why) + [w for s in slip.shaho for w in s.why])
    for l in slip.earnings:
        v.add(l.account, debit=l.amount, sub=slip.eid, memo=l.name)
    v.add("預り金", credit=slip.shaho_total, sub=SI,
          memo=" ".join(f"{s.month:%Y-%m}分" for s in slip.shaho))
    v.add("預り金", credit=slip.koyou, sub=KOYOU)
    v.add("預り金", credit=slip.income_tax, sub=GENSEN)
    v.add("預り金", credit=slip.juminzei, sub=JUMIN)
    v.add("未払金", credit=slip.net, sub=f"給与:{slip.eid}")
    return v


def bonus(bs, co) -> Voucher:
    """賞与の計上。社保の被保険者負担は賞与そのものから控除する（翌月徴収の方針とは無関係）。"""
    e = co.emp(bs.eid)
    v = Voucher(bs.pay_date, f"{bs.pay_date:%Y-%m} 賞与 {e.display}", kind="payroll",
                evidence=f"自制:賞与台帳 {bs.pay_date:%Y-%m}", derivation=list(bs.why))
    v.add("賞与", debit=bs.amount, sub=bs.eid, memo="賞与")
    v.add("預り金", credit=bs.emp_total, sub=SI, memo=f"{bs.pay_date:%Y-%m}分 賞与")
    v.add("預り金", credit=bs.koyou, sub=KOYOU)
    v.add("預り金", credit=bs.income_tax, sub=GENSEN)
    v.add("未払金", credit=bs.net, sub=f"賞与:{bs.eid}")
    return v


def bonus_payout(bs, date, bank_account, bank_sub, row_label) -> Voucher:
    v = Voucher(date, f"賞与振込 {bs.eid}", kind="payout", evidence=f"銀行明細 {row_label}")
    v.add("未払金", debit=bs.net, sub=f"賞与:{bs.eid}")
    v.add(bank_account, credit=bs.net, sub=bank_sub)
    return v


def salary_payout(slip, date, bank_account, bank_sub, row_label) -> Voucher:
    v = Voucher(date, f"給与振込 {slip.eid}", kind="payout", evidence=f"銀行明細 {row_label}")
    v.add("未払金", debit=slip.net, sub=f"給与:{slip.eid}")
    v.add(bank_account, credit=slip.net, sub=bank_sub)
    return v


def shaho_accrual(notice, date) -> Voucher:
    """会社負担分（その月分）を月末に未払計上。会社負担＝告知額−被保険者負担。"""
    v = Voucher(date, f"{notice.month:%Y-%m}分 社会保険料 会社負担", kind="accrual",
                evidence=f"自制:社会保険料計算表 {notice.month:%Y-%m}分",
                derivation=[f"告知額 {notice.total:,}（健保 {notice.health:,}＋厚年 {notice.pension:,}"
                            f"＋拠出金 {notice.contribution:,}、個々の全額の合算を円未満切捨て"
                            f"・rules_r08.notice_total_truncate）− 被保険者負担 {notice.employee:,}"
                            f" ＝ 会社負担 {notice.company:,}"])
    v.add("法定福利費", debit=notice.company, memo=f"{notice.month:%Y-%m}分")
    v.add("未払費用", credit=notice.company, sub=SI, memo=f"{notice.month:%Y-%m}分")
    return v


def shaho_payment(notice, date, bank_account, bank_sub, row_label, policy) -> Voucher:
    v = Voucher(date, f"{notice.month:%Y-%m}分 社会保険料 納付", kind="payment",
                evidence=f"銀行明細 {row_label}／納入告知書 {notice.month:%Y-%m}分")
    v.add("預り金", debit=notice.employee, sub=SI, memo=f"{notice.month:%Y-%m}分 被保険者負担")
    if policy["shaho_expense"] == "accrual":
        v.add("未払費用", debit=notice.company, sub=SI, memo=f"{notice.month:%Y-%m}分 会社負担")
    else:
        v.add("法定福利費", debit=notice.company, memo=f"{notice.month:%Y-%m}分 会社負担")
    v.add(bank_account, credit=notice.total, sub=bank_sub)
    return v


def withholding_payment(kind, amount, label, date, bank_account, bank_sub, row_label) -> Voucher:
    v = Voucher(date, f"{label} 納付", kind="payment", evidence=f"銀行明細 {row_label}")
    v.add("預り金", debit=amount, sub=kind)
    v.add(bank_account, credit=amount, sub=bank_sub)
    return v


def bank_rule(row, rule, bank_account, bank_sub) -> Voucher:
    t = rule["then"]
    amt = row.amount_abs
    v = Voucher(row.date, f"{row.desc}", kind="bank_rule",
                evidence=t.get("evidence") or f"銀行明細 {row.label}",
                derivation=[f"銀行ルール {rule['id']}：{rule.get('note', '')}".rstrip("：")])
    if row.outflow:
        v.add(t["debit"], debit=amt, sub=t.get("sub", ""), tax=t.get("tax", ""), memo=row.desc)
        v.add(bank_account, credit=amt, sub=bank_sub)
    else:
        v.add(bank_account, debit=amt, sub=bank_sub)
        v.add(t["credit"], credit=amt, sub=t.get("sub", ""), tax=t.get("tax", ""), memo=row.desc)
    return v


SUSPENSE = {"out": "仮払金", "in": "仮受金"}
SUSPENSE_SUB = "未確認"


def suspense(row, bank_account, bank_sub, qkey) -> Voucher:
    """性質の分からない明細をいったん仮払金／仮受金に置く（作者 2026-10-10）。
    帳簿の預金＝銀行残高を常に保つため（未達を作らない）。性質は推測しない——要確認の回答で正しい科目に振り替わる
    （回答があれば次の締めではこの仕訳自体が作られず、回答の仕訳になる）。"""
    amt = row.amount_abs
    v = Voucher(row.date, f"{row.desc}（暫記・要確認）", kind="suspense", evidence=f"銀行明細 {row.label}",
                derivation=[f"性質が未確認のため暫記（要確認 {qkey}）。回答すると正しい科目で仕訳し直す"])
    if row.outflow:
        v.add(SUSPENSE["out"], debit=amt, sub=SUSPENSE_SUB, tax="対象外", memo=row.desc)
        v.add(bank_account, credit=amt, sub=bank_sub)
    else:
        v.add(bank_account, debit=amt, sub=bank_sub)
        v.add(SUSPENSE["in"], credit=amt, sub=SUSPENSE_SUB, tax="対象外", memo=row.desc)
    return v


def decided(row, d, bank_account, bank_sub, qkey) -> Voucher:
    """会計担当者の回答（decisions.yaml）から作る仕訳。"""
    amt = row.amount_abs
    # 1 明細に科目が複数（家賃＋仲介手数料、売掛回収＋前受 など）は lines で内訳を書く。合計の一致は呼び出し側が確かめる
    parts = [(l["account"], int(l["amount"]), l.get("sub", ""), l.get("tax", "")) for l in d["lines"]] \
        if d.get("lines") else [(d["account"], amt, d.get("sub", ""), d.get("tax", ""))]
    v = Voucher(row.date, d.get("memo") or row.desc, kind="decision",
                evidence=d.get("evidence") or f"銀行明細 {row.label}",
                derivation=[f"会計担当者の回答（decisions.yaml {qkey}）：{d.get('reason', '')}"])
    if row.outflow:
        for acc, a, sub, tax in parts:
            v.add(acc, debit=a, sub=sub, tax=tax, memo=row.desc)
        v.add(bank_account, credit=amt, sub=bank_sub)
    else:
        v.add(bank_account, debit=amt, sub=bank_sub)
        for acc, a, sub, tax in parts:
            v.add(acc, credit=a, sub=sub, tax=tax, memo=row.desc)
    return v


def sales(inv, source) -> Voucher:
    """請求（売上の発生）。入金は銀行ルールで売掛金を消し込む。"""
    v = Voucher(inv["date"], f"売上 {inv['customer']}", kind="sales",
                evidence=inv.get("evidence") or f"請求書 {source}")
    v.add("売掛金", debit=int(inv["amount"]), sub=inv["customer"])
    v.add("売上高", credit=int(inv["amount"]), sub=inv["customer"], tax=inv.get("tax", ""))
    return v


def labor_insurance_accrual(month, date, amount, why) -> Voucher:
    """労働保険の会社負担を月次で見積り計上（年度更新で精算）。"""
    v = Voucher(date, f"{month:%Y-%m} 労働保険 会社負担（見積）", kind="accrual",
                evidence=f"自制:労働保険見積表 {month:%Y-%m}", derivation=list(why))
    v.add("法定福利費", debit=amount, memo="労働保険（見積）")
    v.add("未払費用", credit=amount, sub="労働保険", memo=f"{month:%Y-%m}分")
    return v


def adjustment(a) -> Voucher:
    """会計担当者が入力した仕訳（決算整理など）。判断記録は company.judgments にある。"""
    v = Voucher(a["date"], a["narration"], kind="adjustment",
                evidence=a.get("evidence") or f"自制:調整仕訳 {a['id']}",
                derivation=[f"調整仕訳 {a['id']}（{a['by']}・{a['at']}）{a.get('reason') or ''}".rstrip()])
    for l in a["lines"]:
        v.add(l["account"], debit=int(l.get("debit") or 0), credit=int(l.get("credit") or 0),
              sub=l.get("sub", ""), tax=l.get("tax", ""), memo=l.get("memo", ""))
    return v


def pl_closing(fy_end_date, pl_balances) -> Voucher:
    """損益振替：年度末に損益科目の残高を繰越利益剰余金へ振り替える（導出できる処理なので自動）。"""
    v = Voucher(fy_end_date, f"{fy_end_date:%Y-%m} 損益振替（年度末）", kind="closing",
                evidence="自制:損益振替",
                derivation=["年度末の損益科目残高をすべて繰越利益剰余金へ振り替える"])
    net = 0
    for (acc, sub), bal in sorted(pl_balances.items()):
        if bal > 0:
            v.add(acc, credit=bal, sub=sub)
        elif bal < 0:
            v.add(acc, debit=-bal, sub=sub)
        net += bal
    if net > 0:
        v.add("繰越利益剰余金", debit=net, memo="当期純損失")
    elif net < 0:
        v.add("繰越利益剰余金", credit=-net, memo="当期純利益")
    return v


LI = "労働保険"


def labor_payment(calc, date, policy, bank_account, bank_sub, row_label) -> list:
    """年度更新の納付。方針で仕訳が変わる（jp/labor_annual.py の説明参照）。"""
    y = calc.fiscal_year
    if policy == "monthly_accrual":
        pay = Voucher(date, f"労働保険 年度更新 納付（{y}年度確定・{y + 1}年度概算）", kind="payment",
                      evidence=f"銀行明細 {row_label}／労働保険概算・確定保険料申告書",
                      derivation=["発生主義：納付額はいったん仮払金に置き、前年度分を確定額で精算する"])
        pay.add("仮払金", debit=calc.payment, sub=LI)
        pay.add(bank_account, credit=calc.payment, sub=bank_sub)
        st = Voucher(date, f"労働保険 {y}年度分の精算（確定保険料）", kind="adjustment",
                     evidence="自制:年度更新計算表",
                     derivation=[f"前年度の確定保険料 {calc.final_premium:,}＋一般拠出金 {calc.general_contribution:,} を、"
                                 f"控除済みの被保険者負担 {calc.withheld_prior:,} と見積計上した会社負担 "
                                 f"{calc.accrued_prior:,} で消し込み、差額を法定福利費で調整"])
        cost = calc.final_premium + calc.general_contribution
        st.add("預り金", debit=calc.withheld_prior, sub=KOYOU)
        st.add("未払費用", debit=calc.accrued_prior, sub=LI)
        d = cost - calc.withheld_prior - calc.accrued_prior
        if d > 0:
            st.add("法定福利費", debit=d, memo="年度更新の確定差額")
        elif d < 0:
            st.add("法定福利費", credit=-d, memo="年度更新の確定差額")
        st.add("仮払金", credit=cost, sub=LI)
        return [pay, st]
    v = Voucher(date, f"労働保険 年度更新 納付（{y}年度確定・{y + 1}年度概算）", kind="payment",
                evidence=f"銀行明細 {row_label}／労働保険概算・確定保険料申告書",
                derivation=["簡便法：前年度に控除した被保険者負担（預り金）を消し込み、残りを法定福利費"])
    v.add("預り金", debit=calc.withheld_prior, sub=KOYOU)
    rest = calc.payment - calc.withheld_prior
    if rest > 0:
        v.add("法定福利費", debit=rest, memo="年度更新（会社負担・概算を含む）")
    elif rest < 0:
        v.add("法定福利費", credit=-rest, memo="年度更新（控除額が納付額を超える分）")
    v.add(bank_account, credit=calc.payment, sub=bank_sub)
    return [v]


def depreciation(asset, month_end_date, amount, why, split=None) -> Voucher:
    """split：[(費用科目, 額)]（台帳の allocation で按分したとき）。無ければ全額 減価償却費。"""
    v = Voucher(month_end_date, f"減価償却 {asset['name']}", kind="depreciation",
                evidence=f"自制:固定資産台帳 {asset['id']}", derivation=list(why))
    for acc, a in (split or [("減価償却費", amount)]):
        if a:
            v.add(acc, debit=a, sub=asset["id"])
    v.add("減価償却累計額", credit=amount, sub=asset["id"])
    return v
