# -*- coding: utf-8 -*-
"""中国式の決算ワークペーパー（底稿）を直接読む（作者 2026-10-15：お客さまに表を埋めさせない。
お客さまが持っている底稿から、読めるものは読む。対応表は事務所の経験から）。

読むもの：
  · 序时账（「中文科目・日文科目・明细科目・借方・贷方」の見出しがある表。「全年序时账」があればそれ）
      → 科目・補助ごとの年度末の残高 → 次の年度の期首残高（貸借対照表の科目だけ）
  · 資産負債表（表の名前が「资产负债表＋日付」の最後のもの）→ 年度末の日・会社名・資産合計（照合に使う）
読み方：
  · 科目の対応は data/jp/workpaper_accounts.yaml（推測で科目を決めない。分からない科目は名前のまま返す）
  · 金額に円未満がある（底稿の式で按分した値）→ 科目・補助ごとに四捨五入。差は繰越利益剰余金が吸収する（数を返す）
  · 繰越利益剰余金＝ほかの全部の差（その年度の損益と、前からの繰越の合計）
  · 序时账から出した資産の合計を、資産負債表の「資産合計」と照らす（1 円未満の差まで）
  · 資産負債表の年初の残高が 0 でない（前の年度がある）とき：序时账はその年度の動きだけで、年初の内訳が無い
    → 読まない（prior_year）。前の年度の底稿か、弥生の期首残高データが要る
"""
from __future__ import annotations

import datetime
import pathlib
import re
from collections import defaultdict
from decimal import ROUND_HALF_UP, Decimal

import yaml

DATA = pathlib.Path(__file__).resolve().parents[2] / "data" / "jp" / "workpaper_accounts.yaml"
HEAD = ("中文科目", "日文科目", "明细科目", "借方", "贷方")
_BS = re.compile(r"资产负债表\s*(\d{8})")
_BANKISH = re.compile(r"银行|銀行|信用金庫|信用组合|信用組合|信金|ゆうちょ|郵便|[Bb]ank|住友|三菱|みずほ|りそな|楽天|PayPay|ネット")


class WorkpaperError(ValueError):
    pass


def _spec():
    return yaml.safe_load(DATA.read_text(encoding="utf-8"))


def _s(v) -> str:
    """前後の空白を除き、中の空白は 1 つに（「ABC Holdings Ltd」の空白は残す。底稿には前後に空白のある行がある）。"""
    return re.sub(r"[\s　]+", " ", str(v)).strip() if v is not None else ""


def _num(v) -> Decimal:
    if v in (None, ""):
        return Decimal(0)
    if isinstance(v, (int, float)):
        return Decimal(str(v))
    t = str(v).replace(",", "").strip()
    try:
        return Decimal(t) if t else Decimal(0)
    except ArithmeticError:
        return Decimal(0)


def _journal(wb):
    """序时账の表（「全年序时账」を優先。無ければ見出しのそろった表のうち行の多いもの）と見出しの列。"""
    cands = []
    for ws in wb.worksheets:
        for i, row in enumerate(ws.iter_rows(min_row=1, max_row=3, values_only=True)):
            heads = [_s(c) for c in row]
            if all(h in heads for h in HEAD):
                cands.append((("全年" in ws.title), ws.max_row or 0, ws, i + 1, {h: heads.index(h) for h in HEAD}))
                break
    if not cands:
        return None
    cands.sort(key=lambda c: (c[0], c[1]), reverse=True)
    return cands[0][2:]


def _balance_sheet(wb):
    """最後の日付の資産負債表：(年度末, 会社名, 資産合計, 年初の資産合計)。"""
    best = None
    for ws in wb.worksheets:
        m = _BS.search(ws.title)
        if m and (best is None or m.group(1) > best[0]):
            best = (m.group(1), ws)
    if best is None:
        return None
    day = datetime.datetime.strptime(best[0], "%Y%m%d").date()
    name, total, opening = "", None, None
    for row in best[1].iter_rows(values_only=True):
        cells = [c for c in row]
        for c in cells:
            t = _s(c)
            if t.startswith("单位名称："):
                name = t.split("：", 1)[1]
        texts = [_s(c) for c in cells]
        if "资产总计" in texts or "資産合計" in texts:
            nums = [c for c in cells if isinstance(c, (int, float))]
            if nums:
                total = Decimal(str(nums[0]))
                opening = Decimal(str(nums[1])) if len(nums) > 1 else None
    return dict(year_end=day, company=name, total_assets=total, opening_assets=opening)


def _to_ja(text: str, kanji: dict) -> str:
    out = text.replace("支付", "支払")
    return "".join(kanji.get(ch, ch) for ch in out)


def map_account(cn: str, ja: str, detail: str, chart: dict, spec: dict, banks=()) -> tuple | None:
    """(科目, 補助) か None（分からない）。"""
    rule = None
    for p in spec["pairs"]:
        if p["cn"] == cn and (p.get("ja") is None or p["ja"] == ja):
            if rule is None or (p.get("ja") and not rule.get("ja")):
                rule = p
    if rule is None:
        acc = _to_ja(ja, spec.get("kanji") or {})
        if acc in chart:
            rule = dict(account=acc, sub="detail")
        else:
            return None
    acc = rule["account"]
    if rule.get("cash") and detail in spec.get("cash_detail", []):
        return rule["cash"], ""
    sub_rule = rule.get("sub", "detail")
    if sub_rule == "detail":
        sub = "" if detail in spec.get("generic_detail", []) else detail
    elif sub_rule == "none":
        sub = ""
    elif str(sub_rule).endswith(":"):
        sub = f"{sub_rule}{detail}" if detail else sub_rule.rstrip(":")
    else:
        sub = sub_rule
    if acc in ("普通預金", "当座預金"):
        # 預金の行の明细は相手や内容（「存款利息」など）のことが多い。会社の口座が 1 つなら、全部その口座
        same = [b for b in banks if b.get("account") == acc]
        if len(same) == 1:
            sub = same[0].get("sub") or ""
        elif sub and not _BANKISH.search(sub):     # 口座の登録がまだ：銀行名らしくない明细（利息など）は口座を分けない
            sub = ""
    return acc, sub


def extra_accounts(unknown: list, chart: dict, extra=()) -> list:
    """対応の分からない科目を「追加科目」として登録する案（科目名は日文科目のまま）。区分は中文科目から：
    同じ中文科目の科目が科目表にあれば、その区分・残高の側（预付账款 → 前払費用と同じ 流動資産・借方）。
    無ければ残高の向き（借方 → 流動資産、貸方 → 流動負債）で置き、guessed を付ける（画面が確かめてと言う）。"""
    used = {int(a["code"]) for a in chart.values()} | {int(a["code"]) for a in extra}
    out = []
    for u in unknown:
        name = u["ja"] or u["cn"]
        if name in chart or any(a["name"] == name for a in extra + out):
            continue
        same = next((a for a in chart.values() if a.get("cn") == u["cn"]), None)
        if same is not None:
            section, normal, guessed = same["section"], same["normal"], False
        else:
            debit = u["amount"] > 0
            section, normal, guessed = ("流動資産", "debit", True) if debit else ("流動負債", "credit", True)
        base = {"流動資産": 1900, "有形固定資産": 1690, "無形固定資産": 1790, "投資その他の資産": 1890,
                "流動負債": 2900, "固定負債": 2990, "株主資本": 3900}.get(section, 9900)
        code = base
        while code in used:
            code += 1
        used.add(code)
        out.append(dict(code=code, name=name, section=section, normal=normal, tax="対象外", cn=u["cn"],
                        **({"guessed": True} if guessed else {})))
    return out


def read(path, chart: dict, banks=()) -> dict:
    """底稿 → 期首残高の案。返すもの：year_end・company・balances [{account, sub, debit|credit}]・retained・
    unknown [{cn, ja, sub, amount}]（科目の分からない貸借対照表の科目。金額は借方正）・rounding（四捨五入で動いた額の合計）・
    check {total_assets, computed, ok}・journal（読んだ表の名前・行数）。読めなければ WorkpaperError（code）。"""
    from openpyxl import load_workbook
    spec = _spec()
    try:
        wb = load_workbook(path, read_only=True, data_only=True)
    except Exception as e:                                    # 壊れた・暗号化された
        raise WorkpaperError("open") from e
    try:
        found = _journal(wb)
        if found is None:
            raise WorkpaperError("no_journal")
        ws, head_row, col = found
        bs = _balance_sheet(wb)
        if bs is None:
            raise WorkpaperError("no_bs")
        if bs["opening_assets"] not in (None, 0):
            raise WorkpaperError("prior_year")
        sums = defaultdict(Decimal)
        n = 0
        for row in ws.iter_rows(min_row=head_row + 1, values_only=True):
            cn = _s(row[col["中文科目"]]) if len(row) > col["中文科目"] else ""
            if not cn:
                continue
            ja, detail = _s(row[col["日文科目"]]), _s(row[col["明细科目"]])
            sums[(cn, ja, detail)] += _num(row[col["借方"]]) - _num(row[col["贷方"]])
            n += 1
        journal = dict(sheet=ws.title, rows=n)
    finally:
        wb.close()
    pl_top, retained_names = set(spec["pl_top"]), set(spec["equity_retained"])
    bal, unknown, rounding = defaultdict(int), [], Decimal(0)
    assets = Decimal(0)
    for (cn, ja, detail), amt in sums.items():
        if cn in pl_top or cn in retained_names or ja in retained_names or not amt:
            continue
        hit = map_account(cn, ja, detail, chart, spec, banks)
        whole = int(amt.quantize(Decimal(1), rounding=ROUND_HALF_UP))
        rounding += Decimal(whole) - amt
        if hit is None:
            unknown.append(dict(cn=cn, ja=ja, sub=detail, amount=whole))
            if any(k in cn for k in ("资产", "应收", "预付", "预缴", "现金", "存款", "设备", "建筑", "土地", "折旧")):
                assets += amt
            continue
        bal[hit] += whole
        if chart[hit[0]]["section"] in ("流動資産", "有形固定資産", "無形固定資産", "投資その他の資産"):
            assets += amt
    balances = [dict(account=a, **({"sub": s} if s else {}), **({"debit": n} if n > 0 else {"credit": -n}))
                for (a, s), n in sorted(bal.items(), key=lambda x: (chart[x[0][0]]["code"], x[0][1])) if n]
    total = sum(n for n in bal.values()) + sum(u["amount"] for u in unknown)
    retained = total                                            # 借方が多い分＝貸方の繰越利益剰余金（マイナスなら借方）
    if retained:
        balances.append(dict(account="繰越利益剰余金", **({"credit": retained} if retained > 0 else {"debit": -retained})))
    check = dict(total_assets=float(bs["total_assets"]) if bs["total_assets"] is not None else None,
                 computed=float(assets))
    check["ok"] = check["total_assets"] is not None and abs(Decimal(str(check["total_assets"])) - assets) < 1
    return dict(year_end=bs["year_end"], company=bs["company"], balances=balances, retained=retained,
                unknown=sorted(unknown, key=lambda u: (u["cn"], u["ja"], u["sub"])), rounding=float(rounding),
                check=check, journal=journal)
