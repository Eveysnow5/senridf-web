# -*- coding: utf-8 -*-
"""締めの網頁汇总：経営者向けの月次報告と、会計担当者向けの底稿概要。各一つの HTML ファイル（CSS 内蔵、外部読込なし）。

作者 2026-10-10：「两份都要」。経営者には数字とお願い事項だけ、会計担当者には検査・事項・判断の記録まで。
言語は底稿と同じ（zh / ja）。数字は view.build の結果をそのまま使う（ここで計算し直さない）。
"""
from __future__ import annotations

import datetime
import html

from . import hints, view
from .messages import category_name, check_name, result_text
from .pending import CATEGORY_LABEL

T = {
    "boss_title": {"zh": "月度报告", "ja": "月次報告"},
    "acct_title": {"zh": "底稿概要", "ja": "底稿概要"},
    "boss_file": {"zh": "月度报告（老板）.html", "ja": "月次報告（経営者向け）.html"},
    "acct_file": {"zh": "底稿概要（会计）.html", "ja": "底稿概要（会計担当者向け）.html"},
    "asof": {"zh": "截至 {d}", "ja": "{d} 現在"},
    "rev": {"zh": "本月收入", "ja": "今月の売上"}, "profit": {"zh": "本月利润", "ja": "今月の利益"},
    "cash": {"zh": "月末存款", "ja": "月末の預金"}, "ytd": {"zh": "本期累计", "ja": "期首から"},
    "bank_ok": {"zh": "＝银行月末余额", "ja": "＝銀行の月末残高"}, "bank_ng": {"zh": "≠银行月末余额", "ja": "≠銀行の月末残高"},
    "sus": {"zh": "有 {n} 笔银行流水暂记在仮払金／仮受金（合计 {v}），确认性质后数字可能变。",
            "ja": "銀行明細 {n} 件を仮払金／仮受金に暫記中（計 {v}）。性質の確認後に数字が変わることがあります。"},
    "final_ok": {"zh": "本月数字已可定稿。", "ja": "今月の数字は確定できます。"},
    "final_ng": {"zh": "本月还有待处理事项，数字尚未定稿。", "ja": "今月はまだ対応事項があり、数字は確定していません。"},
    "bs": {"zh": "资产负债表", "ja": "貸借対照表"}, "pl": {"zh": "利润表", "ja": "損益計算書"},
    "month": {"zh": "本月", "ja": "今月"},
    "assets": {"zh": "资产合计", "ja": "資産合計"}, "le": {"zh": "负债・净资产合计", "ja": "負債・純資産合計"},
    "net": {"zh": "当期净损益", "ja": "当期純損益"},
    "up": {"zh": "接下来要缴的", "ja": "これから納めるもの"},
    "up_note": {"zh": "按月末余额估算，请以缴费通知、纳付书为准。", "ja": "月末残高からの見積り。告知書・納付書で確認してください。"},
    "ask_boss": {"zh": "需要您配合的事项", "ja": "ご確認いただきたいこと"},
    "none": {"zh": "没有。", "ja": "ありません。"},
    "checks": {"zh": "检查", "ja": "検査"}, "status": {"PASS": {"zh": "通过", "ja": "合格"},
                                                    "FAIL": {"zh": "未通过", "ja": "不合格"},
                                                    "SKIP": {"zh": "未检查", "ja": "未検査"}},
    "items": {"zh": "事项", "ja": "事項"},
    "b_ask": {"zh": "待确认", "ja": "要確認"}, "b_todo": {"zh": "待处理", "ja": "要対応"},
    "b_err": {"zh": "疑似错误", "ja": "誤りの疑い"},
    "an": {"zh": "分析", "ja": "分析"}, "sug": {"zh": "建议", "ja": "提案"},
    "judg": {"zh": "本期的判断记录（{d} 以后）", "ja": "今期の判断の記録（{d} 以降）"},
    "judg_cols": {"zh": ["种类", "对象", "内容", "判断人", "日期", "理由"], "ja": ["種類", "対象", "内容", "判断者", "日付", "理由"]},
    "foot": {"zh": "由月结引擎生成（{t}）。会计担当者的判断为前提；法人税等为概算，不是申报书。",
             "ja": "月次決算エンジンで作成（{t}）。会計担当者の判断を前提とした補助資料です。法人税等は概算で申告書ではありません。"},
}
SEC = {"流動資産": "流动资产", "有形固定資産": "有形固定资产", "無形固定資産": "无形固定资产", "投資その他の資産": "投资及其他资产",
       "流動負債": "流动负债", "固定負債": "非流动负债", "株主資本": "净资产", "売上高": "营业收入", "売上原価": "营业成本",
       "販売費及び一般管理費": "销售及管理费用", "営業外収益": "营业外收入", "営業外費用": "营业外支出", "特別利益": "特别利润",
       "特別損失": "特别损失", "法人税等": "所得税费用"}

CSS = """
body{font-family:"Noto Sans SC","Hiragino Sans","Yu Gothic","Microsoft YaHei",sans-serif;color:#1f2433;background:#fff;
margin:0;padding:24px 16px;line-height:1.65;font-size:14px}
main{max-width:860px;margin:0 auto}h1{font-size:20px;margin:0}h2{font-size:15px;margin:22px 0 8px;border-bottom:1px solid #e2e5ef;padding-bottom:4px}
.meta{color:#6b7183;font-size:12px}.kpis{display:grid;grid-template-columns:repeat(auto-fit,minmax(170px,1fr));gap:10px;margin-top:12px}
.kpi{border:1px solid #e2e5ef;border-radius:8px;padding:8px 12px}.kpi .k{font-size:12px;color:#6b7183}.kpi .v{font-size:20px;font-weight:600}
.kpi .s{font-size:11px;color:#6b7183}.ok{color:#047857}.ng{color:#b91c1c}.note{background:#fdf0d9;border-radius:6px;padding:6px 10px;font-size:13px;margin-top:10px}
table{width:100%;border-collapse:collapse;font-size:13px}td,th{padding:4px 6px;border-bottom:1px solid #eef0f5;vertical-align:top;text-align:left}
td.n,th.n{text-align:right;white-space:nowrap;font-variant-numeric:tabular-nums}tr.h td{font-weight:600;border-bottom:1px solid #9aa0b4}
tr.t td{font-weight:600;border-top:1px solid #9aa0b4}tr.i td:first-child{padding-left:18px}.two{display:grid;grid-template-columns:1fr 1fr;gap:18px}
.it{border:1px solid #e2e5ef;border-radius:8px;padding:8px 12px;margin:8px 0}.it b{font-size:13px}.it .d{font-size:12px;color:#4b5163;white-space:pre-wrap}
.pill{display:inline-block;font-size:11px;padding:0 7px;border-radius:9px}.PASS{background:#dcf5ea;color:#047857}.FAIL{background:#fde4e4;color:#b91c1c}
.SKIP{background:#f1f3f9;color:#6b7183}footer{margin-top:28px;font-size:11px;color:#6b7183}
@media(max-width:640px){.two{grid-template-columns:1fr}}@media print{body{padding:0}}
"""


def _t(key, lang, **kw):
    return T[key][lang].format(**kw) if kw else T[key][lang]


def _y(n):
    return f"{int(n or 0):,}"


def _e(s):
    return html.escape(str(s if s is not None else ""))


def _sec(name, lang):
    return SEC.get(name, name) if lang == "zh" else name


def _acc(line, lang):
    if lang == "zh" and line.get("cn"):
        return f"{_e(line['account'])} <span class=meta>{_e(line['cn'])}</span>"
    return _e(line["account"])


def _page(title, body, lang, today):
    return (f"<!doctype html><html lang=\"{'zh-CN' if lang == 'zh' else 'ja'}\"><head><meta charset=\"utf-8\">"
            f"<meta name=\"viewport\" content=\"width=device-width,initial-scale=1\"><title>{_e(title)}</title>"
            f"<style>{CSS}</style></head><body><main>{body}<footer>{_e(_t('foot', lang, t=today))}</footer></main></body></html>")


def _head(r, v, lang, title):
    s = v["summary"]
    return (f"<h1>{_e(r['company'])} · {_e(r['month'])} {_e(title)}</h1>"
            f"<div class=meta>{_e(_t('asof', lang, d=s['as_of']))}</div>")


def _kpis(v, lang):
    s = v["summary"]
    cash_cls = "ok" if s["bank_ok"] else "ng"
    out = ["<div class=kpis>"]
    for k, val, sub, cls in (("rev", s["revenue_month"], f"{_t('ytd', lang)} {_y(s['revenue_ytd'])}", ""),
                             ("profit", s["profit_month"], f"{_t('ytd', lang)} {_y(s['profit_ytd'])}", ""),
                             ("cash", s["cash"], _t("bank_ok" if s["bank_ok"] else "bank_ng", lang), cash_cls)):
        out.append(f"<div class=kpi><div class=k>{_e(_t(k, lang))}</div><div class=v>{_y(val)}</div>"
                   f"<div class='s {cls}'>{_e(sub)}</div></div>")
    out.append("</div>")
    if s["suspense_rows"]:
        out.append(f"<div class=note>{_e(_t('sus', lang, n=s['suspense_rows'], v=_y(s['suspense_amount'])))}</div>")
    return "".join(out)


def _statements(v, lang, detail):
    bs = [f"<table><tbody>"]
    for sec in v["bs"]["sections"]:
        bs.append(f"<tr class=h><td>{_e(_sec(sec['section'], lang))}</td><td class=n>{_y(sec['total'])}</td></tr>")
        if detail:
            bs += [f"<tr class=i><td>{_acc(l, lang)}</td><td class=n>{_y(l['amount'])}</td></tr>" for l in sec["lines"]]
    bs.append(f"<tr class=t><td>{_e(_t('assets', lang))}</td><td class=n>{_y(v['bs']['assets'])}</td></tr>")
    bs.append(f"<tr class=t><td>{_e(_t('le', lang))}</td><td class=n>{_y(v['bs']['liabilities'] + v['bs']['equity'])}</td></tr>")
    bs.append("</tbody></table>")
    pl = [f"<table><thead><tr><th></th><th class=n>{_e(_t('month', lang))}</th><th class=n>{_e(_t('ytd', lang))}</th></tr>"
          f"</thead><tbody>"]
    for sec in v["pl"]["sections"]:
        pl.append(f"<tr class=h><td>{_e(_sec(sec['section'], lang))}</td><td class=n>{_y(sec['total'])}</td>"
                  f"<td class=n>{_y(sec['total_ytd'])}</td></tr>")
        if detail:
            pl += [f"<tr class=i><td>{_acc(l, lang)}</td><td class=n>{_y(l['amount'])}</td><td class=n>{_y(l['ytd'])}</td></tr>"
                   for l in sec["lines"]]
    pl.append(f"<tr class=t><td>{_e(_t('net', lang))}</td><td class=n>{_y(v['pl']['net_month'])}</td>"
              f"<td class=n>{_y(v['pl']['net_ytd'])}</td></tr></tbody></table>")
    return (f"<div class=two><div><h2>{_e(_t('bs', lang))}</h2>{''.join(bs)}</div>"
            f"<div><h2>{_e(_t('pl', lang))}</h2>{''.join(pl)}</div></div>")


UP_LABEL = {"shaho": {"zh": "{m} 月份社保", "ja": "{m} 分 社会保険料"}, "gensen": {"zh": "源泉所得税", "ja": "源泉所得税"},
            "jumin": {"zh": "住民税", "ja": "住民税"}}


def _upcoming(v, lang):
    rows = []
    for u in v["upcoming"]:
        lab = UP_LABEL[u["what"]][lang].format(m=u["month"]) + (("（纳期特例）" if lang == "zh" else "（納期の特例）")
                                                                 if u["tokurei"] else "")
        rows.append(f"<tr><td>{_e(u['date'])}</td><td>{_e(lab)}</td><td class=n>{_y(u['amount'])}</td></tr>")
    body = "".join(rows) or f"<tr><td>{_e(_t('none', lang))}</td></tr>"
    return (f"<h2>{_e(_t('up', lang))}</h2><table><tbody>{body}</tbody></table>"
            f"<div class=meta>{_e(_t('up_note', lang))}</div>")


def _tx(text, lang):
    return text if lang == "ja" else result_text(text, lang)


def _item(p, lang, led=None, res=None):
    title = p.title if p.category == "bank_unmatched" else _tx(p.title, lang)
    amt = f" <span class=meta>{_y(p.amount)}</span>" if p.amount is not None else ""
    from . import nextsteps
    nx = nextsteps.for_pending(p.key, p.category, lang)
    return (f"<div class=it><b>{_e(title)}</b>{amt} <span class=meta>{_e(p.qid)} · {_e(p.date or '')}</span>"
            f"<div class=d><b>{_e(_t('an', lang))}</b>：{_e(_tx(p.detail, lang))}</div>"
            + "".join(f"<div class=d>· {_e(h[lang])}</div>" for h in (hints.for_pending(led, res, p) if led else []))
            + f"<div class=d><b>{_e(_t('sug', lang))}</b>：{_e(nx['text'])}</div></div>")


def is_final(res, opened):
    """確定してよいか：落ちた検査が無く、未対応の事項も無い（未検査＝対象 0 件は確定を妨げない）。"""
    return not any(c.status == "FAIL" for c in res.report.checks) and not opened


def _boss_title(p, lang):
    """銀行の明細は摘要の原文だけでは何の支払か分からないので、日付と入出金を添える。"""
    if p.category in ("bank_unmatched", "bank_ambiguous"):
        io = ("转出" if lang == "zh" else "出金") if (p.amount or 0) < 0 else ("转入" if lang == "zh" else "入金")
        what = p.title if p.category == "bank_unmatched" else _tx(p.title, lang)
        return f"{p.date} {io} {what}"
    return _tx(p.title, lang)


def boss(r, co, led, res, v, lang, today):
    opened = led.pending.open_items()
    asks = [p for p in opened if view.bucket(p.key) in ("ask", "todo")]
    final = is_final(res, opened)
    body = [_head(r, v, lang, _t("boss_title", lang)), _kpis(v, lang),
            f"<div class=meta style='margin-top:8px'>{_e(_t('final_ok' if final else 'final_ng', lang))}</div>",
            _statements(v, lang, detail=False), _upcoming(v, lang),
            f"<h2>{_e(_t('ask_boss', lang))}</h2>"]
    if asks:
        body.append("<ul>" + "".join(
            f"<li>{_e(_boss_title(p, lang))}"
            f"{(' <span class=meta>' + _y(p.amount) + '</span>') if p.amount is not None else ''}</li>"
            for p in asks[:12]) + "</ul>")
    else:
        body.append(f"<p>{_e(_t('none', lang))}</p>")
    return _page(f"{r['company']} {r['month']} {_t('boss_title', lang)}", "".join(body), lang, today)


def accountant(r, co, led, res, v, lang, today):
    opened = led.pending.open_items()
    body = [_head(r, v, lang, _t("acct_title", lang)), _kpis(v, lang),
            f"<div class=meta style='margin-top:8px'>{_e(_t('final_ok' if is_final(res, opened) else 'final_ng', lang))}</div>",
            _statements(v, lang, detail=True), _upcoming(v, lang)]
    rows = "".join(
        f"<tr><td>{_e(c.id)}</td><td>{_e(check_name(c.id, c.name, lang) if lang != 'ja' else c.name)}"
        + "".join(f"<div class=meta>{_e(_tx(d, lang))}</div>" for d in c.details[:6])
        + f"</td><td><span class='pill {c.status}'>{_e(T['status'][c.status][lang])}</span></td>"
          f"<td class=n>{c.n_checked}</td></tr>" for c in res.report.checks)
    body.append(f"<h2>{_e(_t('checks', lang))}</h2><table><tbody>{rows}</tbody></table>")
    body.append(f"<h2>{_e(_t('items', lang))}</h2>")
    for b in ("err", "todo", "ask"):
        its = [p for p in opened if view.bucket(p.key) == b]
        body.append(f"<h3 style='font-size:13px;margin:12px 0 4px'>{_e(_t('b_' + b, lang))}（{len(its)}）</h3>")
        body += [_item(p, lang, led, res) for p in its] or [f"<div class=meta>{_e(_t('none', lang))}</div>"]
    start = res.month
    js = [j for j in co.judgments if j.at and j.at >= start]
    cols = "".join(f"<th>{_e(c)}</th>" for c in _t("judg_cols", lang))
    jr = "".join(f"<tr><td>{_e(j.kind)}</td><td>{_e(j.key)}</td><td>{_e(j.value)}</td><td>{_e(j.by)}</td>"
                 f"<td>{_e(j.at)}</td><td>{_e(j.reason)}</td></tr>" for j in sorted(js, key=lambda j: (str(j.at), j.key)))
    body.append(f"<h2>{_e(_t('judg', lang, d=start))}</h2><table><thead><tr>{cols}</tr></thead>"
                f"<tbody>{jr or '<tr><td>' + _e(_t('none', lang)) + '</td></tr>'}</tbody></table>")
    return _page(f"{r['company']} {r['month']} {_t('acct_title', lang)}", "".join(body), lang, today)


def build(r, co, led, res, v, lang, today):
    lang = lang if lang in ("zh", "ja") else "zh"
    return {"boss": dict(name=_t("boss_file", lang), html=boss(r, co, led, res, v, lang, today)),
            "accountant": dict(name=_t("acct_file", lang), html=accountant(r, co, led, res, v, lang, today))}
