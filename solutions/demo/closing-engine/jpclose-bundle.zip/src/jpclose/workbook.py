# -*- coding: utf-8 -*-
"""Excel の入力ブック（公司资料.xlsx）⇔ 会社フォルダ（company.yaml などの YAML 群）。

作者 2026-10-09：「YAML はプログラマの書式。会計担当者には Excel の表で渡したい」。
エンジンは YAML のフォルダしか読まない（検査・判断記録の仕組みはそのまま）。ブックは入口の
書式にすぎないので、ここで**ブック → YAML** に変換してからいつもどおり締める。

  to_folder(xlsx, out_dir)   ブックを読み、out_dir に YAML 群を書く。問題は [(シート, 行, 内容)] で返す
  from_folder(dir, xlsx)     既存の会社フォルダをブックに書き出す（サンプルの例示・往復の試験・回答の書き戻し）
  blank(xlsx)                空白テンプレート（方針の行と選択肢のドロップダウンつき）

シートの作り：1 行目＝見出し（中国語）、2 行目＝欄の名前（機械用、非表示）、3 行目から中身。
銀行明細はブックに入れない（ネットバンキングのダウンロードをそのまま bank/ に置く）。
"""
from __future__ import annotations

import datetime
import pathlib
from collections import OrderedDict

import yaml

from .company import POLICY_CHOICES, POLICY_HELP

WORKBOOK_NAME = "公司资料.xlsx"

# --------------------------------------------------------------------------- 定義
# (欄の名前, 見出し, 幅)
T = {
    # 標準科目表に無い科目（受取家賃・減価償却費（賃貸） など）。section は科目表の区分名
    "追加科目": [("code", "科目代码", 9), ("name", "科目名", 18), ("section", "区分（営業外収益 等）", 16),
             ("normal", "借贷(debit/credit)", 10), ("tax", "税区分", 12), ("cn", "中文科目(可空)", 14)],
    "支给项目": [("name", "支给项目名", 14), ("account", "科目", 12), ("taxable", "课税", 7),
             ("koyou_wage", "算雇用保险工资", 9), ("nontaxable_check", "非课税检查(commute)", 12)],
    "银行账户": [("id", "账户ID", 8), ("account", "科目", 10), ("sub", "银行名", 14), ("files", "流水文件位置", 14),
             ("date", "表头:日期", 10), ("desc", "表头:摘要", 12), ("out", "表头:出金", 10), ("in", "表头:入金", 10),
             ("balance", "表头:余额", 10), ("date_format", "日期格式", 11)],
    "员工": [("id", "员工ID", 8), ("display", "显示名", 14), ("role", "身份(officer/employee)", 12),
           ("birth", "出生日期", 11), ("hired", "入职日", 11), ("left", "离职日", 11), ("shaho", "社保", 6),
           ("koyou", "雇用保险", 7), ("wh_column", "源泉栏(kou/otsu)", 9), ("dependents", "扶养人数", 7),
           ("commute_mode", "通勤方式(car/transit)", 11), ("commute_one_way_km", "单程km", 7),
           ("commute_pass_monthly", "月定期", 8), ("commute_parking", "停车费", 8)],
    "标准报酬": [("employee", "员工ID", 8), ("from", "适用月(YYYY-MM)", 12), ("amount", "标准报酬月额", 12),
             ("evidence", "依据", 24)],
    "住民税": [("employee", "员工ID", 8), ("month", "月(YYYY-MM)", 11), ("amount", "月额", 9)],
    "固定工资": [("employee", "员工ID", 8), ("item", "支给项目", 12), ("amount", "金额", 10)],
    "期初余额": [("account", "科目", 14), ("sub", "明细", 20), ("debit", "借方", 12), ("credit", "贷方", 12)],
    "每月工资": [("month", "月(YYYY-MM)", 11), ("employee", "员工ID", 8), ("item", "支给项目", 12),
             ("amount", "金额", 10), ("remove", "本月不发(TRUE)", 10)],
    "奖金": [("month", "月(YYYY-MM)", 11), ("date", "支付日", 11), ("employee", "员工ID", 8), ("amount", "金额", 10)],
    "开票": [("date", "日期", 11), ("customer", "客户", 18), ("amount", "金额", 12), ("tax", "税区分", 12),
           ("evidence", "依据", 20)],
    "银行规则": [("id", "规则ID", 7), ("desc_contains", "摘要包含", 16), ("direction", "方向(out/in)", 9),
             ("amount", "金额(可选)", 10), ("account", "科目", 12), ("sub", "明细", 12), ("tax", "税区分", 12),
             ("evidence", "依据", 16), ("note", "说明", 16), ("by", "判断人", 10), ("at", "日期", 11),
             ("reason", "理由", 20)],
    "固定资产": [("id", "资产ID", 8), ("name", "名称", 16), ("account", "科目", 12), ("cost", "取得价额", 12),
             ("acquired", "取得日", 11), ("in_service", "开始使用日", 11), ("life", "耐用年数", 7),
             ("method", "方法(straight/declining_200)", 12), ("accumulated_at_fy_start", "期初累计折旧", 12),
             ("by", "判断人", 10), ("at", "日期", 11), ("reason", "理由", 20)],
    "折旧分摊": [("asset", "资产ID", 8), ("from", "从(YYYY-MM)", 11), ("to", "到(可空)", 11), ("account", "费用科目", 16),
             ("ratio", "比例(1, 0.5, 2/3)", 10)],
    "回答": [("key", "待确认的key", 40), ("action", "处理(book/done)", 9), ("account", "科目", 12), ("sub", "明细", 12),
           ("tax", "税区分", 12), ("amount", "拆分金额(多行时)", 11), ("evidence", "依据", 16), ("memo", "摘要", 14),
           ("by", "判断人", 10), ("at", "日期", 11), ("reason", "理由", 22)],
    "调整分录": [("id", "分录ID", 12), ("date", "日期", 11), ("recurring_from", "每月:从", 9), ("recurring_to", "每月:到", 9),
             ("recurring_day", "每月:日(end/数字)", 9), ("narration", "摘要", 22), ("account", "科目", 12),
             ("sub", "明细", 14), ("debit", "借方", 11), ("credit", "贷方", 11), ("tax", "税区分", 10),
             ("evidence", "依据", 16), ("by", "判断人", 10), ("at", "日期", 11), ("reason", "理由", 20)],
    "劳动保险": [("fiscal_year", "年度", 7), ("wages_koyou", "开始前工资:雇用", 12), ("wages_rousai", "开始前工资:劳灾", 12),
             ("estimate_paid", "上年度概算保险费", 12), ("withheld_employee", "本人负担扣除额", 12),
             ("installment", "延纳(TRUE/FALSE)", 9), ("estimate_base", "今年度见込额(可空)", 12),
             ("accrued_employer", "已计提公司负担(可空)", 12), ("by", "判断人", 10), ("at", "日期", 11), ("reason", "理由", 20)],
    "法人税": [("fiscal_year_end", "决算月(YYYY-MM)", 11), ("pref_houjinzeiwari_rate", "府县 法人税割率", 10),
            ("pref_kintou", "府县 均等割(年)", 10), ("jigyouzei_excess", "事业税超过税率", 9),
            ("loss_carryforward", "繰越欠損金控除", 11), ("capital_and_reserve", "资本金等(可空)", 12),
            ("employees_in_city", "从业者数(可空)", 9), ("municipality", "市区町村(可空)", 10),
            ("by", "判断人", 10), ("at", "日期", 11), ("reason", "理由", 20)],
    "法人税调整": [("fiscal_year_end", "决算月", 10), ("kind", "加算/减算(add/deduct)", 10), ("item", "项目", 20),
              ("amount", "金额", 11)],
    "中间纳付": [("fiscal_year_end", "决算月", 10), ("item", "税目", 16), ("amount", "金额", 11)],
}
KV = [  # 公司 シート（項目, 説明）
    ("company.name", "公司名", ""), ("company.prefecture", "协会けんぽ支部（都道府县）", "例：東京 / 大阪"),
    ("company.municipality", "总公司市区町村", "法人住民税用，例：大阪市"),
    ("company.health_insurer", "健康保险", "目前只支持 kyoukaikenpo"),
    ("company.rousai_code", "劳灾保险 事业种类编号", "例：94"), ("company.koyou_kind", "雇用保险 事业区分", "一般の事業 等"),
    ("company.fiscal_year_end_month", "决算月(1〜12)", ""),
    ("company.start_month", "开始记账月(YYYY-MM)", "期初余额是它前一个月末"),
    ("payroll.closing_day", "工资截止日", "end（月末）或数字"), ("payroll.pay_day", "发薪日", "数字，31=月末"),
    ("payroll.pay_day_shift", "发薪日遇休息日", "before（提前）/ after（顺延）"),
    ("opening.as_of", "期初余额的日期", "开始月前一个月末，例：2026-03-31"),
    ("bank_keywords.shaho", "摘要关键词：社保", "逗号分隔，例：ｼﾔｶｲﾎｹﾝ"),
    ("bank_keywords.gensen", "摘要关键词：源泉", ""), ("bank_keywords.jumin", "摘要关键词：住民税", ""),
]
CT_CHOICES = {"status": ("taxable", "exempt"), "method": ("general", "simplified"),
              "category": (1, 2, 3, 4, 5, 6), "accounting": ("tax_included", "tax_excluded")}
CT_HELP = {"status": "taxable（课税事业者）/ exempt（免税事业者）", "method": "课税事业者才填：general（本则）/ simplified（简易）",
           "category": "简易课税才填：事业区分 1〜6", "accounting": "tax_included（税込）/ tax_excluded（税抜）"}
POLICY_COLS = [("key", "项目", 24), ("help", "说明与选项", 46), ("value", "选择", 14), ("by", "判断人", 10),
               ("at", "日期", 11), ("reason", "理由", 26)]
ORDER = ["公司", "方针", "追加科目", "支给项目", "银行账户", "员工", "标准报酬", "住民税", "固定工资", "期初余额", "每月工资", "奖金",
         "开票", "银行规则", "固定资产", "折旧分摊", "回答", "调整分录", "劳动保险", "法人税", "法人税调整", "中间纳付"]
GUIDE = [
    "公司资料.xlsx：把这个工作簿和银行流水（bank/ 文件夹，网银下载的 CSV 或 Excel）放在同一个文件夹，选择这个文件夹即可。",
    "按顺序填写：公司 → 方针 → 支给项目 → 银行账户 → 员工（标准报酬・住民税・固定工资）→ 期初余额。其余的表有需要时再填。",
    "第 2 行是程序用的栏名（已隐藏），不要改。从第 3 行开始填。空着的表 = 没有这项。",
    "日期写 2026-04-30，月份写 2026-04（Excel 自动变成日期也没关系）。金额只写数字。",
    "「方针」表的每一项都要选，并写判断人和日期——本产品不替你选默认值，判断会记进底稿的「判断记录」。",
    "每月：在「每月工资」写与名册不同的部分（加班・时薪等），在「开票」写当月的请求书。结账后「待确认」的回答写在「回答」表。",
]


# --------------------------------------------------------------------------- 値の正規化
def _v(x):
    if isinstance(x, datetime.datetime):
        x = x.date()
    if isinstance(x, float) and x == int(x):
        return int(x)
    if isinstance(x, str):
        x = x.strip()
        return x if x != "" else None
    return x


def _month(x):
    x = _v(x)
    if isinstance(x, datetime.date):
        return f"{x:%Y-%m}"
    return None if x is None else str(x)[:7]


def _date(x):
    x = _v(x)
    if isinstance(x, datetime.date):
        return x.isoformat()
    return None if x is None else str(x)[:10]


def _bool(x):
    x = _v(x)
    if isinstance(x, str):
        return {"true": True, "false": False, "是": True, "否": False, "yes": True, "no": False}.get(x.lower(), x)
    return x


def _clean(d):
    return {k: v for k, v in d.items() if v is not None and v != "" and v != {}}


def _rows(ws):
    """2 行目の欄名で、3 行目以降を dict にする。全部空の行は飛ばす。"""
    grid = list(ws.iter_rows(values_only=True))
    if len(grid) < 2:
        return []
    keys = [str(k).strip() if k is not None else "" for k in grid[1]]
    out = []
    for i, r in enumerate(grid[2:], start=3):
        d = {k: _v(v) for k, v in zip(keys, r) if k}
        if any(v is not None for v in d.values()):
            out.append((i, d))
    return out


# --------------------------------------------------------------------------- ブック → YAML
def to_folder(xlsx, out_dir) -> list:
    """ブックを YAML 群に変換して out_dir に書く。返り値は問題 [(シート, 行, 内容)]（空なら正常）。"""
    from openpyxl import load_workbook
    out, problems = pathlib.Path(out_dir), []
    wb = load_workbook(xlsx, data_only=True)
    sheets = {ws.title: ws for ws in wb.worksheets}
    for name in ("公司", "方针"):
        if name not in sheets:
            problems.append((name, 0, f"表「{name}」が無い——テンプレートの表を消さない"))
    if problems:
        return problems
    rows = {n: _rows(sheets[n]) if n in sheets else [] for n in ORDER}

    # 公司（項目と値）
    kv = {}
    for r in sheets["公司"].iter_rows(min_row=1, values_only=True):
        if r and r[-1] and str(r[-1]).startswith(("company.", "payroll.", "opening.", "bank_keywords.")):
            kv[str(r[-1])] = _v(r[1])
    co = _clean({k.split(".", 1)[1]: kv.get(k) for k in kv if k.startswith("company.")})
    for k in ("start_month",):
        if co.get(k) is not None:
            co[k] = _month(co[k])
    if co.get("rousai_code") is not None:
        co["rousai_code"] = str(co["rousai_code"])
    pr = _clean({k.split(".", 1)[1]: kv.get(k) for k in kv if k.startswith("payroll.")})
    pr["items"] = {}
    for i, d in rows["支给项目"]:
        pr["items"][d["name"]] = _clean({"account": d.get("account"), "taxable": _bool(d.get("taxable")),
                                         "koyou_wage": _bool(d.get("koyou_wage")),
                                         "nontaxable_check": d.get("nontaxable_check")})
    pol, ct = {}, {}
    for i, d in rows["方针"]:
        key = str(d.get("key") or "")
        val = _bool(d.get("value"))
        ent = _clean({"value": val, "by": d.get("by"), "at": _date(d.get("at")), "reason": d.get("reason")})
        if key.startswith("policies."):
            if val is not None or len(ent) > 0:
                pol[key.split(".", 1)[1]] = ent
        elif key.startswith("consumption_tax."):
            if ent:
                ct[key.split(".", 1)[1]] = ent
    banks = []
    for i, d in rows["银行账户"]:
        banks.append(_clean({"id": d.get("id"), "account": d.get("account"), "sub": d.get("sub"),
                             "files": d.get("files") or "bank/*",
                             "csv": _clean({k: d.get(k) for k in ("date", "desc", "out", "in", "balance", "date_format")})}))
    kw = {k.split(".", 1)[1]: [w.strip() for w in str(v).split(",") if w.strip()]
          for k, v in kv.items() if k.startswith("bank_keywords.") and v}
    company_doc = OrderedDict(company=co)
    add = [_clean({k: d.get(k) for k, _, _ in T["追加科目"]}) for i, d in rows["追加科目"]]
    if add:
        company_doc["accounts"] = {"add": add}
    company_doc.update(payroll=pr, policies=pol, consumption_tax=ct, bank_accounts=banks)
    if kw:
        company_doc["bank_keywords"] = kw
    _dump(out / "company.yaml", dict(company_doc))

    # 员工・标准报酬・住民税・固定工资
    emps = OrderedDict()
    for i, d in rows["员工"]:
        e = _clean({"id": d.get("id"), "display": d.get("display"), "role": d.get("role"),
                    "birth": _date(d.get("birth")), "hired": _date(d.get("hired")), "left": _date(d.get("left")),
                    "shaho": _bool(d.get("shaho")), "koyou": _bool(d.get("koyou"))})
        e["withholding"] = _clean({"column": d.get("wh_column"), "dependents": d.get("dependents") or 0})
        cm = _clean({"mode": d.get("commute_mode"), "one_way_km": d.get("commute_one_way_km"),
                     "pass_monthly": d.get("commute_pass_monthly"), "parking": d.get("commute_parking")})
        if cm:
            e["commute"] = cm
        emps[e.get("id")] = e
    for sheet, field, mk in (("标准报酬", "smr", lambda d: _clean({"from": _month(d.get("from")), "amount": d.get("amount"),
                                                               "evidence": d.get("evidence")})),):
        for i, d in rows[sheet]:
            if d.get("employee") not in emps:
                problems.append((sheet, i, f"员工ID「{d.get('employee')}」が「员工」表に無い"))
                continue
            emps[d["employee"]].setdefault(field, []).append(mk(d))
    for i, d in rows["住民税"]:
        if d.get("employee") not in emps:
            problems.append(("住民税", i, f"员工ID「{d.get('employee')}」が「员工」表に無い"))
            continue
        emps[d["employee"]].setdefault("juminzei", {})[_month(d.get("month"))] = d.get("amount") or 0
    for i, d in rows["固定工资"]:
        if d.get("employee") not in emps:
            problems.append(("固定工资", i, f"员工ID「{d.get('employee')}」が「员工」表に無い"))
            continue
        emps[d["employee"]].setdefault("pay", {})[d.get("item")] = d.get("amount")
    _dump(out / "employees.yaml", {"employees": list(emps.values())})

    # 期初余额
    bal = [_clean({"account": d.get("account"), "sub": d.get("sub"), "debit": d.get("debit"), "credit": d.get("credit")})
           for i, d in rows["期初余额"]]
    _dump(out / "opening_balances.yaml", _clean({"as_of": _date(kv.get("opening.as_of")), "balances": bal}))

    # 每月工资・奖金・开票 → monthly/YYYY-MM/
    monthly = {}
    for i, d in rows["每月工资"]:
        m = _month(d.get("month"))
        e = monthly.setdefault(m, {}).setdefault("payroll", {"employees": {}})["employees"].setdefault(d.get("employee"), {})
        if _bool(d.get("remove")) is True:
            e.setdefault("remove", []).append(d.get("item"))
        else:
            e.setdefault("items", {})[d.get("item")] = d.get("amount")
    for i, d in rows["奖金"]:
        m = _month(d.get("month"))
        b = monthly.setdefault(m, {}).setdefault("payroll", {"employees": {}}).setdefault(
            "bonus", {"date": _date(d.get("date")), "employees": {}})
        b["employees"][d.get("employee")] = d.get("amount")
    for i, d in rows["开票"]:
        dt = _date(d.get("date"))
        monthly.setdefault(dt[:7], {}).setdefault("sales", {"invoices": []})["invoices"].append(
            _clean({"date": dt, "customer": d.get("customer"), "amount": d.get("amount"), "tax": d.get("tax"),
                    "evidence": d.get("evidence")}))
    for m, docs in monthly.items():
        for kind, doc in docs.items():
            _dump(out / "monthly" / m / f"{kind}.yaml", doc)

    # 银行规则
    rules = []
    for i, d in rows["银行规则"]:
        side = "credit" if d.get("direction") == "in" else "debit"
        rules.append(_clean({"id": d.get("id"), "note": d.get("note"),
                             "when": _clean({"desc_contains": d.get("desc_contains"), "direction": d.get("direction"),
                                             "amount": d.get("amount")}),
                             "then": _clean({side: d.get("account"), "sub": d.get("sub"), "tax": d.get("tax"),
                                             "evidence": d.get("evidence")}),
                             "by": d.get("by"), "at": _date(d.get("at")), "reason": d.get("reason")}))
    if rules:
        _dump(out / "bank_rules.yaml", {"rules": rules})

    # 固定资产・折旧分摊
    assets = OrderedDict()
    for i, d in rows["固定资产"]:
        assets[d.get("id")] = _clean({k: (_date(d.get(k)) if k in ("acquired", "in_service", "at") else d.get(k))
                                      for k, _, _ in T["固定资产"]})
    for i, d in rows["折旧分摊"]:
        a = assets.get(d.get("asset"))
        if a is None:
            problems.append(("折旧分摊", i, f"资产ID「{d.get('asset')}」が「固定资产」表に無い"))
            continue
        per_key = (_month(d.get("from")), _month(d.get("to")))
        al = a.setdefault("allocation", [])
        per = next((p for p in al if (p["from"], p.get("to")) == per_key), None)
        if per is None:
            per = _clean({"from": per_key[0], "to": per_key[1]})
            per["accounts"] = {}
            al.append(per)
        per["accounts"][d.get("account")] = str(d.get("ratio"))
    if assets:
        _dump(out / "fixed_assets.yaml", {"assets": list(assets.values())})

    # 回答（同じ key の行が複数 → 内訳 lines）
    dec = OrderedDict()
    for i, d in rows["回答"]:
        dec.setdefault(str(d.get("key")), []).append((i, d))
    decisions = {}
    for k, rs in dec.items():
        first = rs[0][1]
        ent = _clean({"action": first.get("action"), "evidence": first.get("evidence"), "memo": first.get("memo"),
                      "by": first.get("by"), "at": _date(first.get("at")), "reason": first.get("reason")})
        if len(rs) > 1 or first.get("amount") is not None:
            ent["lines"] = [_clean({"account": d.get("account"), "sub": d.get("sub"), "tax": d.get("tax"),
                                    "amount": d.get("amount")}) for _, d in rs]
        else:
            ent.update(_clean({"account": first.get("account"), "sub": first.get("sub"), "tax": first.get("tax")}))
        decisions[k] = ent
    if decisions:
        _dump(out / "decisions.yaml", {"decisions": decisions})

    # 调整分录（同じ ID の行が一つの仕訳）
    entries = OrderedDict()
    for i, d in rows["调整分录"]:
        e = entries.get(d.get("id"))
        if e is None:
            e = _clean({"id": d.get("id"), "date": _date(d.get("date")), "narration": d.get("narration"),
                        "evidence": d.get("evidence"), "by": d.get("by"), "at": _date(d.get("at")),
                        "reason": d.get("reason")})
            if d.get("recurring_from"):
                e["recurring"] = _clean({"from": _month(d.get("recurring_from")), "to": _month(d.get("recurring_to")),
                                         "day": d.get("recurring_day")})
            e["lines"] = []
            entries[d.get("id")] = e
        e["lines"].append(_clean({"account": d.get("account"), "sub": d.get("sub"), "debit": d.get("debit"),
                                  "credit": d.get("credit"), "tax": d.get("tax")}))
    if entries:
        _dump(out / "adjustments.yaml", {"entries": list(entries.values())})

    # 劳动保险
    annual = []
    for i, d in rows["劳动保险"]:
        annual.append(_clean({"fiscal_year": d.get("fiscal_year"),
                              "wages_before_start": _clean({"koyou": d.get("wages_koyou"), "rousai": d.get("wages_rousai")}),
                              "estimate_paid": d.get("estimate_paid"), "withheld_employee": d.get("withheld_employee"),
                              "installment": _bool(d.get("installment")), "estimate_base": d.get("estimate_base"),
                              "accrued_employer": d.get("accrued_employer"),
                              "by": d.get("by"), "at": _date(d.get("at")), "reason": d.get("reason")}))
    if annual:
        _dump(out / "labor_insurance.yaml", {"annual": annual})

    # 法人税（・调整・中间纳付）
    years = OrderedDict()
    for i, d in rows["法人税"]:
        fy = _month(d.get("fiscal_year_end"))
        years[fy] = _clean({**{k: d.get(k) for k, _, _ in T["法人税"] if k not in ("fiscal_year_end", "at")},
                            "fiscal_year_end": fy, "at": _date(d.get("at")),
                            "jigyouzei_excess": _bool(d.get("jigyouzei_excess"))})
        if years[fy].get("pref_houjinzeiwari_rate") is not None:
            years[fy]["pref_houjinzeiwari_rate"] = str(years[fy]["pref_houjinzeiwari_rate"])
    for i, d in rows["法人税调整"]:
        y = years.get(_month(d.get("fiscal_year_end")))
        if y is None:
            problems.append(("法人税调整", i, "决算月が「法人税」表に無い"))
            continue
        y.setdefault("adjustments", {"add": [], "deduct": []})[d.get("kind")].append(
            {"item": d.get("item"), "amount": d.get("amount")})
    for i, d in rows["中间纳付"]:
        y = years.get(_month(d.get("fiscal_year_end")))
        if y is None:
            problems.append(("中间纳付", i, "决算月が「法人税」表に無い"))
            continue
        y.setdefault("interim_paid", {})[d.get("item")] = d.get("amount")
    if years:
        _dump(out / "corporate_tax.yaml", {"years": list(years.values())})
    return problems


def _dump(path, data):
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_text("# 公司资料.xlsx から自動生成（手で直すならブックの方を直す）\n"
                    + yaml.safe_dump(data, allow_unicode=True, sort_keys=False, width=200), encoding="utf-8")


# --------------------------------------------------------------------------- YAML → ブック
def _load(root, name):
    p = pathlib.Path(root) / name
    return (yaml.safe_load(p.read_text(encoding="utf-8")) or {}) if p.exists() else {}


def _s(x):
    """書き出し用：日付はそのまま文字列にする（Excel の日付型にすると月の欄が 1 日付きになる）。"""
    if isinstance(x, datetime.date):
        return x.isoformat()
    return x


def from_folder(root, xlsx):
    root = pathlib.Path(root)
    c = _load(root, "company.yaml")
    office = {}
    if c.get("office"):
        office = (_load(root, c["office"]).get("policies") or {})
    data = {n: [] for n in ORDER}
    co, pr = c.get("company") or {}, c.get("payroll") or {}
    kv = {f"company.{k}": v for k, v in co.items()}
    kv.update({f"payroll.{k}": v for k, v in pr.items() if k != "items"})
    op = _load(root, "opening_balances.yaml")
    kv["opening.as_of"] = op.get("as_of")
    for k, v in (c.get("bank_keywords") or {}).items():
        kv[f"bank_keywords.{k}"] = ",".join(v)
    pol = dict(office, **(c.get("policies") or {}))
    pol_rows = {f"policies.{k}": v for k, v in pol.items()}
    pol_rows.update({f"consumption_tax.{k}": v for k, v in (c.get("consumption_tax") or {}).items()})
    data["追加科目"] = list((c.get("accounts") or {}).get("add") or [])
    for name, it in (pr.get("items") or {}).items():
        data["支给项目"].append(dict(it, name=name))
    for b in c.get("bank_accounts") or []:
        data["银行账户"].append(dict({k: v for k, v in b.items() if k != "csv"}, **(b.get("csv") or {})))
    for e in _load(root, "employees.yaml").get("employees") or []:
        wh, cm = e.get("withholding") or {}, e.get("commute") or {}
        data["员工"].append(dict(e, wh_column=wh.get("column"), dependents=wh.get("dependents"),
                                 commute_mode=cm.get("mode"), commute_one_way_km=cm.get("one_way_km"),
                                 commute_pass_monthly=cm.get("pass_monthly"), commute_parking=cm.get("parking")))
        for s in e.get("smr") or []:
            data["标准报酬"].append(dict(s, employee=e["id"]))
        for m, a in (e.get("juminzei") or {}).items():
            data["住民税"].append({"employee": e["id"], "month": _s(m) if not isinstance(m, str) else m, "amount": a})
        for it, a in (e.get("pay") or {}).items():
            data["固定工资"].append({"employee": e["id"], "item": it, "amount": a})
    data["期初余额"] = list(op.get("balances") or [])
    md = root / "monthly"
    for d in sorted(p for p in md.glob("*") if p.is_dir()) if md.exists() else []:
        pay = _load(d, "payroll.yaml")
        for eid, x in (pay.get("employees") or {}).items():
            for it, a in (x.get("items") or {}).items():
                data["每月工资"].append({"month": d.name, "employee": eid, "item": it, "amount": a})
            for it in x.get("remove") or []:
                data["每月工资"].append({"month": d.name, "employee": eid, "item": it, "remove": True})
        b = pay.get("bonus")
        if b:
            for eid, a in (b.get("employees") or {}).items():
                data["奖金"].append({"month": d.name, "date": b.get("date"), "employee": eid, "amount": a})
        for inv in _load(d, "sales.yaml").get("invoices") or []:
            data["开票"].append(inv)
    for r in _load(root, "bank_rules.yaml").get("rules") or []:
        w, t = r.get("when") or {}, r.get("then") or {}
        data["银行规则"].append(dict({k: v for k, v in r.items() if k not in ("when", "then")}, **w, **t,
                                     account=t.get("debit") or t.get("credit")))
    for a in _load(root, "fixed_assets.yaml").get("assets") or []:
        data["固定资产"].append(a)
        for per in a.get("allocation") or []:
            for acc, ratio in per["accounts"].items():
                data["折旧分摊"].append({"asset": a["id"], "from": per["from"], "to": per.get("to"),
                                     "account": acc, "ratio": str(ratio)})
    for k, d in (_load(root, "decisions.yaml").get("decisions") or {}).items():
        head = {x: d.get(x) for x in ("action", "evidence", "memo", "by", "at", "reason")}
        if d.get("lines"):
            for l in d["lines"]:
                data["回答"].append(dict(head, key=k, **l))
        else:
            data["回答"].append(dict(head, key=k, account=d.get("account"), sub=d.get("sub"), tax=d.get("tax")))
    for e in _load(root, "adjustments.yaml").get("entries") or []:
        rc = e.get("recurring") or {}
        head = dict({x: e.get(x) for x in ("id", "date", "narration", "evidence", "by", "at", "reason")},
                    recurring_from=rc.get("from"), recurring_to=rc.get("to"), recurring_day=rc.get("day"))
        for l in e.get("lines") or []:
            data["调整分录"].append(dict(head, **l))
    for a in _load(root, "labor_insurance.yaml").get("annual") or []:
        w = a.get("wages_before_start") or {}
        data["劳动保险"].append(dict(a, wages_koyou=w.get("koyou"), wages_rousai=w.get("rousai")))
    for y in _load(root, "corporate_tax.yaml").get("years") or []:
        data["法人税"].append(y)
        for kind in ("add", "deduct"):
            for x in ((y.get("adjustments") or {}).get(kind) or []):
                data["法人税调整"].append({"fiscal_year_end": y["fiscal_year_end"], "kind": kind, **x})
        for it, amt in (y.get("interim_paid") or {}).items():
            data["中间纳付"].append({"fiscal_year_end": y["fiscal_year_end"], "item": it, "amount": amt})
    _write(xlsx, kv, pol_rows, data)


def blank(xlsx):
    _write(xlsx, {}, {}, {n: [] for n in ORDER})


# --------------------------------------------------------------------------- 書き出し（体裁）
def _write(xlsx, kv, pol_rows, data):
    from openpyxl import Workbook
    from openpyxl.styles import Alignment, Font, PatternFill
    from openpyxl.worksheet.datavalidation import DataValidation
    head_fill = PatternFill("solid", fgColor="E0E7FF")
    bold = Font(bold=True)
    wb = Workbook()
    g = wb.active
    g.title = "说明"
    g.column_dimensions["A"].width = 110
    g.append(["公司资料（月结引擎 · 日本）"])
    g["A1"].font = Font(bold=True, size=13)
    for line in GUIDE:
        g.append([line])
    for r in g.iter_rows(min_row=2):
        r[0].alignment = Alignment(wrap_text=True, vertical="top")

    ws = wb.create_sheet("公司")
    ws.append(["项目", "填写", "说明", "key"])
    for c in ws[1]:
        c.font, c.fill = bold, head_fill
    for key, label, help_ in KV:
        ws.append([label, _s(kv.get(key)), help_, key])
    ws.column_dimensions["A"].width, ws.column_dimensions["B"].width, ws.column_dimensions["C"].width = 26, 22, 36
    ws.column_dimensions["D"].hidden = True

    ws = wb.create_sheet("方针")
    ws.append([lab for _, lab, _ in POLICY_COLS])
    ws.append([k for k, _, _ in POLICY_COLS])
    rows = [(f"policies.{k}", POLICY_HELP.get(k, ""), ch) for k, ch in POLICY_CHOICES.items()]
    rows += [(f"consumption_tax.{k}", CT_HELP[k], ch) for k, ch in CT_CHOICES.items()]
    for i, (key, help_, choices) in enumerate(rows, start=3):
        ent = pol_rows.get(key) or {}
        ws.append([key, f"{help_}　选项：{' / '.join(str(c).lower() if isinstance(c, bool) else str(c) for c in choices)}",
                   _s(ent.get("value")), ent.get("by"), _s(ent.get("at")), ent.get("reason")])
        dv = DataValidation(type="list", allow_blank=True,
                            formula1='"' + ",".join(str(c).upper() if isinstance(c, bool) else str(c) for c in choices) + '"')
        ws.add_data_validation(dv)
        dv.add(f"C{i}")
    _style_table(ws, POLICY_COLS, head_fill, bold)
    for r in ws.iter_rows(min_row=3, min_col=2, max_col=2):
        r[0].alignment = Alignment(wrap_text=True, vertical="top")

    for name in ORDER[2:]:
        ws = wb.create_sheet(name)
        cols = T[name]
        ws.append([lab for _, lab, _ in cols])
        ws.append([k for k, _, _ in cols])
        for d in data.get(name) or []:
            ws.append([_s(d.get(k)) for k, _, _ in cols])
        _style_table(ws, cols, head_fill, bold)
    wb.save(xlsx)


def _style_table(ws, cols, fill, bold):
    from openpyxl.utils import get_column_letter
    for i, (_, _, w) in enumerate(cols, start=1):
        ws.column_dimensions[get_column_letter(i)].width = w
    for c in ws[1]:
        c.font, c.fill = bold, fill
    ws.row_dimensions[2].hidden = True
    ws.freeze_panes = "A3"


def find_workbook(root):
    """会社フォルダ直下の入力ブック（公司资料.xlsx。名前が違っても「公司」「方针」の表があれば使う）。"""
    root = pathlib.Path(root)
    p = root / WORKBOOK_NAME
    if p.exists():
        return p
    from openpyxl import load_workbook
    for q in sorted(root.glob("*.xlsx")):
        try:
            names = load_workbook(q, read_only=True).sheetnames
        except Exception:                       # 壊れた・暗号化された xlsx は入力ブックではない
            continue
        if "公司" in names and "方针" in names:
            return q
    return None
