# -*- coding: utf-8 -*-
"""Excel の入力ブック（公司资料.xlsx）⇔ 会社フォルダ（company.yaml などの YAML 群）。

作者 2026-10-09：「YAML はプログラマの書式。会計担当者には Excel の表で渡したい」。
エンジンは YAML のフォルダしか読まない（検査・判断記録の仕組みはそのまま）。ブックは入口の
書式にすぎないので、ここで**ブック → YAML** に変換してからいつもどおり締める。

  to_folder(xlsx, out_dir)   ブックを読み、out_dir に YAML 群を書く。問題は [(シート, 行, 内容)] で返す
  from_folder(dir, xlsx)     既存の会社フォルダをブックに書き出す（サンプルの例示・往復の試験・回答の書き戻し）
  blank(xlsx)                空白テンプレート（方針の行と選択肢のドロップダウンつき）

シートの作り：1 行目＝見出し（中国語）、2 行目＝欄の名前（機械用、非表示）、3 行目から中身。
銀行明細はブックに入れない（ネットバンキングのダウンロードをそのまま bank/ に置く）。
"""
from __future__ import annotations

import datetime
import pathlib
from collections import OrderedDict

import yaml

from . import workbook_text as X
from . import workbook_text_en as XE
from . import workbook_text_ja as XJ
from .company import POLICY_CHOICES

WORKBOOK_NAME = "公司资料.xlsx"

# --------------------------------------------------------------------------- 定義
# (欄の名前, 見出し, 幅)。欄の説明・選択肢の言葉は workbook_text.py
T = {
    # 標準科目表に無い科目（受取家賃・減価償却費（賃貸） など）。section は科目表の区分名
    "追加科目": [("code", "科目代码", 10), ("name", "科目名", 18), ("section", "区分", 20),
             ("normal", "余额方向", 12), ("tax", "税区分", 14), ("cn", "中文科目（可空）", 16)],
    "支给项目": [("name", "支给项目名", 16), ("account", "科目", 16), ("taxable", "算所得税", 14),
             ("koyou_wage", "算雇用保险", 14), ("nontaxable_check", "非课税限额检查", 18)],
    # 明細の置き場所（files）と日付の書式（date_format）は書かせない：中身で振り分け、書式は自動で読む
    "银行账户": [("id", "账户ID", 12), ("account", "科目", 14), ("sub", "银行名", 16),
             ("date", "流水的列名：日期", 18), ("desc", "流水的列名：摘要", 18), ("out", "流水的列名：出金", 20),
             ("in", "流水的列名：入金", 18), ("balance", "流水的列名：余额", 18)],
    "员工": [("id", "员工ID", 10), ("display", "显示名", 14), ("role", "身份", 12),
           ("birth", "出生日期", 13), ("hired", "入职日", 13), ("left", "离职日", 13), ("shaho", "社会保险", 13),
           ("koyou", "雇用保险", 13), ("wh_column", "源泉栏", 13), ("dependents", "扶养人数", 13),
           ("commute_mode", "通勤方式", 14), ("commute_one_way_km", "单程公里", 12),
           ("commute_pass_monthly", "月定期券", 12), ("commute_parking", "停车费", 12),
           ("juminzei_method", "住民税", 16)],
    "标准报酬": [("employee", "员工ID", 12), ("from", "适用月", 14), ("amount", "標準報酬月額", 16),
             ("evidence", "依据", 30)],
    "住民税": [("employee", "员工ID", 12), ("month", "月", 14), ("amount", "月额", 12)],
    "固定工资": [("employee", "员工ID", 12), ("item", "支给项目", 16), ("amount", "金额", 12)],
    "期初余额": [("account", "科目", 18), ("sub", "明细", 30), ("debit", "借方", 16), ("credit", "贷方", 16)],
    "每月工资": [("month", "月", 12), ("employee", "员工ID", 12), ("item", "支给项目", 16),
             ("amount", "金额", 16), ("remove", "本月不发", 14)],
    "奖金": [("month", "月", 12), ("date", "支付日", 13), ("employee", "员工ID", 12), ("amount", "金额", 14)],
    "开票": [("date", "日期", 13), ("customer", "客户", 22), ("amount", "金额", 14), ("tax", "税区分", 14),
           ("evidence", "依据", 22)],
    "银行规则": [("id", "规则ID", 10), ("desc_contains", "摘要包含", 18), ("direction", "方向", 12),
             ("amount", "金额（可空）", 14), ("account", "科目", 16), ("sub", "明细", 16), ("tax", "税区分", 14),
             ("evidence", "依据", 18), ("note", "说明", 18), ("by", "判断人", 12), ("at", "日期", 13),
             ("reason", "理由", 22)],
    "固定资产": [("id", "资产ID", 10), ("name", "名称", 18), ("account", "科目", 16), ("cost", "取得价额", 14),
             ("acquired", "取得日", 13), ("in_service", "开始使用日", 13), ("life", "耐用年数", 12),
             ("method", "折旧方法", 16), ("accumulated_at_fy_start", "期初累计折旧", 16),
             ("by", "判断人", 12), ("at", "日期", 13), ("reason", "理由", 22)],
    "折旧分摊": [("asset", "资产ID", 12), ("from", "从", 13), ("to", "到（可空）", 13), ("account", "费用科目", 18),
             ("ratio", "比例", 14)],
    "回答": [("key", "事项编号", 40), ("action", "处理", 12), ("account", "科目", 16), ("sub", "明细", 14),
           ("tax", "税区分", 14), ("amount", "拆分金额", 16), ("evidence", "依据", 18), ("memo", "摘要", 16),
           ("by", "判断人", 12), ("at", "日期", 13), ("reason", "理由", 24)],
    "调整分录": [("id", "分录ID", 16), ("date", "日期", 13), ("recurring_from", "每月重复：从", 14),
             ("recurring_to", "每月重复：到", 14), ("recurring_day", "每月重复：日", 14), ("narration", "摘要", 24),
             ("account", "科目", 16), ("sub", "明细", 16), ("debit", "借方", 13), ("credit", "贷方", 13),
             ("tax", "税区分", 14), ("evidence", "依据", 18), ("settlement", "决算整理", 12), ("by", "判断人", 12),
             ("at", "日期", 13), ("reason", "理由", 22)],
    "劳动保险": [("fiscal_year", "保险年度", 16), ("wages_koyou", "开始前工资：雇用保险", 18),
             ("wages_rousai", "开始前工资：劳灾", 18), ("estimate_paid", "上年度概算保険料", 18),
             ("withheld_employee", "开始前本人负担扣除额", 18), ("installment", "延納", 12),
             ("estimate_base", "今年度工资预计（可空）", 18), ("accrued_employer", "已计提公司负担（可空）", 18),
             ("by", "判断人", 12), ("at", "日期", 13), ("reason", "理由", 22)],
    "法人税": [("fiscal_year_end", "决算月", 13), ("pref_houjinzeiwari_rate", "府县 法人税割率", 16),
            ("pref_kintou", "府县 均等割（年）", 14), ("jigyouzei_excess", "事业税超过税率", 14),
            ("loss_carryforward", "繰越欠損金控除", 14), ("capital_and_reserve", "資本金等（可空）", 14),
            ("employees_in_city", "従業者数（可空）", 14), ("municipality", "市区町村（可空）", 14),
            ("by", "判断人", 12), ("at", "日期", 13), ("reason", "理由", 22)],
    "法人税调整": [("fiscal_year_end", "决算月", 13), ("kind", "加算／减算", 14), ("item", "项目", 26),
              ("amount", "金额", 14)],
    "中间纳付": [("fiscal_year_end", "决算月", 13), ("item", "税目", 18), ("amount", "金额", 14)],
}
KV = [  # 公司 シート（項目, 既定の見出し）。見出しと説明は workbook_text.KV_LABEL・KV_HINT
    "company.name", "company.prefecture", "company.municipality", "company.health_insurer", "company.rousai_code",
    "company.koyou_kind", "company.fiscal_year_end_month", "company.start_month", "payroll.closing_day",
    "payroll.pay_day", "payroll.pay_day_shift", "opening.as_of", "bank_keywords.shaho", "bank_keywords.gensen",
    "bank_keywords.jumin",
]
CT_CHOICES = {"status": ("taxable", "exempt"), "method": ("general", "simplified"),
              "category": (1, 2, 3, 4, 5, 6), "accounting": ("tax_included", "tax_excluded")}
POLICY_COLS = [("label", "要决定的事", 34), ("help", "怎么选", 70), ("value", "选择", 34), ("by", "判断人", 12),
               ("at", "日期", 13), ("reason", "理由", 26), ("key", "key", 6)]
ORDER = ["公司", "方针", "追加科目", "支给项目", "银行账户", "员工", "标准报酬", "住民税", "固定工资", "期初余额", "每月工资", "奖金",
         "开票", "银行规则", "固定资产", "折旧分摊", "回答", "调整分录", "劳动保险", "法人税", "法人税调整", "中间纳付"]
CHART_SHEET = "科目表"           # 内蔵の科目表（参照用。読み込みには使わない）
# 表の行：1 この表の説明・2 見出し・3 欄の説明・4 欄名（隠す）・5〜 データ。以前のブックは 1 見出し・2 欄名・3〜 データ
FIRST_ROW = 5
KEY_SCAN = 8                    # 欄名の行を探す範囲

# 言語ごとの文（表の名前・見出し・説明・選択肢の言葉）。正規の名前（エンジン・YAML・このファイルの中）は中国語のまま
LANGS = {"zh": X, "ja": XJ, "en": XE}


def _words(get):
    """どの言語の言葉でも読めるように、全言語を合わせる：{鍵: {言葉: 値}}。"""
    out = {}
    for m in LANGS.values():
        for k, pairs in get(m).items():
            out.setdefault(k, {}).update({w: c for w, c in pairs})
    return out


W2C = _words(lambda m: m.CHOICES)                                               # 言葉 → エンジンの値（全言語）
KV_W2C = _words(lambda m: m.KV_CHOICES)
P_W2C = _words(lambda m: {k: v[2] for k, v in m.POLICY.items()})
C2W = {g: {k: {c: w for w, c in v} for k, v in m.CHOICES.items()} for g, m in LANGS.items()}      # 値 → その言語の言葉
KV_C2W = {g: {k: {c: w for w, c in v} for k, v in m.KV_CHOICES.items()} for g, m in LANGS.items()}
P_C2W = {g: {k: {c: w for w, c in v[2]} for k, v in m.POLICY.items()} for g, m in LANGS.items()}
CANON = {title: name for m in LANGS.values() for name, title in m.SHEETS.items()}                 # 表の名前 → 正規の名前
BOOK = {"lang": "zh"}           # いま扱っているブックの言語（to_folder が決める。Worker は一度に 1 社）


def title(name, lang=None) -> str:
    """正規の表の名前 → その言語の表の名前。"""
    return LANGS[lang or BOOK["lang"]].SHEETS.get(name, name)


def label(name, key, lang=None) -> str:
    m = LANGS[lang or BOOK["lang"]]
    if m.LABELS:
        return m.LABELS[name][key]
    return {k: lab for k, lab, _ in T[name]}[key]


def book_lang(titles) -> str:
    """ブックの言語（「公司」の表の名前で決める）。"""
    for g in ("ja", "en", "zh"):
        if LANGS[g].SHEETS["公司"] in titles:
            return g
    return "zh"


def is_input_book(titles) -> bool:
    return {"公司", "方针"} <= {CANON.get(t) for t in titles}


def sheet(book, name):
    """ブックの中の、正規の名前 name の表（どの言語の名前でも）。無ければ None。"""
    for ws in book.worksheets:
        if CANON.get(ws.title) == name:
            return ws
    return None


def localize(text, lang=None):
    """文の中の「表の名前」を、ブックの言語の名前にする（エンジンの文は正規＝中国語の名前で書いてある）。"""
    lang = lang or BOOK["lang"]
    if lang == "zh" or not isinstance(text, str) or "「" not in text:
        return text
    for name, t in LANGS[lang].SHEETS.items():
        if name != t:
            text = text.replace(f"「{name}」", f"「{t}」")
    return text


def _pick(table, v):
    """言葉 ⇄ 値。True と 1、False と 0 を取り違えない（Python では True == 1）。"""
    for k, out in table.items():
        if type(k) is type(v) and k == v:
            return out
    return v


# --------------------------------------------------------------------------- 値の正規化
def _v(x):
    if isinstance(x, datetime.datetime):
        x = x.date()
    if isinstance(x, float) and x == int(x):
        return int(x)
    if isinstance(x, str):
        x = x.strip()
        return x if x != "" else None
    return x


def _month(x):
    x = _v(x)
    if isinstance(x, datetime.date):
        return f"{x:%Y-%m}"
    return None if x is None else str(x)[:7]


def _date(x):
    x = _v(x)
    if isinstance(x, datetime.date):
        return x.isoformat()
    return None if x is None else str(x)[:10]


def _bool(x):
    x = _v(x)
    if isinstance(x, str):
        return {"true": True, "false": False, "是": True, "否": False, "yes": True, "no": False}.get(x.lower(), x)
    return x


def _clean(d):
    return {k: v for k, v in d.items() if v is not None and v != "" and v != {}}


def _is_key(c: str) -> bool:
    """欄名（英小文字と _ だけ）か。見出し・説明の行は中国語なので当たらない。"""
    return c.isascii() and c.replace("_", "").isalpha() and c.islower()


def _key_row(grid) -> int:
    """欄名の行（0 始まり）。今のブックは 4 行目、以前のブックは 2 行目——決め打ちにせず探す。"""
    for i, r in enumerate(grid[:KEY_SCAN]):
        cells = [str(c).strip() for c in r if c is not None and str(c).strip() != ""]
        if cells and all(_is_key(c) for c in cells):
            return i
    return 1


def _rows(ws, name=None):
    """欄名の行の下を dict にする：[(Excel の行番号, {欄名: 値})]。全部空の行は飛ばす。

    name（表の名前）を渡すと、選ぶ欄の言葉（役員・甲欄・记账…）をエンジンの値（officer・kou・book…）に直す。
    エンジンの値がそのまま書いてある以前のブックも、そのまま読める。"""
    grid = list(ws.iter_rows(values_only=True))
    if len(grid) < 2:
        return []
    k = _key_row(grid)
    keys = [str(x).strip() if x is not None else "" for x in grid[k]]
    out = []
    for i, r in enumerate(grid[k + 1:], start=k + 2):
        d = {key: _pick(W2C.get((name, key), {}), _v(v)) for key, v in zip(keys, r) if key}
        if any(v is not None for v in d.values()):
            out.append((i, d))
    return out


# --------------------------------------------------------------------------- 欄の値の確認
# 作者 2026-10-12（逐栏填错の試験）：1 欄だけ間違えたブックを 76 通り作ったら、「どの表のどの欄か」まで言えたのは 19。
# 20 はプログラムの生のエラー（ValueError: invalid literal…）、20 は締めの途中で落ち、17 は黙って通った。
# エンジンの各所に任せず、**ブックを読むところで**欄ごとに確かめる：読み方の幅は広く（2026/4/30・12,000円 も読む）、
# 読めなければ「表・行・欄・書いてあった値・どう書くか」を言う。
DATE_KEYS = {"birth", "hired", "left", "acquired", "in_service", "at", "date"}
MONTH_KEYS = {"from", "to", "month", "recurring_from", "recurring_to", "fiscal_year_end"}
INT_KEYS = {"amount", "debit", "credit", "cost", "life", "dependents", "accumulated_at_fy_start", "commute_pass_monthly",
            "commute_parking", "estimate_paid", "wages_koyou", "wages_rousai", "withheld_employee", "fiscal_year",
            "pref_kintou", "loss_carryforward", "estimate_base", "accrued_employer", "capital_and_reserve",
            "employees_in_city", "code"}
NUM_KEYS = {"ratio", "pref_houjinzeiwari_rate", "commute_one_way_km"}
TEXT_SHEETS = {"银行账户"}                        # この表の date・desc… は明細の列名（日付ではない）
REF = {"employee": ("员工", "id"), "item": ("支给项目", "name"), "asset": ("固定资产", "id")}
REF_DONE = set()         # 以前は一部を to_folder の中で別に確かめていた（文が中国語まじりだった）。今は全部ここで
MUST = {
    "追加科目": ["code", "name", "section", "normal"], "支给项目": ["name", "account"],
    "银行账户": ["id", "account", "date", "desc", "out", "in", "balance"],
    "员工": ["id"],
    "标准报酬": ["employee", "from", "amount"], "住民税": ["employee", "month", "amount"],
    "固定工资": ["employee", "item", "amount"], "期初余额": ["account"], "每月工资": ["month", "employee", "item"],
    "奖金": ["month", "date", "employee", "amount"], "开票": ["date", "customer", "amount"],
    "银行规则": ["id", "desc_contains", "direction", "account"],
    "固定资产": ["id", "name", "account", "cost", "acquired"],
    "折旧分摊": ["asset", "from", "account", "ratio"], "回答": ["key", "action"], "调整分录": ["id", "account"],
    "劳动保险": ["fiscal_year", "estimate_paid"], "法人税": ["fiscal_year_end"],
    "法人税调整": ["fiscal_year_end", "kind", "item", "amount"], "中间纳付": ["fiscal_year_end", "item", "amount"],
}
INT_RANGE = {"life": (2, 100, "life"), "dependents": (0, 20, "dependents")}      # 桁違い・欄違いを拾う
_D_FORMATS = ("%Y-%m-%d", "%Y/%m/%d", "%Y.%m.%d", "%Y年%m月%d日", "%Y%m%d")
_M_FORMATS = ("%Y-%m", "%Y/%m", "%Y年%m月", "%Y.%m")


class _Bad(ValueError):
    """読めない値。code は workbook_text*.PH の鍵、kw はその文に入れる値（文はブックの言語で作る）。"""

    def __init__(self, code, **kw):
        super().__init__(code)
        self.code, self.kw = code, kw

    def text(self, lang):
        ph = LANGS[lang].PH
        kw = dict(self.kw)
        if "what" in kw:
            kw["what"] = ph[f"what_{kw['what']}"]
        return ph[self.code].format(**kw)


def _norm(v) -> str:
    import unicodedata
    return unicodedata.normalize("NFKC", str(v)).strip()        # 全角の数字・記号を半角に


def _to_date(v) -> str:
    if isinstance(v, datetime.datetime):
        return v.date().isoformat()
    if isinstance(v, datetime.date):
        return v.isoformat()
    if isinstance(v, str):
        s = _norm(v)
        if len(s) > 10 and s[10] in " T":         # 「2026-04-30 00:00:00」のように時刻が付いている
            s = s[:10]
        for f in _D_FORMATS:
            try:
                return datetime.datetime.strptime(s, f).date().isoformat()
            except ValueError:
                continue
    raise _Bad("date")


def _to_month(v) -> str:
    if isinstance(v, datetime.date):
        return f"{v:%Y-%m}"
    if isinstance(v, str):                       # 数（2026.1 など）は 1 月か 10 月か決められないので読まない
        s = _norm(v)
        for f in _M_FORMATS:
            try:
                return f"{datetime.datetime.strptime(s, f):%Y-%m}"
            except ValueError:
                continue
        try:
            return _to_date(v)[:7]
        except _Bad:
            pass
    raise _Bad("month")


def _to_int(v) -> int:
    if isinstance(v, bool):
        raise _Bad("int")
    if isinstance(v, int):
        return v
    if isinstance(v, float):
        if v == int(v):
            return int(v)
        raise _Bad("decimal")
    s = _norm(v).replace(",", "").replace("円", "").replace("¥", "").replace("\\", "").replace(" ", "")
    neg = s.startswith(("-", "▲", "△"))
    s = s.lstrip("-▲△")
    if s.isdigit():
        return -int(s) if neg else int(s)
    raise _Bad("int")


def _to_num(v):
    from fractions import Fraction
    if isinstance(v, (int, float)) and not isinstance(v, bool):
        return v
    try:
        Fraction(_norm(v).replace(" ", ""))
    except (ValueError, ZeroDivisionError):
        raise _Bad("num") from None
    return _norm(v).replace(" ", "")


def _check_rows(rows, lang="zh") -> list:
    """読んだ行を欄ごとに確かめ、読める書き方は正規の形に直す（その場で書き換える）。問題 [(表, 行, 文)] を返す。
    文は lang（ブックの言語）で作る：欄の名前も表の名前もその言語。"""
    ph = LANGS[lang].PH
    from .jp import shouhi
    taxes = list(shouhi.table()["categories"])
    chart = _chart_rows()
    accounts = {r[1] for r in chart} | {d.get("name") for _, d in rows.get("追加科目", []) if d.get("name")}
    sections = {r[3] for r in chart}
    ids = {t: {d.get(k) for _, d in rows.get(t, []) if d.get(k) is not None} for t, k in REF.values()}
    out = []
    for name, cols in T.items():
        lab = {k: label(name, k, lang) for k, _, _ in cols}
        for i, d in rows.get(name, []):
            def bad(k, msg, show=True):
                out.append((name, i, ph["col"].format(label=lab[k])
                            + (ph["wrote"].format(v=d.get(k)) if show else "") + msg))

            for k in MUST.get(name, []):
                if d.get(k) is None:
                    bad(k, ph["must"], show=False)
            for k in lab:
                v = d.get(k)
                if v is None:
                    continue
                try:
                    if (name, k) in X.CHOICES:
                        codes = [c for _, c in X.CHOICES[(name, k)]]
                        ok = any(type(c) is type(v) and c == v for c in codes)
                        if (name, k) == ("调整分录", "recurring_day") and not ok:
                            try:
                                d[k] = _to_int(v)
                            except _Bad:
                                raise _Bad("day") from None
                            if not 1 <= d[k] <= 31:
                                raise _Bad("day")
                        elif not ok:
                            raise _Bad("choice", words="／".join(w for w, _ in LANGS[lang].CHOICES[(name, k)]))
                    elif name in TEXT_SHEETS:
                        if k == "account" and v not in accounts:
                            raise _Bad("account_bank", chart=title(CHART_SHEET, lang), extra=title("追加科目", lang))
                    elif k in DATE_KEYS:
                        d[k] = _to_date(v)
                    elif k in MONTH_KEYS:
                        d[k] = _to_month(v)
                    elif k in INT_KEYS:
                        d[k] = _to_int(v)
                        lo, hi, what = INT_RANGE.get(k, (None, None, ""))
                        if lo is not None and not lo <= d[k] <= hi:
                            raise _Bad("range", what=what, lo=lo, hi=hi)
                    elif k in NUM_KEYS:
                        d[k] = _to_num(v)
                    elif k == "account":
                        if v not in accounts:
                            raise _Bad("account", chart=title(CHART_SHEET, lang), extra=title("追加科目", lang))
                    elif k == "tax":
                        if v not in taxes:
                            raise _Bad("tax", list="／".join(taxes))
                    elif k == "section":
                        if v not in sections:
                            raise _Bad("section")
                    elif k in REF and (name, k) not in X.LIST_OFF and (name, k) not in REF_DONE:
                        if v not in ids[REF[k][0]]:
                            raise _Bad("ref", sheet=title(REF[k][0], lang))
                except _Bad as e:
                    bad(k, e.text(lang))
                    d[k] = None                  # 読めなかった値を先へ流さない（後ろで生のエラーになる）
            if name == "奖金" and d.get("month") and d.get("date") and str(d["date"])[:7] != d["month"]:
                out.append((name, i, ph["bonus"].format(a=lab["date"], date=d["date"], b=lab["month"], month=d["month"])))
            if name in ("期初余额", "调整分录") and d.get("debit") and d.get("credit"):
                out.append((name, i, ph["both"].format(a=lab["debit"], b=lab["credit"])))
    return out


KV_KIND = {"company.fiscal_year_end_month": "int", "payroll.pay_day": "int", "company.start_month": "month",
           "opening.as_of": "date"}


def _check_kv(key, v, lang="zh"):
    """「公司」の表の 1 項目：(直した値, 問題の文 or None)。"""
    if v is None:
        return v, None
    try:
        kind = KV_KIND.get(key)
        if kind == "int":
            return _to_int(v), None
        if kind == "month":
            return _to_month(v), None
        if kind == "date":
            return _to_date(v), None
        if key == "payroll.closing_day" and v != "end":
            return _to_int(v), None
    except _Bad as e:
        m = LANGS[lang]
        return None, m.PH["kv"].format(label=m.KV_LABEL.get(key, key), v=v, why=e.text(lang))
    return v, None


# --------------------------------------------------------------------------- ブック → YAML
def to_folder(xlsx, out_dir) -> list:
    """ブックを YAML 群に変換して out_dir に書く。返り値は問題 [(シート, 行, 内容)]（空なら正常）。"""
    from openpyxl import load_workbook
    out, problems = pathlib.Path(out_dir), []
    wb = load_workbook(xlsx, data_only=True)
    sheets = {CANON.get(ws.title, ws.title): ws for ws in wb.worksheets}      # どの言語のブックでも、正規の名前で引く
    lang = BOOK["lang"] = book_lang([ws.title for ws in wb.worksheets])
    for name in ("公司", "方针"):
        if name not in sheets:
            problems.append((name, 0, f"表「{name}」がありません。テンプレートの表は消さないでください"))
    if problems:
        return problems
    rows = {n: _rows(sheets[n], n) if n in sheets else [] for n in ORDER}
    problems += _check_rows(rows, lang)

    # 公司（項目と値）
    kv = {}
    for n, r in enumerate(sheets["公司"].iter_rows(min_row=1, values_only=True), start=1):
        if r and r[-1] and str(r[-1]).startswith(("company.", "payroll.", "opening.", "bank_keywords.")):
            kv[str(r[-1])], why = _check_kv(str(r[-1]), _pick(KV_W2C.get(str(r[-1]), {}), _v(r[1])), lang)
            if why:
                problems.append(("公司", n, why))
    co = _clean({k.split(".", 1)[1]: kv.get(k) for k in kv if k.startswith("company.")})
    for k in ("start_month",):
        if co.get(k) is not None:
            co[k] = _month(co[k])
    if co.get("rousai_code") is not None:
        co["rousai_code"] = str(co["rousai_code"])
    pr = _clean({k.split(".", 1)[1]: kv.get(k) for k in kv if k.startswith("payroll.")})
    pr["items"] = {}
    for i, d in rows["支给项目"]:
        pr["items"][d["name"]] = _clean({"account": d.get("account"), "taxable": _bool(d.get("taxable")),
                                         "koyou_wage": _bool(d.get("koyou_wage")),
                                         "nontaxable_check": d.get("nontaxable_check")})
    pol, ct = {}, {}
    for i, d in rows["方针"]:
        key = str(d.get("key") or "")
        val = _bool(_pick(P_W2C.get(key, {}), d.get("value")))
        if val is not None and key in X.POLICY and not any(type(c) is type(val) and c == val for _, c in X.POLICY[key][2]):
            m = LANGS[lang]
            problems.append(("方针", i, m.PH["policy"].format(label=m.POLICY[key][0], col=m.UI["policy_cols"][2],
                                                             v=d.get("value"))))
            val = None
        ent = _clean({"value": val, "by": d.get("by"), "at": _date(d.get("at")), "reason": d.get("reason")})
        if key.startswith("policies."):
            if val is not None or len(ent) > 0:
                pol[key.split(".", 1)[1]] = ent
        elif key.startswith("consumption_tax."):
            if ent:
                ct[key.split(".", 1)[1]] = ent
    banks = []
    for i, d in rows["银行账户"]:
        banks.append(_clean({"id": d.get("id"), "account": d.get("account"), "sub": d.get("sub"),
                             "csv": _clean({k: d.get(k) for k in ("date", "desc", "out", "in", "balance", "date_format")})}))
    kw = {k.split(".", 1)[1]: [w.strip() for w in str(v).split(",") if w.strip()]
          for k, v in kv.items() if k.startswith("bank_keywords.") and v}
    company_doc = OrderedDict(company=co)
    add = [_clean({k: d.get(k) for k, _, _ in T["追加科目"]}) for i, d in rows["追加科目"]]
    if add:
        company_doc["accounts"] = {"add": add}
    company_doc.update(payroll=pr, policies=pol, consumption_tax=ct, bank_accounts=banks)
    if kw:
        company_doc["bank_keywords"] = kw
    _dump(out / "company.yaml", dict(company_doc))

    # 员工・标准报酬・住民税・固定工资
    emps = OrderedDict()
    for i, d in rows["员工"]:
        e = _clean({"id": d.get("id"), "display": d.get("display"), "role": d.get("role"),
                    "birth": _date(d.get("birth")), "hired": _date(d.get("hired")), "left": _date(d.get("left")),
                    "shaho": _bool(d.get("shaho")), "koyou": _bool(d.get("koyou"))})
        e["withholding"] = _clean({"column": d.get("wh_column"), "dependents": d.get("dependents")})
        cm = _clean({"mode": d.get("commute_mode"), "one_way_km": d.get("commute_one_way_km"),
                     "pass_monthly": d.get("commute_pass_monthly"), "parking": d.get("commute_parking")})
        if cm:
            e["commute"] = cm
        if str(d.get("juminzei_method") or "").strip().lower() in ("none", "なし", "无", "普通徴収", "普通征收"):
            e["juminzei"] = "none"
        emps[e.get("id")] = e
    for sheet, field, mk in (("标准报酬", "smr", lambda d: _clean({"from": _month(d.get("from")), "amount": d.get("amount"),
                                                               "evidence": d.get("evidence")})),):
        for i, d in rows[sheet]:
            if d.get("employee") not in emps:
                continue
            emps[d["employee"]].setdefault(field, []).append(mk(d))
    for i, d in rows["住民税"]:
        if d.get("employee") not in emps:
            continue
        if emps[d["employee"]].get("juminzei") == "none":
            problems.append(("住民税", i, LANGS[lang].PH["jumin_none"].format(emp=title("员工", lang))))
            continue
        emps[d["employee"]].setdefault("juminzei", {})[_month(d.get("month"))] = d.get("amount") or 0
    for i, d in rows["固定工资"]:
        if d.get("employee") not in emps:
            continue
        emps[d["employee"]].setdefault("pay", {})[d.get("item")] = d.get("amount")
    _dump(out / "employees.yaml", {"employees": list(emps.values())})

    # 期初余额
    bal = [_clean({"account": d.get("account"), "sub": d.get("sub"), "debit": d.get("debit"), "credit": d.get("credit")})
           for i, d in rows["期初余额"]]
    _dump(out / "opening_balances.yaml", _clean({"as_of": _date(kv.get("opening.as_of")), "balances": bal}))

    # 每月工资・奖金・开票 → monthly/YYYY-MM/
    monthly = {}
    for i, d in rows["每月工资"]:
        m = _month(d.get("month"))
        if m is None or d.get("employee") is None or d.get("item") is None:
            continue                             # 読めなかった行（問題は上で報告済み）
        e = monthly.setdefault(m, {}).setdefault("payroll", {"employees": {}})["employees"].setdefault(d.get("employee"), {})
        if _bool(d.get("remove")) is True:
            e.setdefault("remove", []).append(d.get("item"))
        else:
            e.setdefault("items", {})[d.get("item")] = d.get("amount")
    for i, d in rows["奖金"]:
        m = _month(d.get("month"))
        if m is None or d.get("employee") is None:
            continue
        b = monthly.setdefault(m, {}).setdefault("payroll", {"employees": {}}).setdefault(
            "bonus", {"date": _date(d.get("date")), "employees": {}})
        b["employees"][d.get("employee")] = d.get("amount")
    for i, d in rows["开票"]:
        dt = _date(d.get("date"))
        if dt is None:
            continue
        monthly.setdefault(dt[:7], {}).setdefault("sales", {"invoices": []})["invoices"].append(
            _clean({"date": dt, "customer": d.get("customer"), "amount": d.get("amount"), "tax": d.get("tax"),
                    "evidence": d.get("evidence")}))
    for m, docs in monthly.items():
        for kind, doc in docs.items():
            _dump(out / "monthly" / m / f"{kind}.yaml", doc)

    # 银行规则
    rules = []
    for i, d in rows["银行规则"]:
        side = "credit" if d.get("direction") == "in" else "debit"
        rules.append(_clean({"id": d.get("id"), "note": d.get("note"),
                             "when": _clean({"desc_contains": d.get("desc_contains"), "direction": d.get("direction"),
                                             "amount": d.get("amount")}),
                             "then": _clean({side: d.get("account"), "sub": d.get("sub"), "tax": d.get("tax"),
                                             "evidence": d.get("evidence")}),
                             "by": d.get("by"), "at": _date(d.get("at")), "reason": d.get("reason")}))
    if rules:
        _dump(out / "bank_rules.yaml", {"rules": rules})

    # 固定资产・折旧分摊
    assets = OrderedDict()
    for i, d in rows["固定资产"]:
        assets[d.get("id")] = _clean({k: (_date(d.get(k)) if k in ("acquired", "in_service", "at") else d.get(k))
                                      for k, _, _ in T["固定资产"]})
    for i, d in rows["折旧分摊"]:
        a = assets.get(d.get("asset"))
        if a is None:
            continue
        per_key = (_month(d.get("from")), _month(d.get("to")))
        al = a.setdefault("allocation", [])
        per = next((p for p in al if (p["from"], p.get("to")) == per_key), None)
        if per is None:
            per = _clean({"from": per_key[0], "to": per_key[1]})
            per["accounts"] = {}
            al.append(per)
        per["accounts"][d.get("account")] = str(d.get("ratio"))
    if assets:
        _dump(out / "fixed_assets.yaml", {"assets": list(assets.values())})

    # 回答（同じ key の行が複数 → 内訳 lines）
    dec = OrderedDict()
    for i, d in rows["回答"]:
        dec.setdefault(str(d.get("key")), []).append((i, d))
    decisions = {}
    for k, rs in dec.items():
        first = rs[0][1]
        ent = _clean({"action": first.get("action"), "evidence": first.get("evidence"), "memo": first.get("memo"),
                      "by": first.get("by"), "at": _date(first.get("at")), "reason": first.get("reason")})
        if len(rs) > 1 or first.get("amount") is not None:
            ent["lines"] = [_clean({"account": d.get("account"), "sub": d.get("sub"), "tax": d.get("tax"),
                                    "amount": d.get("amount")}) for _, d in rs]
        else:
            ent.update(_clean({"account": first.get("account"), "sub": first.get("sub"), "tax": first.get("tax")}))
        decisions[k] = ent
    if decisions:
        _dump(out / "decisions.yaml", {"decisions": decisions})

    # 调整分录（同じ ID の行が一つの仕訳）
    entries = OrderedDict()
    for i, d in rows["调整分录"]:
        e = entries.get(d.get("id"))
        if e is None:
            e = _clean({"id": d.get("id"), "date": _date(d.get("date")), "narration": d.get("narration"),
                        "evidence": d.get("evidence"), "settlement": True if _bool(d.get("settlement")) else None,
                        "by": d.get("by"), "at": _date(d.get("at")), "reason": d.get("reason")})
            if d.get("recurring_from"):
                e["recurring"] = _clean({"from": _month(d.get("recurring_from")), "to": _month(d.get("recurring_to")),
                                         "day": d.get("recurring_day")})
            e["lines"] = []
            entries[d.get("id")] = e
        e["lines"].append(_clean({"account": d.get("account"), "sub": d.get("sub"), "debit": d.get("debit"),
                                  "credit": d.get("credit"), "tax": d.get("tax")}))
    if entries:
        _dump(out / "adjustments.yaml", {"entries": list(entries.values())})

    # 劳动保险
    annual = []
    for i, d in rows["劳动保险"]:
        annual.append(_clean({"fiscal_year": d.get("fiscal_year"),
                              "wages_before_start": _clean({"koyou": d.get("wages_koyou"), "rousai": d.get("wages_rousai")}),
                              "estimate_paid": d.get("estimate_paid"), "withheld_employee": d.get("withheld_employee"),
                              "installment": _bool(d.get("installment")), "estimate_base": d.get("estimate_base"),
                              "accrued_employer": d.get("accrued_employer"),
                              "by": d.get("by"), "at": _date(d.get("at")), "reason": d.get("reason")}))
    if annual:
        _dump(out / "labor_insurance.yaml", {"annual": annual})

    # 法人税（・调整・中间纳付）
    years = OrderedDict()
    for i, d in rows["法人税"]:
        fy = _month(d.get("fiscal_year_end"))
        years[fy] = _clean({**{k: d.get(k) for k, _, _ in T["法人税"] if k not in ("fiscal_year_end", "at")},
                            "fiscal_year_end": fy, "at": _date(d.get("at")),
                            "jigyouzei_excess": _bool(d.get("jigyouzei_excess"))})
        if years[fy].get("pref_houjinzeiwari_rate") is not None:
            years[fy]["pref_houjinzeiwari_rate"] = str(years[fy]["pref_houjinzeiwari_rate"])
    for i, d in rows["法人税调整"]:
        y = years.get(_month(d.get("fiscal_year_end")))
        if y is None:
            problems.append(("法人税调整", i, LANGS[lang].PH["fy"].format(
                label=label("法人税调整", "fiscal_year_end", lang), v=d.get("fiscal_year_end"), sheet=title("法人税", lang))))
            continue
        if d.get("kind") not in ("add", "deduct"):
            continue
        y.setdefault("adjustments", {"add": [], "deduct": []})[d.get("kind")].append(
            {"item": d.get("item"), "amount": d.get("amount")})
    for i, d in rows["中间纳付"]:
        y = years.get(_month(d.get("fiscal_year_end")))
        if y is None:
            problems.append(("中间纳付", i, LANGS[lang].PH["fy"].format(
                label=label("中间纳付", "fiscal_year_end", lang), v=d.get("fiscal_year_end"), sheet=title("法人税", lang))))
            continue
        y.setdefault("interim_paid", {})[d.get("item")] = d.get("amount")
    if years:
        _dump(out / "corporate_tax.yaml", {"years": list(years.values())})
    return problems


def _dump(path, data):
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_text("# 公司资料.xlsx から自動生成（手で直すならブックの方を直す）\n"
                    + yaml.safe_dump(data, allow_unicode=True, sort_keys=False, width=200), encoding="utf-8")


# --------------------------------------------------------------------------- YAML → ブック
def _load(root, name):
    p = pathlib.Path(root) / name
    return (yaml.safe_load(p.read_text(encoding="utf-8")) or {}) if p.exists() else {}


def _s(x):
    """書き出し用：日付はそのまま文字列にする（Excel の日付型にすると月の欄が 1 日付きになる）。"""
    if isinstance(x, datetime.date):
        return x.isoformat()
    return x


def from_folder(root, xlsx, lang="zh"):
    root = pathlib.Path(root)
    c = _load(root, "company.yaml")
    office = {}
    if c.get("office"):
        office = (_load(root, c["office"]).get("policies") or {})
    data = {n: [] for n in ORDER}
    co, pr = c.get("company") or {}, c.get("payroll") or {}
    kv = {f"company.{k}": v for k, v in co.items()}
    kv.update({f"payroll.{k}": v for k, v in pr.items() if k != "items"})
    op = _load(root, "opening_balances.yaml")
    kv["opening.as_of"] = op.get("as_of")
    for k, v in (c.get("bank_keywords") or {}).items():
        kv[f"bank_keywords.{k}"] = ",".join(v)
    pol = dict(office, **(c.get("policies") or {}))
    pol_rows = {f"policies.{k}": v for k, v in pol.items()}
    pol_rows.update({f"consumption_tax.{k}": v for k, v in (c.get("consumption_tax") or {}).items()})
    data["追加科目"] = list((c.get("accounts") or {}).get("add") or [])
    for name, it in (pr.get("items") or {}).items():
        data["支给项目"].append(dict(it, name=name))
    for b in c.get("bank_accounts") or []:
        data["银行账户"].append(dict({k: v for k, v in b.items() if k != "csv"}, **(b.get("csv") or {})))
    for e in _load(root, "employees.yaml").get("employees") or []:
        wh, cm = e.get("withholding") or {}, e.get("commute") or {}
        data["员工"].append(dict(e, wh_column=wh.get("column"), dependents=wh.get("dependents"),
                                 commute_mode=cm.get("mode"), commute_one_way_km=cm.get("one_way_km"),
                                 commute_pass_monthly=cm.get("pass_monthly"), commute_parking=cm.get("parking"),
                                 juminzei_method="none" if e.get("juminzei") == "none" else (
                                     "special" if isinstance(e.get("juminzei"), dict) else None)))
        for s in e.get("smr") or []:
            data["标准报酬"].append(dict(s, employee=e["id"]))
        for m, a in (e.get("juminzei") if isinstance(e.get("juminzei"), dict) else {}).items():
            data["住民税"].append({"employee": e["id"], "month": _s(m) if not isinstance(m, str) else m, "amount": a})
        for it, a in (e.get("pay") or {}).items():
            data["固定工资"].append({"employee": e["id"], "item": it, "amount": a})
    data["期初余额"] = list(op.get("balances") or [])
    md = root / "monthly"
    for d in sorted(p for p in md.glob("*") if p.is_dir()) if md.exists() else []:
        pay = _load(d, "payroll.yaml")
        for eid, x in (pay.get("employees") or {}).items():
            for it, a in (x.get("items") or {}).items():
                data["每月工资"].append({"month": d.name, "employee": eid, "item": it, "amount": a})
            for it in x.get("remove") or []:
                data["每月工资"].append({"month": d.name, "employee": eid, "item": it, "remove": True})
        b = pay.get("bonus")
        if b:
            for eid, a in (b.get("employees") or {}).items():
                data["奖金"].append({"month": d.name, "date": b.get("date"), "employee": eid, "amount": a})
        for inv in _load(d, "sales.yaml").get("invoices") or []:
            data["开票"].append(inv)
    for r in _load(root, "bank_rules.yaml").get("rules") or []:
        w, t = r.get("when") or {}, r.get("then") or {}
        data["银行规则"].append(dict({k: v for k, v in r.items() if k not in ("when", "then")}, **w, **t,
                                     account=t.get("debit") or t.get("credit")))
    for a in _load(root, "fixed_assets.yaml").get("assets") or []:
        data["固定资产"].append(a)
        for per in a.get("allocation") or []:
            for acc, ratio in per["accounts"].items():
                data["折旧分摊"].append({"asset": a["id"], "from": per["from"], "to": per.get("to"),
                                     "account": acc, "ratio": str(ratio)})
    for k, d in (_load(root, "decisions.yaml").get("decisions") or {}).items():
        head = {x: d.get(x) for x in ("action", "evidence", "memo", "by", "at", "reason")}
        if d.get("lines"):
            for l in d["lines"]:
                data["回答"].append(dict(head, key=k, **l))
        else:
            data["回答"].append(dict(head, key=k, account=d.get("account"), sub=d.get("sub"), tax=d.get("tax")))
    for e in _load(root, "adjustments.yaml").get("entries") or []:
        rc = e.get("recurring") or {}
        head = dict({x: e.get(x) for x in ("id", "date", "narration", "evidence", "settlement", "by", "at", "reason")},
                    recurring_from=rc.get("from"), recurring_to=rc.get("to"), recurring_day=rc.get("day"))
        for l in e.get("lines") or []:
            data["调整分录"].append(dict(head, **l))
    for a in _load(root, "labor_insurance.yaml").get("annual") or []:
        w = a.get("wages_before_start") or {}
        data["劳动保险"].append(dict(a, wages_koyou=w.get("koyou"), wages_rousai=w.get("rousai")))
    for y in _load(root, "corporate_tax.yaml").get("years") or []:
        data["法人税"].append(y)
        for kind in ("add", "deduct"):
            for x in ((y.get("adjustments") or {}).get(kind) or []):
                data["法人税调整"].append({"fiscal_year_end": y["fiscal_year_end"], "kind": kind, **x})
        for it, amt in (y.get("interim_paid") or {}).items():
            data["中间纳付"].append({"fiscal_year_end": y["fiscal_year_end"], "item": it, "amount": amt})
    _write(xlsx, kv, pol_rows, data, lang)


def blank(xlsx, lang="zh"):
    _write(xlsx, {}, {}, {n: [] for n in ORDER}, lang)


# --------------------------------------------------------------------------- 書き出し（体裁）
HEAD_FILL, NOTE_FILL, HINT_COLOR = "E0E7FF", "FEF9C3", "6B7280"
TAB_REQUIRED, TAB_OPTIONAL, TAB_REF = "2563EB", "9CA3AF", "16A34A"
# 员工の欄のうち、空けておいてよく、画面の問答で聞くもの（作者 2026-10-17：底稿から入れた従業員は生年月日などが
# 分からない）。読み込みでは「必須」の書式エラーにせず、web.setup_gaps が一覧に出す。締める前の company.load は
# 従来どおり全部を要求する（既定値は置かない）
EMP_ASK = ("role", "birth", "hired", "shaho", "koyou", "wh_column")
EMP_ASK_DEPENDENTS = "dependents"     # 甲欄（または未定）で空のとき聞く。0 も答え（「0」と書く）
# 固定資産の欄のうち、空けておいてよく、問答で聞くもの（判断：開始日・耐用年数・方法）。締める前に全部要る
FA_ASK = ("in_service", "life", "method")
FREE_KV = {"payroll.closing_day"}   # 一覧の外も書ける欄（「月末」か日の数字）。ブックのドロップダウンと画面の問答で共通
LAST_ROW = 2000                 # 一覧（ドロップダウン）を付ける範囲の終わり


def _chart_rows():
    """内蔵の科目表：[(code, 科目名, 中文, 区分, debit／credit, 税区分)]。"""
    from .company import CHART
    doc = yaml.safe_load(CHART.read_text(encoding="utf-8")) or {}
    return [(a.get("code"), a.get("name"), a.get("cn"), a.get("section"), a.get("normal"), a.get("tax"))
            for a in doc.get("accounts") or []]


def _lines(text, width) -> int:
    """折り返したときの行数の見積り（全角は 2、半角は 1 と数える）。"""
    n = 0
    for part in str(text).split("\n"):
        w = sum(1 if ord(c) < 256 else 2 for c in part)
        n += max(1, -(-w // max(1, int(width))))
    return n


def _list(words) -> str:
    return '"' + ",".join(str(w) for w in words) + '"'


def _table_sheet(wb, name, cols, note, hints, rows, lists, lang="zh"):
    """表のシート：1 説明・2 見出し・3 欄の説明・4 欄名（隠す）・5〜 データ。lists は {欄名: (式, 厳密か)}。
    cols は (欄名, その言語の見出し, 幅)。name は正規の名前（シートの名前はその言語のもの）。"""
    ui = LANGS[lang].UI
    from openpyxl.styles import Alignment, Font, PatternFill
    from openpyxl.utils import get_column_letter
    from openpyxl.worksheet.datavalidation import DataValidation
    ws = wb.create_sheet(title(name, lang))
    n = len(cols)
    text = ui["note"].format(*note)
    ws.append([text])
    ws.merge_cells(start_row=1, start_column=1, end_row=1, end_column=n)
    ws["A1"].alignment = Alignment(wrap_text=True, vertical="top")
    ws["A1"].fill = PatternFill("solid", fgColor=NOTE_FILL)
    total = sum(w for _, _, w in cols)
    ws.row_dimensions[1].height = 15 * _lines(text, total) + 6
    ws.append([lab for _, lab, _ in cols])
    ws.append([hints.get(k, "") for k, _, _ in cols])
    ws.append([k for k, _, _ in cols])
    for i, (k, _, w) in enumerate(cols, start=1):
        ws.column_dimensions[get_column_letter(i)].width = w
        c = ws.cell(2, i)
        c.font, c.fill = Font(bold=True), PatternFill("solid", fgColor=HEAD_FILL)
        c.alignment = Alignment(vertical="center", wrap_text=True)
        h = ws.cell(3, i)
        h.font = Font(size=9, color=HINT_COLOR)
        h.alignment = Alignment(wrap_text=True, vertical="top")
    ws.row_dimensions[3].height = min(300, 12 * max([_lines(hints.get(k, ""), w) for k, _, w in cols] or [1]) + 6)
    ws.row_dimensions[4].hidden = True
    ws.freeze_panes = f"A{FIRST_ROW}"
    for d in rows:
        ws.append(d)
    for i, (k, _, _) in enumerate(cols, start=1):
        if k not in lists:
            continue
        formula, strict = lists[k]
        dv = DataValidation(type="list", formula1=formula, allow_blank=True, showErrorMessage=strict)
        if strict:
            dv.errorTitle, dv.error = ui["dv_title"], ui["dv_error"]
        ws.add_data_validation(dv)
        col = get_column_letter(i)
        dv.add(f"{col}{FIRST_ROW}:{col}{LAST_ROW}")
    ws.sheet_properties.tabColor = TAB_REQUIRED if name in X.REQUIRED else TAB_OPTIONAL
    return ws


def _lists_for(name, cols, sections, lang="zh"):
    """この表の、一覧を付ける欄：{欄名: (式, 厳密か)}。"""
    t = lambda n: title(n, lang)
    src = {"accounts": f"='{t(CHART_SHEET)}'!$B$2:$B$400", "taxes": _list(X.TAXES), "sections": _list(sections),
           "employees": f"='{t('员工')}'!$A${FIRST_ROW}:$A$400", "pay_items": f"='{t('支给项目')}'!$A${FIRST_ROW}:$A$200",
           "assets": f"='{t('固定资产')}'!$A${FIRST_ROW}:$A$400"}
    out = {}
    for k, _, _ in cols:
        if (name, k) in X.CHOICES:
            # 「月末か数字」のように、一覧の外の値も書ける欄は厳密にしない
            out[k] = (_list(w for w, _ in LANGS[lang].CHOICES[(name, k)]), (name, k) != ("调整分录", "recurring_day"))
        elif k in X.LISTS and (name, k) not in X.LIST_OFF:
            out[k] = (src[X.LISTS[k]], False)       # 科目・员工ID など：一覧は手がかり。追加科目などほかの値も書ける
    return out


def _write(xlsx, kv, pol_rows, data, lang="zh"):
    M = LANGS[lang]
    ui = M.UI
    from openpyxl import Workbook
    from openpyxl.styles import Alignment, Font, PatternFill
    from openpyxl.worksheet.datavalidation import DataValidation
    head_fill = PatternFill("solid", fgColor=HEAD_FILL)
    bold = Font(bold=True)
    chart = _chart_rows()
    sections = list(dict.fromkeys(r[3] for r in chart if r[3]))
    wb = Workbook()
    g = wb.active
    g.title = title("说明", lang)
    g.column_dimensions["A"].width = 120
    for kind, line in M.GUIDE:
        g.append([line])
        c = g.cell(g.max_row, 1)
        c.alignment = Alignment(wrap_text=True, vertical="top")
        if kind == "t":
            c.font = Font(bold=True, size=14)
        elif kind == "h":
            c.font, c.fill = Font(bold=True, size=11), head_fill
        g.row_dimensions[g.max_row].height = 16 * _lines(line, 118) + (8 if kind != "p" else 2)
    g.sheet_properties.tabColor = TAB_REF

    # ---- 公司（項目と値）
    ws = wb.create_sheet(title("公司", lang))
    ws.append(ui["kv_head"] + ["key"])
    for c in ws[1]:
        c.font, c.fill = bold, head_fill
    try:
        from .jp.rates import JpRates
        rates = JpRates()
        kv_lists = {"company.prefecture": list(rates.prefectures()), "company.koyou_kind": list(rates._koyou["kinds"])}
    except Exception:                                   # 料率表が読めなくてもブックは作る（一覧が付かないだけ）
        kv_lists = {}
    for key in KV:
        ws.append([M.KV_LABEL.get(key, key), _s(_pick(KV_C2W[lang].get(key, {}), kv.get(key))), M.KV_HINT.get(key, ""), key])
        r = ws.max_row
        ws.cell(r, 3).alignment = Alignment(wrap_text=True, vertical="top")
        ws.cell(r, 1).alignment = ws.cell(r, 2).alignment = Alignment(vertical="top")
        ws.cell(r, 3).font = Font(size=9, color=HINT_COLOR)
        ws.row_dimensions[r].height = max(18, 12 * _lines(M.KV_HINT.get(key, ""), 96) + 6)
        words = [w for w, _ in M.KV_CHOICES.get(key, [])] or kv_lists.get(key)
        if words:
            # 「月末か数字」は一覧の外も書ける。一覧だけの欄は厳密にする
            dv = DataValidation(type="list", formula1=_list(words), allow_blank=True,
                                showErrorMessage=key not in FREE_KV)
            ws.add_data_validation(dv)
            dv.add(f"B{r}")
    ws.column_dimensions["A"].width, ws.column_dimensions["B"].width, ws.column_dimensions["C"].width = 30, 26, 98
    ws.column_dimensions["D"].hidden = True
    ws.freeze_panes = "A2"
    ws.sheet_properties.tabColor = TAB_REQUIRED

    # ---- 方针（一行に一つの方針。選択は言葉で）
    keys = [f"policies.{k}" for k in POLICY_CHOICES] + [f"consumption_tax.{k}" for k in CT_CHOICES]
    rows = []
    for key in keys:
        plabel, help_, _ = M.POLICY[key]
        ent = pol_rows.get(key) or {}
        rows.append([plabel, help_, _s(_pick(P_C2W[lang][key], ent.get("value"))), ent.get("by"), _s(ent.get("at")),
                     ent.get("reason"), key])
    pcols = [(k, lab, w) for (k, _, w), lab in zip(POLICY_COLS, ui["policy_cols"] + ["key"])]
    ws = _table_sheet(wb, "方针", pcols, M.POLICY_NOTE,
                      {"value": ui["policy_value"], "by": M.BY, "at": M.AT, "reason": M.WHY}, rows, {}, lang)
    for i, key in enumerate(keys, start=FIRST_ROW):
        dv = DataValidation(type="list", allow_blank=True, formula1=_list(w for w, _ in M.POLICY[key][2]))
        ws.add_data_validation(dv)
        dv.add(f"C{i}")
        for col in range(1, 7):                  # 値も上にそろえる（説明が複数行のとき、値だけ下に離れない）
            ws.cell(i, col).alignment = Alignment(wrap_text=col != 3, vertical="top")
        ws.row_dimensions[i].height = 14 * max(_lines(M.POLICY[key][1], 68), _lines(M.POLICY[key][0], 32)) + 6
    ws.column_dimensions["G"].hidden = True

    for name in ORDER[2:]:
        wide = 1.3 if lang == "en" else 1                # 英語の見出し・選択肢は長い
        cols = [(k, label(name, k, lang), int(w * wide)) for k, _, w in T[name]]
        body = [[_s(_pick(C2W[lang].get((name, k), {}), d.get(k))) for k, _, _ in cols] for d in data.get(name) or []]
        _table_sheet(wb, name, cols, M.NOTE[name], M.HINT.get(name, {}), body, _lists_for(name, cols, sections, lang), lang)

    # ---- 科目表（参照用）
    ws = wb.create_sheet(title(CHART_SHEET, lang))
    ws.append(ui["chart_head"] + [ui["chart_note"]])
    for c in ws[1]:
        c.font, c.fill = bold, head_fill
    for r in chart:
        ws.append([r[0], r[1], r[2], r[3], ui["side"].get(r[4], r[4]), r[5]])
    for col, w in zip("ABCDEFG", (10, 22, 16, 24, 10, 16, 80)):
        ws.column_dimensions[col].width = w
    ws.freeze_panes = "A2"
    ws.sheet_properties.tabColor = TAB_REF
    wb.save(xlsx)


def find_workbook(root):
    """会社フォルダ直下の入力ブック（公司资料.xlsx。名前が違っても「公司」「方针」の表があれば使う）。"""
    root = pathlib.Path(root)
    p = root / WORKBOOK_NAME
    if p.exists():
        return p
    from openpyxl import load_workbook
    for q in sorted(root.glob("*.xlsx")):
        try:
            wb = load_workbook(q, read_only=True)
        except Exception:                       # 壊れた・暗号化された xlsx は入力ブックではない
            continue
        try:
            names = wb.sheetnames
        finally:
            wb.close()                          # 閉じないと Windows でファイルが掴まれたままになる
        if is_input_book(names):
            return q
    return None
