# -*- coding: utf-8 -*-
"""証憑の保存と索引簿（作者 2026-10-10：最初から電子帳簿保存法の検索要件で設計する）。

## 一次資料（data/jp/sources/nta_denchou_r08/ に原本、sha256 は README）

国税庁「電子帳簿保存法一問一答【電子取引関係】」「同【スキャナ保存関係】」いずれも令和 8 年 7 月。

  · 検索の項目は **取引年月日その他の日付・取引金額・取引先** の 3 つ。日付と金額は範囲指定、任意の 2 項目以上の
    組合せ（スキャナ 問41・電子取引 問18 の表）。画像を文字にできなくても、手入力して検索できればよい（問41）。
  · ファイル名の規則の代わりに「索引簿」を作り、連番で保存ファイルと対応させる方法でよい（電子取引 問19、
    スキャナ 問46：両方で同じ索引簿を使ってよい）。
  · 電子取引（メール・ダウンロードで受け取った請求書・領収書、ネットバンキングの振込 問10・11）は**データのまま
    保存する義務**がある。改ざん防止は 4 つのうち一つ——「訂正削除の防止に関する事務処理規程」を定めて運用する
    （問18 の表 四、規程の例は 問33）なら、自社のフォルダで満たせる。
  · スキャナ保存（紙を撮った・スキャンした）は、タイムスタンプ（または他社が提供する時刻証明つきの
    システム）が要る。**自社システムでは代替要件を満たせない**（問31・32）。満たさない画像は税法上の保存書類に
    ならない（問59）→ このツールで撮った紙の写しは**作業用の写し**で、紙の原本は捨てない。

## 置き方（会社フォルダの中）

    evidence/索引簿.csv            連番・日付・金額・取引先・… 1 行 1 取引（1 枚の写真に 3 枚のレシートなら 3 行）
    evidence/訂正削除記録.csv      確認済の行を直した・取り消した記録（追記だけ。消さない）
    evidence/<取込年月>/<sha256 の先頭 8 桁>_<元のファイル名>   原本。**名前も中身も変えない、動かさない**

ファイルの置き場所は取込んだ月で決まり、あとから日付や取引先が分かっても動かさない（動かすと索引簿の対応が
切れる。検索は索引簿でする）。同じ中身（sha256 が同じ）を 2 回取り込んでも 1 つにする。

エンジン（Pyodide）が読むのは索引簿だけ。原本の画像・PDF は Python に渡さない（量が多い）。
"""
from __future__ import annotations

import csv
import datetime
import hashlib
import io
import pathlib
import re
from dataclasses import dataclass, field

DIR = "evidence"
INDEX = f"{DIR}/索引簿.csv"
LOG = f"{DIR}/訂正削除記録.csv"

KIND_PAPER = "紙の写し"          # 紙を撮った・スキャンした（スキャナ保存の要件は満たさない → 紙を残す）
KIND_ELEC = "電子取引"           # メール・ダウンロード・ネットバンキングで受け取ったデータ
KINDS = (KIND_PAPER, KIND_ELEC)

DRAFT = "下書き"                 # 読み取った値（未確認）。検索はできるが、仕訳の根拠にはまだしない
CONFIRMED = "確認済"
VOID = "取消"                    # 消さずに取り消す（理由は訂正削除記録）
STATUSES = (DRAFT, CONFIRMED, VOID)

COLUMNS = ["連番", "取引年月日", "取引金額", "取引先", "書類", "区分", "ファイル", "頁", "sha256", "取込日",
           "照合先", "状態", "備考", "読取値"]
LOG_COLUMNS = ["日時", "連番", "項目", "旧", "新", "理由", "担当"]

PAPER_NOTICE = ("紙の写しは作業用。このツールはスキャナ保存の要件（タイムスタンプ）を満たさないので、"
                "紙の原本を 7 年間保存する（国税庁 一問一答【スキャナ保存関係】問31・32・59）")

_BAD = re.compile(r'[\\/:*?"<>|\s]+')


class EvidenceError(ValueError):
    pass


def sha256(data: bytes) -> str:
    return hashlib.sha256(data).hexdigest()


def stored_path(sha: str, original_name: str, received: datetime.date) -> str:
    """原本の置き場所（会社フォルダからの相対パス）。元の名前の使えない文字だけ _ にする。"""
    name = _BAD.sub("_", pathlib.PurePath(original_name).name).strip("_") or "file"
    return f"{DIR}/{received:%Y-%m}/{sha[:8]}_{name}"


def _date(s):
    if s in (None, ""):
        return None
    if isinstance(s, datetime.date):
        return s
    return datetime.date.fromisoformat(str(s).strip().replace("/", "-"))


def _amount(s):
    if s in (None, ""):
        return None
    v = int(str(s).replace(",", "").strip())
    if v < 0:
        raise EvidenceError(f"取引金額は 0 以上（{s}）")
    return v


@dataclass
class Entry:
    no: int
    date: datetime.date | None          # 取引年月日その他の日付
    amount: int | None                  # 取引金額（書類に書かれた額。税込・税抜は書類どおり：問43）
    party: str                          # 取引先
    doc: str                            # 書類の種類（テンプレート名、または 領収書・請求書 等）
    kind: str                           # 区分：紙の写し / 電子取引
    file: str                           # 原本の相対パス
    page: int | None                    # PDF の頁（1 から）。画像・1 頁なら空
    sha: str
    received: datetime.date             # 取込日
    bank: str = ""                      # 照合先：銀行明細の指紋（BankRow.key()）
    status: str = DRAFT
    note: str = ""
    fields: dict = field(default_factory=dict)      # 読取値：テンプレートの項目（対象月・内訳など）。文字列の値

    def row(self) -> list:
        return [self.no, self.date or "", "" if self.amount is None else self.amount, self.party, self.doc,
                self.kind, self.file, self.page or "", self.sha, self.received, self.bank, self.status, self.note,
                dump_fields(self.fields)]

    @property
    def searchable(self) -> bool:
        """検索の 3 項目がそろっている。"""
        return self.date is not None and self.amount is not None and bool(self.party)


@dataclass
class Index:
    entries: list = field(default_factory=list)
    log: list = field(default_factory=list)          # [dict(日時, 連番, 項目, 旧, 新, 理由, 担当)]

    # ---- 読み書き
    @classmethod
    def load(cls, root) -> "Index":
        root = pathlib.Path(root)
        ix = cls()
        p = root / INDEX
        if p.exists():
            rows = list(csv.reader(io.StringIO(p.read_text(encoding="utf-8-sig"))))
            if not rows or rows[0] != COLUMNS:
                raise EvidenceError(f"{INDEX} の見出しが違う（{rows[0] if rows else '空'}）")
            seen = set()
            for i, r in enumerate(rows[1:], start=2):
                if not any(r):
                    continue
                d = dict(zip(COLUMNS, r + [""] * (len(COLUMNS) - len(r))))
                where = f"{INDEX} {i} 行目"
                try:
                    e = Entry(no=int(d["連番"]), date=_date(d["取引年月日"]), amount=_amount(d["取引金額"]),
                              party=d["取引先"].strip(), doc=d["書類"].strip(), kind=d["区分"].strip(),
                              file=d["ファイル"].strip(), page=int(d["頁"]) if d["頁"].strip() else None,
                              sha=d["sha256"].strip().lower(), received=_date(d["取込日"]),
                              bank=d["照合先"].strip(), status=d["状態"].strip() or DRAFT, note=d["備考"].strip(),
                              fields=load_fields(d["読取値"]))
                except (ValueError, TypeError) as ex:
                    raise EvidenceError(f"{where}：{ex}") from None
                if e.no in seen:
                    raise EvidenceError(f"{where}：連番 {e.no} が重複")
                if e.kind not in KINDS:
                    raise EvidenceError(f"{where}：区分は {'／'.join(KINDS)}（{e.kind}）")
                if e.status not in STATUSES:
                    raise EvidenceError(f"{where}：状態は {'／'.join(STATUSES)}（{e.status}）")
                if not re.fullmatch(r"[0-9a-f]{64}", e.sha):
                    raise EvidenceError(f"{where}：sha256 が 64 桁の 16 進でない")
                if e.status == CONFIRMED and not e.searchable:
                    raise EvidenceError(f"{where}：確認済なのに 日付・金額・取引先 のどれかが空")
                seen.add(e.no)
                ix.entries.append(e)
        q = root / LOG
        if q.exists():
            rows = list(csv.reader(io.StringIO(q.read_text(encoding="utf-8-sig"))))
            if rows and rows[0] != LOG_COLUMNS:
                raise EvidenceError(f"{LOG} の見出しが違う")
            ix.log = [dict(zip(LOG_COLUMNS, r)) for r in rows[1:] if any(r)]
        return ix

    def save(self, root) -> None:
        root = pathlib.Path(root)
        (root / DIR).mkdir(parents=True, exist_ok=True)
        for rel, cols, rows in ((INDEX, COLUMNS, [e.row() for e in sorted(self.entries, key=lambda e: e.no)]),
                                (LOG, LOG_COLUMNS, [[d.get(c, "") for c in LOG_COLUMNS] for d in self.log])):
            if rel == LOG and not rows:
                continue
            buf = io.StringIO()
            w = csv.writer(buf, lineterminator="\r\n")
            w.writerow(cols)
            w.writerows(rows)
            (root / rel).write_text(buf.getvalue(), encoding="utf-8-sig")     # Excel で開ける

    # ---- 登録・確認・取消
    def get(self, no: int) -> Entry:
        for e in self.entries:
            if e.no == no:
                return e
        raise EvidenceError(f"索引簿に連番 {no} が無い")

    def by_sha(self, sha: str) -> list:
        return [e for e in self.entries if e.sha == sha]

    def add(self, *, file: str, sha: str, kind: str, received: datetime.date, page: int | None = None,
            date=None, amount=None, party: str = "", doc: str = "", note: str = "", fields=None) -> Entry:
        """下書きの行を足す（読み取った値、または空）。同じ原本・同じ頁・同じ値の行が既にあれば足さない。"""
        if kind not in KINDS:
            raise EvidenceError(f"区分は {'／'.join(KINDS)}（{kind}）")
        date, amount = _date(date), _amount(amount)
        for e in self.by_sha(sha):
            if e.page == page and e.date == date and e.amount == amount and e.party == party and e.status != VOID:
                return e
        e = Entry(no=max((x.no for x in self.entries), default=0) + 1, date=date, amount=amount, party=party,
                  doc=doc, kind=kind, file=file, page=page, sha=sha, received=received, note=note,
                  fields={k: str(v) for k, v in (fields or {}).items() if v not in (None, "")})
        self.entries.append(e)
        return e

    def _record(self, e: Entry, item: str, old, new, reason: str, by: str, at: datetime.datetime):
        self.log.append({"日時": at.isoformat(timespec="seconds"), "連番": e.no, "項目": item,
                         "旧": "" if old is None else old, "新": "" if new is None else new,
                         "理由": reason, "担当": by})

    def confirm(self, no: int, *, by: str, at: datetime.datetime, reason: str = "", **values) -> Entry:
        """値を確かめて確認済にする。下書きの値の書き換えは記録しない（読み取りの訂正）。
        **確認済の行**を直すときは理由と担当が要り、旧・新を訂正削除記録に残す。"""
        e = self.get(no)
        if e.status == VOID:
            raise EvidenceError(f"連番 {no} は取り消し済")
        names = {"date": "取引年月日", "amount": "取引金額", "party": "取引先", "doc": "書類", "bank": "照合先",
                 "note": "備考"}
        unknown = set(values) - set(names)
        if unknown:
            raise EvidenceError(f"直せない項目 {sorted(unknown)}")
        conv = {"date": _date, "amount": _amount}
        was = e.status
        if was == CONFIRMED and any(conv.get(k, str)(v) != getattr(e, k) for k, v in values.items()):
            if not (by and reason):
                raise EvidenceError(f"連番 {no} は確認済——直すには理由と担当が要る（訂正削除記録に残す）")
        for k, v in values.items():
            v = conv.get(k, lambda x: (x or "").strip())(v)
            if v != getattr(e, k):
                if was == CONFIRMED:
                    self._record(e, names[k], getattr(e, k), v, reason, by, at)
                setattr(e, k, v)
        if not e.searchable:
            raise EvidenceError(f"連番 {no}：日付・金額・取引先がそろわないと確認済にできない")
        e.status = CONFIRMED
        return e

    def void(self, no: int, *, by: str, at: datetime.datetime, reason: str) -> Entry:
        """取り消す（行も原本も消さない）。理由と担当は必須。"""
        if not (by and reason):
            raise EvidenceError("取り消しには理由と担当が要る")
        e = self.get(no)
        if e.status != VOID:
            self._record(e, "状態", e.status, VOID, reason, by, at)
            e.status = VOID
        return e

    # ---- 検索（電帳法の検索要件：3 項目、日付・金額の範囲、組合せ）
    def search(self, *, date_from=None, date_to=None, amount_min=None, amount_max=None, party: str = "",
               include_void: bool = False) -> list:
        df, dt = _date(date_from), _date(date_to)
        lo, hi = _amount(amount_min), _amount(amount_max)
        p = _norm_party(party)
        out = []
        for e in self.entries:
            if e.status == VOID and not include_void:
                continue
            if (df or dt) and (e.date is None or (df and e.date < df) or (dt and e.date > dt)):
                continue
            if (lo is not None or hi is not None) and (e.amount is None or (lo is not None and e.amount < lo)
                                                       or (hi is not None and e.amount > hi)):
                continue
            if p and p not in _norm_party(e.party):
                continue
            out.append(e)
        return sorted(out, key=lambda e: (e.date or datetime.date.max, e.no))

    def notices(self) -> list:
        """画面に出す注意（日本語。画面の言語へは messages.translate）。"""
        out = []
        if any(e.kind == KIND_PAPER and e.status != VOID for e in self.entries):
            out.append(PAPER_NOTICE)
        n = sum(1 for e in self.entries if e.status == DRAFT)
        if n:
            out.append(f"索引簿に未確認の行が {n} 件——日付・金額・取引先を確かめて確認済にする")
        return out


def dump_fields(d: dict) -> str:
    """{"month": "2026-03", "total": "1200"} → 「month=2026-03; total=1200」（Excel で読める・順は名前順）。"""
    return "; ".join(f"{k}={str(v).replace(';', ',')}" for k, v in sorted((d or {}).items()))


def load_fields(s: str) -> dict:
    out = {}
    for part in (s or "").split(";"):
        if "=" in part:
            k, v = part.split("=", 1)
            out[k.strip()] = v.strip()
    return out


def _norm_party(s: str) -> str:
    import unicodedata
    s = unicodedata.normalize("NFKC", s or "")
    return re.sub(r"株式会社|有限会社|合同会社|\(株\)|\(有\)|[\s・()]", "", s).lower()


def register(root, data: bytes, original_name: str, kind: str, received: datetime.date) -> tuple:
    """原本を置いて索引簿に下書きを 1 行足す（同じ中身が既にあれば置かず、その行を返す）。

    返り値 (Entry, new: bool)。読み取った値は呼ぶ側が下書きに書く（1 枚に複数の取引があれば add で行を足す）。"""
    root = pathlib.Path(root)
    ix = Index.load(root)
    sha = sha256(data)
    have = [e for e in ix.by_sha(sha) if e.status != VOID]
    if have:
        return have[0], False
    rel = stored_path(sha, original_name, received)
    p = root / rel
    p.parent.mkdir(parents=True, exist_ok=True)
    if p.exists() and sha256(p.read_bytes()) != sha:
        raise EvidenceError(f"{rel} に別の中身のファイルがある")
    p.write_bytes(data)
    e = ix.add(file=rel, sha=sha, kind=kind, received=received)
    ix.save(root)
    return e, True


def verify(root) -> list:
    """原本が索引簿の sha256 のままか。返り値は問題の一覧（日本語）。原本の無い環境（Pyodide）では呼ばない。"""
    root = pathlib.Path(root)
    ix = Index.load(root)
    out, seen = [], {}
    for e in ix.entries:
        if e.file in seen:
            if seen[e.file] != e.sha:
                out.append(f"連番 {e.no}：同じファイル {e.file} に別の sha256")
            continue
        seen[e.file] = e.sha
        p = root / e.file
        if not p.exists():
            out.append(f"連番 {e.no}：原本 {e.file} が無い")
        elif sha256(p.read_bytes()) != e.sha:
            out.append(f"連番 {e.no}：原本 {e.file} の中身が取込時と違う（sha256 不一致）")
    return out
