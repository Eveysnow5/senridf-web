# -*- coding: utf-8 -*-
"""給与計算（月次）。

一人・一回の支給について：
  支給額 → 社会保険料（被保険者負担）→ 雇用保険料 → 源泉所得税 → 住民税 → 差引支給額
を計算し、各数字に**推導チェーン**（どの規則・どの料率表・どの入力行）を付ける。

社会保険料は「月分」で考える。翌月徴収なら 6 月払いの給与で 5 月分を控除する。
「その月分」の保険料は shaho_month() 一箇所で計算し、給与控除・告知額・会社負担の
三者が**同じ関数**を通る（経路が違うと 1 円ずれて鉤稽が永遠に合わない）。
"""
from __future__ import annotations

import datetime
from dataclasses import dataclass, field
from decimal import Decimal as D

from .core.money import ROUNDERS, sum_money, truncate
from .jp.calendar import add_months, is_business_day, is_care_insured, month_end


@dataclass
class ShahoMonth:
    """ある従業員のある月分の社会保険料。full は 0.1 円単位（印字値と同じ精度）。"""
    eid: str
    month: datetime.date
    smr: int
    pension_smr: int
    care: bool
    health_full: D              # 健保（＋介護）
    support_full: D             # 子ども・子育て支援金
    pension_full: D
    contribution_full: D        # 拠出金（事業主のみ）
    emp_health: int             # 被保険者負担（端数処理後）
    emp_support: int
    emp_pension: int
    why: list = field(default_factory=list)

    @property
    def emp_total(self) -> int:
        return self.emp_health + self.emp_support + self.emp_pension


def shaho_month(co, rates, e, month) -> ShahoMonth | None:
    if not e.insured_for(month):
        return None
    s = e.smr_for(month)
    if s is None:
        raise ValueError(f"{e.id}: {month:%Y-%m}分の標準報酬月額が無い")
    smr = s[1]
    r = rates.shaho(co.prefecture, month)
    psmr = rates.pension_smr(co.prefecture, smr)
    care = is_care_insured(e.birth, month)
    m = D(smr)
    h_rate = r.health + (r.care if care else D(0))
    health_full = m * h_rate
    support_full = m * r.child_support
    pension_full = D(psmr) * r.pension
    contrib_full = D(psmr) * r.child_contribution
    rnd = ROUNDERS[co.policy["shaho_rounding"]]
    why = [f"{month:%Y-%m}分 標準報酬月額 {smr:,}（{s[2] or '⚠ 根拠書類未登録'}）",
           f"{r.source}：健保 {r.health}{' ＋介護 ' + str(r.care) if care else ''}"
           f"{' ＋支援金 ' + str(r.child_support) if r.child_support else ''}・厚年 {r.pension}",
           f"介護：{'該当' if care else '非該当'}（生年月日 {e.birth}、rules_r08.care_insurance_age）",
           f"端数：{co.policy['shaho_rounding']}（rules_r08.shaho_employee_rounding）"]
    if co.policy["support_rounding"] == "with_health":
        emp_health = int(rnd((health_full + support_full) / 2))
        emp_support = 0
        why.append("支援金は健保（＋介護）と合算して一つの控除額にした（会社設定 support_rounding: with_health）")
    else:
        emp_health = int(rnd(health_full / 2))
        emp_support = int(rnd(support_full / 2))
        why.append("支援金は健保と別に端数処理（会社設定 support_rounding: separate）")
    emp_pension = int(rnd(pension_full / 2))
    return ShahoMonth(e.id, month, smr, psmr, care, health_full, support_full, pension_full,
                      contrib_full, emp_health, emp_support, emp_pension, why)


@dataclass
class Notice:
    """納入告知書（月分）。告知額は個々の全額の合算を円未満切捨て（rules_r08.notice_total_truncate）。"""
    month: datetime.date
    health: int                 # 健保＋介護＋支援金（告知書の「健康保険料」欄）
    pension: int
    contribution: int
    employee: int               # 被保険者負担の合計（控除額の合計）
    members: list
    bonuses: list = field(default_factory=list)

    @property
    def total(self) -> int:
        return self.health + self.pension + self.contribution

    @property
    def company(self) -> int:
        return self.total - self.employee


def notice(co, rates, month) -> Notice | None:
    """その月分の納入告知書。**その月に支払った賞与の保険料も同じ告知書に入る。**"""
    ms = [x for x in (shaho_month(co, rates, e, month) for e in co.employees) if x]
    bs = [b for b in bonus_slips(co, rates, month) if b.std_health or b.std_pension]
    if not ms and not bs:
        return None
    allx = ms + bs
    return Notice(month=month,
                  health=int(truncate(sum((x.health_full + x.support_full for x in allx), D(0)))),
                  pension=int(truncate(sum((x.pension_full for x in allx), D(0)))),
                  contribution=int(truncate(sum((x.contribution_full for x in allx), D(0)))),
                  employee=sum(x.emp_total for x in allx), members=ms, bonuses=bs)


@dataclass
class PayslipLine:
    name: str
    amount: int
    account: str = ""
    why: str = ""


@dataclass
class Payslip:
    eid: str
    pay_date: datetime.date
    pay_month: datetime.date
    earnings: list                  # PayslipLine
    shaho: list                     # ShahoMonth（翌月徴収の退職時は 2 か月分になりうる）
    koyou: int
    koyou_wage: int
    taxable: int
    income_tax: int
    juminzei: int
    why: list = field(default_factory=list)
    pending: list = field(default_factory=list)      # (key, title, detail)

    @property
    def gross(self) -> int:
        return sum(l.amount for l in self.earnings)

    @property
    def shaho_total(self) -> int:
        return sum(s.emp_total for s in self.shaho)

    @property
    def deductions(self) -> int:
        return self.shaho_total + self.koyou + self.income_tax + self.juminzei

    @property
    def net(self) -> int:
        return self.gross - self.deductions


def pay_date_for(co, month) -> datetime.date:
    d = month.replace(day=min(co.pay_day, month_end(month.year, month.month).day))
    step = -1 if co.pay_day_shift == "before" else 1
    while not is_business_day(d):
        d += datetime.timedelta(days=step)
    return d


def closing_date_for(co, month) -> datetime.date:
    if co.closing_day == "end":
        return month_end(month.year, month.month)
    return month.replace(day=int(co.closing_day))


def payslip(co, rates, e, pay_month) -> Payslip | None:
    """pay_month に支払う給与。在籍していなければ None。"""
    pay_date = pay_date_for(co, pay_month)
    inp = (co.monthly_input(pay_month).get("employees") or {}).get(e.id, {})
    active = (e.hired <= month_end(pay_month.year, pay_month.month)
              and (e.left is None or e.left >= pay_month))
    if not active and not inp:
        return None
    pending = []
    # 入退社月の日割りは製品が推測しない（日割りの方法は就業規則次第）。
    # 月次入力で支給額を明示していなければ要確認。
    joining = e.hired.replace(day=1) == pay_month and e.hired.day != 1
    leaving = (e.left is not None and e.left.replace(day=1) == pay_month
               and e.left != month_end(pay_month.year, pay_month.month))
    if (joining or leaving) and not (inp.get("items") or inp.get("prorated")):
        pending.append((f"proration:{e.id}:{pay_month:%Y-%m}", "入退社月の支給額",
                        f"{e.id} は {pay_month:%Y-%m} に{'入社' if joining else '退社'}"
                        f"（{e.hired if joining else e.left}）。固定給を満額で計算した。"
                        f"日割りするなら月次入力で支給額を明示する"))
    items = dict(e.pay)
    for k, v in (inp.get("items") or {}).items():
        if k not in co.pay_items:
            raise ValueError(f"{pay_month:%Y-%m} 給与入力 {e.id}: 支給項目「{k}」が未定義")
        items[k] = v
    for k in inp.get("remove", []) or []:
        items.pop(k, None)
    earnings = [PayslipLine(k, int(v), co.pay_items[k]["account"], "固定給（名簿）" if k in e.pay and k not in (inp.get("items") or {})
                            else f"{pay_month:%Y-%m} 月次入力")
                for k, v in items.items() if int(v)]
    why = []

    # 社会保険：どの月分を控除するか
    if co.policy["shaho_collection"] == "next_month":
        months = [add_months(pay_month, -1)]
        # 月末退職：退職日が月末（喪失日が翌月1日）**かつ** この支給が退職月の最後の給与
        # → 退職月分も控除できる（年金機構）。
        # ⚠️ 「喪失月 ＝ 支給月の翌月」だけで判定すると、月の途中で退職する人の
        #    **前月の給与**でも条件が成立し、二か月分を控除してしまう（答え合わせ表で発見）。
        if (e.left is not None and e.left == month_end(e.left.year, e.left.month)
                and pay_month == e.left.replace(day=1)):
            months.append(pay_month)
            why.append("月末退職のため前月分と当月分の 2 か月分を控除（年金機構「退職した従業員の保険料の徴収」）")
    else:
        months = [pay_month]
    sh = [x for x in (shaho_month(co, rates, e, m) for m in months) if x]
    if e.shaho and e.hired.replace(day=1) == (e.loss_month() or datetime.date.max):
        pending.append((f"same_month_loss:{e.id}", "同月得喪",
                        f"{e.id} は資格取得月に喪失している。厚生年金は原則徴収、国民年金加入時は還付等——個別判断"))

    # 雇用保険
    koyou_wage = sum(l.amount for l in earnings if co.pay_items[l.name]["koyou_wage"])
    koyou = 0
    if e.koyou and koyou_wage:
        basis = pay_date if co.policy["koyou_rate_basis"] == "pay_date" else closing_date_for(co, pay_month)
        k = rates.koyou(co.koyou_kind, basis)
        koyou = int(ROUNDERS[co.policy["koyou_rounding"]](D(koyou_wage) * k["worker"]))
        why.append(f"雇用保険 {koyou_wage:,}×{k['worker']}＝{koyou:,}（{k['source']}、年度判定 {basis}）")

    # 通勤手当：非課税限度を超える部分は課税（rules：国税庁 No.2582 / No.2585）
    commute_excess = 0
    for l in earnings:
        if co.pay_items[l.name].get("nontaxable_check") != "commute":
            continue
        lim, cwhy = rates.commute_limit(e.commute, pay_date)
        if lim is None:
            pending.append((f"commute_limit:{e.id}", "通勤手当の非課税限度",
                            f"{e.id} の {l.name} {l.amount:,} 円を全額非課税とした。{cwhy}"))
            continue
        ex = max(0, l.amount - lim)
        commute_excess += ex
        why.append(f"{l.name} {l.amount:,}：{cwhy}" + (f"、超過 {ex:,} は課税" if ex else "、全額非課税"))

    # 源泉所得税
    taxable_gross = sum(l.amount for l in earnings if co.pay_items[l.name]["taxable"]) + commute_excess
    taxable = taxable_gross - sum(s.emp_total for s in sh) - koyou
    tax, twhy = rates.withholding_monthly(max(taxable, 0), e.dependents, e.wh_column, pay_date)
    why.append(f"源泉：課税支給 {taxable_gross:,} − 社保 {sum(s.emp_total for s in sh):,} − 雇保 {koyou:,} "
               f"＝ {taxable:,}；{twhy}")
    if rates.withholding_uses_formula(max(taxable, 0), e.wh_column, pay_date):
        pending.append(("assumption:gensen_formula_rounding", "源泉の式区間の端数処理",
                        "月額表の 740,000 円以上（または乙欄 3.063%）は式で計算した。円未満切捨てとしたが、"
                        "表の注記に明記がない（rules_r08.gensen_formula_rounding）"))

    # 住民税（特別徴収）：給与の支払月で引く
    jm = e.juminzei.get(pay_month)
    jumin = jm or 0
    if e.juminzei and e.left is not None and e.left.replace(day=1) == pay_month:
        pending.append((f"juminzei_leaver:{e.id}", "退職者の住民税",
                        f"{e.id} は {e.left} 退職。残りの特別徴収税額を最後の給与で一括徴収するか、"
                        f"普通徴収に切り替えるか（市区町村へ異動届）を決める。初版は当月分だけ控除した"))
    if e.juminzei and jm is None:
        pending.append((f"juminzei_missing:{e.id}:{pay_month:%Y-%m}", "住民税の月額が無い",
                        f"{e.id} は特別徴収の設定があるが {pay_month:%Y-%m} の月額が無い。"
                        f"決定通知書の月額を入れるか、退職時の一括徴収・普通徴収切替を判断する"
                        f"（特別徴収がまだ始まっていない月なら 0 と明示する）"))
    for s in sh:
        if e.smr_for(s.month)[2] is None:
            pending.append((f"smr_evidence:{e.id}", "標準報酬月額の根拠書類が未登録",
                            f"{e.id} の標準報酬月額 {s.smr:,} に根拠（決定通知書等）が登録されていない。"
                            f"ここが違うと社保の全項目が一斉に違い、しかも互いに自洽する"))
            break
    return Payslip(e.id, pay_date, pay_month, earnings, sh, koyou, koyou_wage,
                   taxable, tax, jumin, why, pending)


# ===================================================================== 賞与
BONUS_HEALTH_ANNUAL_CAP = 5730000     # rules_r08.bonus_standard_amount（健保・介護・支援金：年度累計）
BONUS_PENSION_MONTHLY_CAP = 1500000   # 同（厚年・拠出金：月間）


@dataclass
class BonusSlip:
    eid: str
    pay_date: datetime.date
    amount: int
    std_health: int
    std_pension: int
    care: bool
    health_full: D
    support_full: D
    pension_full: D
    contribution_full: D
    emp_health: int
    emp_support: int
    emp_pension: int
    koyou: int
    prev_taxable: int | None
    rate: D | None
    income_tax: int
    why: list = field(default_factory=list)
    pending: list = field(default_factory=list)

    @property
    def emp_total(self) -> int:
        return self.emp_health + self.emp_support + self.emp_pension

    @property
    def net(self) -> int:
        return self.amount - self.emp_total - self.koyou - self.income_tax


def _bonus_input(co, month):
    b = co.monthly_input(month).get("bonus") or {}
    if not b:
        return None, {}
    return datetime.date.fromisoformat(str(b["date"])), {k: int(v) for k, v in (b.get("employees") or {}).items()}


def _fiscal_april(month):
    return datetime.date(month.year if month.month >= 4 else month.year - 1, 4, 1)


def bonus_slips(co, rates, month):
    """その月に支払う賞与。monthly/YYYY-MM/payroll.yaml の bonus: {date, employees: {id: 額}}。"""
    pay_date, amounts = _bonus_input(co, month)
    out = []
    for eid, amount in amounts.items():
        e = co.emp(eid)
        why, pending = [], []
        std = amount // 1000 * 1000
        insured = e.insured_for(month)
        # 健保の年度累計（4/1〜3/31）。開始月より前の賞与は入力が無いので要確認
        fy = _fiscal_april(month)
        prior, m = 0, fy
        while m < month:
            _, a = _bonus_input(co, m)
            prior += min(a.get(eid, 0) // 1000 * 1000, BONUS_HEALTH_ANNUAL_CAP)
            m = add_months(m, 1)
        if fy < co.start_month:
            pending.append((f"bonus_cum:{eid}:{fy:%Y}", "賞与の年度累計（健保上限）",
                            f"{eid}：健保の標準賞与額は年度（{fy:%Y}/4〜）累計 573 万円が上限。開始月より前の賞与は"
                            f"入力が無いので累計に入っていない"))
        std_h = max(0, min(std, BONUS_HEALTH_ANNUAL_CAP - prior)) if insured else 0
        std_p = min(std, BONUS_PENSION_MONTHLY_CAP) if insured else 0
        if insured:
            r = rates.shaho(co.prefecture, month)
            care = is_care_insured(e.birth, month)
            h_rate = r.health + (r.care if care else D(0))
            hf, sf = D(std_h) * h_rate, D(std_h) * r.child_support
            pf, cf = D(std_p) * r.pension, D(std_p) * r.child_contribution
            rnd = ROUNDERS[co.policy["shaho_rounding"]]
            if co.policy["support_rounding"] == "with_health":
                eh, es = int(rnd((hf + sf) / 2)), 0
            else:
                eh, es = int(rnd(hf / 2)), int(rnd(sf / 2))
            ep = int(rnd(pf / 2))
            why.append(f"標準賞与額 {std:,}（千円未満切捨て）→ 健保 {std_h:,}（年度累計 {prior:,}）・厚年 {std_p:,}"
                       f"（rules_r08.bonus_standard_amount）")
        else:
            care, hf, sf, pf, cf, eh, es, ep = False, D(0), D(0), D(0), D(0), 0, 0, 0
            why.append(f"{month:%Y-%m}分は被保険者でない（資格喪失月の賞与は対象外）")
        koyou = 0
        if e.koyou:
            k = rates.koyou(co.koyou_kind, pay_date)
            koyou = int(ROUNDERS[co.policy["koyou_rounding"]](D(amount) * k["worker"]))
            why.append(f"雇用保険 {amount:,}×{k['worker']}＝{koyou:,}")
        # 源泉：前月中に支払った給与の「社会保険料等控除後の金額」で率を引く
        prev = payslip(co, rates, e, add_months(month, -1)) if add_months(month, -1) >= co.start_month else None
        prev_taxable = prev.taxable if prev else None
        base = amount - (eh + es + ep) - koyou
        tax, rate = 0, None
        if prev_taxable is None or prev_taxable <= 0:
            pending.append((f"bonus_special:{eid}:{month:%Y-%m}", "賞与の源泉（前月に給与が無い）",
                            f"{eid}：前月の給与が無い（または開始月前で不明）。月額表を使う特別な計算"
                            f"（賞与の1/6 等）になる——初版は計算せず 0 円で置いた"))
        elif base > prev_taxable * 10:
            pending.append((f"bonus_special:{eid}:{month:%Y-%m}", "賞与の源泉（前月給与の10倍超）",
                            f"{eid}：社保等控除後の賞与 {base:,} が前月の {prev_taxable:,} の 10 倍を超える。"
                            f"月額表を使う特別な計算になる——初版は計算せず 0 円で置いた"))
        else:
            rate, rwhy = rates.withholding_bonus_rate(prev_taxable, e.dependents, e.wh_column, pay_date)
            tax = int(truncate(D(base) * rate / 100))
            why.append(f"源泉：({amount:,}−社保 {eh + es + ep:,}−雇保 {koyou:,})×{rate}%＝{tax:,}；{rwhy}")
        if e.role == "officer":
            pending.append((f"officer_bonus:{eid}:{month:%Y-%m}", "役員への賞与",
                            f"{eid} は役員。事前確定届出給与として届け出た額どおりでなければ法人税法上"
                            f"損金不算入（法人税法第34条）。届出の有無と額を確認する"))
        out.append(BonusSlip(eid, pay_date, amount, std_h, std_p, care, hf, sf, pf, cf, eh, es, ep,
                             koyou, prev_taxable, rate, tax, why, pending))
    return out


def run_month(co, rates, pay_month):
    out = []
    for e in co.employees:
        p = payslip(co, rates, e, pay_month)
        if p is not None and p.earnings:
            out.append(p)
    return out


def totals(slips) -> dict:
    return dict(gross=sum_money(p.gross for p in slips), net=sum_money(p.net for p in slips),
                shaho=sum_money(p.shaho_total for p in slips), koyou=sum_money(p.koyou for p in slips),
                tax=sum_money(p.income_tax for p in slips), jumin=sum_money(p.juminzei for p in slips))
