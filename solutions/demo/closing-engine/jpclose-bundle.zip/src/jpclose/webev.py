# -*- coding: utf-8 -*-
"""証憑の画面（ブラウザ）から呼ぶ入口。web.py と同じく JSON にできる dict を返す。

原本（画像・PDF）はページがフォルダに直接書く（Python には来ない：量が多い）。ここで扱うのは索引簿と、
OCR・PDF の文字層から読んだ「行」だけ。変えた索引簿・記録の中身を files で返し、ページがフォルダへ書き戻す。

  path(sha, name, received, kind)    原本を置く相対パス（kind なし＝未確認の置き場、あり＝区分のフォルダ）
  add(dir, file, sha, kind, received, pages, basis)   1 ファイル分の頁の文字 → テンプレートで読み、下書きを足す
                                               （kind は画面の当て推量、basis はその根拠。確認の時に人が確かめる）
  confirm(dir, no, values, by, reason)         確かめて確認済（確認済の訂正は記録に残る）。values の kind・file で
                                               区分と置き場所を決める（原本を移すのは画面）
  classify(dir, rel)                           利用者が入れた表（Excel・CSV）が何か（recognize.classify）
  void(dir, no, by, reason)                    取り消す
  attach(dir, no, bank_key, by)                照合先（銀行明細）を決める
  import_workpaper(dir, rel, lang)             中国式の決算ワークペーパーから期首残高（無ければ入力ブックも作る）
  import_journal(dir, rel)                     弥生の仕訳と銀行明細から銀行ルールの候補を作る（書かない）
  add_rules(dir, rules, by, at)                選んだ候補を入力ブックの銀行ルールに足す
  import_opening(dir, rel)                     弥生会計の期首残高データを入力ブックの「期初余额」に入れる
  preview(dir, key, answer)                    回答を保存する前に、その回答でできる仕訳を見せる（直前の締めの帳簿で）
  listing(dir, q)                              一覧と検索（電帳法の 3 項目・範囲・組合せ）
"""
from __future__ import annotations

import datetime
import pathlib

from decimal import ROUND_HALF_UP, Decimal

from . import evidence as ev, extract


def _foreign_draft(r) -> tuple:
    """外貨の書類の下書き：(円の金額 or None, 備考, 索引簿の項目)。

    作者 2026-10-13：換算が書類に書いてあれば（手書きでも）それを使う。無ければ尋ねる。
    レートは利用者が決めて書くもの（どの日のレートかはこちらで決めない）。
    円の金額を入れるのは、書いてある換算の掛け算が合うときだけ。円未満は四捨五入（作者の決定：
    1250 × 21.37 ＝ 26712.5 → 26,713 円）。丸めたときはそう書く。"""
    money = f"{r.currency} {r.foreign // 100:,}.{r.foreign % 100:02d}"
    fx = dict(currency=r.currency, foreign=f"{r.foreign // 100}.{r.foreign % 100:02d}")
    c = r.conversion
    if not c:
        return None, f"外貨の書類です（{money}）。円に換算した金額を入れてください（使ったレートは備考に書きます）", fx
    fx.update(fx_rate=c["rate"], fx_yen=c["yen"])
    yen = Decimal(c["yen"])
    said = f"{r.foreign // 100}.{r.foreign % 100:02d} × {c['rate']} ＝ {c['yen']}"
    whole = int(yen.quantize(Decimal(1), rounding=ROUND_HALF_UP))
    if yen != whole:
        fx.update(fx_rounded="1")
        return whole, (f"外貨の書類です（{money}）。書類に書いてある換算 {said} の円未満を四捨五入して、"
                       f"{whole:,} 円を金額に入れました。確かめてください"), fx
    return whole, f"外貨の書類です（{money}）。書類に書いてある換算 {said} 円を金額に入れました。確かめてください", fx


def _own_names(root) -> list:
    """自分の会社の名前（取引先の候補から外す）。company.yaml、無ければ入力ブック（公司资料.xlsx）から。
    画面のフォルダには入力ブックしか無い——company.yaml だけを見ていたので、自分の会社が取引先に入っていた
    （作者 2026-10-15 の画面）。"""
    import tempfile
    import yaml
    from . import workbook
    p = pathlib.Path(root) / "company.yaml"
    try:
        if p.exists():
            doc = yaml.safe_load(p.read_text(encoding="utf-8"))
        else:
            doc = {}
            book = workbook.find_workbook(root)
            if book:
                with tempfile.TemporaryDirectory() as td:
                    workbook.to_folder(book, td)
                    q = pathlib.Path(td) / "company.yaml"
                    doc = yaml.safe_load(q.read_text(encoding="utf-8")) if q.exists() else {}
    except Exception:                                    # 読めないブックでも証憑の取り込みは止めない（名前を外せないだけ）
        doc = {}
    name = ((doc or {}).get("company") or {}).get("name") or ""
    return [name, name.replace("株式会社", "").strip()] if name else []


def _now(now=None) -> datetime.datetime:
    if isinstance(now, datetime.datetime):
        return now
    return datetime.datetime.fromisoformat(now) if now else datetime.datetime.now().replace(microsecond=0)


def _files(root) -> dict:
    root = pathlib.Path(root)
    return {rel: (root / rel).read_text(encoding="utf-8-sig") for rel in (ev.INDEX, ev.LOG) if (root / rel).exists()}


def _entry(e: ev.Entry) -> dict:
    return dict(no=e.no, date=str(e.date) if e.date else "", amount=e.amount, party=e.party, doc=e.doc, kind=e.kind,
                file=e.file, page=e.page, sha=e.sha, received=str(e.received), bank=e.bank, status=e.status,
                note=e.note, fields=e.fields, searchable=e.searchable)


def _out(root, ix: ev.Index, **extra) -> dict:
    return dict(ok=True, entries=[_entry(e) for e in sorted(ix.entries, key=lambda e: e.no)], notices=ix.notices(),
                files=_files(root), **extra)


def _err(e: Exception) -> dict:
    return dict(ok=False, error=str(e))


def path(sha: str, name: str, received: str, kind: str | None = None) -> str:
    return ev.stored_path(sha, name, datetime.date.fromisoformat(received), kind or None)


def classify(company_dir, rel: str) -> dict:
    """company_dir/rel に置かれた表が何か。画面はこの答えで置き場所を決める（置くのは画面）。"""
    from . import recognize
    root = pathlib.Path(company_dir)
    try:
        return dict(ok=True, **recognize.classify(root / rel, root))
    except (OSError, ValueError) as e:
        return _err(e)


def add(company_dir, file: str, sha: str, kind: str, received: str, pages: list, basis: str = "",
        n_pages: int | None = None) -> dict:
    """pages: [{"page": 1 or None, "lines": [...]}]（**1 つのファイルの頁をまとめて**渡す）。頁ごとにテンプレートで読み、
    当たった書類ごとに下書きを 1 行。**ファイルのどの頁も当たらなければ、ファイルに空の下書きを 1 行**（頁ごとではない。
    作者 2026-10-15：4 頁の契約書が 4 行になり、同じ確認を 4 回させていた）。n_pages はファイルの頁数（読まなかった頁を含む）。

    検算が通ったもの（ok）だけ金額・日付を下書きに入れる。通らなかったものは読めた値を備考に書くだけ——読み違いを
    そのまま「確認」されないように（取引先と書類の種類は入れる）。"""
    root = pathlib.Path(company_dir)
    try:
        ix = ev.Index.load(root)
        rec = datetime.date.fromisoformat(received)
        tpls = extract.load_templates(root)
        how = {"kind_basis": basis} if basis else {}       # 区分の根拠（photo／text／vector／scan）：画面が説明に使う
        added, unmatched = [], []
        for pg in pages:
            results = extract.read(pg.get("lines") or [], tpls)
            if not results:
                unmatched.append(pg.get("page"))
            for r in results:
                fields = {k: v for k, v in r.fields.items() if v is not None}
                fields.update(template=r.template, ok="1" if r.ok else "0", **how)
                if n_pages and n_pages > 1:                # 何頁のファイルの 1 枚か（読まなかった頁があることが画面で分かるように）
                    fields["pages"] = str(n_pages)
                party = r.party or str(r.fields.get("name") or "")
                note = "" if r.ok else ("読み取り（未検算）：" + "・".join(
                    f"{k}={v}" for k, v in r.fields.items() if v is not None) + "／" + "；".join(r.problems))
                amount = r.amount
                if r.ok and r.currency and r.foreign:
                    amount, note, fx = _foreign_draft(r)
                    fields.update(fx)
                elif r.currency:                           # 外貨の書類だが検算が通らない：通貨だけは伝える（円として読ませない）
                    fields.update(currency=r.currency)
                added.append(ix.add(file=file, sha=sha, kind=kind, received=rec, page=pg.get("page"),
                                    date=r.date if r.ok else None, amount=amount if r.ok else None,
                                    party=party, doc=r.doc, note=note, fields=fields))
        # 読んだがどのテンプレートにも当たらなかった頁は、まとめて 1 行（どの頁も当たらなければ、ファイルに 1 行）。
        # 読まなかった頁（スキャンの 2 頁目以降など）は「当たらなかった」に数えない
        if unmatched or not added:
            rest = dict(how, **({"pages": str(n_pages)} if n_pages else {}))
            if added and unmatched:
                rest["unread_pages"] = ",".join(str(x) for x in unmatched if x)
            one = unmatched[0] if (added and len(unmatched) == 1) else None
            # テンプレートの無い書類：汎用の規則で日付・金額・取引先を読む（作者 2026-10-15：数字を出せるなら出す）。
            # 検算はできないので、備考に「汎用」と手がかりを書く。確認するまで記帳には使わない
            from . import generic
            lines = [l for pg in pages if pg.get("page") in unmatched or not added for l in (pg.get("lines") or [])]
            g = generic.read(lines, _own_names(root)) if lines else None
            if g:
                rest.update(generic="1", generic_why=g["why"], **({"generic_amount": g["amount_key"]} if g["amount_key"] else {}))
                note = f"汎用の規則で読みました（{g['why']}）。検算できないので、原本と照らしてから確認してください"
                added.append(ix.add(file=file, sha=sha, kind=kind, received=rec, page=one, date=g["date"],
                                    amount=g["amount"], party=g["party"], note=note, fields=rest))
            else:
                added.append(ix.add(file=file, sha=sha, kind=kind, received=rec, page=one, fields=rest))
        ix.save(root)
        return _out(root, ix, added=[e.no for e in added])
    except (ev.EvidenceError, ValueError) as e:
        return _err(e)


def check(company_dir, lines: list) -> dict:
    """1 頁の文字をテンプレートで読んだら、当たったものが何枚で、そのうち検算が通ったのが何枚か（索引簿には書かない）。
    画面が「本機の読み取り助手で読んだが、テンプレートに当たって検算が通らなかった頁」だけをブラウザの読み取りで
    読み直すために使う（作者 2026-10-15：速い読み取りで足りない頁だけ遅い読み取りで補う）。"""
    root = pathlib.Path(company_dir)
    try:
        rs = extract.read(lines or [], extract.load_templates(root))
        return dict(ok=True, matched=len(rs), passed=sum(1 for r in rs if r.ok))
    except ValueError as e:
        return _err(e)


def preview(company_dir, key: str, answer: dict) -> dict:
    """回答を保存する前に、その回答でできる仕訳を見せる（作者 2026-10-13：弥生の「仕訳プレビュー」を借りる）。

    締めと同じ関数で作る（journal.decided・evlink.booked・税抜経理なら shouhi.split_voucher）——画面に別の規則を
    持たせない。直前の締め（web._LAST）の帳簿と明細を使うので、締める前は使えない。
    返すもの：lines＝[{side: debit/credit, account, sub, tax, amount}]（税抜経理なら消費税の行も分かれている）。"""
    from . import evlink, journal, web
    from .jp import shouhi
    led = web._LAST.get("led")
    if led is None:
        return dict(ok=False, error="先に締めを実行してください（帳簿がまだ無い）")
    co, d = led.co, dict(answer or {})
    try:
        parts = d.get("lines") or [dict(account=d.get("account"), amount=None)]
        for l in parts:
            if l.get("account") not in co.chart:
                return dict(ok=False, error="account")
        if key.startswith("evidence:"):
            if d.get("credit") not in co.chart:
                return dict(ok=False, error="credit")
            e = ev.Index.load(pathlib.Path(company_dir)).get(int(key.split(":")[1]))
            total = e.amount
            v = evlink.booked(e, d, key)
        else:
            rows = {r.key(): r for res in led.results for rs in res.all_bank_rows.values() for r in rs}
            r = rows.get(key)
            if r is None:
                return dict(ok=False, error="row")
            b = {x["id"]: x for x in co.bank_accounts}[r.bank]
            total = r.amount_abs
            v = journal.decided(r, d, b["account"], b.get("sub", ""), key)
        if d.get("lines") and sum(int(l["amount"]) for l in d["lines"]) != total:
            return dict(ok=False, error="sum")
        if co.ct.get("accounting") == "tax_excluded":            # 締め（close.close_month）と同じ条件
            shouhi.split_voucher(v, co.chart)
        return dict(ok=True, date=str(v.date), balanced=v.balanced(),
                    lines=[dict(side="debit" if l.debit else "credit", account=l.account, sub=l.sub,
                                tax=l.tax if l.account not in (shouhi.INPUT_TAX, shouhi.OUTPUT_TAX) else "",
                                amount=int(l.debit or l.credit)) for l in v.lines])
    except (ev.EvidenceError, ValueError, KeyError, TypeError) as e:
        return dict(ok=False, error=f"{type(e).__name__}: {e}")


def confirm(company_dir, no: int, values: dict, by: str, reason: str = "", now=None) -> dict:
    root = pathlib.Path(company_dir)
    try:
        ix = ev.Index.load(root)
        vals = {k: v for k, v in (values or {}).items()
                if k in ("date", "amount", "party", "doc", "note", "bank", "kind", "file")}
        ix.confirm(int(no), by=by, at=_now(now), reason=reason, **vals)
        ix.save(root)
        return _out(root, ix)
    except (ev.EvidenceError, ValueError) as e:
        return _err(e)


def void(company_dir, no: int, by: str, reason: str, now=None) -> dict:
    root = pathlib.Path(company_dir)
    try:
        ix = ev.Index.load(root)
        ix.void(int(no), by=by, at=_now(now), reason=reason)
        ix.save(root)
        return _out(root, ix)
    except (ev.EvidenceError, ValueError) as e:
        return _err(e)


def attach(company_dir, no: int, bank_key: str, by: str, now=None) -> dict:
    """候補の明細を選んだ（evidence_choose の回答）。確認済の行の照合先を変えるのは訂正なので理由を書く。"""
    root = pathlib.Path(company_dir)
    try:
        ix = ev.Index.load(root)
        e = ix.get(int(no))
        reason = "照合先を画面で選びました" if e.status == ev.CONFIRMED else ""
        ix.confirm(int(no), by=by, at=_now(now), reason=reason, bank=bank_key)
        ix.save(root)
        return _out(root, ix)
    except (ev.EvidenceError, ValueError) as e:
        return _err(e)


def listing(company_dir, q: dict | None = None) -> dict:
    root = pathlib.Path(company_dir)
    try:
        ix = ev.Index.load(root)
        q = q or {}
        hit = ix.search(date_from=q.get("date_from") or None, date_to=q.get("date_to") or None,
                        amount_min=q.get("amount_min") or None, amount_max=q.get("amount_max") or None,
                        party=q.get("party") or "", include_void=bool(q.get("include_void")))
        return _out(root, ix, hits=[e.no for e in hit])
    except (ev.EvidenceError, ValueError) as e:
        return _err(e)


def import_opening(company_dir, rel: str) -> dict:
    """弥生会計の期首残高データ（company_dir/rel）を、入力ブックの「期初余额」の表に入れる。

    作り直した入力ブックを book（base64）で返す——置き換えるのは画面（前のブックを控えてから）。入れないとき：
      no_book   入力ブックがまだ無い（開始月・年度の設定がそこにある）
      yaml      入力が手書きの YAML の会社（ブックが正ではない）
      book      入力ブックに直すところがある（text）
      file      ファイルの形が違う（lines：行番号と理由）
      exists    期首残高がもう入っている（n 行）——上書きしない
      start     期首日が、入力ブックの記帳開始月の初日ではない（day・start）
    繰越利益剰余金は弥生のファイルに無い（弥生では入力できない科目）。貸借の差額を入れ、retained で知らせる
    （弥生の［貸借調整］と同じ計算）。前期の貸借対照表と照らすのは利用者。
    科目表に無い科目名（unknown）もそのまま入れる——名前の対応はこちらで決めない。締める前の確認が指摘する。"""
    import base64
    import tempfile
    import yaml
    from . import company, web, workbook, yayoi
    root = pathlib.Path(company_dir)
    try:
        if workbook.find_workbook(root) is None:
            return dict(ok=False, error="no_book")
        source, conv = web.prepare(root)
        if source != "workbook":
            return dict(ok=False, error="yaml")
        if conv:
            return dict(ok=False, error="book", text="；".join(f"表「{s}」第 {r} 行：{m}" for s, r, m in conv))
        got = yayoi.read_opening((root / rel).read_bytes())
        if got["problems"]:
            return dict(ok=False, error="file", lines=[dict(line=i, why=w) for i, w in got["problems"][:10]])
        op = workbook._load(root, "opening_balances.yaml")
        if op.get("balances"):
            return dict(ok=False, error="exists", n=len(op["balances"]))
        doc = workbook._load(root, "company.yaml")
        start, day = web._start_month(doc), got["day"]
        if start is None or day != start:
            return dict(ok=False, error="start", day=str(day), start=f"{start:%Y-%m}" if start else "")
        chart, _ = company.load_chart((doc.get("accounts") or {}).get("add", []))
        rows, total = [], 0
        for acc, sub, n in got["balances"]:
            if n:
                rows.append(dict(account=acc, **({"sub": sub} if sub else {}), **({"debit": n} if n > 0 else {"credit": -n})))
                total += n
        retained = 0
        if total and not any(r["account"] in yayoi.NOT_IMPORTABLE for r in rows):
            retained = total                                   # 借方が多い分＝貸方の繰越利益剰余金（マイナスなら借方）
            rows.append(dict(account="繰越利益剰余金", **({"credit": total} if total > 0 else {"debit": -total})))
        workbook._dump(root / "opening_balances.yaml", dict(as_of=day - datetime.timedelta(days=1), balances=rows))
        out = pathlib.Path(tempfile.gettempdir()) / "jpclose_opening_book.xlsx"
        workbook.from_folder(root, out, workbook.BOOK["lang"])
        return dict(ok=True, rows=len(rows), as_of=str(day - datetime.timedelta(days=1)), retained=retained,
                    unknown=sorted({r["account"] for r in rows if r["account"] not in chart}),
                    book=base64.b64encode(out.read_bytes()).decode("ascii"))
    except (OSError, ValueError, yaml.YAMLError) as e:
        return _err(e)


def _book_state(root):
    """入力ブックの会社の、いまの資料（YAML に変換して読む）。読めなければ (None, error)。"""
    from . import web, workbook
    if workbook.find_workbook(root) is None:
        return None, "no_book"
    source, conv = web.prepare(root)
    if source != "workbook":
        return None, "yaml"
    if conv:
        return None, "book"
    return workbook, None


def import_journal(company_dir, rel: str) -> dict:
    """弥生インポート形式の仕訳（company_dir/rel）と、フォルダにある同じ期間の銀行明細から、銀行ルールの候補を作る。
    **何も書かない**（会社の資料に入れるのは、利用者が選んだ候補を add_rules で）。

    返すもの：rules（候補）・split（科目が割れている摘要）・unknown（科目表に無い科目）・vouchers・period・
    paired（明細と組めた仕訳）・unmatched_journal・unmatched_bank。入れないとき error：no_book・yaml・book・file・no_bank。"""
    from . import bank as bankmod, company, learnrules, workbook, yayoi
    root = pathlib.Path(company_dir)
    try:
        wb, err = _book_state(root)
        if err:
            return dict(ok=False, error=err)
        got = yayoi.read_journal((root / rel).read_bytes())
        if got["problems"]:
            return dict(ok=False, error="file", lines=[dict(line=i, why=w) for i, w in got["problems"][:10]])
        doc = workbook._load(root, "company.yaml")
        banks = [b for b in doc.get("bank_accounts") or [] if b.get("id")]
        chart, _ = company.load_chart((doc.get("accounts") or {}).get("add", []))
        rows, probs = bankmod.load_all(root, banks, {}) if banks else ({}, ["no bank"])
        vs = got["vouchers"]
        first, last = learnrules.period(vs)
        if not banks or probs or not any(rows.values()):
            return dict(ok=False, error="no_bank", vouchers=len(vs), unknown=learnrules.unknown_accounts(vs, chart))
        in_range = {bid: [r for r in rs if first - datetime.timedelta(days=learnrules.DAYS) <= r.date
                          <= last + datetime.timedelta(days=learnrules.DAYS)] for bid, rs in rows.items()}
        existing = (workbook._load(root, "bank_rules.yaml").get("rules") or [])
        out = learnrules.learn(vs, banks, in_range, chart, existing)
        return dict(ok=True, vouchers=len(vs), period=[str(first), str(last)],
                    unknown=learnrules.unknown_accounts(vs, chart), **out)
    except (OSError, ValueError) as e:
        return _err(e)


def add_rules(company_dir, rules: list, by: str, at: str) -> dict:
    """選んだ候補を入力ブックの「银行规则」の表に足す。作り直したブックを book（base64）で返す（置き換えは画面）。
    科目表に無い科目の候補は入れない（先に「追加科目」に登録してもらう）。error：no_book・yaml・book・by・empty。"""
    import base64
    import tempfile
    import yaml
    from . import company, workbook
    root = pathlib.Path(company_dir)
    try:
        if not (by or "").strip():
            return dict(ok=False, error="by")
        wb, err = _book_state(root)
        if err:
            return dict(ok=False, error=err)
        doc = workbook._load(root, "company.yaml")
        chart, _ = company.load_chart((doc.get("accounts") or {}).get("add", []))
        cur = workbook._load(root, "bank_rules.yaml").get("rules") or []
        ids = {str(r.get("id")) for r in cur}
        n, added, skipped = 1, [], []
        for c in rules or []:
            if c.get("account") not in chart:
                skipped.append(c.get("desc_contains"))
                continue
            while f"Y{n:02d}" in ids:
                n += 1
            rid = f"Y{n:02d}"
            ids.add(rid)
            side = "credit" if c.get("direction") == "in" else "debit"
            then = {side: c["account"]}
            if c.get("sub"):
                then["sub"] = c["sub"]
            if c.get("tax") and c["tax"] != "対象外":
                then["tax"] = c["tax"]
            added.append(dict(id=rid, by=by.strip(), at=datetime.date.fromisoformat(at),
                              note=f"弥生の仕訳から（同じ摘要の明細 {int(c.get('n') or 0)} 件が同じ科目）",
                              when=dict(desc_contains=c["desc_contains"], direction=c["direction"]), then=then))
        if not added:
            return dict(ok=False, error="empty", skipped=skipped)
        workbook._dump(root / "bank_rules.yaml", dict(rules=cur + added))
        out = pathlib.Path(tempfile.gettempdir()) / "jpclose_rules_book.xlsx"
        workbook.from_folder(root, out, workbook.BOOK["lang"])
        return dict(ok=True, added=[r["id"] for r in added], skipped=skipped,
                    book=base64.b64encode(out.read_bytes()).decode("ascii"))
    except (OSError, ValueError, yaml.YAMLError) as e:
        return _err(e)


def import_workpaper(company_dir, rel: str, lang: str = "ja") -> dict:
    """中国式の決算ワークペーパー（company_dir/rel）から、次の年度の期首残高を読んで入力ブックに入れる
    （作者 2026-10-15：お客さまに表を埋めさせない）。入力ブックが無ければ作る（会社名・決算月・記帳を始める月も底稿から）。

    入れないとき error：yaml（YAML で入力している会社）・book（入力ブックに直すところ：text）・exists（期首残高がもうある：n）・
    start（入力ブックの記帳を始める月が、底稿の年度末の次の月でない：day・start）・open／no_journal／no_bs／prior_year（底稿を読めない）。
    返すもの：rows・retained・unknown（科目の分からない科目：名前のまま入れた）・rounding・check（資産合計との照合）・
    company・year_end・as_of・start・created（入力ブックを作ったか）・book（base64）。"""
    import base64
    import tempfile
    import yaml
    from . import company, web, workbook, workpaper
    from .jp.calendar import add_months
    root = pathlib.Path(company_dir)
    try:
        created = workbook.find_workbook(root) is None
        if not created:
            source, conv = web.prepare(root)
            if source != "workbook":
                return dict(ok=False, error="yaml")
            if conv:
                return dict(ok=False, error="book", text="；".join(f"表「{s}」第 {r} 行：{m}" for s, r, m in conv))
        else:
            workbook.BOOK["lang"] = lang if lang in ("zh", "ja", "en") else "ja"
        doc = workbook._load(root, "company.yaml") if not created else {}
        chart, _ = company.load_chart((doc.get("accounts") or {}).get("add", []))
        try:
            got = workpaper.read(root / rel, chart, doc.get("bank_accounts") or [])
        except workpaper.WorkpaperError as e:
            return dict(ok=False, error=str(e))
        if (workbook._load(root, "opening_balances.yaml").get("balances") or []) and not created:
            return dict(ok=False, error="exists", n=len(workbook._load(root, "opening_balances.yaml")["balances"]))
        ye = got["year_end"]
        start = add_months(datetime.date(ye.year, ye.month, 1), 1)
        co = dict(doc.get("company") or {})
        cur = web._start_month(doc) if doc else None
        if cur is not None and cur != start:
            return dict(ok=False, error="start", day=str(ye), start=f"{cur:%Y-%m}")
        co.setdefault("name", got["company"] or None)
        co.setdefault("fiscal_year_end_month", ye.month)
        co.setdefault("start_month", f"{start:%Y-%m}")
        doc["company"] = {k: v for k, v in co.items() if v is not None}
        workbook._dump(root / "company.yaml", doc)
        rows = list(got["balances"])
        # 科目表に無い科目は「追加科目」に登録して入れる（入れないと入力ブックが通らない。消しもしない）
        acc = dict(doc.get("accounts") or {})
        have = list(acc.get("add") or [])
        added_accounts = workpaper.extra_accounts(got["unknown"], chart, have)
        if added_accounts:
            acc["add"] = have + [{k: v for k, v in a.items() if k != "guessed"} for a in added_accounts]
            doc["accounts"] = acc
            workbook._dump(root / "company.yaml", doc)
        for u in got["unknown"]:
            n = int(u["amount"])
            rows.append(dict(account=u["ja"] or u["cn"], **({"sub": u["sub"]} if u["sub"] else {}),
                             **({"debit": n} if n > 0 else {"credit": -n})))
        workbook._dump(root / "opening_balances.yaml", dict(as_of=ye, balances=rows))
        out = pathlib.Path(tempfile.gettempdir()) / "jpclose_workpaper_book.xlsx"
        workbook.from_folder(root, out, workbook.BOOK["lang"])
        return dict(ok=True, rows=len(rows), retained=got["retained"], unknown=got["unknown"], rounding=got["rounding"],
                    accounts_added=added_accounts,
                    check=got["check"], company=got["company"], year_end=str(ye), as_of=str(ye), start=f"{start:%Y-%m}",
                    created=created, journal=got["journal"], book=base64.b64encode(out.read_bytes()).decode("ascii"))
    except (OSError, ValueError, yaml.YAMLError) as e:
        return _err(e)
