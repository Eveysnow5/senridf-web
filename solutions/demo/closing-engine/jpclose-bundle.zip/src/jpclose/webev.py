# -*- coding: utf-8 -*-
"""証憑の画面（ブラウザ）から呼ぶ入口。web.py と同じく JSON にできる dict を返す。

原本（画像・PDF）はページがフォルダに直接書く（Python には来ない：量が多い）。ここで扱うのは索引簿と、
OCR・PDF の文字層から読んだ「行」だけ。変えた索引簿・記録の中身を files で返し、ページがフォルダへ書き戻す。

  path(sha, name, received, kind)    原本を置く相対パス（kind なし＝未確認の置き場、あり＝区分のフォルダ）
  add(dir, file, sha, kind, received, pages, basis)   1 ファイル分の頁の文字 → テンプレートで読み、下書きを足す
                                               （kind は画面の当て推量、basis はその根拠。確認の時に人が確かめる）
  confirm(dir, no, values, by, reason)         確かめて確認済（確認済の訂正は記録に残る）。values の kind・file で
                                               区分と置き場所を決める（原本を移すのは画面）
  classify(dir, rel)                           利用者が入れた表（Excel・CSV）が何か（recognize.classify）
  void(dir, no, by, reason)                    取り消す
  attach(dir, no, bank_key, by)                照合先（銀行明細）を決める
  preview(dir, key, answer)                    回答を保存する前に、その回答でできる仕訳を見せる（直前の締めの帳簿で）
  listing(dir, q)                              一覧と検索（電帳法の 3 項目・範囲・組合せ）
"""
from __future__ import annotations

import datetime
import pathlib

from decimal import ROUND_HALF_UP, Decimal

from . import evidence as ev, extract


def _foreign_draft(r) -> tuple:
    """外貨の書類の下書き：(円の金額 or None, 備考, 索引簿の項目)。

    作者 2026-10-13：換算が書類に書いてあれば（手書きでも）それを使う。無ければ尋ねる。
    レートは利用者が決めて書くもの（どの日のレートかはこちらで決めない）。
    円の金額を入れるのは、書いてある換算の掛け算が合うときだけ。円未満は四捨五入（作者の決定：
    1250 × 21.37 ＝ 26712.5 → 26,713 円）。丸めたときはそう書く。"""
    money = f"{r.currency} {r.foreign // 100:,}.{r.foreign % 100:02d}"
    fx = dict(currency=r.currency, foreign=f"{r.foreign // 100}.{r.foreign % 100:02d}")
    c = r.conversion
    if not c:
        return None, f"外貨の書類です（{money}）。円に換算した金額を入れてください（使ったレートは備考に書きます）", fx
    fx.update(fx_rate=c["rate"], fx_yen=c["yen"])
    yen = Decimal(c["yen"])
    said = f"{r.foreign // 100}.{r.foreign % 100:02d} × {c['rate']} ＝ {c['yen']}"
    whole = int(yen.quantize(Decimal(1), rounding=ROUND_HALF_UP))
    if yen != whole:
        fx.update(fx_rounded="1")
        return whole, (f"外貨の書類です（{money}）。書類に書いてある換算 {said} の円未満を四捨五入して、"
                       f"{whole:,} 円を金額に入れました。確かめてください"), fx
    return whole, f"外貨の書類です（{money}）。書類に書いてある換算 {said} 円を金額に入れました。確かめてください", fx


def _now(now=None) -> datetime.datetime:
    if isinstance(now, datetime.datetime):
        return now
    return datetime.datetime.fromisoformat(now) if now else datetime.datetime.now().replace(microsecond=0)


def _files(root) -> dict:
    root = pathlib.Path(root)
    return {rel: (root / rel).read_text(encoding="utf-8-sig") for rel in (ev.INDEX, ev.LOG) if (root / rel).exists()}


def _entry(e: ev.Entry) -> dict:
    return dict(no=e.no, date=str(e.date) if e.date else "", amount=e.amount, party=e.party, doc=e.doc, kind=e.kind,
                file=e.file, page=e.page, sha=e.sha, received=str(e.received), bank=e.bank, status=e.status,
                note=e.note, fields=e.fields, searchable=e.searchable)


def _out(root, ix: ev.Index, **extra) -> dict:
    return dict(ok=True, entries=[_entry(e) for e in sorted(ix.entries, key=lambda e: e.no)], notices=ix.notices(),
                files=_files(root), **extra)


def _err(e: Exception) -> dict:
    return dict(ok=False, error=str(e))


def path(sha: str, name: str, received: str, kind: str | None = None) -> str:
    return ev.stored_path(sha, name, datetime.date.fromisoformat(received), kind or None)


def classify(company_dir, rel: str) -> dict:
    """company_dir/rel に置かれた表が何か。画面はこの答えで置き場所を決める（置くのは画面）。"""
    from . import recognize
    root = pathlib.Path(company_dir)
    try:
        return dict(ok=True, **recognize.classify(root / rel, root))
    except (OSError, ValueError) as e:
        return _err(e)


def add(company_dir, file: str, sha: str, kind: str, received: str, pages: list, basis: str = "") -> dict:
    """pages: [{"page": 1 or None, "lines": [...]}]。頁ごとにテンプレートで読み、当たった書類ごとに下書きを 1 行。
    何も当たらなければ空の下書きを 1 行（利用者が日付・金額・取引先を入れる）。

    検算が通ったもの（ok）だけ金額・日付を下書きに入れる。通らなかったものは読めた値を備考に書くだけ——読み違いを
    そのまま「確認」されないように（取引先と書類の種類は入れる）。"""
    root = pathlib.Path(company_dir)
    try:
        ix = ev.Index.load(root)
        rec = datetime.date.fromisoformat(received)
        tpls = extract.load_templates(root)
        how = {"kind_basis": basis} if basis else {}       # 区分の根拠（photo／text／vector／scan）：画面が説明に使う
        added = []
        for pg in pages:
            results = extract.read(pg.get("lines") or [], tpls)
            if not results:
                added.append(ix.add(file=file, sha=sha, kind=kind, received=rec, page=pg.get("page"), fields=how))
                continue
            for r in results:
                fields = {k: v for k, v in r.fields.items() if v is not None}
                fields.update(template=r.template, ok="1" if r.ok else "0", **how)
                party = r.party or str(r.fields.get("name") or "")
                note = "" if r.ok else ("読み取り（未検算）：" + "・".join(
                    f"{k}={v}" for k, v in r.fields.items() if v is not None) + "／" + "；".join(r.problems))
                amount = r.amount
                if r.ok and r.currency and r.foreign:
                    amount, note, fx = _foreign_draft(r)
                    fields.update(fx)
                elif r.currency:                           # 外貨の書類だが検算が通らない：通貨だけは伝える（円として読ませない）
                    fields.update(currency=r.currency)
                added.append(ix.add(file=file, sha=sha, kind=kind, received=rec, page=pg.get("page"),
                                    date=r.date if r.ok else None, amount=amount if r.ok else None,
                                    party=party, doc=r.doc, note=note, fields=fields))
        ix.save(root)
        return _out(root, ix, added=[e.no for e in added])
    except (ev.EvidenceError, ValueError) as e:
        return _err(e)


def preview(company_dir, key: str, answer: dict) -> dict:
    """回答を保存する前に、その回答でできる仕訳を見せる（作者 2026-10-13：弥生の「仕訳プレビュー」を借りる）。

    締めと同じ関数で作る（journal.decided・evlink.booked・税抜経理なら shouhi.split_voucher）——画面に別の規則を
    持たせない。直前の締め（web._LAST）の帳簿と明細を使うので、締める前は使えない。
    返すもの：lines＝[{side: debit/credit, account, sub, tax, amount}]（税抜経理なら消費税の行も分かれている）。"""
    from . import evlink, journal, web
    from .jp import shouhi
    led = web._LAST.get("led")
    if led is None:
        return dict(ok=False, error="先に締めを実行してください（帳簿がまだ無い）")
    co, d = led.co, dict(answer or {})
    try:
        parts = d.get("lines") or [dict(account=d.get("account"), amount=None)]
        for l in parts:
            if l.get("account") not in co.chart:
                return dict(ok=False, error="account")
        if key.startswith("evidence:"):
            if d.get("credit") not in co.chart:
                return dict(ok=False, error="credit")
            e = ev.Index.load(pathlib.Path(company_dir)).get(int(key.split(":")[1]))
            total = e.amount
            v = evlink.booked(e, d, key)
        else:
            rows = {r.key(): r for res in led.results for rs in res.all_bank_rows.values() for r in rs}
            r = rows.get(key)
            if r is None:
                return dict(ok=False, error="row")
            b = {x["id"]: x for x in co.bank_accounts}[r.bank]
            total = r.amount_abs
            v = journal.decided(r, d, b["account"], b.get("sub", ""), key)
        if d.get("lines") and sum(int(l["amount"]) for l in d["lines"]) != total:
            return dict(ok=False, error="sum")
        if co.ct.get("accounting") == "tax_excluded":            # 締め（close.close_month）と同じ条件
            shouhi.split_voucher(v, co.chart)
        return dict(ok=True, date=str(v.date), balanced=v.balanced(),
                    lines=[dict(side="debit" if l.debit else "credit", account=l.account, sub=l.sub,
                                tax=l.tax if l.account not in (shouhi.INPUT_TAX, shouhi.OUTPUT_TAX) else "",
                                amount=int(l.debit or l.credit)) for l in v.lines])
    except (ev.EvidenceError, ValueError, KeyError, TypeError) as e:
        return dict(ok=False, error=f"{type(e).__name__}: {e}")


def confirm(company_dir, no: int, values: dict, by: str, reason: str = "", now=None) -> dict:
    root = pathlib.Path(company_dir)
    try:
        ix = ev.Index.load(root)
        vals = {k: v for k, v in (values or {}).items()
                if k in ("date", "amount", "party", "doc", "note", "bank", "kind", "file")}
        ix.confirm(int(no), by=by, at=_now(now), reason=reason, **vals)
        ix.save(root)
        return _out(root, ix)
    except (ev.EvidenceError, ValueError) as e:
        return _err(e)


def void(company_dir, no: int, by: str, reason: str, now=None) -> dict:
    root = pathlib.Path(company_dir)
    try:
        ix = ev.Index.load(root)
        ix.void(int(no), by=by, at=_now(now), reason=reason)
        ix.save(root)
        return _out(root, ix)
    except (ev.EvidenceError, ValueError) as e:
        return _err(e)


def attach(company_dir, no: int, bank_key: str, by: str, now=None) -> dict:
    """候補の明細を選んだ（evidence_choose の回答）。確認済の行の照合先を変えるのは訂正なので理由を書く。"""
    root = pathlib.Path(company_dir)
    try:
        ix = ev.Index.load(root)
        e = ix.get(int(no))
        reason = "照合先を画面で選びました" if e.status == ev.CONFIRMED else ""
        ix.confirm(int(no), by=by, at=_now(now), reason=reason, bank=bank_key)
        ix.save(root)
        return _out(root, ix)
    except (ev.EvidenceError, ValueError) as e:
        return _err(e)


def listing(company_dir, q: dict | None = None) -> dict:
    root = pathlib.Path(company_dir)
    try:
        ix = ev.Index.load(root)
        q = q or {}
        hit = ix.search(date_from=q.get("date_from") or None, date_to=q.get("date_to") or None,
                        amount_min=q.get("amount_min") or None, amount_max=q.get("amount_max") or None,
                        party=q.get("party") or "", include_void=bool(q.get("include_void")))
        return _out(root, ix, hits=[e.no for e in hit])
    except (ev.EvidenceError, ValueError) as e:
        return _err(e)
