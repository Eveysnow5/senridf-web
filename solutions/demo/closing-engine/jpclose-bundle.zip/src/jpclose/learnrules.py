# -*- coding: utf-8 -*-
"""過去の帳簿（弥生会計の仕訳）と同じ期間の銀行明細から、銀行ルールの候補を作る（作者 2026-10-14：
新しいお客さまに表を埋めさせる量を減らす。履歴から読めるものは読む）。

銀行ルールが照らすのは**銀行明細の摘要**で、仕訳の摘要ではない（仕訳の摘要は担当者が書いた「事務所家賃 5 月分」など）。
だから仕訳だけからはルールを作らない。仕訳の預金の行と、銀行明細の行を**日付と金額で 1 対 1 に組み**、
組めたものについて「この明細の摘要 → 過去はこの科目に記帳した」を集める：
  · 摘要から数字を除いたものが同じ明細を 1 つの群にする（月や番号が摘要に入っていても同じ群に）
  · 群のすべてが同じ科目・補助・税区分 → 候補（件数と例を付ける）。2 件以上のときだけ
  · 科目が割れている群 → 候補にしない（「割れている」として見せる。どちらかを推測で選ばない）
  · 給与・社会保険・源泉・住民税の支払は候補にしない：締めが給与の計算から照合する。ルールにすると、
    金額が違ったときに黙ってルールで記帳されてしまう
  · 組めなかった仕訳・明細は数だけ返す（日付か金額が違う、または同じ日に同じ金額が複数）
候補は**候補**：会社の資料に入れるのは利用者が選んだものだけ（webev.add_rules）。
"""
from __future__ import annotations

import re
from collections import defaultdict

from . import yayoi

ENGINE_HANDLED = {"給料手当", "役員報酬", "賞与", "法定福利費", "預り金", "未払費用"}
DAYS = 3                                             # 仕訳の日付と明細の日付のずれ（記帳日が引落日とずれる）
_DIGITS = re.compile(r"[0-9０-９]+")
_SPACE = re.compile(r"[\s　]+")


def key_of(desc: str) -> str:
    """明細の摘要から、群にする鍵（数字を除き、空白をまとめる）。"""
    return _SPACE.sub(" ", _DIGITS.sub("", desc or "")).strip(" -/.:")


def rule_text(k: str, descs: list, others=()) -> str | None:
    """ルールの「摘要に含む」に書く字。ルールは**元の摘要**にそのまま当てる（bank.rule_hits）ので、数字を抜いた鍵は
    数字や全角の空白が摘要の途中にあると当たらない（「ﾔﾁﾝ 5ｶﾞﾂ ｶｸｳﾋﾞﾙ」の鍵「ﾔﾁﾝ ｶﾞﾂ ｶｸｳﾋﾞﾙ」は元の摘要に無い）。
    群のすべての摘要（descs）に含まれ、群の外の摘要（others：同じ口座・同じ向きで鍵が違うもの）には含まれない字：
    鍵そのもの、無ければ数字で切った断片の長いもの。どれも無ければ None（ルールにできない）。"""
    parts = sorted({s.strip(" -/.:　") for s in _DIGITS.split(descs[0])}, key=lambda s: (-len(s), s)) if descs else []
    for c in [k] + parts:
        if len(c) >= 2 and all(c in d for d in descs) and not any(c in o for o in others):
            return c
    return None


def _others(rows, direction: str, k: str) -> list:
    return [r.desc for r in rows if ("in" if r.signed > 0 else "out") == direction and key_of(r.desc) != k]


def learn(vouchers: list, banks: list, rows_by_bank: dict, chart: dict, existing_rules=()) -> dict:
    """vouchers：yayoi.read_journal の vouchers。banks：会社の銀行口座（id・account・sub）。
    rows_by_bank：{口座 id: 明細の行}。existing_rules：今のルール（同じ摘要のルールがあれば候補にしない）。"""
    have = [(r.get("when") or {}).get("desc_contains", "") for r in existing_rules or []]
    pairs, unmatched_j, used = [], 0, set()
    by_bank_side = {}
    for b in banks:
        by_bank_side[(b["account"], b.get("sub", "") or "")] = b["id"]
    for v in vouchers:
        bank_lines = [l for l in v["lines"] if (l["account"], l["sub"]) in by_bank_side]
        if len(bank_lines) != 1:
            unmatched_j += 1 if bank_lines else 0
            continue
        bl = bank_lines[0]
        counter = [l for l in v["lines"] if l is not bl]
        bid = by_bank_side[(bl["account"], bl["sub"])]
        signed = bl["amount"] if bl["side"] == "debit" else -bl["amount"]
        cands = [r for r in rows_by_bank.get(bid, []) if r.signed == signed
                 and abs((r.date - v["date"]).days) <= DAYS and r.id not in used]
        # 同じ日・同じ摘要・同じ金額の明細が何行もある（振込手数料 440 円が 1 日に 3 回など）：どれと組んでも同じ
        if len(cands) > 1 and len({(r.date, r.desc) for r in cands}) == 1:
            cands = cands[:1]
        if len(cands) != 1:
            unmatched_j += 1
            continue
        r = cands[0]
        used.add(r.id)
        pairs.append((bid, r, counter))
    groups = defaultdict(list)
    for bid, r, counter in pairs:
        k = key_of(r.desc)
        if len(k) >= 2:
            groups[(bid, "in" if r.signed > 0 else "out", k)].append((r, counter))
    rules, split = [], []
    for (bid, direction, k), items in sorted(groups.items()):
        shapes = {tuple((c["account"], c["sub"], yayoi.category_of_code(c["tax"])) for c in counter)
                  for _, counter in items}
        if any(k in h or h in k for h in have if h):
            continue
        if len(shapes) > 1:
            split.append(dict(bank=bid, direction=direction, desc_contains=k, n=len(items),
                              accounts=sorted({c[0] for s in shapes for c in s})))
            continue
        shape = next(iter(shapes))
        if len(shape) != 1 or len(items) < 2:            # 複合仕訳（科目が 2 つ以上）や 1 件だけは候補にしない
            continue
        acc, sub, tax = shape[0]
        if acc in ENGINE_HANDLED:
            continue
        text = rule_text(k, [r.desc for r, _ in items], _others(rows_by_bank.get(bid, []), direction, k))
        if text is None:
            continue
        rules.append(dict(bank=bid, direction=direction, desc_contains=text, account=acc, sub=sub, tax=tax,
                          n=len(items), known=acc in chart,
                          examples=[f"{r.date} {r.desc} {r.signed:+,}" for r, _ in items[:3]]))
    rules.sort(key=lambda x: (-x["n"], x["desc_contains"]))
    rows_total = sum(len(v) for v in rows_by_bank.values())
    return dict(rules=rules, split=split, paired=len(pairs), unmatched_journal=unmatched_j,
                unmatched_bank=rows_total - len(used))


def unknown_accounts(vouchers: list, chart: dict) -> list:
    """仕訳に出てくるが科目表に無い科目：[{account, n}]（多い順）。"""
    n = defaultdict(int)
    for v in vouchers:
        for l in v["lines"]:
            if l["account"] and l["account"] not in chart:
                n[l["account"]] += 1
    return [dict(account=a, n=c) for a, c in sorted(n.items(), key=lambda x: (-x[1], x[0]))]


def period(vouchers: list) -> tuple:
    ds = [v["date"] for v in vouchers]
    return (min(ds), max(ds)) if ds else (None, None)


DICTIONARY = __import__("pathlib").Path(__file__).resolve().parents[2] / "data" / "jp" / "bank_dictionary.yaml"


def suggest(rows_by_bank: dict, chart: dict, existing_rules=(), entries=None) -> dict:
    """履歴が無くても、よくある摘要（data/jp/bank_dictionary.yaml）から銀行ルールの候補を作る（learn と同じ形）。
    摘要の群（key_of）ごとに、辞書の言葉を含み向きが同じ項目が**ちょうど 1 つ**のときだけ候補にする（2 つ当たる
    ＝意味が決まらない）。今のルールに同じ摘要があるものは出さない。1 件だけの群も出す（手数料・利息は月 1 回もある）。
    返す：{rules:[{bank, direction, desc_contains, account, sub, tax, n, known, examples, why, source:"dict"}]}"""
    import yaml
    if entries is None:
        entries = yaml.safe_load(DICTIONARY.read_text(encoding="utf-8"))["entries"]
    have = [(r.get("when") or {}).get("desc_contains", "") for r in existing_rules or []]
    groups = defaultdict(list)
    for bid, rows in rows_by_bank.items():
        for r in rows:
            k = key_of(r.desc)
            if len(k) >= 2:
                groups[(bid, "in" if r.signed > 0 else "out", k)].append(r)
    rules = []
    for (bid, direction, k), items in sorted(groups.items()):
        if any(k in h or h in k for h in have if h):
            continue
        hit = [e for e in entries if e["direction"] == direction and any(w in k for w in e["words"])]
        if len(hit) != 1:
            continue
        e = hit[0]
        text = rule_text(k, [r.desc for r in items], _others(rows_by_bank[bid], direction, k))
        if text is None:
            continue
        rules.append(dict(bank=bid, direction=direction, desc_contains=text, account=e["account"], sub="", tax="",
                          n=len(items), known=e["account"] in chart, why=e.get("why", ""), source="dict",
                          examples=[f"{r.date} {r.desc} {r.signed:+,}" for r in items[:3]]))
    rules.sort(key=lambda x: (-x["n"], x["desc_contains"]))
    return dict(rules=rules)


SUSPENSE = {"仮払金", "仮受金"}         # 「まだ決まっていない」の科目：ルールにすると決まらないまま毎月黙って記帳される
MIN_MONTHS = 2


def _answer_shape(d):
    """回答 1 件を、ルールにできる形 (科目, 補助, 税区分) に。内訳（lines）・「処理済み」などは None。"""
    if not d or d.get("action") != "book" or d.get("lines") or not d.get("account"):
        return None
    return (d["account"], d.get("sub") or "", d.get("tax") or "")


def from_answers(decisions: dict, rows_by_bank: dict, chart: dict, existing_rules=()) -> dict:
    """回答から銀行ルールの候補（作者 2026-10-23：同じ相手に毎月同じ答えを書かせない）。learn と同じ形。

    回答の鍵は明細の指紋（bank.Row.key）なので、明細の行に当てて摘要を取る。摘要の群（key_of）ごとに：
      · 回答が **2 か月以上**あり、すべて「仕訳する」で同じ科目・補助・税区分 → 候補
      · 群の中に違う答え（別の科目・内訳・「処理済み」）がある → 候補にしない（split に。どちらかを推測で選ばない）
      · 給与・社保・税（締めが計算から照合する）と仮払金・仮受金（決まっていない）は候補にしない
      · ルールの字は元の摘要に当たり、群の外の摘要には当たらないもの（rule_text）
    根拠（evidence）がすべての回答で同じなら、ルールにも写す（「賃貸借契約書」など）。"""
    from .bank import rule_hits
    have =[(r.get("when") or {}).get("desc_contains", "") for r in existing_rules or []]
    groups = defaultdict(list)
    for bid, rows in rows_by_bank.items():
        for r in rows:
            d = decisions.get(r.key())
            if d:
                groups[(bid, "in" if r.signed > 0 else "out", key_of(r.desc))].append((r, d))
    rules, split = [], []
    for (bid, direction, k), items in sorted(groups.items()):
        if len(k) < 2 or any(k in h or h in k for h in have if h):
            continue
        shapes = {_answer_shape(d) for _, d in items}
        books = [(r, d) for r, d in items if _answer_shape(d)]
        if not books:
            continue
        if len(shapes) > 1:
            split.append(dict(bank=bid, direction=direction, desc_contains=k, n=len(items),
                              accounts=sorted({s[0] for s in shapes if s})))
            continue
        acc, sub, tax = next(iter(shapes))
        if any(rule_hits(r, existing_rules or []) for r, _ in books):     # 今のルールが当たる（2 本目は重なりになる）
            continue
        months = {(r.date.year, r.date.month) for r, _ in books}
        if len(months) < MIN_MONTHS or acc in ENGINE_HANDLED or acc in SUSPENSE:
            continue
        text = rule_text(k, [r.desc for r, _ in books], _others(rows_by_bank[bid], direction, k))
        if text is None:
            continue
        evs = {str(d.get("evidence") or "") for _, d in books}
        books.sort(key=lambda x: x[0].date)
        rules.append(dict(bank=bid, direction=direction, desc_contains=text, account=acc, sub=sub, tax=tax,
                          n=len(books), months=len(months), known=acc in chart, source="answers",
                          evidence=next(iter(evs)) if len(evs) == 1 else "",
                          examples=[f"{r.date} {r.desc} {r.signed:+,}" for r, _ in books[-3:]]))
    rules.sort(key=lambda x: (-x["n"], x["desc_contains"]))
    return dict(rules=rules, split=split, source="answers")
