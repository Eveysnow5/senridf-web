# -*- coding: utf-8 -*-
"""事項の「分析」に添える推論（作者 2026-10-10：常見の原因を反推する）。

推論は**候補を示すだけ**で、仕訳も回答もしない（記帳依拠規則：性質は推測で決めない）。どれも帳簿と明細から
計算で出せるものだけ（言語モデルは使わない）：
  · 銀行明細（ルール無し）：同じ摘要の過去の明細と、その時の科目／振込先が個人らしいか
  · 予定の支払が無い：期限の後に同額の明細があるか（遅れて払った可能性）
  · 社保の金額が違う：差額が、誰か一人の標準報酬月額を 1〜2 等級動かした場合の差と一致するか
各推論は {"ja","zh","en"} の三言語の一文。
"""
from __future__ import annotations

import copy
import dataclasses
import datetime
import re
from collections import Counter

from . import payroll

TRANSFER = ("ﾌﾘｺﾐ", "振込", "ﾌﾘｺﾐ ")
CORP = ("ｶ)", "(ｶ", "ｶﾌﾞｼｷ", "ﾕ)", "(ﾕ", "ｲ)", "(ｲ", "ｼﾔ)", "ｼﾞﾑｼﾖ", "ｾﾞｲ)", "ｶﾞﾂｺｳ", "ﾎｳｼﾞﾝ", "ｷﾖｳｶｲ",
        "ｸﾐｱｲ", "ｷﾞﾝｺｳ", "ｼﾔｶｲ", "ﾄﾞ)", "ｾﾞｲﾑｼﾖ", "ｶ-ﾄﾞ", "ｼﾔｶｲﾎｹﾝ", "ﾈﾝｷﾝ", "ｼﾔｸｼﾖ")
HANKANA_NAME = re.compile(r"^[ｦ-ﾟ]+( [ｦ-ﾟ]+)?$")


def _h(zh, ja, en):
    return {"zh": zh, "ja": ja, "en": en}


def _y(n):
    return f"{int(n):,}"


def looks_personal(desc: str) -> bool:
    """振込先が個人の名前らしいか（半角カナの姓名だけ、法人・役所の印が無い）。"""
    d = desc
    for t in ("パソコン振込", "ﾌﾘｺﾐ", "振込"):
        if t in d:
            d = d.split(t, 1)[1]
            break
    else:
        return False
    d = d.strip()
    return bool(d) and not any(c in d for c in CORP) and bool(HANKANA_NAME.match(d))


def _rows(res):
    return [r for rows in res.all_bank_rows.values() for r in rows]


def bank_row(led, res, p):
    rows = _rows(res)
    row = next((r for r in rows if r.key() == p.key), None)
    if row is None:
        return []
    out = []
    same = [r for r in rows if r.desc == row.desc and r.id != row.id]
    if same:
        ids = {r.id for r in same}
        accs = Counter(l.account for v in led.vouchers if getattr(v, "bank_row", None) in ids
                       for l in v.lines if l.account not in ("普通預金", "当座預金", "仮払金", "仮受金"))
        last = max(r.date for r in same)
        if accs:
            acc = "、".join(a for a, _ in accs.most_common(2))
            out.append(_h(f"同名流水还有 {len(same)} 笔（最近 {last}），以前记在「{acc}」——同一性质的话可沿用",
                          f"同じ摘要の明細がほかに {len(same)} 件（最近 {last}）、以前は「{acc}」で仕訳——同じ性質なら同じ科目",
                          f"{len(same)} other rows with this description (latest {last}), booked to “{acc}” before"))
        else:
            out.append(_h(f"同名流水还有 {len(same)} 笔（最近 {last}），都还没入账",
                          f"同じ摘要の明細がほかに {len(same)} 件（最近 {last}）、いずれも未仕訳",
                          f"{len(same)} other rows with this description (latest {last}), none booked yet"))
    else:
        out.append(_h("流水里没有其他同名的收付——第一次出现的对象", "明細に同じ摘要はほかに無い——初めての相手",
                      "No other row with this description — a new counterparty"))
    if row.outflow and looks_personal(row.desc):
        out.append(_h("收款人看起来是个人：如果是报酬（设计・咨询・翻译等），要扣 10.21% 源泉并在次月 10 日（或纳期特例）缴纳；"
                      "如果是借给个人或代垫，记貸付金或立替金",
                      "振込先は個人のようです：報酬（デザイン・顧問・翻訳など）なら 10.21% の源泉徴収と翌月 10 日（または納期の特例）の納付が必要。"
                      "個人への貸付・立替なら貸付金・立替金",
                      "The payee looks like an individual: a fee (design, advice, translation…) needs 10.21% withholding paid by the "
                      "10th of next month; a loan or advance goes to 貸付金 / 立替金"))
    if row.amount_abs % 10000 == 0:
        out.append(_h("金额是万元整数——更像借款、押金或预付，不像按单据结算的费用",
                      "金額が万円単位の端数なし——請求書払いより、貸付・預け金・前払いに多い形",
                      "A round amount — more typical of a loan, deposit or advance than an invoice"))
    return out


def missing(led, res, p):
    d = p.data or {}
    if "due" not in d:
        return []
    due = datetime.date.fromisoformat(d["due"])
    out_dir = d.get("direction") == "out"
    rows = _rows(res)
    later = [r for r in rows if r.date > due + datetime.timedelta(days=d.get("window", 3))
             and r.amount_abs == d["expected"] and r.outflow == out_dir]
    if later:
        r = later[0]
        return [_h(f"{r.date} 有一笔同额{'支出' if out_dir else '收入'} {_y(r.amount_abs)}（{r.desc}）——可能是晚付了；"
                   f"如果是，这笔会在那个月入账，这里回答「已处理」并写明即可",
                   f"{r.date} に同額の{'出金' if out_dir else '入金'} {_y(r.amount_abs)}（{r.desc}）があります。遅れて払った可能性があります。"
                   f"そうならその月に仕訳されるので、ここは「処理済み」で理由を書いてください",
                   f"On {r.date} there is a {'payment' if out_dir else 'receipt'} of the same amount {_y(r.amount_abs)} "
                   f"({r.desc}) — possibly paid late; if so it is booked in that month, answer this one as done")]
    # 銀行を通らない納付（他の口座・立替）を調整仕訳で入れていれば、それを示す（差があれば差も）
    kind = p.key.split(":")[1]
    word = {"gensen": "源泉", "jumin": "住民税", "shaho": "社会保険料"}.get(kind)
    if word and out_dir:
        near = []
        for v in led.vouchers:
            if v.kind != "adjustment" or not (due - datetime.timedelta(days=20) <= v.date <= due + datetime.timedelta(days=40)):
                continue
            amt = sum(int(l.debit) for l in v.lines
                      if l.account in ("預り金", "未払費用", "未払金") and word in (l.sub or ""))
            if amt:
                near.append((v, amt))
        if near:
            v, amt = near[0]
            dif = amt - d["expected"]
            tail = (_h("", "", "") if dif == 0 else
                    _h(f"，比应缴 {_y(d['expected'])} 差 {dif:+,}", f"、予定 {_y(d['expected'])} との差 {dif:+,}",
                       f", {dif:+,} against the expected {_y(d['expected'])}"))
            return [_h(f"调整分录 {v.date} 记了这笔缴款 {_y(amt)}（{v.narration}）{tail['zh']}——是从银行以外付的；"
                       f"金额一致就回答「已处理」",
                       f"調整仕訳 {v.date} にこの納付 {_y(amt)}（{v.narration}）がある{tail['ja']}——銀行以外での支払。"
                       f"金額が合っていれば「処理済み」で回答",
                       f"An adjusting entry on {v.date} records this payment {_y(amt)} ({v.narration}){tail['en']} — "
                       f"paid outside the bank; if the amount is right, answer done")]
    # 明細が期限の日に届いていない予定は「明細に無い」にならない（close：明細の期間の要確認にまとめる）ので、
    # ここに来るのは明細が期限を過ぎている場合だけ
    last = max((r.date for r in rows), default=None)
    if last:
        return [_h(f"到流水最后一天 {last} 都没有同额的{'支出' if out_dir else '收入'}——可能是从别的账户付的，或者还没付",
                   f"明細の最終日 {last} まで同額の{'出金' if out_dir else '入金'}は無い——別の口座で払ったか、未払い",
                   f"No {'payment' if out_dir else 'receipt'} of that amount up to the last statement day {last} — "
                   f"paid from another account, or not paid yet")]
    return []


def shaho_mismatch(led, res, p):
    """差額が、誰か一人の標準報酬月額を 1〜2 等級動かした場合の差（告知額の総額）と一致するか。"""
    d = p.data or {}
    if "bank_amount" not in d:
        return []
    diff = d["bank_amount"] - d["expected"]
    month = datetime.date.fromisoformat(p.key.split(":")[-1] + "-01")
    co, rates = led.co, led.rates
    grades = rates.smr_grades()
    base = payroll.notice(co, rates, month)
    if base is None:
        return []
    total = lambda n: n.health + n.pension + n.contribution
    for e in co.employees:
        s = e.smr_for(month)
        if not e.insured_for(month) or not s or s[1] not in grades:
            continue
        i = grades.index(s[1])
        for step in (1, -1, 2, -2):
            if not 0 <= i + step < len(grades):
                continue
            new = grades[i + step]
            e2 = dataclasses.replace(e, smr=sorted(list(e.smr) + [(month, new, None)]))
            co2 = copy.copy(co)
            co2.employees = [e2 if x.id == e.id else x for x in co.employees]
            n2 = payroll.notice(co2, rates, month)
            if n2 is not None and total(n2) - total(base) == diff:
                return [_h(f"差额 {diff:+,} 正好等于 {e.id} 的标准报酬月额从 {_y(s[1])} 调到 {_y(new)} 的影响——"
                           f"可能做了随时改定或定时决定，请对照标准报酬决定通知书，在「标准报酬」表加上新月额",
                           f"差 {diff:+,} は {e.id} の標準報酬月額が {_y(s[1])} → {_y(new)} に変わった場合とちょうど一致——"
                           f"随時改定・定時決定の可能性。決定通知書と照合し「标准报酬」表に新しい月額を",
                           f"The difference {diff:+,} equals {e.id}'s standard remuneration moving from {_y(s[1])} to "
                           f"{_y(new)} — possibly a revision; check the notice and add the new amount")]
    return [_h(f"差额 {diff:+,} 不能用某一位员工的标准报酬上下调 1–2 档来解释——请检查资格取得丧失、介护保险年龄或费率",
               f"差 {diff:+,} は誰か一人の標準報酬月額を 1〜2 等級動かしても説明できない——資格の得喪・介護の年齢・料率を確認",
               f"The difference {diff:+,} is not explained by one person moving 1–2 grades — check joins/leaves, care "
               f"insurance age or rates")]


# 摘要の頭の「振込の種類」の語（相手の名前ではない）。これを除いた残りを「相手」とみなして似た明細を探す
_PREFIXES = ("パソコン振込", "ﾊﾟｿｺﾝ ﾌﾘｺﾐ", "ﾌﾘｺﾐ", "振込", "PE ", "MHF)", "ｶ-ﾄﾞ", "ｶｰﾄﾞ", "ﾃﾞﾋﾞｯﾄ", "IB ", "CT ", "ATM")


def _core(desc: str) -> str:
    d = (desc or "").replace("　", " ").strip()        # 全角の空白（「振込　ﾖｳ ｾﾂ」）
    changed = True
    while changed:
        changed = False
        for t in _PREFIXES:
            if d.startswith(t):
                d, changed = d[len(t):].strip(), True
    return " ".join(d.split())


def suggest(led, res, p) -> dict | None:
    """回答の下書き（smart_importer の考え方：既にある仕訳を手本にする。作者 2026-10-10）。

    ルールか回答で仕訳済みの過去の明細のうち、**同じ摘要**（無ければ振込の種類の語を除いた**同じ相手**）・同じ向きの
    ものの相手科目を数え、いちばん多いものを返す。機械学習は使わない（1 社の明細は数十件、根拠を言える方がよい）。
    返すのは下書きだけ——仕訳はしない（利用者が確かめて保存したときに回答になる）。"""
    rows = _rows(res)
    row = next((r for r in rows if r.key() == p.key), None)
    if row is None:
        return None
    co = led.co
    skip = {b["account"] for b in co.bank_accounts} | {"仮払消費税等", "仮受消費税等", "仮払金", "仮受金"}
    # 手本：ルール・回答で仕訳した明細と、予定（給与振込・納付）に当てた明細。予定の仕訳は bank_row を持たないので
    # 証憑の参照「銀行明細 <ファイル:行>」で引く（認領の印 claimed_by は月ごとに明細を読み直すので過去の月には残らない）
    booked = {v.bank_row: v for v in led.vouchers if v.kind in ("bank_rule", "decision") and getattr(v, "bank_row", "")}
    by_ev = {v.evidence: v for v in led.vouchers if v.kind in ("payout", "payment") and v.evidence}
    for r in rows:
        v = by_ev.get(f"銀行明細 {r.label}")             # 一致で引く（「…:5」が「…:50」に当たらない）
        if r.id not in booked and v is not None and v.date == r.date:
            booked[r.id] = v

    def counterpart(v):
        ls = [l for l in v.lines if l.account not in skip]
        if len(ls) != 1:                       # 内訳が複数（家賃＋手数料など）は手本にしない
            return None
        return (ls[0].account, ls[0].sub or "", ls[0].tax or "")

    core = _core(row.desc)
    for basis, same in (("same", lambda r: r.desc == row.desc),
                        ("similar", lambda r: core and _core(r.desc) == core)):
        tier = [r for r in rows if r.id in booked and r.id != row.id and bool(r.outflow) == bool(row.outflow) and same(r)]   # outflow は出金額（向きは真偽で比べる）
        cps = Counter(c for c in (counterpart(booked[r.id]) for r in tier) if c)
        if not cps:
            continue
        # 手本が**全部同じ科目**のときだけ下書きにする。同じ摘要が複数の科目・相手になっていた（「ｷﾕｳﾖ ﾌﾘｺﾐ」が三人分の
        # 給与振込、など）なら、摘要からはどれか分からない——回数や金額の近さで選ぶと外れる（架空の 3 人で確かめた）
        # ので、候補を並べて下書きは入れない
        ranked = cps.most_common()
        (acc, sub, tax), n = ranked[0]
        alts = [dict(account=c[0], sub=c[1], tax=c[2], n=k) for c, k in ranked][:4]
        hit = [r for r in tier if counterpart(booked[r.id]) == (acc, sub, tax)]
        last = max(hit, key=lambda r: r.date)
        amounts = sorted({r.amount_abs for r in hit})
        # 金額が手本と桁違い（2 倍超・半分未満）なら、同じ相手でも別の取引の可能性が高い（給与の振込先に立替の精算が
        # 来た、など。実在の会社の回答で確かめた）→ 下書きを入れず、注意だけ出す
        far = not (min(amounts) / 2 <= row.amount_abs <= max(amounts) * 2)
        return dict(account=acc, sub=sub, tax=tax, n=n, of=len(tier), basis=basis,
                    last=str(last.date), last_desc=last.desc, amounts=amounts[-3:], far=far,
                    alts=alts, ambiguous=len(alts) > 1)
    return None


def for_pending(led, res, p) -> list[dict]:
    try:
        if p.category == "bank_unmatched":
            return bank_row(led, res, p)
        if p.key.startswith("missing:"):
            return missing(led, res, p)
        if p.key.startswith("mismatch:shaho:"):
            return shaho_mismatch(led, res, p)
    except Exception:                      # 推論は補助：失敗しても締めを止めない（分析欄が空になるだけ）
        import traceback
        traceback.print_exc()
    return []
