# -*- coding: utf-8 -*-
"""証憑（索引簿の確認済の行）を帳簿につなぐ（作者 2026-10-10）。close_month から月ごとに呼ぶ。

使うのは**確認済**の行だけ（下書きは帳簿に影響しない）。行の行き先は 3 通り：

  1. 引擎が自分で計算した支払の根拠になる書類（テンプレートで種類と対象月が分かるもの）
       · 社会保険料の領収済通知書（nenkin_hokenryo）：対象月の告知額（計算値）と等しいか。等しければ
         その月の納付の伝票の証憑欄に連番を足す。違えば「金額の不一致」
       · 勤務時間集計表（会社のテンプレート、template=kinmu_jikan）：その人・その月の給与の入力（支給の合計）と
         等しいか。入力が無ければ payroll_missing の要確認が出ている（画面で下書きにする）
  2. 照合先（銀行明細の指紋）がある行：その明細から作った伝票の証憑欄に連番を足す
  3. それ以外：evmatch で明細を探す。ちょうど 1 行なら自動で付ける（帳簿の証憑欄に「自動照合」と書く。索引簿へ
     書き戻すのは画面）。複数なら選ばせる。明細に無ければ、同じ月の**調整仕訳**（立替などを会計担当者が手で入れた
     もの）で金額が等しいものを探す——1 枚 ↔ 1 本、または複数枚の合計 ↔ 1 本で、組合せが**一つだけ**なら付ける
     （既に仕訳してある立替を、もう一度「誰が払ったか」と聞くと二重計上の元になる。実在の会社で発見、2026-10-10）。
     税抜経理の会社では、前の月の調整仕訳は記帳の時に本体と仮払消費税等の行に分かれている。書類の額は税込
     なので、「行」は分かれる前の 1 行（本体＋すぐ後ろの税の行）に戻して比べる（_gross_lines）。
     それでも無ければ「銀行明細に無い証憑」——誰が払ったかを回答してもらう：
       decisions.yaml の evidence:<連番> に action: book（account・tax・credit・credit_sub）→ 費用／未払金（立替者）
       などの仕訳。使わなかった書類（全期で払った分割の納付書）は action: done と理由。
"""
from __future__ import annotations

import re
import unicodedata

from . import evidence as ev, evmatch
from .core.model import Voucher
from .pending import Pending

NENKIN, KINMU = "nenkin_hokenryo", "kinmu_jikan"
KEY = "evidence:"
CHOOSE_KEY = "evidence_choose:"
DIFF_KEY = "evidence_diff:"

def _name(s: str) -> str:
    """名前の比較用：NFKC・空白と中点を除く・括弧の注記（「（兼職・時給 1,300）」など）を除く。
    簡体字と繁体字の違いは字の表で吸収しない（名簿の names に書類の書き方を書く）。"""
    s = re.sub(r"[（(][^）)]*[）)]", "", unicodedata.normalize("NFKC", s or ""))
    return re.sub(r"[\s・]", "", s)


def employee_for(co, name: str):
    n = _name(name)
    for x in co.employees:
        if n and n in {_name(x.display), _name(x.id), *(_name(a) for a in getattr(x, "names", []))}:
            return x
    return None


def _tag(v: Voucher, e: ev.Entry, how: str = ""):
    t = f"証憑#{e.no}{how}"
    if t not in v.evidence:
        v.evidence = f"{v.evidence}／{t}" if v.evidence else t


def _link(led, e: ev.Entry, r, auto: bool):
    """どの証憑がどの明細に付いたか（画面の証憑の一覧の「対応する明細」に出す）。自動照合は索引簿に書き戻して
    いないので、ここで覚えておかないと画面には「—」としか出ない（2026-10-12 の利用者試験）。"""
    led.__dict__.setdefault("ev_links", {})[e.no] = dict(date=str(r.date), desc=r.desc, amount=r.signed, auto=auto)


def _in_month(d, start, end):
    return d is not None and start <= d <= end


def apply(led, month, start, end, rows_by_bank, new: list):
    co = led.co
    ix: ev.Index | None = getattr(co, "evidence", None)
    if not ix or not ix.entries:
        return
    pb = led.pending
    rows = [r for rs in rows_by_bank.values() for r in rs]
    by_key = {r.key(): r for r in rows}
    by_row = {}
    for v in list(led.vouchers) + new:
        if v.bank_row:
            by_row.setdefault(v.bank_row, v)
    ym = f"{month:%Y-%m}"
    loose = []
    for e in ix.entries:
        if e.status != ev.CONFIRMED:
            continue
        tpl = e.fields.get("template", "")
        # ---- 1 引擎の計算と突き合わせる書類
        if tpl == NENKIN:
            # 告知額の照合は対象月に、伝票への連番は納付の伝票ができた月に（対象月の翌月以降に払う）
            n = led.notices.get(month) if e.fields.get("month") == ym else None
            if n is not None and n.total != e.amount:
                pb.add(Pending(f"{DIFF_KEY}{e.no}", "amount_mismatch", f"証憑#{e.no}：社会保険料の告知額が計算と違う",
                               f"{ym}分の告知額は書類 {e.amount:,} 円、計算 {n.total:,} 円（差 {e.amount - n.total:+,}）。"
                               f"標準報酬月額・資格の得喪・料率を確認する",
                               date=end, amount=e.amount))
            for v in new:
                if v.kind == "payment" and f"納入告知書 {e.fields.get('month')}分" in v.evidence:
                    _tag(v, e)
            continue
        if tpl == KINMU and e.fields.get("month") == ym:
            emp = employee_for(co, e.party)
            if emp is None:
                pb.add(Pending(f"{DIFF_KEY}{e.no}", "payroll", f"証憑#{e.no}：勤務時間集計表の人が名簿に無い",
                               f"「{e.party}」に当たる従業員が名簿（employees.yaml）に無い。名簿のその人に names: "
                               f"[{e.party}] を足す（書類の書き方）か、索引簿の取引先を名簿の表示名にする", date=end))
                continue
            items = ((co.monthly_input(month).get("employees") or {}).get(emp.id) or {}).get("items") or {}
            paid = sum(int(x or 0) for x in items.values())
            if items and paid != e.amount:
                pb.add(Pending(f"{DIFF_KEY}{e.no}", "amount_mismatch", f"証憑#{e.no}：勤務時間集計表と給与の入力が違う",
                               f"{emp.id} の {ym} の支給は入力 {paid:,} 円、勤務時間集計表 {e.amount:,} 円"
                               f"（差 {e.amount - paid:+,}）", date=end, amount=e.amount))
            for v in new:
                if v.kind == "payroll" and f"給与 {emp.display}" in v.narration:
                    _tag(v, e)
            continue
        # ---- 2 照合先のある行
        if e.bank:
            r = by_key.get(e.bank)
            if r is not None and r.id in by_row:
                _tag(by_row[r.id], e)
                _link(led, e, r, auto=False)
            continue
        # ---- 3 この月の日付の、照合先の無い行
        if _in_month(e.date, start, end) and tpl not in (NENKIN, KINMU):
            loose.append(e)
    if not loose:
        return
    sub = ev.Index(entries=loose)
    nobank = []
    taken = {x.bank for x in ix.entries if x.bank and x.status != ev.VOID}
    free = [r for r in rows if r.key() not in taken]
    for o in evmatch.match(sub, free, direction_of=direction):
        e = next(x for x in loose if x.no == o.no)
        key = f"{KEY}{e.no}"
        if o.status == "auto":
            r = by_key[o.candidates[0].bank_key]
            if r.id in by_row:
                _tag(by_row[r.id], e, "（自動照合）")
                _link(led, e, r, auto=True)
            continue
        if o.status == "choose":
            pb.add(Pending(f"{CHOOSE_KEY}{e.no}", "evidence", f"証憑#{e.no}：同じ金額の明細が複数",
                           f"{e.date} {e.party} {e.amount:,} 円。候補："
                           + "、".join(f"{c.date} {c.desc}" for c in o.candidates[:5])
                           + "。画面で付ける明細を選ぶ（索引簿の照合先に書く）",
                           date=e.date, amount=e.amount,
                           data=dict(no=e.no, candidates=[c.bank_key for c in o.candidates[:5]])))
            continue
        nobank.append((e, o))
    nobank = _to_adjustments(nobank, list(led.vouchers) + new)
    for e, o in nobank:
        key = f"{KEY}{e.no}"
        # none：銀行明細にも調整仕訳にも無い
        d = co.decisions.get(key)
        p = pb.add(Pending(key, "evidence", f"証憑#{e.no}：銀行明細に無い（{e.party} {e.amount:,} 円）",
                           f"{e.date} {e.party} {e.amount:,} 円（{e.doc or '書類'}）に当たる銀行明細が無い。"
                           f"誰がどう払ったか（立替・現金・カード・別の口座）を回答し、科目を決める。"
                           f"使わなかった書類（全期で納めた分割の納付書など）なら「処理済み」と理由",
                           date=e.date, amount=e.amount,
                           data=dict(no=e.no, party=e.party, doc=e.doc,
                                     groups=[dict(g, bank_key=g["bank_key"]) for g in o.groups][:3])))
        if (d and d.get("action") == "book" and d.get("lines")
                and sum(int(l["amount"]) for l in d["lines"]) != e.amount):
            pb.add(Pending(f"decision_sum:{key}", "amount_mismatch", f"証憑#{e.no}：回答の内訳が証憑と合わない",
                           f"内訳の合計 {sum(int(l['amount']) for l in d['lines']):,} ≠ 証憑 {e.amount:,}。"
                           f"lines を直す（この証憑は仕訳していない）", date=e.date, amount=e.amount))
            led.rejected.add(key)
            d = None
        if d and d.get("action") == "book":
            p.resolved_by = d
            new.append(booked(e, d, key))
        elif d:
            p.resolved_by = d


ALL = "all"
ADJ_DAYS = 40                                    # 証憑の日付と調整仕訳の日付の差（立替の精算は月末にまとめることが多い）
MAX_GROUP = 6


def _amount(v: Voucher) -> int:
    return int(sum(l.debit for l in v.lines))


def _gross_lines(v: Voucher) -> list:
    """借方の行を、税抜経理で分かれる前の姿（税込）で返す：[(番号, 税込の額)]。番号は貸方も含めた「分かれる前の
    行」の通し番号で、記帳の前後で変わらない（split_voucher は本体のすぐ後ろに税の行を足すだけ）。
    使い済みはこの番号で覚える——実際の行番号で覚えると、記帳で前の行が分かれた時に別の行を指す。"""
    from .jp.shouhi import INPUT_TAX, OUTPUT_TAX
    out, n = [], -1
    for l in v.lines:
        if l.account in (INPUT_TAX, OUTPUT_TAX) and l.memo == "税抜経理" and n >= 0:
            if l.debit and out and out[-1][0] == n:
                out[-1] = (n, out[-1][1] + int(l.debit))
            continue
        n += 1
        if l.debit:
            out.append((n, int(l.debit)))
    return out


def _to_adjustments(nobank: list, vouchers: list) -> list:
    """明細に無い証憑を、前後 ADJ_DAYS 日の調整仕訳（前の月に入れたものも）に当てる。当たったものは伝票に連番を
    書き、残りを返す。どれも「一つだけ」のときだけ付ける：
      1 枚 ↔ 1 本（借方合計）／ 残りの組合せ（2〜MAX_GROUP 枚）の合計 ↔ 1 本 ／ 1 枚 ↔ 1 本の中の借方の 1 行 ／
      組合せの合計 ↔ 借方の 1 行（按分や手数料で 1 本の合計が書類と違っても、書類の額か書類の合計がそのまま
      1 行になっていることが多い：電気＋水道を 1 行、払込手数料は別の行）"""
    import itertools
    near = lambda e, v: e.date is not None and abs((v.date - e.date).days) <= ADJ_DAYS
    # 使った分を伝票に覚える（月をまたいで）：ALL＝1 本まるごと説明済み、数字＝その行だけ説明済み。
    # 覚えないと、合計で埋まった 2 月の伝票の 200 円の行に、3 月の 200 円の領収書が付く（実在の会社で発見）
    used = lambda v: v.__dict__.setdefault("_ev_used", set())
    adj = [v for v in vouchers if v.kind == "adjustment" and not used(v)]
    left = list(nobank)
    for e, o in list(left):
        cands = [v for v in adj if _amount(v) == e.amount and near(e, v)]
        rivals = [x for x, _ in left if x is not e and x.amount == e.amount and cands and near(x, cands[0])]
        if len(cands) == 1 and not rivals:
            _tag(cands[0], e, "（調整仕訳に照合）")
            used(cands[0]).add(ALL)
            adj.remove(cands[0])
            left.remove((e, o))
    for v in list(adj):
        pool = [(e, o) for e, o in left if near(e, v) and e.amount and e.amount < _amount(v)]
        hits = []
        for n in range(2, min(MAX_GROUP, len(pool)) + 1):
            for combo in itertools.combinations(pool, n):
                if sum(e.amount for e, _ in combo) == _amount(v):
                    hits.append(combo)
                    if len(hits) > 1:
                        break
            if len(hits) > 1:
                break
        if len(hits) == 1:
            for e, o in hits[0]:
                _tag(v, e, "（調整仕訳に照合・合計）")
                left.remove((e, o))
            used(v).add(ALL)
            adj.remove(v)
    free = lambda v, i: ALL not in used(v) and i not in used(v)
    lines = [(v, i, a) for v in vouchers if v.kind == "adjustment" for i, a in _gross_lines(v)]
    for e, o in list(left):
        cands = [(v, i) for v, i, a in lines if a == e.amount and near(e, v) and free(v, i)]
        rivals = [x for x, _ in left if x is not e and x.amount == e.amount and cands and near(x, cands[0][0])]
        if len(cands) == 1 and not rivals:
            v, i = cands[0]
            _tag(v, e, "（調整仕訳の行に照合）")
            used(v).add(i)
            left.remove((e, o))
    # 複数枚の合計が 1 行（電気＋水道を 1 行の水道光熱費で入れた等）。組合せが一つだけのとき
    for v, i, a in lines:
        if not free(v, i):
            continue
        pool = [(e, o) for e, o in left if near(e, v) and e.amount and e.amount < a]
        hits = []
        for n in range(2, min(MAX_GROUP, len(pool)) + 1):
            for combo in itertools.combinations(pool, n):
                if sum(e.amount for e, _ in combo) == a:
                    hits.append(combo)
                    if len(hits) > 1:
                        break
            if len(hits) > 1:
                break
        if len(hits) == 1:
            for e, o in hits[0]:
                _tag(v, e, "（調整仕訳の行に照合・合計）")
                left.remove((e, o))
            used(v).add(i)
    return left


def direction(e: ev.Entry) -> str:
    """支払の証憑（既定）か、受取の証憑（還付の送金通知など：読取値 direction=in）か。"""
    return "in" if e.fields.get("direction") == "in" else "out"


def booked(e: ev.Entry, d: dict, key: str) -> Voucher:
    """銀行を通らない取引の仕訳。支払：account（費用など）／ credit（未払金：立替者 など）。
    受取（direction=in）：credit 側の科目（現金・未収入金など）／ account。"""
    v = Voucher(e.date, d.get("memo") or f"{e.party} {e.doc}".strip(), kind="decision",
                evidence=f"証憑#{e.no}",
                derivation=[f"会計担当者の回答（decisions.yaml {key}）：{d.get('reason', '')}"])
    parts = [(l["account"], int(l["amount"]), l.get("sub", ""), l.get("tax", "")) for l in d["lines"]] \
        if d.get("lines") else [(d["account"], e.amount, d.get("sub", ""), d.get("tax", ""))]
    if direction(e) == "in":
        v.add(d["credit"], debit=e.amount, sub=d.get("credit_sub", ""))
        for acc, a, sub, tax in parts:
            v.add(acc, credit=a, sub=sub, tax=tax, memo=e.party)
        return v
    for acc, a, sub, tax in parts:
        v.add(acc, debit=a, sub=sub, tax=tax, memo=e.party)
    v.add(d["credit"], credit=e.amount, sub=d.get("credit_sub", ""))
    return v
