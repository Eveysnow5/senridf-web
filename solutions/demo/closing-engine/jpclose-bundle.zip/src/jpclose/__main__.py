# -*- coding: utf-8 -*-
"""コマンドライン。

    python -m jpclose close   <会社ディレクトリ> <YYYY-MM> [--out 底稿.xlsx] [--today YYYY-MM-DD] [--lang zh|ja]
    python -m jpclose answers <会社ディレクトリ> <YYYY-MM>     # 未回答の銀行明細の回答ひな形を出す

終了コード：チェックがすべて合格 0、不合格・未検査あり 1、設定の誤り 2。
"""
from __future__ import annotations

import argparse
import datetime
import pathlib
import sys

if hasattr(sys.stdout, "reconfigure"):
    sys.stdout.reconfigure(encoding="utf-8", errors="replace")

from . import close, company, report
from .core import checks as C


def _month(s):
    y, m = s.split("-")
    return datetime.date(int(y), int(m), 1)


def main(argv=None):
    ap = argparse.ArgumentParser(prog="jpclose")
    sub = ap.add_subparsers(dest="cmd", required=True)
    for name in ("close", "answers"):
        p = sub.add_parser(name)
        p.add_argument("company")
        p.add_argument("month")
        p.add_argument("--today")
        if name == "close":
            p.add_argument("--out")
            p.add_argument("--lang", default="zh", choices=("zh", "ja"),
                           help="底稿の言語。既定は中国語（作者の決定 A1：在日華人企業が主な顧客）")
    a = ap.parse_args(argv)
    try:
        co = company.load(a.company)
    except company.CompanyError as e:
        print(f"設定の誤り：{e}")
        return 2
    month = _month(a.month)
    today = datetime.date.fromisoformat(a.today) if a.today else datetime.date.today()
    led = close.run(co, month, today=today)
    res = led.results[-1]

    if a.cmd == "answers":
        print("# decisions.yaml に貼り付けて、account / tax / evidence / reason を埋める")
        print("decisions:")
        for p in led.pending.open_items():
            if p.category in ("bank_unmatched", "bank_ambiguous"):
                print(f'  "{p.key}":')
                print(f"    action: book        # {p.qid} {p.title} {p.amount:+,} 円")
                print("    account: ")
                print("    tax: ")
                print("    evidence: ")
                print("    by:                 # 判断者（必須・作者の決定 A3）")
                print(f"    at: {today}       # 判断日（必須）")
                print("    reason: ")
        return 0

    stem = "工作底稿" if a.lang == "zh" else "作業底稿"
    out = pathlib.Path(a.out) if a.out else co.root / "out" / f"{stem}_{month:%Y-%m}.xlsx"
    out.parent.mkdir(parents=True, exist_ok=True)
    summary = report.write(led, month, out, lang=a.lang)
    print(f"{co.name}  {month:%Y-%m}")
    for c in res.report.checks:
        mark = {C.PASS: "OK  ", C.FAIL: "NG  ", C.SKIP: "SKIP"}[c.status]
        print(f"  {mark} [{c.id}] {c.name}（{c.n_checked}）")
        if c.status != C.PASS:
            for d in c.details[:5]:
                print(f"         - {d}")
    print(f"  {res.report.summary()}")
    print(f"  要確認 未回答 {summary['open']} 件 / 全 {summary['pending']} 件")
    print(f"  底稿 {out}")
    return 0 if res.report.ok else 1


if __name__ == "__main__":
    sys.exit(main())
