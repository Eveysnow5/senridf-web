# -*- coding: utf-8 -*-
"""伝票モデル。

一つの伝票（仕訳）は複数行。各行は借方か貸方のどちらか一方に金額を持つ。
金額は Decimal（円）。

**推導チェーン（derivation）と証憑（evidence）を伝票に持たせる**のがこの製品の要点。
会計担当者が「なぜこの額か」を、法令の条文・公表料率・入力データの行まで辿れること。
証憑が無い伝票は「自制（計算表）」か「⚠ 未登録」かを区別して示す——空欄にしない。
空欄だと「紙が存在しない」と「登録し忘れ」が見分けられない。
"""
from __future__ import annotations

import datetime
from dataclasses import dataclass, field
from decimal import Decimal

ZERO = Decimal(0)


@dataclass(frozen=True)
class Line:
    account: str                 # 勘定科目（科目表のコード名）
    debit: Decimal = ZERO
    credit: Decimal = ZERO
    sub: str = ""                # 補助科目（取引先・従業員 id・税目 …）
    tax: str = ""                # 消費税区分（課税仕入10% / 対象外 …）。空なら科目の既定
    memo: str = ""

    def __post_init__(self):
        if self.debit and self.credit:
            raise ValueError(f"{self.account}: 一行に借方と貸方の両方がある")
        if self.debit < 0 or self.credit < 0:
            raise ValueError(f"{self.account}: 負の金額（反対側に書くこと）")


@dataclass
class Voucher:
    date: datetime.date
    narration: str
    lines: list = field(default_factory=list)
    vno: int | None = None                  # 採番は close の最後に一括で
    kind: str = ""                          # payroll / payment / bank_rule / accrual / depreciation …
    evidence: str = ""                      # 証憑の参照。自制なら "自制:<計算表名>"
    derivation: list = field(default_factory=list)   # 推導チェーン（文字列のリスト）
    source: str = ""                        # 入力のどこから来たか（ファイル:行）
    # この伝票を生んだ銀行明細の id。証憑欄の文字列で判定してはいけない
    # （ルールの証憑は「賃貸借契約書」等になるので、文字列判定は誤る——実例あり）
    bank_row: str = ""

    @property
    def debit_total(self) -> Decimal:
        return sum((l.debit for l in self.lines), ZERO)

    @property
    def credit_total(self) -> Decimal:
        return sum((l.credit for l in self.lines), ZERO)

    def balanced(self) -> bool:
        return self.debit_total == self.credit_total

    def add(self, account, debit=ZERO, credit=ZERO, **kw):
        """金額 0 の行は作らない（0 円の行は底稿を読みにくくするだけ）。"""
        debit, credit = Decimal(debit), Decimal(credit)
        if debit or credit:
            self.lines.append(Line(account, debit, credit, **kw))
        return self

    def evidence_label(self) -> str:
        if self.evidence:
            return self.evidence
        return "⚠ 未登録"
