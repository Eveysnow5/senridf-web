# -*- coding: utf-8 -*-
"""金額の扱い。**内蔵の round() と float の足し算を金額に使わない。**

理由は二つ（いずれも実際の帳簿で起きた）：

1. float の累加は順序で結果が変わる。円未満の端数を含む帳簿だと、残高がちょうど
   0.5 銭の位置に落ちることがあり、「行ごとに差し引く」と「借方合計−貸方合計」で
   1 銭違う値になる。同じ底稿の二つの表が食い違う。
2. 内蔵 round() は銀行丸め（偶数への丸め）で、会計の四捨五入ではない。

さらに日本の給与・社会保険では端数処理が**法令で個別に決まっている**
（社会保険の被保険者負担分は「50銭以下切捨て・50銭超切上げ」など）。
それぞれ名前のついた関数にして、どの規則で丸めたかを推導チェーンに残す。
"""
from __future__ import annotations

import decimal

D = decimal.Decimal
ONE = D(1)


def dec(x) -> D:
    """float を経由せずに Decimal にする（str 経由）。"""
    if isinstance(x, D):
        return x
    return D(str(x))


def sum_money(values, places: int = 0) -> D:
    """精確に合計してから丸める。順序に依存しない。日本円は places=0。"""
    q = ONE.scaleb(-places)
    t = sum((dec(v) for v in values), D(0))
    return t.quantize(q, rounding=decimal.ROUND_HALF_UP)


def half_up(x, places: int = 0) -> D:
    """四捨五入。"""
    return dec(x).quantize(ONE.scaleb(-places), rounding=decimal.ROUND_HALF_UP)


def truncate(x) -> D:
    """円未満切捨て（0 方向）。"""
    return dec(x).quantize(ONE, rounding=decimal.ROUND_DOWN)


def deduct_half_down(x) -> D:
    """給与から控除する被保険者負担分：**50銭以下切捨て、50銭超切上げ**。

    0.5 ちょうどは切り捨て。四捨五入（0.5 は切上げ）とは 0.5 のときだけ違う。
    出典：協会けんぽ 保険料額表の注記①、厚労省（雇用保険）の同旨の規定。
    """
    return dec(x).quantize(ONE, rounding=decimal.ROUND_HALF_DOWN)


def cash_half_up(x) -> D:
    """被保険者が現金で支払う場合：**50銭未満切捨て、50銭以上切上げ**（＝四捨五入）。"""
    return dec(x).quantize(ONE, rounding=decimal.ROUND_HALF_UP)


ROUNDERS = {
    "deduct_half_down": deduct_half_down,    # 給与控除（既定の法定規則）
    "cash_half_up": cash_half_up,            # 現金徴収
    "truncate": truncate,                    # 労使の特約で切捨てとしている場合
}


def yen(x) -> int:
    """整数円にする。端数があればエラー（黙って丸めない）。"""
    v = dec(x)
    if v != v.to_integral_value():
        raise ValueError(f"{x} は整数円ではない——どの端数規則で丸めるかを明示すること")
    return int(v)


def fmt(v) -> str:
    """失敗メッセージ用。整数なら桁区切り、端数があれば小数 2 桁まで。"""
    v = dec(v)
    if v == v.to_integral_value():
        return f"{int(v):,}"
    return f"{v:,.2f}"
