# -*- coding: utf-8 -*-
"""断言フレームワーク＋会社に依存しない汎用断言。

## 二つの硬い規則

1. **「正解」に依存しない。** 構造上の制約か、再計算できる導出だけで判定する。
   人が確認した値でしか正誤が決まらないものは断言ではなく baseline で、次の伝票では無効。
2. **検査対象 0 件は通過ではなく SKIP。** 断言しない検査は無言の no-op で、
   その「全緑」には情報量がない。実例：正規表現を raw 文字列で書き忘れて
   単語境界がバックスペース文字になり、交差参照チェックが 0 件にしか当たらず緑のままだった。
   SKIP を既定の挙動にしておけば、こういう空振りが赤く見える。

## 判定は「等しい」であって「差が重要性以下」ではない

許容差を設けると 1 円の系統的なずれが永遠に隠れる。比べる値は同じ丸め経路で作り、
等号で比べる。

## 分類（作者の方法論 A〜F）

  A 帳簿の構造   B 伝票↔銀行   C 導出の検算   D 切り分けの保存   E 法令・期限   F 表の鉤稽
  X 文書自身の整合
"""
from __future__ import annotations

import re
from dataclasses import dataclass, field

from .money import fmt, sum_money

PASS, FAIL, SKIP = "PASS", "FAIL", "SKIP"


@dataclass
class Check:
    id: str
    name: str
    status: str
    n_checked: int = 0
    details: list = field(default_factory=list)

    @property
    def ok(self) -> bool:
        return self.status == PASS


def result(cid, name, n, failures, notes=()) -> Check:
    """**n == 0 → SKIP**。この関数を迂回しないこと。"""
    if n == 0:
        return Check(cid, name, SKIP, 0, ["検査対象が 0 件——通過ではない。入力が空か、上流が切れていないか確認。"])
    return Check(cid, name, FAIL if failures else PASS, n, list(failures) + list(notes))


@dataclass
class Report:
    checks: list = field(default_factory=list)
    # 対象外：**日程・方針から導出して**その月に検査対象が存在しないと分かっているもの。
    # （例：納期の特例で当月に納期限が来ない）。SKIP とは別物——SKIP は「あるはずなのに 0 件」。
    # ここに入れるときは理由を書く。理由を書けないなら SKIP のままにする。
    not_applicable: list = field(default_factory=list)       # (id, name, reason)

    def add(self, c: Check) -> Check:
        self.checks.append(c)
        return c

    @property
    def failed(self):
        return [c for c in self.checks if c.status == FAIL]

    @property
    def skipped(self):
        return [c for c in self.checks if c.status == SKIP]

    @property
    def ok(self) -> bool:
        """SKIP も通過扱いにしない。"""
        return not self.failed and not self.skipped

    def summary(self) -> str:
        n = len(self.checks)
        na = f"、対象外 {len(self.not_applicable)}" if self.not_applicable else ""
        return (f"{n - len(self.failed) - len(self.skipped)}/{n} 通過、"
                f"{len(self.failed)} 失敗、{len(self.skipped)} 未検査{na}")


# --------------------------------------------------------------------- A 帳簿構造
def a1_balanced(vouchers) -> Check:
    bad = [f"伝票{v.vno} {v.date} {v.narration}：借 {fmt(v.debit_total)} ≠ 貸 {fmt(v.credit_total)}"
           for v in vouchers if not v.balanced()]
    return result("A1", "各伝票の貸借一致", len(vouchers), bad)


def a2_total_balanced(vouchers) -> Check:
    dr = sum_money(v.debit_total for v in vouchers)
    cr = sum_money(v.credit_total for v in vouchers)
    bad = [] if dr == cr else [f"借方総計 {fmt(dr)} ≠ 貸方総計 {fmt(cr)}"]
    return result("A2", "仕訳帳の貸借総計一致", len(vouchers), bad)


def a3_accounts_known(vouchers, chart) -> Check:
    n, bad = 0, []
    for v in vouchers:
        for l in v.lines:
            n += 1
            if l.account not in chart:
                bad.append(f"伝票{v.vno}：科目「{l.account}」が科目表にない")
    return result("A3", "全科目が科目表にある", n, bad)


def a4_dates_in_period(vouchers, start, end, today) -> Check:
    """期間内、かつ今日より後でない。後者は「未到来の納付を支払済みにした」を捕まえる。"""
    bad = []
    for v in vouchers:
        if not start <= v.date <= end:
            bad.append(f"伝票{v.vno} {v.date} が期間 {start}〜{end} の外")
        elif v.date > today:
            bad.append(f"伝票{v.vno} {v.date} は今日 {today} より後——まだ発生していない")
    return result("A4", "日付が期間内かつ未来でない", len(vouchers), bad)


def a7_vno_contiguous(vouchers, start=1) -> Check:
    nos = sorted(v.vno for v in vouchers if v.vno is not None)
    bad = []
    if len(nos) != len(vouchers):
        bad.append(f"採番されていない伝票が {len(vouchers) - len(nos)} 件")
    if nos and nos != list(range(start, start + len(nos))):
        bad.append(f"伝票番号が連続していない（{nos[0]}〜{nos[-1]}、{len(nos)} 件）")
    if len(set(nos)) != len(nos):
        bad.append("伝票番号が重複")
    return result("A7", "伝票番号が連続・重複なし", len(vouchers), bad)


def a9_liability_no_debit_balance(balances, liability_accounts, allowed=()) -> Check:
    """負債科目に借方残高が無い。

    預り金に借方残高 → 預かった額より多く納めた／控除漏れ。未払金に借方残高 → 二重払い。
    「控除は月末、納付は翌月」の時差で一時的に起きる科目は allowed で宣言させる——
    宣言した理由が消えたら宣言も消すこと。
    """
    n, bad = 0, []
    for acc in liability_accounts:
        for sub, bal in balances.get(acc, {}).items():
            n += 1
            if bal > 0 and (acc, sub) not in allowed:    # bal は借方正
                bad.append(f"{acc}/{sub or '（補助なし）'} に借方残高 {fmt(bal)}")
    return result("A9", "負債科目に説明のない借方残高がない", n, bad)


# --------------------------------------------------------------------- B 伝票↔銀行
def b5_balance_chain(rows) -> Check:
    """銀行明細の残高連鎖：前行残高 − 出金 ＋ 入金 ＝ 本行残高。

    行の欠落・金額の読み違い・重複排除のしすぎは全部ここで切れる。件数一致では捕まらない。
    rows: dict(balance, inflow, outflow) のリスト（日付順）。
    """
    bad, prev = [], None
    for i, r in enumerate(rows):
        if prev is not None:
            exp = prev - r["outflow"] + r["inflow"]
            if exp != r["balance"]:
                bad.append(f"{i + 1} 行目で残高連鎖が切れる：推定 {fmt(exp)} ≠ 実際 {fmt(r['balance'])}")
        prev = r["balance"]
    return result("B5", "銀行残高の連鎖が閉じる", len(rows), bad)


def b6_book_equals_bank(pairs) -> Check:
    """帳簿の預金残高＝銀行残高（月末）。**未達を認めない**——ずれたら原因を伝票で直す。"""
    pairs = list(pairs)
    bad = [f"{lab}：帳簿 {fmt(a)} ≠ 銀行 {fmt(b)}（差 {fmt(a - b)}）" for lab, a, b in pairs if a != b]
    return result("B6", "帳簿の預金残高＝銀行残高", len(pairs), bad)


def b12_claims_unique_in_window(claims, window_days) -> Check:
    """一つの銀行明細行は一回しか認領されない、かつ認領した伝票の予定日と窓の内。

    「各明細行に仕訳がある」（存在）と「合計が一致」（総額）は両方緑のまま、
    同じ明細を二つの伝票が奪い合うことがある。合計は相殺で合ってしまう。
    claims: (bank_row_id, voucher_label, expected_date, bank_date[, 前の日数, 後の日数]) のリスト。
    窓が付いていれば予定ごとの窓（社保は期限前の納付を広く認める）、無ければ ±window_days。
    """
    bad, seen = [], {}
    for c in claims:
        row, lab, exp, act = c[:4]
        before, after = (c[4], c[5]) if len(c) >= 6 else (window_days, window_days)
        if row in seen:
            bad.append(f"明細 {row} を {seen[row]} と {lab} が二重に認領")
        seen[row] = lab
        if exp is not None and not -before <= (act - exp).days <= after:
            bad.append(f"{lab}：予定日 {exp} と明細日 {act} が窓（前 {before} 日・後 {after} 日）の外")
    return result("B1B2", "明細の認領が一意かつ日付窓の内", len(claims), bad)


def b4_all_bank_rows_accounted(all_rows, matched, ruled, pending) -> Check:
    """全明細行 ＝ 照合済 ＋ ルール仕訳 ＋ 要確認。どれにも入らない行（静かな脱落）を許さない。"""
    all_rows, m, r, p = set(all_rows), set(matched), set(ruled), set(pending)
    bad = []
    lost = sorted(all_rows - m - r - p)
    if lost:
        bad.append(f"どこにも入っていない明細：{lost}")
    dup = sorted((m & r) | (m & p) | (r & p))
    if dup:
        bad.append(f"二つの区分に同時に入っている明細：{dup}")
    return result("B4", "銀行明細の全行が照合／仕訳／要確認のどれか一つに入る", len(all_rows), bad)


# --------------------------------------------------------------------- D 切り分け
def d5_partition(parts, whole, name) -> Check:
    """入った分だけ出る。分類は切り分けなので保存を断言する。"""
    parts = list(parts)
    s, w = sum_money(parts), sum_money([whole])
    bad = [] if s == w else [f"{name}：部分の合計 {fmt(s)} ≠ 全体 {fmt(w)}（差 {fmt(s - w)}）"]
    return result("D5", f"{name}の保存", len(parts), bad)


# --------------------------------------------------------------------- F 鉤稽
def f_tie(cid, name, pairs) -> Check:
    """二つの口径が**等しい**こと。pairs: (説明, 甲, 乙)。"""
    pairs = list(pairs)
    bad = [f"{lab}：{fmt(a)} ≠ {fmt(b)}（差 {fmt(a - b)}）" for lab, a, b in pairs if a != b]
    return result(cid, name, len(pairs), bad)


# --------------------------------------------------------------------- X 文書
REF = re.compile(r"\b(Q-[0-9]{3})\b")


def x_refs_resolve(texts, valid_ids, pattern=REF) -> Check:
    refs = set()
    for t in texts:
        refs |= set(pattern.findall(str(t)))
    bad = sorted(refs - set(valid_ids))
    return result("X1", "文中の要確認番号がすべて実在する", len(refs),
                  [f"存在しない参照：{bad}"] if bad else [])
