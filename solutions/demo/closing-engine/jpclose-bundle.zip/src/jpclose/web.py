# -*- coding: utf-8 -*-
"""ブラウザ（Pyodide）から呼ぶ入口。CPython でも同じように動く（テストはこちらで行う）。

作者の決定（2026-10-09）：エンジンはブラウザ内で動かす。**財務データは利用者のパソコンから出ない。**
ページは会社ディレクトリのファイルを Pyodide の仮想ファイルシステムに書き、ここを呼ぶ。
返り値は JSON にできる dict（画面表示用）で、底稿は out_path に書く。

  precheck(dir, month)  上傳清單の各行の状態（ある／無い／書式の誤り）。締める前に見せる
  run(dir, month, …)    締めて底稿を書く。progress(stage, i, n, label) で進捗を返す
"""
from __future__ import annotations

import datetime
import pathlib

import yaml

from . import bank, close, company, report
from .core import checks as C
from .pending import CATEGORY_LABEL

# 上傳清單（作者 2026-10-09：客に「どのファイルを・どの順で・どの書式で」出すかを一覧で示す）。
# ページはこの id で文言（i18n）を引く。順番は準備する順。
#   need: required（無いと締められない）/ monthly（毎月）/ optional / season（6・7 月の年度更新）/ year_end（決算月）
CHECKLIST = [
    dict(id="company", path="company.yaml", need="required"),
    dict(id="employees", path="employees.yaml", need="required"),
    dict(id="opening", path="opening_balances.yaml", need="required"),
    dict(id="bank", path="bank/", need="required"),
    dict(id="monthly", path="monthly/YYYY-MM/", need="monthly"),
    dict(id="bank_rules", path="bank_rules.yaml", need="optional"),
    dict(id="fixed_assets", path="fixed_assets.yaml", need="optional"),
    dict(id="decisions", path="decisions.yaml", need="optional"),
    dict(id="adjustments", path="adjustments.yaml", need="optional"),
    dict(id="labor_insurance", path="labor_insurance.yaml", need="season"),
    dict(id="corporate_tax", path="corporate_tax.yaml", need="year_end"),
]


def _yaml_status(p: pathlib.Path):
    if not p.exists():
        return None, None
    try:
        return yaml.safe_load(p.read_text(encoding="utf-8")) or {}, None
    except yaml.YAMLError as e:
        return None, f"YAML の書式：{e}".replace("\n", " ")
    except UnicodeDecodeError:
        return None, "文字コードが UTF-8 でない（メモ帳なら「UTF-8」で保存し直す）"


def precheck(company_dir, month: str) -> dict:
    """上傳清單の各行：status は ok / missing（必須が無い）/ error / absent（任意で無い）/ warn（今月は要る）。"""
    root = pathlib.Path(company_dir)
    y, m = (int(x) for x in month.split("-"))
    target = datetime.date(y, m, 1)
    items, docs = [], {}
    for it in CHECKLIST:
        row = dict(id=it["id"], path=it["path"], need=it["need"], status="ok", detail="")
        if it["path"].endswith(".yaml"):
            data, err = _yaml_status(root / it["path"])
            docs[it["id"]] = data
            if err:
                row.update(status="error", detail=err)
            elif data is None:
                row["status"] = "missing" if it["need"] == "required" else "absent"
        items.append(row)
    by = {r["id"]: r for r in items}
    co_doc = docs.get("company") or {}

    # 銀行明細：company.yaml の bank_accounts[].files で探す
    banks = co_doc.get("bank_accounts") or []
    if not banks:
        by["bank"].update(status="missing", detail="company.yaml の bank_accounts が無い")
    else:
        found = []
        for b in banks:
            files = bank.statement_files(root, str(b.get("files", "")))
            if not files:
                by["bank"].update(status="missing", detail=f"{b.get('id')}：{b.get('files')} に当たるファイルが無い")
                break
            try:
                rows, probs = bank.load(type("Co", (), {"root": root})(), b)
            except Exception as e:                     # 列の設定の誤り・金額に円未満など
                by["bank"].update(status="error", detail=f"{b.get('id')}：{type(e).__name__}: {e}")
                break
            if probs:
                by["bank"].update(status="error", detail="；".join(probs))
                break
            if rows:
                found.append(f"{b.get('id')} {len(files)} ファイル {len(rows)} 行（{rows[0].date}〜{rows[-1].date}）")
                if rows[-1].date < datetime.date(y, m, 28):
                    by["bank"].update(status="warn")
                    found.append(f"⚠ {month} の月末までの明細が無い（最後 {rows[-1].date}）")
        if by["bank"]["status"] in ("ok", "warn"):
            by["bank"]["detail"] = "；".join(found)

    # 月次入力：締める月の payroll.yaml / sales.yaml
    md = root / "monthly" / f"{target:%Y-%m}"
    months = sorted(p.name for p in (root / "monthly").glob("*-*") if p.is_dir()) if (root / "monthly").exists() else []
    have = [n for n in ("payroll.yaml", "sales.yaml") if (md / n).exists()]
    for n in have:
        _, err = _yaml_status(md / n)
        if err:
            by["monthly"].update(status="error", detail=f"{target:%Y-%m}/{n}：{err}")
    if by["monthly"]["status"] == "ok":
        by["monthly"]["detail"] = (f"{target:%Y-%m}：{'・'.join(have) if have else '無し（名簿の固定給だけで計算）'}"
                                   f"（フォルダ {len(months)} か月分）")
        if not have:
            by["monthly"]["status"] = "absent"

    # 時期で要るもの
    fy_end = (co_doc.get("company") or {}).get("fiscal_year_end_month")
    if target.month in (6, 7) and by["labor_insurance"]["status"] == "absent":
        by["labor_insurance"]["status"] = "warn"
    if fy_end and int(fy_end) == target.month and by["corporate_tax"]["status"] == "absent":
        by["corporate_tax"]["status"] = "warn"

    # 最後に、エンジンと同じ読み込みを通す（中身の誤り：科目名・方針・判断記録の欠け…）
    error = None
    if not any(r["status"] in ("missing", "error") for r in items):
        try:
            company.load(root)
        except company.CompanyError as e:
            error = str(e)
        except (yaml.YAMLError, UnicodeDecodeError, KeyError, TypeError, ValueError) as e:
            error = f"{type(e).__name__}: {e}"
    blocking = [r["id"] for r in items if r["status"] in ("missing", "error")]
    return dict(items=items, error=error, ready=not blocking and error is None, months=months)


def run(company_dir, month: str, today: str, lang: str = "zh", out_path: str = "/tmp/workpaper.xlsx",
        progress=None) -> dict:
    y, m = (int(x) for x in month.split("-"))
    target = datetime.date(y, m, 1)
    td = datetime.date.fromisoformat(today)
    tell = progress or (lambda *a: None)
    try:
        co = company.load(pathlib.Path(company_dir))
    except company.CompanyError as e:
        return dict(ok=False, error=f"{e}", kind="company")
    except (yaml.YAMLError, UnicodeDecodeError) as e:     # 利用者のファイルが壊れている（書式・文字コード）
        return dict(ok=False, error=f"{type(e).__name__}: {e}", kind="company")
    try:
        led = close.run(co, target, today=td, progress=lambda i, n, label: tell("month", i, n, label))
    except Exception as e:                               # 料率表が無い月など
        return dict(ok=False, error=f"{type(e).__name__}: {e}", kind="close")
    tell("workpaper", 0, 1, "")
    res = led.results[-1]
    summary = report.write(led, target, out_path, lang=lang)
    lb = report.L(lang)
    checks = [dict(id=c.id, name=lb.check(c), status=c.status, n=c.n_checked, details=c.details[:8])
              for c in res.report.checks]
    pend = [dict(qid=p.qid, category=lb.category(p.category), title=lb.title(p.title), detail=p.detail,
                 key=p.key, amount=p.amount, date=str(p.date) if p.date else "")
            for p in led.pending.open_items()]
    answers = []
    for p in led.pending.open_items():
        if p.category in ("bank_unmatched", "bank_ambiguous"):
            answers += [f'  "{p.key}":', f"    action: book        # {p.qid} {p.amount:+,}",
                        "    account: ", "    tax: ", "    evidence: ", "    by: ", f"    at: {today}",
                        "    reason: "]
    return dict(ok=res.report.ok, company=co.name, month=month, summary=res.report.summary(),
                checks=checks, pending=pend, n_pending=len(pend), vouchers=summary["vouchers"],
                not_applicable=[dict(id=i, name=n, reason=r) for i, n, r in res.report.not_applicable],
                answers=("decisions:\n" + "\n".join(answers)) if answers else "",
                out_path=out_path)
