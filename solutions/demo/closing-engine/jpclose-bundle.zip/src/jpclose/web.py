# -*- coding: utf-8 -*-
"""ブラウザ（Pyodide）から呼ぶ入口。CPython でも同じように動く（テストはこちらで行う）。

作者の決定（2026-10-09）：エンジンはブラウザ内で動かす。**財務データは利用者のパソコンから出ない。**
ページは会社ディレクトリのファイルを Pyodide の仮想ファイルシステムに書き、ここを呼ぶ。
返り値は JSON にできる dict（画面表示用）で、底稿は out_path に書く。

  precheck(dir, month)  上傳清單の各行の状態（ある／無い／書式の誤り）。締める前に見せる
  run(dir, month, …)    締めて底稿を書く。progress(stage, i, n, label) で進捗を返す
"""
from __future__ import annotations

import datetime
import pathlib

import yaml

from . import bank, close, company, report, workbook
from .messages import category_name, check_name, result_text, translate
from .core import checks as C
from .pending import CATEGORY_LABEL

# 上傳清單（作者 2026-10-09：客に「どのファイルを・どの順で・どの書式で」出すかを一覧で示す）。
# ページはこの id で文言（i18n）を引く。順番は準備する順。
#   need: required（無いと締められない）/ monthly（毎月）/ optional / season（6・7 月の年度更新）/ year_end（決算月）
# sheets：Excel の入力ブック（公司资料.xlsx）で同じ中身を書く表
CHECKLIST = [
    dict(id="company", path="company.yaml", need="required", sheets=["公司", "方针", "追加科目", "支给项目", "银行账户"]),
    dict(id="employees", path="employees.yaml", need="required", sheets=["员工", "标准报酬", "住民税", "固定工资"]),
    dict(id="opening", path="opening_balances.yaml", need="required", sheets=["期初余额"]),
    dict(id="bank", path="bank/", need="required", sheets=[]),
    dict(id="monthly", path="monthly/YYYY-MM/", need="monthly", sheets=["每月工资", "奖金", "开票"]),
    dict(id="bank_rules", path="bank_rules.yaml", need="optional", sheets=["银行规则"]),
    dict(id="fixed_assets", path="fixed_assets.yaml", need="optional", sheets=["固定资产", "折旧分摊"]),
    dict(id="decisions", path="decisions.yaml", need="optional", sheets=["回答"]),
    dict(id="adjustments", path="adjustments.yaml", need="optional", sheets=["调整分录"]),
    dict(id="labor_insurance", path="labor_insurance.yaml", need="season", sheets=["劳动保险"]),
    dict(id="corporate_tax", path="corporate_tax.yaml", need="year_end", sheets=["法人税", "法人税调整", "中间纳付"]),
]
GENERATED = "# 公司资料.xlsx から自動生成"


def prepare(company_dir):
    """入力ブックがあれば YAML に変換する。(source, problems)。source は workbook / yaml。

    手で書いた company.yaml があれば YAML を正とする（ブックの自動生成で上書きしない）。"""
    root = pathlib.Path(company_dir)
    cy = root / "company.yaml"
    hand_written = cy.exists() and not cy.read_text(encoding="utf-8", errors="replace").startswith(GENERATED)
    if hand_written:
        return "yaml", []
    wb = workbook.find_workbook(root)
    if wb is None:
        return "yaml", []
    for it in CHECKLIST:                       # 前回の変換の残りを消す（ブックで消した行が残らないように）
        if it["path"].endswith(".yaml") and (root / it["path"]).exists():
            if (root / it["path"]).read_text(encoding="utf-8", errors="replace").startswith(GENERATED):
                (root / it["path"]).unlink()
    for q in (root / "monthly").glob("*/*.yaml") if (root / "monthly").exists() else []:
        if q.read_text(encoding="utf-8", errors="replace").startswith(GENERATED):
            q.unlink()
    return "workbook", workbook.to_folder(wb, root)


def _yaml_status(p: pathlib.Path):
    if not p.exists():
        return None, None
    try:
        return yaml.safe_load(p.read_text(encoding="utf-8")) or {}, None
    except yaml.YAMLError as e:
        return None, f"YAML の書式：{e}".replace("\n", " ")
    except UnicodeDecodeError:
        return None, "文字コードが UTF-8 でない（メモ帳なら「UTF-8」で保存し直す）"


def precheck(company_dir, month: str, ui: str = "ja") -> dict:
    """上傳清單の各行：status は ok / missing（必須が無い）/ error / absent（任意で無い）/ warn（今月は要る）。"""
    root = pathlib.Path(company_dir)
    y, m = (int(x) for x in month.split("-"))
    target = datetime.date(y, m, 1)
    try:
        source, conv = prepare(root)
    except Exception as e:                      # 壊れたブック
        source, conv = "workbook", [("公司资料.xlsx", 0, f"{type(e).__name__}: {e}")]
    items, docs = [], {}
    for it in CHECKLIST:
        row = dict(id=it["id"], path=it["path"], need=it["need"], status="ok", detail="",
                   sheets=it["sheets"] if source == "workbook" else [])
        if it["path"].endswith(".yaml"):
            data, err = _yaml_status(root / it["path"])
            docs[it["id"]] = data
            if err:
                row.update(status="error", detail=err)
            elif data is None:
                row["status"] = "missing" if it["need"] == "required" else "absent"
        items.append(row)
    by = {r["id"]: r for r in items}
    co_doc = docs.get("company") or {}
    sheet_of = {sh: it["id"] for it in CHECKLIST for sh in it["sheets"]}
    for sh, rown, msg in conv:                  # ブックの問題は、その表が受け持つ行に出す
        r = by.get(sheet_of.get(sh, "company"))
        r.update(status="error", detail=(r["detail"] + "；" if r["detail"] else "") + f"表「{sh}」第 {rown} 行：{msg}")

    # 銀行明細：company.yaml の bank_accounts[].files で探す
    banks = co_doc.get("bank_accounts") or []
    if not banks:
        by["bank"].update(status="missing", detail="company.yaml の bank_accounts が無い")
    else:
        found = []
        for b in banks:
            files = bank.statement_files(root, str(b.get("files", "")))
            if not files:
                by["bank"].update(status="missing", detail=f"{b.get('id')}：{b.get('files')} に当たるファイルが無い")
                break
            try:
                rows, probs = bank.load(type("Co", (), {"root": root})(), b)
            except Exception as e:                     # 列の設定の誤り・金額に円未満など
                by["bank"].update(status="error", detail=f"{b.get('id')}：{type(e).__name__}: {e}")
                break
            if probs:
                by["bank"].update(status="error", detail="；".join(probs))
                break
            if rows:
                found.append(f"{b.get('id')} {len(files)} ファイル {len(rows)} 行（{rows[0].date}〜{rows[-1].date}）")
                if rows[-1].date < datetime.date(y, m, 28):
                    by["bank"].update(status="warn")
                    found.append(f"⚠ {month} の月末までの明細が無い（最後 {rows[-1].date}）")
        if by["bank"]["status"] in ("ok", "warn"):
            by["bank"]["detail"] = "；".join(found)

    # 月次入力：締める月の payroll.yaml / sales.yaml
    md = root / "monthly" / f"{target:%Y-%m}"
    months = sorted(p.name for p in (root / "monthly").glob("*-*") if p.is_dir()) if (root / "monthly").exists() else []
    have = [n for n in ("payroll.yaml", "sales.yaml") if (md / n).exists()]
    for n in have:
        _, err = _yaml_status(md / n)
        if err:
            by["monthly"].update(status="error", detail=f"{target:%Y-%m}/{n}：{err}")
    if by["monthly"]["status"] == "ok":
        by["monthly"]["detail"] = (f"{target:%Y-%m}：{'・'.join(have) if have else '無し（名簿の固定給だけで計算）'}"
                                   f"（フォルダ {len(months)} か月分）")
        if not have:
            by["monthly"]["status"] = "absent"

    # 時期で要るもの
    fy_end = (co_doc.get("company") or {}).get("fiscal_year_end_month")
    if target.month in (6, 7) and by["labor_insurance"]["status"] == "absent":
        by["labor_insurance"]["status"] = "warn"
    if fy_end and int(fy_end) == target.month and by["corporate_tax"]["status"] == "absent":
        by["corporate_tax"]["status"] = "warn"

    # 最後に、エンジンと同じ読み込みを通す（中身の誤り：科目名・方針・判断記録の欠け…）
    error = None
    if not any(r["status"] in ("missing", "error") for r in items):
        try:
            company.load(root)
        except company.CompanyError as e:
            error = str(e)
        except (yaml.YAMLError, UnicodeDecodeError, KeyError, TypeError, ValueError) as e:
            error = f"{type(e).__name__}: {e}"
    blocking = [r["id"] for r in items if r["status"] in ("missing", "error")]
    for r in items:                             # 画面の言語へ（型に当たらないものは日本語のまま）
        r["detail"] = translate(r["detail"], ui)
    return dict(items=items, error=translate(error, ui), ready=not blocking and error is None, months=months,
                source=source)


def merge_answers(company_dir, answers: dict, source: str) -> str:
    """画面で入力した回答を decisions.yaml に足す（同じ key は画面の方で上書き）。合併後の YAML 文字列を返す。"""
    p = pathlib.Path(company_dir) / "decisions.yaml"
    cur = {}
    if p.exists():
        cur = (yaml.safe_load(p.read_text(encoding="utf-8")) or {}).get("decisions") or {}
    cur.update(answers or {})
    text = yaml.safe_dump({"decisions": cur}, allow_unicode=True, sort_keys=False, width=200)
    head = GENERATED + "（画面の回答を合併）\n" if source == "workbook" else "# 要確認への回答（画面で入力したものを含む）\n"
    p.write_text(head + text, encoding="utf-8")
    return text


def run(company_dir, month: str, today: str, lang: str = "zh", out_path: str = "/tmp/workpaper.xlsx",
        progress=None, answers: dict | None = None, ui: str = "ja") -> dict:
    """answers：画面で入力した回答 {key: {action, account|lines, …, by, at, reason}}。decisions.yaml に合併して締める。
    入力がブックなら、回答を書き込んだブックを out_path + ".book.xlsx" に書く（次回はそれを使えばよい）。"""
    r = _run(company_dir, month, today, lang, out_path, progress, answers, ui)
    if r.get("error"):
        r["error"] = translate(r["error"], ui)
    return r


def _texts(res, opened, ui):
    """画面に出るエンジンの文言を一つの言語で。順序は res.report.checks／opened／not_applicable と同じ。"""
    return dict(
        checks=[dict(name=check_name(c.id, c.name, ui), details=[result_text(d, ui) for d in c.details[:8]])
                for c in res.report.checks],
        pending=[dict(category=category_name(p.category, CATEGORY_LABEL[p.category], ui),
                      title=p.title if p.category == "bank_unmatched" else result_text(p.title, ui),
                      detail=result_text(p.detail, ui)) for p in opened],
        na=[dict(name=check_name(i, n, ui), reason=result_text(r, ui)) for i, n, r in res.report.not_applicable])


def _run(company_dir, month, today, lang, out_path, progress, answers, ui="ja"):
    y, m = (int(x) for x in month.split("-"))
    target = datetime.date(y, m, 1)
    td = datetime.date.fromisoformat(today)
    tell = progress or (lambda *a: None)
    try:
        source, conv = prepare(company_dir)
    except Exception as e:
        return dict(ok=False, error=f"公司资料.xlsx：{type(e).__name__}: {e}", kind="company")
    if conv:
        return dict(ok=False, error="；".join(f"表「{s}」第 {r} 行：{m}" for s, r, m in conv), kind="company")
    decisions_yaml = merge_answers(company_dir, answers, source) if answers else ""
    try:
        co = company.load(pathlib.Path(company_dir))
    except company.CompanyError as e:
        return dict(ok=False, error=f"{e}", kind="company")
    except (yaml.YAMLError, UnicodeDecodeError) as e:     # 利用者のファイルが壊れている（書式・文字コード）
        return dict(ok=False, error=f"{type(e).__name__}: {e}", kind="company")
    try:
        led = close.run(co, target, today=td, progress=lambda i, n, label: tell("month", i, n, label))
    except Exception as e:                               # 料率表が無い月など
        return dict(ok=False, error=f"{type(e).__name__}: {e}", kind="close")
    tell("workpaper", 0, 1, "")
    res = led.results[-1]
    summary = report.write(led, target, out_path, lang=lang)
    # 画面の言語（ui）で訳す。底稿の言語（lang）とは別。銀行の摘要（ルール無しの明細の題）は原文のまま。
    # 締めた後に画面の言語を切り替えても文言が追いつくよう、3 言語分（tr）も返す（訳は正規表現だけで軽い）
    opened = led.pending.open_items()
    tr = {l: _texts(res, opened, l) for l in ("ja", "zh", "en")}
    cur = tr.get(ui, tr["ja"])
    checks = [dict(id=c.id, status=c.status, n=c.n_checked, **t) for c, t in zip(res.report.checks, cur["checks"])]
    pend = [dict(qid=p.qid, cat=p.category, key=p.key, amount=p.amount, date=str(p.date) if p.date else "", **t)
            for p, t in zip(opened, cur["pending"])]
    book = ""
    if answers and source == "workbook":
        book = out_path + ".book.xlsx"
        workbook.from_folder(company_dir, book)
    from .jp import shouhi
    accounts = [dict(name=a, section=x["section"]) for a, x in co.chart.items()]
    tmpl = []
    for p in led.pending.open_items():
        if p.category in ("bank_unmatched", "bank_ambiguous"):
            tmpl += [f'  "{p.key}":', f"    action: book        # {p.qid} {p.amount:+,}",
                        "    account: ", "    tax: ", "    evidence: ", "    by: ", f"    at: {today}",
                        "    reason: "]
    return dict(ok=res.report.ok, company=co.name, month=month, summary=res.report.summary(),
                checks=checks, pending=pend, n_pending=len(pend), vouchers=summary["vouchers"],
                not_applicable=[dict(id=x[0], **t) for x, t in zip(res.report.not_applicable, cur["na"])], tr=tr,
                answers=("decisions:\n" + "\n".join(tmpl)) if tmpl else "",
                out_path=out_path, source=source, accounts=accounts,
                tax_categories=sorted(shouhi.table()["categories"]), decisions_yaml=decisions_yaml, book_path=book)
