# -*- coding: utf-8 -*-
"""ブラウザ（Pyodide）から呼ぶ入口。CPython でも同じように動く（テストはこちらで行う）。

作者の決定（2026-10-09）：エンジンはブラウザ内で動かす。**財務データは利用者のパソコンから出ない。**
ページは会社ディレクトリのファイルを Pyodide の仮想ファイルシステムに書き、ここを呼ぶ。
返り値は JSON にできる dict（画面表示用）で、底稿は out_path に書く。
"""
from __future__ import annotations

import datetime
import pathlib

import yaml

from . import close, company, report
from .core import checks as C
from .pending import CATEGORY_LABEL


def run(company_dir, month: str, today: str, lang: str = "zh", out_path: str = "/tmp/workpaper.xlsx") -> dict:
    y, m = (int(x) for x in month.split("-"))
    target = datetime.date(y, m, 1)
    td = datetime.date.fromisoformat(today)
    try:
        co = company.load(pathlib.Path(company_dir))
    except company.CompanyError as e:
        return dict(ok=False, error=f"{e}", kind="company")
    except (yaml.YAMLError, UnicodeDecodeError) as e:     # 利用者のファイルが壊れている（書式・文字コード）
        return dict(ok=False, error=f"{type(e).__name__}: {e}", kind="company")
    try:
        led = close.run(co, target, today=td)
    except Exception as e:                               # 料率表が無い月など
        return dict(ok=False, error=f"{type(e).__name__}: {e}", kind="close")
    res = led.results[-1]
    summary = report.write(led, target, out_path, lang=lang)
    lb = report.L(lang)
    checks = [dict(id=c.id, name=lb.check(c), status=c.status, n=c.n_checked, details=c.details[:8])
              for c in res.report.checks]
    pend = [dict(qid=p.qid, category=lb.category(p.category), title=lb.title(p.title), detail=p.detail,
                 key=p.key, amount=p.amount, date=str(p.date) if p.date else "")
            for p in led.pending.open_items()]
    answers = []
    for p in led.pending.open_items():
        if p.category in ("bank_unmatched", "bank_ambiguous"):
            answers += [f'  "{p.key}":', f"    action: book        # {p.qid} {p.amount:+,}",
                        "    account: ", "    tax: ", "    evidence: ", "    by: ", f"    at: {today}",
                        "    reason: "]
    return dict(ok=res.report.ok, company=co.name, month=month, summary=res.report.summary(),
                checks=checks, pending=pend, n_pending=len(pend), vouchers=summary["vouchers"],
                not_applicable=[dict(id=i, name=n, reason=r) for i, n, r in res.report.not_applicable],
                answers=("decisions:\n" + "\n".join(answers)) if answers else "",
                out_path=out_path)
