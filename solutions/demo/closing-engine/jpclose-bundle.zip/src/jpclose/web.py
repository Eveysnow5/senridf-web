# -*- coding: utf-8 -*-
"""ブラウザ（Pyodide）から呼ぶ入口。CPython でも同じように動く（テストはこちらで行う）。

作者の決定（2026-10-09）：エンジンはブラウザ内で動かす。**財務データは利用者のパソコンから出ない。**
ページは会社ディレクトリのファイルを Pyodide の仮想ファイルシステムに書き、ここを呼ぶ。
返り値は JSON にできる dict（画面表示用）で、底稿は out_path に書く。

  precheck(dir, month)  上傳清單の各行の状態（ある／無い／書式の誤り）。締める前に見せる
  run(dir, month, …)    締めて底稿を書く。progress(stage, i, n, label) で進捗を返す
  month_workpaper(m, …) 直前の run の帳簿から、期間内の別の月の底稿を書く（締め直さない）

結账期間（作者 2026-10-10）：起止年月を自由に選ぶ。日本の会計期末は 12 月とは限らない（決算月は会社が決める）
ので、事業年度の候補は会社の決算月から作る。帳簿は期初残高の翌月（start_month）からしか作れないので、
「起」がそれより前なら締めずに理由を返す。締めは常に start_month から「止」まで順に行い、画面と成果物は
「起」〜「止」の各月を出す。
"""
from __future__ import annotations

import datetime
import pathlib

import yaml

import copy

from . import bank, close, company, fixes, hints, nextsteps, report, summaries, view, workbook
from .jp import depreciation as dep
from .jp.calendar import add_months, month_end
from .messages import category_name, check_name, result_text, translate
from .core import checks as C
from .pending import CATEGORY_LABEL

# 上傳清單（作者 2026-10-09：客に「どのファイルを・どの順で・どの書式で」出すかを一覧で示す）。
# ページはこの id で文言（i18n）を引く。順番は準備する順。
#   need: required（無いと締められない）/ monthly（毎月）/ optional / season（6・7 月の年度更新）/ year_end（決算月）
# sheets：Excel の入力ブック（公司资料.xlsx）で同じ中身を書く表
CHECKLIST = [
    dict(id="company", path="company.yaml", need="required", sheets=["公司", "方针", "追加科目", "支给项目", "银行账户"]),
    dict(id="employees", path="employees.yaml", need="required", sheets=["员工", "标准报酬", "住民税", "固定工资"]),
    dict(id="opening", path="opening_balances.yaml", need="required", sheets=["期初余额"]),
    dict(id="bank", path="bank/", need="required", sheets=[]),
    dict(id="monthly", path="monthly/YYYY-MM/", need="monthly", sheets=["每月工资", "奖金", "开票"]),
    dict(id="bank_rules", path="bank_rules.yaml", need="optional", sheets=["银行规则"]),
    dict(id="fixed_assets", path="fixed_assets.yaml", need="optional", sheets=["固定资产", "折旧分摊"]),
    dict(id="decisions", path="decisions.yaml", need="optional", sheets=["回答"]),
    dict(id="adjustments", path="adjustments.yaml", need="optional", sheets=["调整分录"]),
    dict(id="labor_insurance", path="labor_insurance.yaml", need="season", sheets=["劳动保险"]),
    dict(id="corporate_tax", path="corporate_tax.yaml", need="year_end", sheets=["法人税", "法人税调整", "中间纳付"]),
]
GENERATED = "# 公司资料.xlsx から自動生成"


def _ym(s) -> datetime.date:
    y, m = (int(x) for x in str(s).split("-")[:2])
    return datetime.date(y, m, 1)


def period_info(start: datetime.date | None, fy_end: int | None, last: datetime.date | None) -> dict:
    """結账期間の選択肢。start＝帳簿の開始月、fy_end＝決算月、last＝データ（銀行明細）の最後の月。

    fiscal_years は start を含む事業年度から last を含む事業年度まで（新しい順）。各年度の from は start より前に
    ならない（期中から記帳を始めた会社の最初の年度は start から）。"""
    out = dict(start=f"{start:%Y-%m}" if start else "", fy_end_month=fy_end, last=f"{last:%Y-%m}" if last else "",
               fiscal_years=[])
    if not (start and fy_end):
        return out
    last = last or start
    fs, fe = dep.fy_bounds(start, fy_end)
    while fs <= last:
        out["fiscal_years"].append(dict(start=f"{fs:%Y-%m}", end=f"{fe:%Y-%m}", **{"from": f"{max(fs, start):%Y-%m}"},
                                        to=f"{min(fe, last):%Y-%m}", partial=fe > last or fs < start))
        fs, fe = add_months(fe, 1), add_months(fe, 12)
    out["fiscal_years"].reverse()
    return out


def period_error(month_from: str | None, month: str, start: datetime.date | None) -> str | None:
    """起止の誤り（無ければ None）。文言は日本語（translate が画面の言語へ）。"""
    if not month_from:
        return None
    a, b = _ym(month_from), _ym(month)
    if a > b:
        return f"締める期間の「開始」{a:%Y-%m} が「終了」{b:%Y-%m} より後"
    if start and a < start:
        return (f"期首残高は {add_months(start, -1):%Y-%m} 末のもの：帳簿は {start:%Y-%m} からしか作れない"
                f"（締める期間の「開始」{a:%Y-%m} を {start:%Y-%m} 以降に）")
    return None


def prepare(company_dir):
    """入力ブックがあれば YAML に変換する。(source, problems)。source は workbook / yaml。

    手で書いた company.yaml があれば YAML を正とする（ブックの自動生成で上書きしない）。"""
    root = pathlib.Path(company_dir)
    workbook.BOOK["lang"] = "zh"               # ブックを読めばその言語になる（to_folder）。YAML の会社は正規の名前のまま
    cy = root / "company.yaml"
    hand_written = cy.exists() and not cy.read_text(encoding="utf-8", errors="replace").startswith(GENERATED)
    if hand_written:
        return "yaml", []
    wb = workbook.find_workbook(root)
    if wb is None:
        return "yaml", []
    for it in CHECKLIST:                       # 前回の変換の残りを消す（ブックで消した行が残らないように）
        if it["path"].endswith(".yaml") and (root / it["path"]).exists():
            if (root / it["path"]).read_text(encoding="utf-8", errors="replace").startswith(GENERATED):
                (root / it["path"]).unlink()
    for q in (root / "monthly").glob("*/*.yaml") if (root / "monthly").exists() else []:
        if q.read_text(encoding="utf-8", errors="replace").startswith(GENERATED):
            q.unlink()
    return "workbook", workbook.to_folder(wb, root)


def _yaml_status(p: pathlib.Path):
    if not p.exists():
        return None, None
    try:
        return yaml.safe_load(p.read_text(encoding="utf-8")) or {}, None
    except yaml.YAMLError as e:
        return None, f"YAML の書式：{e}".replace("\n", " ")
    except UnicodeDecodeError:
        return None, "文字コードが UTF-8 でない（メモ帳なら「UTF-8」で保存し直す）"


def _start_month(co_doc):
    """company.yaml の開始月（書き方は 2026-04 か日付）。読めなければ None（開始月の誤りは締めの方が報告する）。"""
    v = ((co_doc or {}).get("company") or {}).get("start_month")
    if isinstance(v, datetime.date):
        return v.replace(day=1)
    try:
        return _ym(str(v)[:7]) if v else None
    except (ValueError, TypeError):
        return None


def _month_last(d):
    nxt = (d.replace(day=28) + datetime.timedelta(days=4)).replace(day=1)
    return nxt - datetime.timedelta(days=1)


def precheck(company_dir, month: str, ui: str = "ja", month_from: str | None = None) -> dict:
    """上傳清單の各行：status は ok / missing（必須が無い）/ error / absent（任意で無い）/ warn（今月は要る）。

    month は結账期間の「止」、month_from は「起」（省略＝止の一か月だけ）。period（選択肢）も返す。"""
    root = pathlib.Path(company_dir)
    y, m = (int(x) for x in month.split("-"))
    target = datetime.date(y, m, 1)
    first = _ym(month_from) if month_from else target
    last_rows = []
    try:
        source, conv = prepare(root)
    except Exception as e:                      # 壊れたブック
        wbp = workbook.find_workbook(root)          # 名前は言語ごとに違う（公司资料／会社資料／company-data）
        source, conv = "workbook", [(wbp.name if wbp else workbook.WORKBOOK_NAME, 0, f"{type(e).__name__}: {e}")]
    items, docs = [], {}
    for it in CHECKLIST:
        row = dict(id=it["id"], path=it["path"], need=it["need"], status="ok", detail="",
                   sheets=it["sheets"] if source == "workbook" else [])
        if it["path"].endswith(".yaml"):
            data, err = _yaml_status(root / it["path"])
            docs[it["id"]] = data
            if err:
                row.update(status="error", detail=err)
            elif data is None:
                row["status"] = "missing" if it["need"] == "required" else "absent"
        items.append(row)
    by = {r["id"]: r for r in items}
    co_doc = docs.get("company") or {}
    sheet_of = {sh: it["id"] for it in CHECKLIST for sh in it["sheets"]}
    for sh, rown, msg in conv:                  # ブックの問題は、その表が受け持つ行に出す
        r = by.get(sheet_of.get(sh, "company"))
        r.update(status="error", detail=(r["detail"] + "；" if r["detail"] else "")
                 + f"表「{workbook.title(sh) if sh in workbook.CANON.values() else sh}」{rown} 行目：{workbook.localize(msg)}")

    # 銀行明細：bank/ の中の明細を口座に振り分けて読む（置き場所を書いた口座はその通りに）
    banks = co_doc.get("bank_accounts") or []
    if not banks:
        by["bank"].update(status="missing", detail="company.yaml の bank_accounts が無い")
    else:
        found = []
        opening_of = {}
        for x in ((docs.get("opening") or {}).get("balances") or []):
            k = (x.get("account"), x.get("sub") or "")
            opening_of[k] = opening_of.get(k, 0) + int(x.get("debit") or 0) - int(x.get("credit") or 0)
        need = ("date", "desc", "in", "out", "balance")
        if any(not b.get("id") or not all((b.get("csv") or {}).get(k) for k in need) for b in banks):
            banks_ready = False                        # 「银行账户」の行が埋まっていない（表の問題として報告済み）
        else:
            banks_ready = True
        try:
            loaded, probs = bank.load_all(root, banks, opening_of) if banks_ready else ({}, [])
        except Exception as e:                         # 列の設定の誤り・金額に円未満など
            loaded, probs = {}, [f"{type(e).__name__}: {e}"]
        if probs:
            gone = [p for p in probs if p.endswith("明細ファイルが無い") or "明細ファイルが無い（" in p]
            by["bank"].update(status="missing" if len(gone) == len(probs) else "error", detail="；".join(probs))
        for b in banks if (banks_ready and not probs) else []:
            rows = loaded[b["id"]]
            if rows:
                last_rows.append(rows[-1].date)
                files = len({r.label.rsplit(":", 1)[0] for r in rows})
                found.append(f"{b.get('id')} {files} ファイル {len(rows)} 行（{rows[0].date}〜{rows[-1].date}）")
                if rows[-1].date < datetime.date(y, m, 28):
                    by["bank"].update(status="warn")
                    found.append(f"⚠ {b.get('id')}：{month} の月末までの明細が無い（最後 {rows[-1].date}）")
                # 明細の始まり：帳簿の開始月より後から始まっていれば、前の月の明細が入っていない（締める前に言う）
                start = _start_month(co_doc)
                # 期首の残高と、最初の行の直前の残高が合っていれば、その間は動きが無かっただけ（欠けていない）
                opening = opening_of.get((b.get("account"), b.get("sub") or ""), 0)
                if start and rows[0].date > _month_last(start) and opening != rows[0].balance - rows[0].signed:
                    by["bank"].update(status="warn")
                    found.append(f"⚠ {b.get('id')}：明細は {rows[0].date} から。{start:%Y-%m}-01〜{rows[0].date - datetime.timedelta(days=1)} の明細が無い")
        if by["bank"]["status"] in ("ok", "warn"):
            by["bank"]["detail"] = "；".join(found)

    # 月次入力：締める月の payroll.yaml / sales.yaml
    md = root / "monthly" / f"{target:%Y-%m}"
    months = sorted(p.name for p in (root / "monthly").glob("*-*") if p.is_dir()) if (root / "monthly").exists() else []
    have = [n for n in ("payroll.yaml", "sales.yaml") if (md / n).exists()]
    for n in have:
        _, err = _yaml_status(md / n)
        if err:
            by["monthly"].update(status="error", detail=f"{target:%Y-%m}/{n}：{err}")
    if by["monthly"]["status"] == "ok":
        if source == "workbook":            # 入力ブックの利用者は yaml を見たことがない → 表の名前で言う
            sheet = {"payroll.yaml": "每月工资", "sales.yaml": "开票"}
            got = "・".join(f"「{sheet[n]}」" for n in have)
            by["monthly"]["detail"] = (f"{target:%Y-%m}：{got if have else '無し（名簿の固定給だけで計算）'}"
                                       f"（入力ブックの表、{len(months)} か月分）")
        else:
            by["monthly"]["detail"] = (f"{target:%Y-%m}：{'・'.join(have) if have else '無し（名簿の固定給だけで計算）'}"
                                       f"（フォルダ {len(months)} か月分）")
        if not have:
            by["monthly"]["status"] = "absent"

    # 時期で要るもの（期間のどこかに 6・7 月／決算月があれば）
    fy_end = (co_doc.get("company") or {}).get("fiscal_year_end_month")
    in_range = []
    k = min(first, target)
    while k <= target:
        in_range.append(k.month)
        k = add_months(k, 1)
    if {6, 7} & set(in_range) and by["labor_insurance"]["status"] == "absent":
        by["labor_insurance"].update(status="warn", detail="期間に 6・7 月（労働保険の年度更新）がある：前年度の賃金総額・"
                                     "前年度に納めた概算保険料・控除した雇用保険料を用意する（無くても締められるが、計算表は作れない）")
    if fy_end and int(fy_end) in in_range and by["corporate_tax"]["status"] == "absent":
        by["corporate_tax"].update(status="warn", detail="期間に決算月がある：法人税等の計算に要る資料（地方税の税率・"
                                   "均等割・繰越欠損金・中間納付）を用意する（無くても締められるが、計算表は作れない）")

    # 結账期間：選択肢（会社の決算月から）と、起止の誤り
    c0 = co_doc.get("company") or {}
    try:
        start = _ym(c0["start_month"]) if c0.get("start_month") else None
        fyx = int(fy_end) if fy_end else None
    except (TypeError, ValueError):
        start, fyx = None, None
    last = max(last_rows).replace(day=1) if last_rows else None
    period = period_info(start, fyx, last)
    perr = period_error(month_from, month, start)

    # 最後に、エンジンと同じ読み込みを通す（中身の誤り：科目名・方針・判断記録の欠け…）
    error = None
    if not any(r["status"] in ("missing", "error") for r in items):
        try:
            company.load(root)
        except company.CompanyError as e:
            error = str(e)
        except (yaml.YAMLError, UnicodeDecodeError, KeyError, TypeError, ValueError) as e:
            error = f"{type(e).__name__}: {e}"
    if error is None and perr:
        error = perr
    blocking = [r["id"] for r in items if r["status"] in ("missing", "error")]
    for r in items:                             # 画面の言語へ（型に当たらないものは日本語のまま）
        r["detail"] = workbook.localize(translate(r["detail"], ui))
        r["sheets"] = [workbook.title(s) for s in r["sheets"]]         # 表の名前はブックの言語で
    return dict(items=items, error=workbook.localize(translate(error, ui)), ready=not blocking and error is None,
                months=months, source=source, period=period, book_lang=workbook.BOOK["lang"] if source == "workbook" else "")


def _book_names(obj):
    """結果の中の文に出てくる表の名前（「银行规则」…）を、ブックの言語の名前にする（中国語のブックなら何もしない）。"""
    if workbook.BOOK["lang"] == "zh":
        return obj
    if isinstance(obj, str):
        return workbook.localize(obj)
    if isinstance(obj, list):
        return [_book_names(x) for x in obj]
    if isinstance(obj, dict):
        return {k: ([workbook.title(s) for s in v] if k == "sheets" and isinstance(v, list) else _book_names(v))
                for k, v in obj.items()}
    return obj


def merge_answers(company_dir, answers: dict, source: str) -> str:
    """画面で入力した回答を decisions.yaml に足す（同じ key は画面の方で上書き）。合併後の YAML 文字列を返す。"""
    p = pathlib.Path(company_dir) / "decisions.yaml"
    cur = {}
    if p.exists():
        cur = (yaml.safe_load(p.read_text(encoding="utf-8")) or {}).get("decisions") or {}
    cur.update(answers or {})
    text = yaml.safe_dump({"decisions": cur}, allow_unicode=True, sort_keys=False, width=200)
    head = GENERATED + "（画面の回答を合併）\n" if source == "workbook" else "# 要確認への回答（画面で入力したものを含む）\n"
    p.write_text(head + text, encoding="utf-8")
    return text


def run(company_dir, month: str, today: str, lang: str = "zh", out_path: str = "/tmp/workpaper.xlsx",
        progress=None, answers: dict | None = None, ui: str = "ja", edits: dict | None = None,
        month_from: str | None = None) -> dict:
    """answers：画面で入力した回答 {key: {action, account|lines, …, by, at, reason}}。decisions.yaml に合併して締める。
    入力がブックなら、回答を書き込んだブックを out_path + ".book.xlsx" に書く（次回はそれを使えばよい）。

    month＝結账期間の「止」、month_from＝「起」（省略＝止の一か月）。上位の項目（view・checks・reports…）は「止」の月。
    periods に「起」〜「止」の各月の同じ項目を入れる（画面の月切り替え用）。底稿は「止」の月だけ書く
    （他の月は month_workpaper で。直前の run の帳簿を使うので締め直さない）。"""
    r = _run(company_dir, month, today, lang, out_path, progress, answers, ui, edits, month_from)
    if r.get("error"):
        r["error"] = translate(r["error"], ui)
    keep = {k: r.pop(k) for k in ("decisions_yaml", "accounts", "answers") if k in r}     # 利用者の入力・科目名は触らない
    r = _book_names(r)
    r.update(keep)
    return r


# 直前の run の帳簿（month_workpaper 用）。Pyodide の Worker は一つの会社を続けて扱うので一つだけ持つ
_LAST: dict = {}


def _as_of(led, res, last):
    """期間の途中の月：その月末までの事項だけを持つ帳簿（浅いコピー。仕訳・残高は共通）。末の月はそのまま。"""
    if res.month == last:
        return led
    lm = copy.copy(led)
    lm.pending = led.pending.until(month_end(res.month.year, res.month.month))
    return lm


def _month_payload(co, led, res, opened, lang, today, last) -> dict:
    """一か月分の画面表示（月切り替え用）。事項（opened）は期間の末の状態で共通なので入れない。"""
    led = _as_of(led, res, last)
    vw = view.build(co, led, res)
    month = f"{res.month:%Y-%m}"
    tr = {l: _texts(res, [], l) for l in ("ja", "zh", "en")}
    return dict(month=month, ok=res.report.ok, summary=res.report.summary(), view=vw,
                checks=[dict(id=c.id, status=c.status, n=c.n_checked) for c in res.report.checks],
                not_applicable=[dict(id=x[0]) for x in res.report.not_applicable],
                tr={l: dict(checks=t["checks"], na=t["na"]) for l, t in tr.items()},
                reports=summaries.build(dict(company=co.name, month=month), co, led, res, vw, lang, today))


def month_workpaper(month: str, lang: str, out_path: str) -> dict:
    """直前の run の帳簿から、その月の底稿を書く。期間外・run 前なら error。"""
    led = _LAST.get("led")
    if led is None:
        return dict(ok=False, error="先に締めを実行してください（帳簿がまだ無い）")
    m = _ym(month)
    if not any(r.month == m for r in led.results) or m < _LAST["from"]:
        return dict(ok=False, error=f"{month} は締める期間の外")
    res = [r for r in led.results if r.month == m][0]
    summary = report.write(_as_of(led, res, led.results[-1].month), m, out_path, lang=lang)
    return dict(ok=True, month=month, out_path=out_path, vouchers=summary["vouchers"])


def _texts(res, opened, ui, hs=None):
    """画面に出るエンジンの文言を一つの言語で。順序は res.report.checks／opened／not_applicable と同じ。"""
    return dict(
        checks=[dict(name=check_name(c.id, c.name, ui), details=[result_text(d, ui) for d in c.details[:8]],
                     next=nextsteps.for_check(c.id, ui) if c.status == "FAIL" else None)
                for c in res.report.checks],
        pending=[dict(category=category_name(p.category, CATEGORY_LABEL[p.category], ui),
                      title=p.title if p.category == "bank_unmatched" else result_text(p.title, ui),
                      detail=result_text(p.detail, ui), next=nextsteps.for_pending(p.key, p.category, ui),
                      hints=[h["ja" if ui not in ("zh", "en") else ui] for h in (hs or {}).get(p.key, [])])
                 for p in opened],
        na=[dict(name=check_name(i, n, ui), reason=result_text(r, ui)) for i, n, r in res.report.not_applicable])


def _run(company_dir, month, today, lang, out_path, progress, answers, ui="ja", edits=None, month_from=None):
    y, m = (int(x) for x in month.split("-"))
    target = datetime.date(y, m, 1)
    first = _ym(month_from) if month_from else target
    td = datetime.date.fromisoformat(today)
    tell = progress or (lambda *a: None)
    try:
        source, conv = prepare(company_dir)
    except Exception as e:
        return dict(ok=False, error=f"公司资料.xlsx：{type(e).__name__}: {e}", kind="company")
    if conv:
        return dict(ok=False, error="；".join(f"表「{s}」第 {r} 行：{m}" for s, r, m in conv), kind="company")
    decisions_yaml = merge_answers(company_dir, answers, source) if answers else ""
    # 画面で直した「待処理」（住民税の月額・通勤方法など）を資料に書く。検証に落ちたら締めずに返す
    try:
        changed = fixes.apply_all(company_dir, edits, today) if edits else []
    except fixes.FixError as e:
        return dict(ok=False, error=f"{e}", kind="fix")
    try:
        co = company.load(pathlib.Path(company_dir))
    except company.CompanyError as e:
        return dict(ok=False, error=f"{e}", kind="company")
    except (yaml.YAMLError, UnicodeDecodeError) as e:     # 利用者のファイルが壊れている（書式・文字コード）
        return dict(ok=False, error=f"{type(e).__name__}: {e}", kind="company")
    perr = period_error(month_from, month, co.start_month)
    if perr:
        return dict(ok=False, error=perr, kind="period")
    try:
        led = close.run(co, target, today=td, progress=lambda i, n, label: tell("month", i, n, label))
    except Exception as e:                               # 料率表が無い月など
        return dict(ok=False, error=f"{type(e).__name__}: {e}", kind="close")
    tell("workpaper", 0, 1, "")
    res = led.results[-1]
    summary = report.write(led, target, out_path, lang=lang)
    # 画面の言語（ui）で訳す。底稿の言語（lang）とは別。銀行の摘要（ルール無しの明細の題）は原文のまま。
    # 締めた後に画面の言語を切り替えても文言が追いつくよう、3 言語分（tr）も返す（訳は正規表現だけで軽い）
    opened = led.pending.open_items()
    hs = {p.key: hints.for_pending(led, res, p) for p in opened}      # 推論（候補を示すだけ）
    tr = {l: _texts(res, opened, l, hs) for l in ("ja", "zh", "en")}
    cur = tr.get(ui, tr["ja"])
    checks = [dict(id=c.id, status=c.status, n=c.n_checked, **t) for c, t in zip(res.report.checks, cur["checks"])]
    pend = [dict(qid=p.qid, cat=p.category, key=p.key, amount=p.amount, date=str(p.date) if p.date else "",
                 bucket=view.bucket(p.key), fix=fixes.form_for(p.key),
                 # 回答の下書き（過去の同じ明細の科目）。銀行明細（ルール無し）だけ
                 suggest=hints.suggest(led, res, p) if p.category == "bank_unmatched" else None,
                 # 証憑の要確認：連番・候補の明細（選ぶボタン）・合計で一致する明細
                 ev=p.data if p.key.startswith(("evidence:", "evidence_choose:")) else None, **t)
            for p, t in zip(opened, cur["pending"])]
    book = ""
    if (answers or edits) and source == "workbook":
        book = out_path + ".book.xlsx"
        workbook.from_folder(company_dir, book, workbook.BOOK["lang"])
    # YAML 入力：変えたファイルの中身を返す（画面がフォルダに書き戻す）。ブック入力はブックに入っている
    changed_files = {n: (pathlib.Path(company_dir) / n).read_text(encoding="utf-8")
                     for n in changed} if source != "workbook" else {}
    from .jp import shouhi
    vw = view.build(co, led, res)
    accounts = [dict(name=a, section=x["section"]) for a, x in co.chart.items()]
    _LAST.clear()
    _LAST.update(led=led, **{"from": first})
    periods = [_month_payload(co, led, r, opened, lang, today, target)
               for r in led.results if first <= r.month <= target]
    tmpl = []
    for p in led.pending.open_items():
        if p.category in ("bank_unmatched", "bank_ambiguous"):
            tmpl += [f'  "{p.key}":', f"    action: book        # {p.qid} {p.amount:+,}",
                        "    account: ", "    tax: ", "    evidence: ", "    by: ", f"    at: {today}",
                        "    reason: "]
    return dict(ok=res.report.ok, company=co.name, month=month, summary=res.report.summary(),
                checks=checks, pending=pend, n_pending=len(pend), vouchers=summary["vouchers"],
                not_applicable=[dict(id=x[0], **t) for x, t in zip(res.report.not_applicable, cur["na"])], tr=tr,
                view=vw, hidden_checks=sorted(view.CUSTOMER_HIDDEN_CHECKS),
                evidence_links={str(k): v for k, v in sorted(getattr(led, "ev_links", {}).items())},
                reports=summaries.build(dict(company=co.name, month=month), co, led, res, vw, lang, today),
                answers=("decisions:\n" + "\n".join(tmpl)) if tmpl else "",
                out_path=out_path, source=source, accounts=accounts,
                tax_categories=sorted(shouhi.table()["categories"]), decisions_yaml=decisions_yaml, book_path=book,
                changed_files=changed_files, periods=periods, month_from=f"{first:%Y-%m}",
                period=period_info(co.start_month, co.fy_end_month,
                                   max((r.date for rows in res.all_bank_rows.values() for r in rows),
                                       default=target).replace(day=1)))
