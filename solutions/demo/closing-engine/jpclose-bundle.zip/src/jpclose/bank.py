# -*- coding: utf-8 -*-
"""銀行明細の取り込み・残高連鎖・照合。

## 取り込み

銀行ごとに CSV の列名・文字コード・日付書式が違うので、会社設定（bank_accounts[].csv）で
列名を指定する。文字コードは cp932 → utf-8-sig → utf-8 の順に試す（日本の銀行 CSV は
cp932 が多く、UTF-8 で読むと「列が見つからない」という見当違いの症状で落ちる）。

Excel（.xlsx）もそのまま読む（作者 2026-10-09：利用者に CSV への保存し直しをさせない）。
最初のシートの先頭 10 行から、指定の列名が全部そろった行を見出しとみなす。日付のセルは
日付型・Excel のシリアル値（銀行のダウンロードによくある）・文字列（date_format で読む）のどれでもよい。

## 残高連鎖（B5）

CSV でも期間の切り間違い・ファイルのつなぎ間違い・銀行側の列変更は起こる。
「前行残高 − 出金 ＋ 入金 ＝ 本行残高」が全行で閉じることを断言する。件数一致では捕まらない。

## 照合

予定（給与振込・社保・源泉・住民税・定期支払）を明細に当てる。
  · 金額一致かつ予定日 ±窓 の中の、**未認領**の明細だけが候補
  · 候補がちょうど 1 件 → 認領。2 件以上 → **推測しない**（要確認）
  · 1 つの明細は 1 回しか認領されない（B1B2）
予定に当たらなかった明細は銀行ルール（会社が書いた）で仕訳。ルールが 2 つ以上当たれば要確認。
どれにも当たらなければ要確認。全行がこの三つのどれか一つに入ることを B4 で断言する。
"""
from __future__ import annotations

import csv
import datetime
import glob
import io
import pathlib
import re
from dataclasses import dataclass, field


@dataclass
class BankRow:
    bank: str
    date: datetime.date
    desc: str
    inflow: int
    outflow: int
    balance: int
    label: str                      # ファイル名:行番号
    claimed_by: str | None = None

    @property
    def id(self) -> str:
        return f"{self.bank}:{self.label}"

    @property
    def amount_abs(self) -> int:
        return self.inflow or self.outflow

    @property
    def signed(self) -> int:
        return self.inflow - self.outflow

    def key(self) -> str:
        """要確認の指紋：口座・日付・符号付き金額・摘要。"""
        return f"bank:{self.bank}:{self.date}:{self.signed}:{self.desc}"


def _decode(raw: bytes) -> tuple[str, str]:
    for enc in ("cp932", "utf-8-sig", "utf-8"):
        try:
            return raw.decode(enc), enc
        except UnicodeDecodeError:
            continue
    raise ValueError("文字コードを判定できない（cp932 / utf-8 のどれでもない）")


def _int(s) -> int:
    if isinstance(s, (int, float)) and not isinstance(s, bool):     # Excel の数値セル
        if s != int(s):
            raise ValueError(f"金額に円未満がある：{s}")
        return int(s)
    s = str(s or "").replace(",", "").replace("円", "").replace("¥", "").strip()
    return int(s) if s else 0


EXCEL_EPOCH = datetime.date(1899, 12, 30)      # Excel（1900 年方式）のシリアル値 0 日目


def _date(v, fmt) -> datetime.date:
    if isinstance(v, datetime.datetime):
        return v.date()
    if isinstance(v, datetime.date):
        return v
    if isinstance(v, (int, float)) and not isinstance(v, bool):
        return EXCEL_EPOCH + datetime.timedelta(days=int(v))
    return datetime.datetime.strptime(str(v).strip(), fmt).date()


def _csv_table(path, need):
    """(見出し, [(行番号, dict)], 問題)。"""
    text, enc = _decode(pathlib.Path(path).read_bytes())
    rd = csv.DictReader(io.StringIO(text))
    missing = [c for c in need if c not in (rd.fieldnames or [])]
    if missing:
        return None, [], f"列 {missing} が無い（文字コード {enc}、見出し {rd.fieldnames}）"
    return rd.fieldnames, list(enumerate(rd, start=2)), None


def _xlsx_table(path, need):
    from openpyxl import load_workbook
    wb = load_workbook(path, read_only=True, data_only=True)
    try:
        grid = list(wb.worksheets[0].iter_rows(values_only=True))
    finally:
        wb.close()
    for h, row in enumerate(grid[:10]):
        head = [str(c).strip() if c is not None else "" for c in row]
        if all(c in head for c in need):
            out = []
            for i, r in enumerate(grid[h + 1:], start=h + 2):
                if all(c is None or str(c).strip() == "" for c in r):
                    continue                    # 空行（シート末尾の書式だけの行など）
                out.append((i, {k: v for k, v in zip(head, r) if k}))
            return head, out, None
    return None, [], f"先頭 10 行に列 {need} がそろった見出し行が無い（最初のシート「{wb.worksheets[0].title}」）"


STATEMENT_EXT = (".csv", ".xlsx", ".xlsm")


def statement_files(root, pattern) -> list:
    """明細ファイル。説明書きの .txt などが同じフォルダにあっても読まない。"""
    return sorted(f for f in glob.glob(str(pathlib.Path(root) / pattern)) if f.lower().endswith(STATEMENT_EXT))


def load(co, bank) -> tuple[list, list]:
    """(rows, problems)。rows は日付順。problems は取り込みの異常（空なら正常）。"""
    cfg = bank["csv"]
    files = statement_files(co.root, bank["files"])
    rows, problems = [], []
    if not files:
        problems.append(f"{bank['id']}：明細ファイルが無い（{bank['files']}）")
    need = [cfg[k] for k in ("date", "desc", "in", "out", "balance")]
    for f in files:
        reader = _xlsx_table if f.lower().endswith((".xlsx", ".xlsm")) else _csv_table
        _, table, err = reader(f, need)
        if err:
            problems.append(f"{f}：{err}")
            continue
        fmt = cfg.get("date_format", "%Y/%m/%d")
        if len(table) >= 2 and _date(table[0][1][cfg["date"]], fmt) > _date(table[-1][1][cfg["date"]], fmt):
            # 新しい順のファイル（大手行のダウンロードに多い）は同日内の順も逆。日付で並べ直すだけでは
            # 同日の行が逆順のまま残り、残高連鎖（B5）が切れる（実在の会社で試して発見、2026-10-09）→ 先に反転する
            table = table[::-1]
        for i, r in table:
            rows.append(BankRow(bank=bank["id"],
                                date=_date(r[cfg["date"]], fmt),
                                desc=str(r[cfg["desc"]] or "").strip(), inflow=_int(r[cfg["in"]]),
                                outflow=_int(r[cfg["out"]]), balance=_int(r[cfg["balance"]]),
                                label=f"{f.replace(chr(92), '/').split('/')[-1]}:{i}"))
    # 同じ行が二つのファイルに入っている（期間の重なり）→ 完全一致だけ落とす
    seen, uniq = set(), []
    for r in rows:
        k = (r.date, r.desc, r.inflow, r.outflow, r.balance)
        if k in seen:
            continue
        seen.add(k)
        uniq.append(r)
    uniq.sort(key=lambda r: r.date)       # 安定ソート：同日はファイル内の順を保つ（新しい順のファイルは上で反転済み）
    return uniq, problems


def chain_rows(rows):
    return [dict(balance=r.balance, inflow=r.inflow, outflow=r.outflow) for r in rows]


@dataclass
class Expected:
    key: str
    label: str
    date: datetime.date
    amount: int
    direction: str                  # out / in
    make: object                    # (row) -> Voucher
    window: int = 5
    hint: str = ""                  # 摘要に含まれるはずの語（候補の絞り込みには使わない、表示用）
    early: int = 0                  # 予定日より**前**に払うのを何日まで認めるか（0 なら window と同じ）

    def in_window(self, d) -> bool:
        delta = (d - self.date).days
        return -(self.early or self.window) <= delta <= self.window


@dataclass
class MatchResult:
    claims: list = field(default_factory=list)         # (row_id, label, expected_date, row_date, 前の日数, 後の日数)
    vouchers: list = field(default_factory=list)
    unmatched_expected: list = field(default_factory=list)
    ambiguous: list = field(default_factory=list)      # (expected, [rows])


def match(expected, rows) -> MatchResult:
    res = MatchResult()
    for x in sorted(expected, key=lambda x: x.date):
        cands = [r for r in rows if r.claimed_by is None and r.amount_abs == x.amount
                 and (r.outflow if x.direction == "out" else r.inflow)
                 and x.in_window(r.date)]
        if len(cands) == 1:
            r = cands[0]
            r.claimed_by = x.key
            res.claims.append((r.id, x.label, x.date, r.date, x.early or x.window, x.window))
            made = x.make(r)
            if made is None:                 # 単体テストは仕訳を作らない make を渡す
                continue
            # 一つの明細から複数の伝票ができることがある（年度更新：納付＋前年度分の精算）。
            # 約束：リストの**先頭が納付の伝票**で、銀行明細に紐づくのはそれだけ。
            made = made if isinstance(made, list) else [made]
            made[0].bank_row = r.id
            res.vouchers.extend(made)
        elif len(cands) > 1:
            res.ambiguous.append((x, cands))
        else:
            res.unmatched_expected.append(x)
    return res


def rule_hits(row, rules):
    hits = []
    for r in rules:
        w = r["when"]
        if "direction" in w and w["direction"] != ("out" if row.outflow else "in"):
            continue
        if "desc_contains" in w and w["desc_contains"] not in row.desc:
            continue
        if "desc_regex" in w and not re.search(w["desc_regex"], row.desc):
            continue
        if "amount" in w and int(w["amount"]) != row.amount_abs:
            continue
        hits.append(r)
    return hits
