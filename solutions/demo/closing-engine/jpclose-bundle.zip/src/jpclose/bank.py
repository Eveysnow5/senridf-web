# -*- coding: utf-8 -*-
"""銀行明細の取り込み・残高連鎖・照合。

## 取り込み

銀行ごとに CSV の列名・文字コード・日付書式が違うので、会社設定（bank_accounts[].csv）で
列名を指定する。文字コードは cp932 → utf-8-sig → utf-8 の順に試す（日本の銀行 CSV は
cp932 が多く、UTF-8 で読むと「列が見つからない」という見当違いの症状で落ちる）。

Excel（.xlsx）もそのまま読む（作者 2026-10-09：利用者に CSV への保存し直しをさせない）。
最初のシートの先頭 10 行から、指定の列名が全部そろった行を見出しとみなす。日付のセルは
日付型・Excel のシリアル値（銀行のダウンロードによくある）・文字列（date_format で読む）のどれでもよい。

## 残高連鎖（B5）

CSV でも期間の切り間違い・ファイルのつなぎ間違い・銀行側の列変更は起こる。
「前行残高 − 出金 ＋ 入金 ＝ 本行残高」が全行で閉じることを断言する。件数一致では捕まらない。

## 照合

予定（給与振込・社保・源泉・住民税・定期支払）を明細に当てる。
  · 金額一致かつ予定日 ±窓 の中の、**未認領**の明細だけが候補
  · 候補がちょうど 1 件 → 認領。2 件以上 → **推測しない**（要確認）
  · 1 つの明細は 1 回しか認領されない（B1B2）
予定に当たらなかった明細は銀行ルール（会社が書いた）で仕訳。ルールが 2 つ以上当たれば要確認。
どれにも当たらなければ要確認。全行がこの三つのどれか一つに入ることを B4 で断言する。
"""
from __future__ import annotations

import csv
import datetime
import glob
import io
import pathlib
import re
from dataclasses import dataclass, field


@dataclass
class BankRow:
    bank: str
    date: datetime.date
    desc: str
    inflow: int
    outflow: int
    balance: int
    label: str                      # ファイル名:行番号
    claimed_by: str | None = None

    @property
    def id(self) -> str:
        return f"{self.bank}:{self.label}"

    @property
    def amount_abs(self) -> int:
        return self.inflow or self.outflow

    @property
    def signed(self) -> int:
        return self.inflow - self.outflow

    def key(self) -> str:
        """要確認の指紋：口座・日付・符号付き金額・摘要。"""
        return f"bank:{self.bank}:{self.date}:{self.signed}:{self.desc}"


def _decode(raw: bytes) -> tuple[str, str]:
    for enc in ("cp932", "utf-8-sig", "utf-8"):
        try:
            return raw.decode(enc), enc
        except UnicodeDecodeError:
            continue
    raise ValueError("文字コードを判定できない（cp932 / utf-8 のどれでもない）")


def _int(s) -> int:
    if isinstance(s, (int, float)) and not isinstance(s, bool):     # Excel の数値セル
        if s != int(s):
            raise ValueError(f"金額に円未満がある：{s}")
        return int(s)
    s = str(s or "").replace(",", "").replace("円", "").replace("¥", "").strip()
    return int(s) if s else 0


EXCEL_EPOCH = datetime.date(1899, 12, 30)      # Excel（1900 年方式）のシリアル値 0 日目


DATE_FORMATS = ("%Y/%m/%d", "%Y-%m-%d", "%Y%m%d", "%Y年%m月%d日", "%Y.%m.%d")


def _date(v, fmt) -> datetime.date:
    if isinstance(v, datetime.datetime):
        return v.date()
    if isinstance(v, datetime.date):
        return v
    if isinstance(v, (int, float)) and not isinstance(v, bool):
        return EXCEL_EPOCH + datetime.timedelta(days=int(v))
    if fmt:
        return datetime.datetime.strptime(str(v).strip(), fmt).date()
    for f in DATE_FORMATS:                     # 書式の登録が無い：よくある書き方を順に試す
        try:
            return datetime.datetime.strptime(str(v).strip(), f).date()
        except ValueError:
            continue
    raise ValueError(f"日付「{v}」を読めない（2026/04/30・2026-04-30・20260430・2026年4月30日・2026.4.30 のどれでもない）")


def _csv_table(path, need):
    """(見出し, [(行番号, dict)], 問題)。"""
    text, enc = _decode(pathlib.Path(path).read_bytes())
    rd = csv.DictReader(io.StringIO(text))
    missing = [c for c in need if c not in (rd.fieldnames or [])]
    if missing:
        return None, [], f"列 {missing} が無い（文字コード {enc}、見出し {rd.fieldnames}）"
    return rd.fieldnames, list(enumerate(rd, start=2)), None


def _xlsx_table(path, need):
    from openpyxl import load_workbook
    wb = load_workbook(path, read_only=True, data_only=True)
    try:
        grid = list(wb.worksheets[0].iter_rows(values_only=True))
    finally:
        wb.close()
    for h, row in enumerate(grid[:10]):
        head = [str(c).strip() if c is not None else "" for c in row]
        if all(c in head for c in need):
            out = []
            for i, r in enumerate(grid[h + 1:], start=h + 2):
                if all(c is None or str(c).strip() == "" for c in r):
                    continue                    # 空行（シート末尾の書式だけの行など）
                out.append((i, {k: v for k, v in zip(head, r) if k}))
            return head, out, None
    return None, [], f"先頭 10 行に列 {need} がそろった見出し行が無い（最初のシート「{wb.worksheets[0].title}」）"


STATEMENT_EXT = (".csv", ".xlsx", ".xlsm")


def statement_files(root, pattern) -> list:
    """明細ファイル。説明書きの .txt などが同じフォルダにあっても読まない。"""
    return sorted(f for f in glob.glob(str(pathlib.Path(root) / pattern), recursive=True)
                  if f.lower().endswith(STATEMENT_EXT))


def _need(bank) -> list:
    cfg = bank["csv"]
    return [cfg[k] for k in ("date", "desc", "in", "out", "balance")]


def _file_rows(f, bank) -> tuple[list, str | None]:
    """1 つのファイルを bank の列名で読む：(古い順の行, 読めない理由)。"""
    cfg = bank["csv"]
    reader = _xlsx_table if f.lower().endswith((".xlsx", ".xlsm")) else _csv_table
    _, table, err = reader(f, _need(bank))
    if err:
        return [], err
    fmt = cfg.get("date_format")            # 無ければ自動（入力ブックでは書かせない）
    if len(table) >= 2 and _date(table[0][1][cfg["date"]], fmt) > _date(table[-1][1][cfg["date"]], fmt):
        # 新しい順のファイル（大手行のダウンロードに多い）は同日内の順も逆。日付で並べ直すだけでは
        # 同日の行が逆順のまま残り、残高連鎖（B5）が切れる（実在の会社で試して発見、2026-10-09）→ 先に反転する
        table = table[::-1]
    signed = cfg["in"] == cfg["out"]        # 金額が 1 列（入金は正、出金は負）の明細：出金と入金に同じ列名を登録する
    rows = []
    for i, r in table:
        if signed:
            amt = _int(r[cfg["in"]])
            inflow, outflow = (amt, 0) if amt > 0 else (0, -amt)
        else:
            inflow, outflow = _int(r[cfg["in"]]), _int(r[cfg["out"]])
        rows.append(BankRow(bank=bank["id"], date=_date(r[cfg["date"]], fmt),
                            desc=str(r[cfg["desc"]] or "").strip(), inflow=inflow, outflow=outflow,
                            balance=_int(r[cfg["balance"]]),
                            label=f"{f.replace(chr(92), '/').split('/')[-1]}:{i}"))
    return rows, None


def load(co, bank) -> tuple[list, list]:
    """(rows, problems)。rows は日付順。problems は取り込みの異常（空なら正常）。

    bank["files"]（置き場所の型）を明示した口座の読み方。入力ブックの利用者は置き場所を書かない → load_all。"""
    files = statement_files(co.root, bank["files"])
    rows, problems = [], []
    if not files:
        problems.append(f"{bank['id']}：明細ファイルが無い（{bank['files']}）")
    for f in files:
        got, err = _file_rows(f, bank)
        if err:
            problems.append(f"{f}：{err}")
            continue
        rows += got
    return _finish(rows), problems


POOL = "bank/**/*"       # 置き場所を書かない口座の明細を探す所（画面の「表」の入口がここに置く）


def load_all(root, banks, opening=None) -> tuple[dict, list]:
    """すべての口座の明細：({口座 id: rows}, problems)。

    置き場所（files）を書いた口座はその通りに読む。書いていない口座は、bank/ の中の明細を**中身で**振り分ける
    （作者 2026-10-12：利用者はフォルダの決まりを知らない。路 B の試験では「流水文件位置」の 1 欄で締められなくなった）：
      1. bank/<口座 id>/ に入っていれば、その口座
      2. 口座の列名（日付・摘要・入金・出金・残高）がそろっている口座が 1 つなら、その口座
      3. 列名が同じ口座が複数あるとき：ファイル名に口座 id か銀行名が入っていれば、その口座。無ければ残高のつながりで決める
         （明細の最初の行の直前の残高が、その口座の期首残高か、もう振り分けた明細の残高に一致する）
      4. それでも決まらなければ問題として報告する（当てずっぽうで振り分けない）
    opening は {(科目, 補助): 期首残高}。"""
    opening = opening or {}
    raw = {b["id"]: [] for b in banks}
    problems, got_file = [], set()
    co = type("Co", (), {"root": root})()
    for b in banks:
        if b.get("files"):
            raw[b["id"]], probs = load(co, b)
            problems += probs
            got_file.add(b["id"])
    auto = [b for b in banks if not b.get("files")]
    pool = statement_files(root, POOL) if auto else []
    undecided = []
    for f in pool:
        p = pathlib.Path(f)
        errs, cands = {}, []
        for b in auto:
            rows, err = _file_rows(f, b)
            if err:
                errs[b["id"]] = err
            else:
                cands.append((b, rows))
        named = [b for b in auto if p.parent.name == b["id"]]
        if named:
            if named[0]["id"] in errs:
                problems.append(f"{p.name}：{errs[named[0]['id']]}")
                continue
            cands = [(b, rows) for b, rows in cands if b is named[0]]
        if not cands:
            if len(auto) == 1:
                problems.append(f"{p.name}：{errs[auto[0]['id']]}")
            else:
                problems.append(f"{p.name}：登録したどの口座の列名とも合わない（" + "；".join(
                    f"{bid} は {e}" for bid, e in errs.items()) + "）")
            continue
        if len(cands) > 1:
            # 口座 id は語として入っているときだけ（「download」の中の a を口座 a と読まない）
            words = "".join(c if c.isalnum() else " " for c in p.stem).split()
            hit = [(b, rows) for b, rows in cands if b["id"] in words or (b.get("sub") and str(b["sub"]) in p.stem)]
            if len(hit) == 1:
                cands = hit
        if len(cands) == 1:
            raw[cands[0][0]["id"]] += cands[0][1]
            got_file.add(cands[0][0]["id"])
        else:
            undecided.append((p, cands))
    moved = True
    while undecided and moved:
        moved = False
        for item in list(undecided):
            p, cands = item
            fits = []
            for b, rows in cands:
                if not rows:
                    continue
                have = raw[b["id"]]
                before = rows[0].balance - rows[0].signed
                same = {(r.date, r.desc, r.inflow, r.outflow, r.balance) for r in have}
                if (before in {r.balance for r in have}
                        or (not have and before == opening.get((b["account"], b.get("sub", "")), 0))
                        or any((r.date, r.desc, r.inflow, r.outflow, r.balance) in same for r in rows)
                        or any(rows[-1].balance == h.balance - h.signed for h in have)):
                    fits.append((b, rows))
            if len(fits) == 1:
                raw[fits[0][0]["id"]] += fits[0][1]
                got_file.add(fits[0][0]["id"])
                undecided.remove(item)
                moved = True
    for p, cands in undecided:
        ids = "・".join(b["id"] for b, _ in cands)
        problems.append(f"{p.name}：口座 {ids} のどれの明細か決められない（列名が同じで、残高もつながらない）。"
                        f"ファイル名の頭に口座 ID を付ける（例：{cands[0][0]['id']}_{p.name}）")
    for b in auto:
        if b["id"] not in got_file:
            problems.append(f"{b['id']}：この口座の明細ファイルが無い")
    return {bid: _finish(rows) for bid, rows in raw.items()}, problems


def _finish(rows) -> list:
    # 同じ行が二つのファイルに入っている（期間の重なり）→ 完全一致だけ落とす
    seen, uniq = set(), []
    for r in rows:
        k = (r.date, r.desc, r.inflow, r.outflow, r.balance)
        if k in seen:
            continue
        seen.add(k)
        uniq.append(r)
    uniq.sort(key=lambda r: r.date)       # 安定ソート：同日はファイル内の順を保つ（新しい順のファイルは上で反転済み）
    return uniq


def chain_rows(rows):
    return [dict(balance=r.balance, inflow=r.inflow, outflow=r.outflow) for r in rows]


@dataclass
class Expected:
    key: str
    label: str
    date: datetime.date
    amount: int
    direction: str                  # out / in
    make: object                    # (row) -> Voucher
    window: int = 5
    hint: str = ""                  # 摘要に含まれるはずの語（候補の絞り込みには使わない、表示用）
    early: int = 0                  # 予定日より**前**に払うのを何日まで認めるか（0 なら window と同じ）

    def in_window(self, d) -> bool:
        delta = (d - self.date).days
        return -(self.early or self.window) <= delta <= self.window


@dataclass
class MatchResult:
    claims: list = field(default_factory=list)         # (row_id, label, expected_date, row_date, 前の日数, 後の日数)
    vouchers: list = field(default_factory=list)
    unmatched_expected: list = field(default_factory=list)
    ambiguous: list = field(default_factory=list)      # (expected, [rows])


def match(expected, rows) -> MatchResult:
    res = MatchResult()
    for x in sorted(expected, key=lambda x: x.date):
        cands = [r for r in rows if r.claimed_by is None and r.amount_abs == x.amount
                 and (r.outflow if x.direction == "out" else r.inflow)
                 and x.in_window(r.date)]
        if len(cands) == 1:
            r = cands[0]
            r.claimed_by = x.key
            res.claims.append((r.id, x.label, x.date, r.date, x.early or x.window, x.window))
            made = x.make(r)
            if made is None:                 # 単体テストは仕訳を作らない make を渡す
                continue
            # 一つの明細から複数の伝票ができることがある（年度更新：納付＋前年度分の精算）。
            # 約束：リストの**先頭が納付の伝票**で、銀行明細に紐づくのはそれだけ。
            made = made if isinstance(made, list) else [made]
            made[0].bank_row = r.id
            res.vouchers.extend(made)
        elif len(cands) > 1:
            res.ambiguous.append((x, cands))
        else:
            res.unmatched_expected.append(x)
    return res


def rule_hits(row, rules):
    hits = []
    for r in rules:
        w = r["when"]
        if "direction" in w and w["direction"] != ("out" if row.outflow else "in"):
            continue
        if "desc_contains" in w and w["desc_contains"] not in row.desc:
            continue
        if "desc_regex" in w and not re.search(w["desc_regex"], row.desc):
            continue
        if "amount" in w and int(w["amount"]) != row.amount_abs:
            continue
        hits.append(r)
    return hits
