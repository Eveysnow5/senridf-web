# -*- coding: utf-8 -*-
"""エンジンのメッセージ（日本語）を画面の言語に寄せる。

作者 2026-10-09：「事前チェックやエラーがエンジンの日本語そのまま。中国語の画面なら訳すべき」。
エンジンの文言はそのまま（日本語が正本、ログ・底稿・テストはこれを見る）。ここでは**資料を準備する段階で
客がよく見る**メッセージだけを型（正規表現）で拾って訳す。型に当たらないものは日本語のまま返す
——当て推量の訳を出すより、原文を見せる方がよい。

    translate("会社 に「name」が無い（…）", "zh") -> "公司 缺少「name」（…）"
"""
from __future__ import annotations

import re

# (型, {言語: 訳})。{0} {1} … は型のグループ。上から順に試す。
PATTERNS = [
    (r"(.+?) に「(.+?)」が無い（既定値は置かない設計——明示すること）",
     {"zh": "{0} 缺少「{1}」（本产品不设默认值，请明确填写）",
      "en": "{0} is missing “{1}” (no defaults — please fill it in)"}),
    (r"方針 (\w+) が会社にも事務所既定にも無い——(.+?)。選択肢 (.+)",
     {"zh": "方针 {0} 没有填写——{1}。选项 {2}", "en": "Policy {0} is not set — {1}. Choices {2}"}),
    (r"方針 (\w+) = (.+?) は選択肢 (.+) に無い",
     {"zh": "方针 {0} = {1} 不在选项 {2} 中", "en": "Policy {0} = {1} is not one of {2}"}),
    (r"consumption_tax\.(\w+) が無い——選択肢 (.+?)（by・at を添えて書く）",
     {"zh": "消费税 {0} 没有填写——选项 {1}（同时写判断人和日期）",
      "en": "Consumption tax {0} is not set — choices {1} (with who and when)"}),
    (r"consumption_tax\.(\w+) = (.+?) は選択肢 (.+) に無い",
     {"zh": "消费税 {0} = {1} 不在选项 {2} 中", "en": "Consumption tax {0} = {1} is not one of {2}"}),
    (r"(.+?)：判断の記録に知らない項目 (.+?)。理由に半角カンマ「,」があると .+",
     {"zh": "{0}：判断记录里有不认识的项目 {1}。理由里有半角逗号「,」时，一行写法会被截断——请用引号括起理由，或分行写",
      "en": "{0}: unknown fields {1} in the judgment. A half-width comma in a one-line reason splits it — quote the reason or write it on separate lines"}),
    (r"(.+?)：判断の記録（by・at）が無い——値だけの書き方は受け付けない",
     {"zh": "{0}：缺少判断记录（判断人 by、日期 at）——只写值不被接受",
      "en": "{0}: no judgment record (by, at) — a bare value is not accepted"}),
    (r"(.+?)：誰が判断したか（by）が無い", {"zh": "{0}：缺少判断人（by）", "en": "{0}: missing who decided (by)"}),
    (r"(.+?)：いつ判断したか（at）が無い", {"zh": "{0}：缺少判断日期（at）", "en": "{0}: missing when it was decided (at)"}),
    (r"(.+?)：at「(.+?)」が日付（YYYY-MM-DD）でない",
     {"zh": "{0}：日期「{1}」不是 YYYY-MM-DD 格式", "en": "{0}: date “{1}” is not YYYY-MM-DD"}),
    (r"(.+?)(?:：|の)科目「(.+?)」が科目表に無い",
     {"zh": "{0}：科目「{1}」不在科目表中（新科目请写在「追加科目」）",
      "en": "{0}: account “{1}” is not in the chart (add it under extra accounts)"}),
    (r"都道府県「(.+?)」は協会けんぽの料率表に無い",
     {"zh": "都道府县「{0}」不在协会けんぽ的费率表中", "en": "Prefecture “{0}” is not in the Kyokai Kenpo rate table"}),
    (r"(.+?) に company\.yaml が無い", {"zh": "{0} 里没有 company.yaml", "en": "No company.yaml in {0}"}),
    (r"従業員 (\S+) が名簿に無い", {"zh": "员工 {0} 不在名册中", "en": "Employee {0} is not in the roster"}),
    (r"従業員 (\S+): shaho（社会保険加入）と koyou（雇用保険加入）を true/false で明示すること",
     {"zh": "员工 {0}：请用 true/false 写明是否参加社保（shaho）和雇用保险（koyou）",
      "en": "Employee {0}: state shaho and koyou as true/false"}),
    (r"従業員 (\S+): 社会保険に加入しているのに標準報酬月額が無い",
     {"zh": "员工 {0}：参加了社保却没有标准报酬月额", "en": "Employee {0}: insured but no standard monthly remuneration"}),
    (r"調整仕訳 (\S+)：借方 (.+?) ≠ 貸方 (.+)",
     {"zh": "调整分录 {0}：借方 {1} ≠ 贷方 {2}", "en": "Adjusting entry {0}: debit {1} ≠ credit {2}"}),
    (r"回答 (.+?)：account と lines（内訳）は同時に書かない",
     {"zh": "回答 {0}：科目和拆分明细（lines）不能同时写", "en": "Answer {0}: give either account or lines, not both"}),
    # 事前チェック（web.precheck）の文言
    (r"YAML の書式：(.+)", {"zh": "YAML 格式错误：{0}", "en": "YAML format error: {0}"}),
    (r"文字コードが UTF-8 でない（メモ帳なら「UTF-8」で保存し直す）",
     {"zh": "文件编码不是 UTF-8（用记事本另存为「UTF-8」）", "en": "Not UTF-8 (re-save as UTF-8)"}),
    (r"company\.yaml の bank_accounts が無い",
     {"zh": "company.yaml 里没有银行账户（bank_accounts）", "en": "No bank_accounts in company.yaml"}),
    (r"(\S+)：(\S+) に当たるファイルが無い",
     {"zh": "{0}：找不到符合 {1} 的流水文件（CSV 或 Excel）", "en": "{0}: no statement file matches {1} (CSV or Excel)"}),
    (r"(\S+) (\d+) ファイル (\d+) 行（(.+?)〜(.+?)）",
     {"zh": "{0}：{1} 个文件 {2} 行（{3}〜{4}）", "en": "{0}: {1} file(s), {2} rows ({3} to {4})"}),
    (r"⚠ (\S+) の月末までの明細が無い（最後 (.+?)）",
     {"zh": "⚠ 流水没有覆盖到 {0} 的月末（最后一笔 {1}）", "en": "⚠ statements do not reach the end of {0} (last {1})"}),
    (r"(\S+)：無し（名簿の固定給だけで計算）（フォルダ (\d+) か月分）",
     {"zh": "{0}：无（按名册的固定工资计算）（共 {1} 个月的文件夹）",
      "en": "{0}: none (roster pay is used) ({1} monthly folders)"}),
    (r"(\S+)：(.+?)（フォルダ (\d+) か月分）",
     {"zh": "{0}：{1}（共 {2} 个月的文件夹）", "en": "{0}: {1} ({2} monthly folders)"}),
    (r"表「(.+?)」第 (\d+) 行：(.+)", {"zh": "表「{0}」第 {1} 行：{2}", "en": "Sheet “{0}” row {1}: {2}"}),
    (r"员工ID「(.+?)」が「员工」表に無い",
     {"zh": "员工ID「{0}」不在「员工」表中", "en": "Employee ID “{0}” is not in the employee sheet"}),
    (r"资产ID「(.+?)」が「固定资产」表に無い",
     {"zh": "资产ID「{0}」不在「固定资产」表中", "en": "Asset ID “{0}” is not in the fixed asset sheet"}),
    (r"决算月が「法人税」表に無い", {"zh": "决算月不在「法人税」表中", "en": "Year-end month not in the corporate tax sheet"}),
    (r"列 (.+?) が無い（文字コード (.+?)、見出し (.+)）",
     {"zh": "缺少列 {0}（编码 {1}，表头 {2}）——company.yaml 银行账户的表头名要和流水文件一致",
      "en": "Columns {0} not found (encoding {1}, header {2}) — the column names in company.yaml must match the file"}),
    (r"先頭 10 行に列 (.+?) がそろった見出し行が無い（最初のシート「(.+?)」）",
     {"zh": "第一张表「{1}」的前 10 行里找不到含有 {0} 的表头", "en": "No header row with {0} in the first 10 rows of sheet “{1}”"}),
]
_COMPILED = [(re.compile(p), t) for p, t in PATTERNS]

# 方針の説明（company.POLICY_HELP）。エラー文の中に丸ごと入るので、句ごと置き換える
POLICY_HELP_TR = {
    "shaho_collection": ("从工资扣社保的月份：next_month（翌月征收，扣上个月的）/ same_month（当月征收）",
                         "month of salary deduction: next_month (deduct last month's) / same_month"),
    "shaho_rounding": ("本人负担部分的尾数：deduct_half_down（法定，工资扣除）/ cash_half_up / truncate（特约）",
                       "rounding of the employee share: deduct_half_down (statutory) / cash_half_up / truncate"),
    "koyou_rounding": ("雇用保险本人负担部分的尾数（与社保相同的三选一）", "rounding of the employment insurance employee share"),
    "support_rounding": ("子育て支援金本人负担是与健保（＋介护）合并取整，还是分开取整",
                         "round the child-support levy together with health insurance or separately"),
    "koyou_rate_basis": ("雇用保险费率的年度按工资截止日还是支付日判断（一次资料未确认——按公司的做法选）",
                         "decide the employment insurance rate year by the closing date or the pay date"),
    "shaho_expense": ("公司负担的社保：accrual（月末计提未払费用）/ on_payment（缴纳时计费用）",
                      "employer share: accrual (accrue at month end) / on_payment (expense when paid)"),
    "labor_insurance_expense": ("劳动保险的公司负担：monthly_accrual（每月按工资估算计提）/ on_payment（年度更新缴纳时计费用）",
                                "employer labour insurance: monthly_accrual / on_payment"),
    "gensen_nouki_tokurei": ("源泉所得税的纳期特例（是否已获批准）", "special payment schedule for withholding tax (approved?)"),
    "juminzei_nouki_tokurei": ("住民税的纳期特例（是否已获批准）", "special payment schedule for resident tax (approved?)"),
}


def _phrases(text: str, lang: str) -> str:
    from .company import POLICY_HELP
    i = 0 if lang == "zh" else 1
    for k, ja in POLICY_HELP.items():
        if ja in text and k in POLICY_HELP_TR:
            text = text.replace(ja, POLICY_HELP_TR[k][i])
    return text


def _one(msg: str, lang: str) -> str:
    for rx, tr in _COMPILED:
        m = rx.fullmatch(msg.strip())
        if m and lang in tr:
            groups = [_phrases(_one(g, lang), lang) if g else "" for g in m.groups()]
            return tr[lang].format(*groups)
    return msg


def translate(msg, lang: str):
    """「；」で区切られた複数のメッセージも一つずつ訳す。ja・未知の言語はそのまま。"""
    if not msg or lang not in ("zh", "en"):
        return msg
    return "；".join(_one(part, lang) for part in str(msg).split("；"))
