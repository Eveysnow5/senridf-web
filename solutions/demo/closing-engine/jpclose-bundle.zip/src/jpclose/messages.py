# -*- coding: utf-8 -*-
"""エンジンのメッセージ（日本語）を画面の言語に寄せる。

作者 2026-10-09：「事前チェックやエラーがエンジンの日本語そのまま。中国語の画面なら訳すべき」。
エンジンの文言はそのまま（日本語が正本、ログ・底稿・テストはこれを見る）。ここでは**資料を準備する段階で
客がよく見る**メッセージだけを型（正規表現）で拾って訳す。型に当たらないものは日本語のまま返す
——当て推量の訳を出すより、原文を見せる方がよい。

    translate("会社 に「name」が無い（…）", "zh") -> "公司 缺少「name」（…）"
"""
from __future__ import annotations

import re

# (型, {言語: 訳})。{0} {1} … は型のグループ。上から順に試す。
PATTERNS = [
    (r"(.+?) に「(.+?)」が無い（既定値は置かない設計——明示すること）",
     {"zh": "{0} 缺少「{1}」（本产品不设默认值，请明确填写）",
      "en": "{0} is missing “{1}” (no defaults — please fill it in)"}),
    (r"方針 (\w+) が会社にも事務所既定にも無い——(.+?)。選択肢 (.+)",
     {"zh": "方针 {0} 没有填写——{1}。选项 {2}", "en": "Policy {0} is not set — {1}. Choices {2}"}),
    (r"方針 (\w+) = (.+?) は選択肢 (.+) に無い",
     {"zh": "方针 {0} = {1} 不在选项 {2} 中", "en": "Policy {0} = {1} is not one of {2}"}),
    (r"consumption_tax\.(\w+) が無い——選択肢 (.+?)（by・at を添えて書く）",
     {"zh": "消费税 {0} 没有填写——选项 {1}（同时写判断人和日期）",
      "en": "Consumption tax {0} is not set — choices {1} (with who and when)"}),
    (r"consumption_tax\.(\w+) = (.+?) は選択肢 (.+) に無い",
     {"zh": "消费税 {0} = {1} 不在选项 {2} 中", "en": "Consumption tax {0} = {1} is not one of {2}"}),
    (r"(.+?)：判断の記録に知らない項目 (.+?)。理由に半角カンマ「,」があると .+",
     {"zh": "{0}：判断记录里有不认识的项目 {1}。理由里有半角逗号「,」时，一行写法会被截断——请用引号括起理由，或分行写",
      "en": "{0}: unknown fields {1} in the judgment. A half-width comma in a one-line reason splits it — quote the reason or write it on separate lines"}),
    (r"(.+?)：判断の記録（by・at）が無い——値だけの書き方は受け付けない",
     {"zh": "{0}：缺少判断记录（判断人 by、日期 at）——只写值不被接受",
      "en": "{0}: no judgment record (by, at) — a bare value is not accepted"}),
    (r"(.+?)：誰が判断したか（by）が無い", {"zh": "{0}：缺少判断人（by）", "en": "{0}: missing who decided (by)"}),
    (r"(.+?)：いつ判断したか（at）が無い", {"zh": "{0}：缺少判断日期（at）", "en": "{0}: missing when it was decided (at)"}),
    (r"(.+?)：at「(.+?)」が日付（YYYY-MM-DD）でない",
     {"zh": "{0}：日期「{1}」不是 YYYY-MM-DD 格式", "en": "{0}: date “{1}” is not YYYY-MM-DD"}),
    (r"(.+?)(?:：|の)科目「(.+?)」が科目表に無い",
     {"zh": "{0}：科目「{1}」不在科目表中（新科目请写在「追加科目」）",
      "en": "{0}: account “{1}” is not in the chart (add it under extra accounts)"}),
    (r"都道府県「(.+?)」は協会けんぽの料率表に無い",
     {"zh": "都道府县「{0}」不在协会けんぽ的费率表中", "en": "Prefecture “{0}” is not in the Kyokai Kenpo rate table"}),
    (r"(.+?) に company\.yaml が無い", {"zh": "{0} 里没有 company.yaml", "en": "No company.yaml in {0}"}),
    (r"従業員 (\S+) が名簿に無い", {"zh": "员工 {0} 不在名册中", "en": "Employee {0} is not in the roster"}),
    (r"従業員 (\S+): shaho（社会保険加入）と koyou（雇用保険加入）を true/false で明示すること",
     {"zh": "员工 {0}：请用 true/false 写明是否参加社保（shaho）和雇用保险（koyou）",
      "en": "Employee {0}: state shaho and koyou as true/false"}),
    (r"従業員 (\S+): 社会保険に加入しているのに標準報酬月額が無い",
     {"zh": "员工 {0}：参加了社保却没有标准报酬月额", "en": "Employee {0}: insured but no standard monthly remuneration"}),
    (r"調整仕訳 (\S+)：借方 (.+?) ≠ 貸方 (.+)",
     {"zh": "调整分录 {0}：借方 {1} ≠ 贷方 {2}", "en": "Adjusting entry {0}: debit {1} ≠ credit {2}"}),
    (r"回答 (.+?)：account と lines（内訳）は同時に書かない",
     {"zh": "回答 {0}：科目和拆分明细（lines）不能同时写", "en": "Answer {0}: give either account or lines, not both"}),
    # 事前チェック（web.precheck）の文言
    (r"YAML の書式：(.+)", {"zh": "YAML 格式错误：{0}", "en": "YAML format error: {0}"}),
    (r"文字コードが UTF-8 でない（メモ帳なら「UTF-8」で保存し直す）",
     {"zh": "文件编码不是 UTF-8（用记事本另存为「UTF-8」）", "en": "Not UTF-8 (re-save as UTF-8)"}),
    (r"company\.yaml の bank_accounts が無い",
     {"zh": "company.yaml 里没有银行账户（bank_accounts）", "en": "No bank_accounts in company.yaml"}),
    (r"(\S+)：(\S+) に当たるファイルが無い",
     {"zh": "{0}：找不到符合 {1} 的流水文件（CSV 或 Excel）", "en": "{0}: no statement file matches {1} (CSV or Excel)"}),
    (r"(\S+) (\d+) ファイル (\d+) 行（(.+?)〜(.+?)）",
     {"zh": "{0}：{1} 个文件 {2} 行（{3}〜{4}）", "en": "{0}: {1} file(s), {2} rows ({3} to {4})"}),
    (r"⚠ (\S+) の月末までの明細が無い（最後 (.+?)）",
     {"zh": "⚠ 流水没有覆盖到 {0} 的月末（最后一笔 {1}）", "en": "⚠ statements do not reach the end of {0} (last {1})"}),
    (r"(\S+)：無し（名簿の固定給だけで計算）（フォルダ (\d+) か月分）",
     {"zh": "{0}：无（按名册的固定工资计算）（共 {1} 个月的文件夹）",
      "en": "{0}: none (roster pay is used) ({1} monthly folders)"}),
    (r"(\S+)：(.+?)（フォルダ (\d+) か月分）",
     {"zh": "{0}：{1}（共 {2} 个月的文件夹）", "en": "{0}: {1} ({2} monthly folders)"}),
    (r"表「(.+?)」第 (\d+) 行：(.+)", {"zh": "表「{0}」第 {1} 行：{2}", "en": "Sheet “{0}” row {1}: {2}"}),
    (r"员工ID「(.+?)」が「员工」表に無い",
     {"zh": "员工ID「{0}」不在「员工」表中", "en": "Employee ID “{0}” is not in the employee sheet"}),
    (r"资产ID「(.+?)」が「固定资产」表に無い",
     {"zh": "资产ID「{0}」不在「固定资产」表中", "en": "Asset ID “{0}” is not in the fixed asset sheet"}),
    (r"决算月が「法人税」表に無い", {"zh": "决算月不在「法人税」表中", "en": "Year-end month not in the corporate tax sheet"}),
    (r"列 (.+?) が無い（文字コード (.+?)、見出し (.+)）",
     {"zh": "缺少列 {0}（编码 {1}，表头 {2}）——company.yaml 银行账户的表头名要和流水文件一致",
      "en": "Columns {0} not found (encoding {1}, header {2}) — the column names in company.yaml must match the file"}),
    (r"先頭 10 行に列 (.+?) がそろった見出し行が無い（最初のシート「(.+?)」）",
     {"zh": "第一张表「{1}」的前 10 行里找不到含有 {0} 的表头", "en": "No header row with {0} in the first 10 rows of sheet “{1}”"}),
]

# ------------------------------------------------------------------ 結果画面（検査・要確認）
# 作者 2026-10-10：「検査の明細と要確認の説明がまだ日本語、中国語の客には"なぜ通らないか"が読めない」。
# 方針は上と同じ：エンジンの日本語が正本。型に当たらないものは日本語のまま（銀行の摘要などは訳さない）。
CHECK_NAMES = {
    "A1": ("每张凭证借贷平衡", "Each voucher balances"),
    "A2": ("日记账借贷总额一致", "Journal debit and credit totals agree"),
    "A3": ("所有科目都在科目表中", "Every account is in the chart"),
    "A4": ("日期在期间内且不是未来", "Dates are inside the period and not in the future"),
    "A7": ("凭证号连续、无重复", "Voucher numbers are continuous with no duplicates"),
    "A9": ("负债科目没有无法说明的借方余额", "No unexplained debit balance on a liability account"),
    "B0": ("银行流水的读取", "Bank statement import"),
    "B1B2": ("每笔流水只被认领一次，且在日期窗口内", "Each bank row is claimed once and inside its date window"),
    "B4": ("每笔流水都归入 对上／入账／待确认 之一", "Every bank row is matched, booked or pending — exactly one"),
    "B5": ("银行余额链条闭合", "The bank balance chain closes"),
    "B6": ("账面存款余额＝银行余额", "Book deposit balance = bank balance"),
    "C1": ("工资明细内部一致（支付－扣除＝实发，扣除均非负）", "Payslips add up (pay − deductions = net, no negative deduction)"),
    "C2": ("缴费通知的个人负担＝各人扣除额合计（含奖金）", "Employee share on the notice = sum of deductions (bonuses included)"),
    "C3": ("期初未付社保（上月份）＝计算", "Opening unpaid social insurance (last month) = computed"),
    "C4": ("固定资产台账的取得价＝账面资产余额", "Fixed asset register cost = book asset balance"),
    "C5": ("年度更新精算后的暂付款＝本年度概算的已缴部分", "Prepaid labour insurance after settlement = this year's estimate paid"),
    "E1": ("社保・源泉税・住民税在期限内缴纳", "Social insurance, withholding and resident tax paid by the due date"),
    "F1": ("试算表借贷平衡", "Trial balance balances"),
    "F2": ("资产负债表：资产＝负债＋净资产（含本期损益）", "Balance sheet: assets = liabilities + equity (incl. current profit)"),
    "X1": ("文中引用的待确认编号都存在", "Every pending number cited in the text exists"),
    "X2": ("回答（decisions.yaml）都对应到实际的待确认", "Every answer (decisions.yaml) matches a real pending item"),
}
CATEGORY_NAMES = {
    "setting": ("设定・方针", "Settings and policies"),
    "closing": ("决算（年度末确认）", "Year-end checks"),
    "bank_unmatched": ("银行流水（无规则）", "Bank row (no rule)"),
    "bank_ambiguous": ("银行流水（候选多个）", "Bank row (several candidates)"),
    "expected_missing": ("预定的支付没有出现", "Expected payment not found"),
    "amount_mismatch": ("金额不一致", "Amount differs"),
    "payroll": ("工资", "Payroll"),
    "evidence": ("依据书类", "Evidence"),
    "assumption": ("前提（一次资料未确认）", "Assumption (not confirmed in primary sources)"),
    "stale_decision": ("未被使用的回答", "Unused answer"),
}
# 文言が固定のもの（要確認の題・本文、検査の注記、型の中の語）
FIXED = {
    "通勤手当の非課税限度": ("通勤津贴的非课税限度", "Non-taxable limit of commuting allowance"),
    "源泉の式区間の端数処理": ("源泉税公式区间的尾数处理", "Rounding in the formula range of the withholding table"),
    "労働保険の年度更新": ("劳动保险的年度更新", "Labour insurance annual renewal"),
    "入退社月の支給額": ("入职・离职当月的支付额", "Pay in the month of joining or leaving"),
    "住民税の月額が無い": ("缺少住民税月额", "Resident tax monthly amount missing"),
    "退職者の住民税": ("离职员工的住民税", "Resident tax of a leaver"),
    "標準報酬月額の根拠書類が未登録": ("标准报酬月额的依据书类未登记", "No document registered for the standard monthly remuneration"),
    "同月得喪": ("同月取得丧失", "Insurance gained and lost in the same month"),
    "賞与の年度累計（健保上限）": ("奖金的年度累计（健保上限）", "Annual bonus total (health insurance cap)"),
    "賞与の源泉（前月に給与が無い）": ("奖金的源泉税（上月无工资）", "Bonus withholding (no salary last month)"),
    "賞与の源泉（前月給与の10倍超）": ("奖金的源泉税（超过上月工资 10 倍）", "Bonus withholding (over 10× last month's salary)"),
    "役員への賞与": ("支付给董事的奖金", "Bonus to a director"),
    "使われなかった回答": ("未被使用的回答", "Unused answer"),
    "期末の棚卸": ("期末盘点", "Year-end stocktake"),
    "見越し・繰延": ("预提・待摊", "Accruals and deferrals"),
    "債権の回収可能性": ("应收款项的可回收性", "Collectability of receivables"),
    "固定資産の実在": ("固定资产的实存", "Existence of fixed assets"),
    "役員報酬": ("董事报酬", "Directors' pay"),
    "消費税の精算": ("消费税的结算", "Consumption tax settlement"),
    "法人税等の計上": ("计提法人税等", "Accrue corporate taxes"),
    "法人税等の計算表": ("法人税等计算表", "Corporate tax worksheet"),
    "法人税：軽減税率の期限": ("法人税：轻减税率的期限", "Corporate tax: expiry of the reduced rate"),
    "事業税：1年未満の事業年度": ("事业税：不足一年的事业年度", "Enterprise tax: business year shorter than 12 months"),
    "消費税の端数（行ごと）": ("消费税的尾数（按行处理）", "Consumption tax rounding (per line)"),
    "消費税：未対応の制度": ("消费税：尚未支持的制度", "Consumption tax: rules not covered"),
    "年度更新：概算の見込額": ("年度更新：概算的预计工资额", "Annual renewal: estimated wages"),
    "年度更新：延納の要件": ("年度更新：分期缴纳的条件", "Annual renewal: conditions for instalments"),
    "年度更新：延納の各期の額": ("年度更新：分期缴纳各期金额", "Annual renewal: amount of each instalment"),
    "出金": ("支出", "payment"), "入金": ("收入", "receipt"), "入社": ("入职", "joined"), "退社": ("离职", "left"),
    "源泉所得税": ("源泉所得税", "Withholding tax"), "住民税": ("住民税", "Resident tax"),
    "（補助なし）": ("（无明细）", "(no sub-account)"),
    "月額表の 740,000 円以上（または乙欄 3.063%）は式で計算した。円未満切捨てとしたが、表の注記に明記がない（rules_r08.gensen_formula_rounding）":
        ("月额表 740,000 日元以上（或乙栏 3.063%）按公式计算，不足 1 日元舍去，但表的注释没有写明（rules_r08.gensen_formula_rounding）",
         "Amounts of 740,000 yen or more (or column Otsu 3.063%) use the formula; fractions of a yen were truncated, "
         "which the table notes do not state (rules_r08.gensen_formula_rounding)"),
    "税抜経理の税額は仕訳の行ごとに円未満切捨てで抜き出した。インボイス制度では請求書ごと・税率ごとに 1 回の端数処理なので、1 枚の請求書が複数行なら数円ずれうる":
        ("税抜记账的税额按每行分录舍去不足 1 日元。发票制度是每张发票、每个税率取整一次，所以一张发票分成多行时可能差几日元",
         "Tax was split out per journal line with fractions truncated. Under the invoice system rounding is once per invoice "
         "and rate, so an invoice booked on several lines may differ by a few yen"),
    "インボイス制度の経過措置（適格請求書発行事業者以外からの仕入の控除割合）・2割特例・旧税率の経過措置は計算していない。該当する仕入があれば申告前に調整する":
        ("没有计算发票制度的过渡措施（从非适格发票开具者采购的扣除比例）、2 成特例、旧税率过渡措施。如有相关采购，申报前请调整",
         "Transitional rules of the invoice system (purchases from non-registered sellers), the 20% special rule and old-rate "
         "transitions are not computed. Adjust before filing if they apply"),
    "年800万円以下 15% は租税特別措置。適用期限を一次資料で確認していない":
        ("年 800 万日元以下 15% 属于租税特别措施，适用期限尚未用一次资料确认",
         "The 15% rate up to 8 million yen is a special measure; its expiry has not been checked in primary sources"),
    "所得の区分（400万・800万）を月数で按分した。按分の規定を一次資料で確認していない":
        ("所得区间（400 万・800 万）按月数折算，折算的规定尚未用一次资料确认",
         "The income bands (4m, 8m) were prorated by months; the proration rule is not confirmed in primary sources"),
    "3 回分割したときの各期の額（端数の寄せ方）は一次資料で未確認。第 1 期を 1/3（円未満切捨て）とした":
        ("分 3 期缴纳时各期金额（尾数归属）尚未用一次资料确认，第 1 期按 1/3（舍去不足 1 日元）",
         "How the three instalments split the remainder is not confirmed; the first is 1/3 truncated"),
    # 年度末の確認リスト（close.YEAR_END_CHECKLIST の本文）
    "棚卸資産（商品・製品・貯蔵品）の期末残高を確定し、売上原価との振替を入れる":
        ("确定存货（商品・产品・储藏品）的期末余额，并做与销售成本之间的结转",
         "Fix the year-end inventory balance and post the transfer to cost of sales"),
    "前払費用・未払費用・未収収益・前受収益を確認する":
        ("确认预付费用・应付费用・应收收益・预收收益", "Review prepaid and accrued expenses and income"),
    "売掛金・未収入金の回収可能性を確認し、必要なら貸倒引当金を計上する":
        ("确认应收账款・其他应收款的可回收性，需要时计提坏账准备", "Review collectability and provide for bad debts if needed"),
    "固定資産台帳と現物を照合し、除却・売却を反映する":
        ("将固定资产台账与实物核对，反映报废・出售", "Reconcile the register with the assets and record disposals"),
    "期中に役員報酬を変えていないか（定期同額給与）、事前確定届出給与と一致するか":
        ("期中有没有变更董事报酬（定期同额给与），是否与事前确定申报给与一致",
         "Was directors' pay changed mid-year (fixed monthly pay), does it match the advance notice"),
    "当期の消費税額を確定し、未払消費税等（または未収）を計上する":
        ("确定本期消费税额，计提应交消费税（或应收）", "Fix this year's consumption tax and accrue it"),
    "法人税・地方法人税・住民税・事業税（特別法人事業税）を計上する":
        ("计提法人税・地方法人税・住民税・事业税（特别法人事业税）", "Accrue corporate, local corporate, inhabitant and enterprise taxes"),
}

RESULT_PATTERNS = [
    # 予定の支払のラベル（題の中に入る）
    (r"給与振込 (\S+)", {"zh": "工资转账 {0}", "en": "Salary transfer {0}"}),
    (r"賞与振込 (\S+)", {"zh": "奖金转账 {0}", "en": "Bonus transfer {0}"}),
    (r"(\d{4}-\d{2})分 社会保険料（期限 (.+?)）", {"zh": "{0} 月份社保（期限 {1}）", "en": "Social insurance for {0} (due {1})"}),
    (r"労働保険 年度更新（期限 (.+?)）", {"zh": "劳动保险年度更新（期限 {0}）", "en": "Labour insurance annual renewal (due {0})"}),
    (r"(源泉所得税|住民税)（納期の特例、(.+)、期限 (\S+?)）",
     {"zh": "{0}（纳期特例，{1}，期限 {2}）", "en": "{0} (special schedule, {1}, due {2})"}),
    (r"(.+)＋期首残高 ([\-\d,]+)（開始月前の支給分）",
     {"zh": "{0}＋期初余额 {1}（开始月之前支付的部分）", "en": "{0} + opening balance {1} (paid before the start month)"}),
    (r"(\d{4}-\d{2})〜(\d{4}-\d{2}) 支給分 ([\-\d,]+)", {"zh": "{0}〜{1} 支付部分 {2}", "en": "paid {0} to {1}: {2}"}),
    (r"(源泉所得税|住民税)（(\d{4}-\d{2}) 支給分、期限 (\S+?)）",
     {"zh": "{0}（{1} 支付部分，期限 {2}）", "en": "{0} (paid {1}, due {2})"}),
    # 要確認の題
    (r"(.+)：ルールが複数当たる", {"zh": "{0}：同时符合多条规则", "en": "{0}: several rules match"}),
    (r"(.+)：候補が複数", {"zh": "{0}：候选流水有多笔", "en": "{0}: several candidate rows"}),
    (r"(.+)：金額が違う", {"zh": "{0}：金额不一致", "en": "{0}: amount differs"}),
    (r"(.+)が明細に無い", {"zh": "{0} 没有出现在银行流水中", "en": "{0}: not in the bank statement"}),
    (r"社保の徴収方法の切替：(\d{4}-\d{2})分の本人負担を二重に控除している疑い",
     {"zh": "社保征收方式切换：{0} 月份的个人负担疑似被扣了两次",
      "en": "Social insurance collection switch: the employee share for {0} may have been deducted twice"}),
    (r"期首の預り金（(.+?)）([\-\d,]+) が納期を過ぎても残っている",
     {"zh": "期初預り金（{0}）{1} 已过缴纳期限仍未处理", "en": "Opening withholding ({0}) {1} is still unpaid past the due date"}),
    (r"減価償却 (.+)", {"zh": "折旧 {0}", "en": "Depreciation {0}"}),
    # 要確認の本文
    (r"(\d{4}-\d{2}-\d{2})（前 (\d+) 日〜後 (\d+) 日）に ([\-\d,]+) 円の(出金|入金)が無い",
     {"zh": "{0}（前 {1} 天至后 {2} 天）内没有 {3} 日元的{4}",
      "en": "No {4} of {3} yen from {1} days before to {2} days after {0}"}),
    (r"(\d{4}-\d{2}-\d{2}) ([+\-][\d,]+) 円。性質（科目・税区分）と証憑を回答する",
     {"zh": "{0} {1} 日元。请回答这笔的性质（科目・税区分）和凭证",
      "en": "{0} {1} yen. Answer what it is (account, tax category) and the evidence"}),
    (r"(\d{4}-\d{2}-\d{2}) ([+\-][\d,]+) 円にルール (.+?) が当たる。ルールを直すか回答する",
     {"zh": "{0} {1} 日元同时符合规则 {2}。请修改规则或直接回答", "en": "{0} {1} yen matches rules {2}. Fix the rules or answer"}),
    (r"([\-\d,]+) 円・(\S+?)（前 (\d+) 日〜後 (\d+) 日）に同額の明細が (\d+) 件：(.+)。どれかを決めて回答する",
     {"zh": "{0} 日元・{1}（前 {2} 天至后 {3} 天）内有 {4} 笔同额流水：{5}。请选定一笔并回答",
      "en": "{0} yen, {1} ({2} days before to {3} after): {4} rows with the same amount: {5}. Choose one and answer"}),
    (r"計算 ([\-\d,]+) 円に対し、明細 (\S+?)「(.+?)」は ([\-\d,]+) 円（差 ([+\-][\d,]+)）。標準報酬月額の改定・資格の得喪・料率の誤り等を確認",
     {"zh": "计算为 {0} 日元，流水 {1}「{2}」为 {3} 日元（差 {4}）。请确认标准报酬月额的改定、资格取得丧失、费率错误等",
      "en": "Computed {0} yen, but the row {1} “{2}” is {3} yen (difference {4}). Check for a revised standard remuneration, "
            "insurance gained or lost, or a wrong rate"}),
    (r"(\S+) は特別徴収の設定があるが (\d{4}-\d{2}) の月額が無い。決定通知書の月額を入れるか、退職時の一括徴収・普通徴収切替を判断する（特別徴収がまだ始まっていない月なら 0 と明示する）",
     {"zh": "{0} 设置了特别征收，但缺少 {1} 的月额。请填入决定通知书上的月额，或判断离职时一次征收／改为普通征收（特别征收尚未开始的月份请明确填 0）",
      "en": "{0} is set up for special collection but has no amount for {1}. Enter the amount from the notice, or decide on "
            "lump-sum or ordinary collection at leaving (enter 0 explicitly for months before collection starts)"}),
    (r"(\S+) は (\S+) 退職。残りの特別徴収税額を最後の給与で一括徴収するか、普通徴収に切り替えるか（市区町村へ異動届）を決める。初版は当月分だけ控除した",
     {"zh": "{0} 于 {1} 离职。请决定剩余的特别征收税额是从最后一次工资一次扣除，还是改为普通征收（向市区町村提交异动届）。目前只扣了当月部分",
      "en": "{0} left on {1}. Decide whether to collect the remaining resident tax from the last salary or switch to ordinary "
            "collection (notify the municipality). For now only this month was deducted"}),
    (r"(\S+) の (\S+) ([\-\d,]+) 円を全額非課税とした。(.+)",
     {"zh": "{0} 的 {1} {2} 日元按全额非课税处理。{3}", "en": "{0}'s {1} of {2} yen was treated as fully non-taxable. {3}"}),
    (r"通勤方法（commute\.mode：transit / car / mixed）が名簿に無い",
     {"zh": "名册中没有通勤方式（commute.mode：transit / car / mixed）",
      "en": "The roster has no commute mode (commute.mode: transit / car / mixed)"}),
    (r"(\S+) は (\d{4}-\d{2}) に(入社|退社)（(\S+?)）。固定給を満額で計算した。日割りするなら月次入力で支給額を明示する",
     {"zh": "{0} 于 {1} {2}（{3}）。按固定工资全额计算。如需按日折算，请在每月工资输入中写明支付额",
      "en": "{0} {2} in {1} ({3}). Full fixed pay was used; to prorate, enter the amount in the monthly input"}),
    (r"(\S+) は資格取得月に喪失している。厚生年金は原則徴収、国民年金加入時は還付等——個別判断",
     {"zh": "{0} 在取得资格的当月丧失资格。厚生年金原则上征收，加入国民年金时可退还等——需个别判断",
      "en": "{0} gained and lost insurance in the same month. Pension is normally collected, refunds apply if national pension "
            "is joined — decide case by case"}),
    (r"(\S+) の標準報酬月額 ([\-\d,]+) に根拠（決定通知書等）が登録されていない。ここが違うと社保の全項目が一斉に違い、しかも互いに自洽する",
     {"zh": "{0} 的标准报酬月额 {1} 没有登记依据（决定通知书等）。这里错了，社保所有项目会一起错，而且彼此还能对得上",
      "en": "{0}'s standard monthly remuneration {1} has no registered document. If it is wrong every insurance item is wrong "
            "together and still consistent"}),
    (r"(\S+)：健保の標準賞与額は年度（(\d{4})/4〜）累計 573 万円が上限。開始月より前の賞与は入力が無いので累計に入っていない",
     {"zh": "{0}：健保的标准奖金额按年度（{1}/4 起）累计上限 573 万日元。开始月之前的奖金没有输入，未计入累计",
      "en": "{0}: health insurance bonus is capped at 5.73m yen per year (from {1}/4); bonuses before the start month are not counted"}),
    (r"(\S+)：前月の給与が無い（または開始月前で不明）。月額表を使う特別な計算（賞与の1/6 等）になる——初版は計算せず 0 円で置いた",
     {"zh": "{0}：上月没有工资（或在开始月之前、不明）。需要用月额表的特别计算（奖金的 1/6 等）——目前未计算，暂按 0 日元",
      "en": "{0}: no salary last month (or unknown before the start month). The special monthly-table method applies — set to 0 for now"}),
    (r"(\S+)：社保等控除後の賞与 ([\-\d,]+) が前月の ([\-\d,]+) の 10 倍を超える。月額表を使う特別な計算になる——初版は計算せず 0 円で置いた",
     {"zh": "{0}：扣除社保等之后的奖金 {1} 超过上月 {2} 的 10 倍。需要用月额表的特别计算——目前未计算，暂按 0 日元",
      "en": "{0}: bonus after deductions {1} exceeds 10× last month's {2}. The special monthly-table method applies — set to 0 for now"}),
    (r"(\S+) は役員。事前確定届出給与として届け出た額どおりでなければ法人税法上損金不算入（法人税法第34条）。届出の有無と額を確認する",
     {"zh": "{0} 是董事。如果不是按事前确定申报给与申报的金额支付，法人税上不能计入费用（法人税法第 34 条）。请确认是否申报以及金额",
      "en": "{0} is a director. Unless paid exactly as notified in advance, it is not deductible (Corporation Tax Act art. 34). "
            "Check the notice and amount"}),
    (r"(\d{4})年度の確定に要る入力（labor_insurance\.yaml：開始月前の賃金・前年度の概算納付額など）が無いので計算表を作れない",
     {"zh": "缺少 {0} 年度确定保险费所需的输入（labor_insurance.yaml：开始月之前的工资、上年度已缴的概算保险费等），无法做计算表",
      "en": "Inputs for the {0} final premium are missing (labor_insurance.yaml: wages before the start month, estimate paid last "
            "year…), so the worksheet cannot be built"}),
    (r"計算表を作った（納付 ([\-\d,]+) 円・期限 (\S+?)）。申告書と突き合わせて確認する",
     {"zh": "已做计算表（缴纳 {0} 日元・期限 {1}）。请与申报书核对", "en": "Worksheet built (payment {0} yen, due {1}). Check it against the return"}),
    (r"今年度の賃金見込額が前年度（([\-\d,]+)）の 1/2〜2 倍に収まる前提で、前年度の額を使った。外れるなら labor_insurance\.yaml の estimate_base に見込額を書く（rules labor_annual_estimate）",
     {"zh": "假设本年度预计工资在上年度（{0}）的 1/2〜2 倍之间，沿用了上年度金额。超出时请在 labor_insurance.yaml 的 estimate_base 写预计额",
      "en": "Assumed this year's wages stay within 1/2–2× of last year's ({0}) and used last year's figure. Otherwise put the "
            "estimate in estimate_base of labor_insurance.yaml"}),
    (r"延納が指定されているが、概算保険料 ([\-\d,]+) は 40 万円未満で延納できない（rules labor_annual_installment）",
     {"zh": "指定了分期缴纳，但概算保险费 {0} 不足 40 万日元，不能分期", "en": "Instalments were requested but the estimate {0} is under 400,000 yen"}),
    (r"概算 ([\-\d,]+) 円（未払法人税等 ([\-\d,]+)）。別表と突き合わせ、adjustments\.yaml で 法人税等／未払法人税等 を計上する",
     {"zh": "概算 {0} 日元（应交法人税等 {1}）。请与别表核对，并在 adjustments.yaml 计提 法人税等／未払法人税等",
      "en": "Estimate {0} yen (payable {1}). Check against the schedules and accrue 法人税等 / 未払法人税等 in adjustments.yaml"}),
    (r"計算表を作れない：(.+)", {"zh": "无法做计算表：{0}", "en": "Cannot build the worksheet: {0}"}),
    (r"decisions\.yaml の「(.+?)」に当たる要確認が無い。古い回答なら消す",
     {"zh": "decisions.yaml 的「{0}」没有对应的待确认。如果是旧回答请删除",
      "en": "No pending item matches “{0}” in decisions.yaml. Delete it if it is old"}),
    (r"(.+?)。済んだら decisions\.yaml に action: done（by・at 必須）で回答する。仕訳が要るものは adjustments\.yaml に入れる",
     {"zh": "{0}。完成后在 decisions.yaml 用 action: done 回答（必须写 by・at）。需要分录的写进 adjustments.yaml",
      "en": "{0}. When done, answer with action: done in decisions.yaml (by and at required). Put any entries in adjustments.yaml"}),
    (r"期首の預り金（社会保険料）([\-\d,]+) は (\d{4}-\d{2})分の被保険者負担（前期は当月徴収で控除済み）。"
     r"今期の方針は翌月徴収なので、(\d{4}-\d{2})の給与でも同じ (\d{4}-\d{2})分を控除する → 同じ月分を 2 回控除し、"
     r"([\-\d,]+) 円が預り金に残り続ける。処理を決める：①本人に返金する（預り金 → 未払金（本人）へ振替、返金の振込で消込）"
     r"②(\d{4}-\d{2})の給与明細で実際には控除していない → 給与の入力を直す③前期も実は翌月徴収だった → 期首残高を直す。"
     r"年末調整の社会保険料控除は、返金後の実際の控除額で計算する",
     {"zh": "期初預り金（社会保険料）{0} 是 {1} 月份的个人负担（上期按当月征收，已经扣过）。本期方针是翌月征收，所以 {2} 的工资又扣了一次 {3} 月份"
            " → 同一个月扣了两次，{4} 日元会一直留在預り金里。请决定处理方式：①退还本人（預り金 → 未払金（本人），退款转账时冲销）"
            "②{5} 的工资明细实际上没有扣 → 修改工资输入 ③上期其实也是翌月征收 → 修改期初余额。年末调整的社保扣除按退款后的实际扣除额计算",
      "en": "Opening withheld social insurance {0} is the employee share for {1} (deducted last period under same-month collection). "
            "This period uses next-month collection, so the {2} salary deducts {3} again → the same month is deducted twice and "
            "{4} yen stays in 預り金. Decide: ① refund the employee (move to 未払金 for the person, clear on payment) ② the {5} "
            "payslip did not actually deduct it → fix the payroll input ③ last period was also next-month → fix the opening "
            "balance. Year-end adjustment uses the amount actually deducted after any refund"}),
    (r"開始前の支給分の源泉所得税は遅くとも (\S+?)（納期の特例の期限）に納付するはず。補助科目が「(.+?)」でないので、"
     r"エンジンの納付の予定に入らず、消し込まれないまま残る。①納付済み → 納付の明細を回答で消し込む"
     r"②年末調整の還付で本人に返す分（源泉徴収票の源泉徴収税額が控除額より少ない）→ 未払金（本人）へ振替③期首残高の誤り → 期首を直す",
     {"zh": "开始月之前支付的工资的源泉税最迟应在 {0}（纳期特例的期限）缴纳。因为明细科目不是「{1}」，引擎不会把它排进缴纳计划，"
            "会一直挂着不被冲销。①已缴纳 → 用回答把缴纳的流水冲销 ②属于年末调整应退还本人的部分（源泉徴収票的税额少于已扣额）"
            "→ 转入 未払金（本人）③期初余额有误 → 修改期初",
      "en": "Withholding on pay before the start month is due by {0} at the latest (special schedule). Because the sub-account is "
            "not “{1}”, the engine does not schedule its payment and it is never cleared. ① already paid → clear it by answering "
            "the payment row ② refundable to the employee after year-end adjustment (tax on the slip is less than withheld) → "
            "move to 未払金 for the person ③ wrong opening balance → fix it"}),
    # 検査の明細
    (r"検査対象が (\d+) 件——通過ではない。入力が空か、上流が切れていないか確認。",
     {"zh": "检查对象为 {0} 件——这不等于通过。请确认输入是否为空、上游是否断了。",
      "en": "{0} items checked — this is not a pass. Check whether the input is empty or something upstream is broken."}),
    (r"(.+?)/(.+?) に借方残高 ([\-\d,]+)", {"zh": "{0}/{1} 出现借方余额 {2}", "en": "{0}/{1} has a debit balance of {2}"}),
    (r"(.+?)：帳簿 ([\-\d,]+) ≠ 銀行 ([\-\d,]+)（差 ([+\-]?[\d,]+)）",
     {"zh": "{0}：账面 {1} ≠ 银行 {2}（差 {3}）", "en": "{0}: book {1} ≠ bank {2} (difference {3})"}),
    (r"差額 ([+\-][\d,]+) 円の分解：", {"zh": "差额 {0} 日元的分解：", "en": "Breakdown of the {0} yen difference:"}),
    (r"① 期首の差 ([+\-][\d,]+)（帳簿の期首 ([\-\d,]+) − 開始月直前の銀行 ([\-\d,]+)）",
     {"zh": "① 期初差额 {0}（账面期初 {1} − 开始月之前的银行余额 {2}）",
      "en": "① opening difference {0} (book opening {1} − bank before the start month {2})"}),
    (r"② 帳簿に入っていない明細 (\d+) 件 合計 ([+\-][\d,]+)",
     {"zh": "② 未入账的流水 {0} 笔，合计 {1}", "en": "② {0} bank rows not in the books, total {1}"}),
    (r"③ 銀行明細に対応しない預金の動き (\d+) 件 合計 ([+\-][\d,]+)",
     {"zh": "③ 没有对应流水的存款变动 {0} 笔，合计 {1}", "en": "③ {0} deposit movements with no bank row, total {1}"}),
    (r"④ 説明できない残り ([+\-][\d,]+)  ← 上の三つで説明できない。明細の取り込み漏れ・同一明細の二重計上・日付の月ずれを疑う",
     {"zh": "④ 无法说明的剩余 {0}  ← 以上三项说明不了。怀疑流水漏导入、同一流水重复入账或日期跨月",
      "en": "④ unexplained remainder {0}  ← not explained by the three above. Suspect a missing import, a double booking or a "
            "month shift"}),
    (r"④ 説明できない残り ([+\-][\d,]+)", {"zh": "④ 无法说明的剩余 {0}", "en": "④ unexplained remainder {0}"}),
    (r"伝票(\d+) (\S+) (.+?)：借 ([\-\d,]+) ≠ 貸 ([\-\d,]+)",
     {"zh": "凭证{0} {1} {2}：借 {3} ≠ 贷 {4}", "en": "Voucher {0} {1} {2}: debit {3} ≠ credit {4}"}),
    (r"借方総計 ([\-\d,]+) ≠ 貸方総計 ([\-\d,]+)", {"zh": "借方合计 {0} ≠ 贷方合计 {1}", "en": "Debit total {0} ≠ credit total {1}"}),
    (r"伝票(\d+)：科目「(.+?)」が科目表にない",
     {"zh": "凭证{0}：科目「{1}」不在科目表中", "en": "Voucher {0}: account “{1}” is not in the chart"}),
    (r"伝票(\d+) (\S+) が期間 (\S+?)〜(\S+) の外",
     {"zh": "凭证{0} {1} 不在期间 {2}〜{3} 内", "en": "Voucher {0} {1} is outside {2} to {3}"}),
    (r"伝票(\d+) (\S+) は今日 (\S+) より後——まだ発生していない",
     {"zh": "凭证{0} {1} 晚于今天 {2}——尚未发生", "en": "Voucher {0} {1} is after today {2} — it has not happened yet"}),
    (r"採番されていない伝票が (\d+) 件", {"zh": "有 {0} 张凭证没有编号", "en": "{0} vouchers have no number"}),
    (r"伝票番号が連続していない（(\d+)〜(\d+)、(\d+) 件）",
     {"zh": "凭证号不连续（{0}〜{1}，{2} 张）", "en": "Voucher numbers are not continuous ({0} to {1}, {2})"}),
    (r"(\d+) 行目で残高連鎖が切れる：推定 ([\-\d,]+) ≠ 実際 ([\-\d,]+)",
     {"zh": "第 {0} 行余额链条断开：推算 {1} ≠ 实际 {2}", "en": "Balance chain breaks at row {0}: expected {1} ≠ actual {2}"}),
    (r"明細 (.+?) を (.+?) と (.+?) が二重に認領",
     {"zh": "流水 {0} 被 {1} 和 {2} 重复认领", "en": "Row {0} is claimed by both {1} and {2}"}),
    (r"(.+?)：予定日 (\S+) と明細日 (\S+) が窓（前 (\d+) 日・後 (\d+) 日）の外",
     {"zh": "{0}：预定日 {1} 与流水日 {2} 超出窗口（前 {3} 天・后 {4} 天）",
      "en": "{0}: due {1} and row date {2} are outside the window ({3} days before, {4} after)"}),
    (r"どこにも入っていない明細：(.+)", {"zh": "没有归入任何一类的流水：{0}", "en": "Rows in no category: {0}"}),
    (r"二つの区分に同時に入っている明細：(.+)", {"zh": "同时归入两类的流水：{0}", "en": "Rows in two categories: {0}"}),
    (r"(\S+)：差引 ([\-\d,]+) が負", {"zh": "{0}：实发 {1} 为负数", "en": "{0}: net pay {1} is negative"}),
    (r"(\S+)：控除に負の値", {"zh": "{0}：扣除项出现负数", "en": "{0}: a deduction is negative"}),
    (r"(\d{4}-\d{2})分：([\-\d,]+) ≠ ([\-\d,]+)", {"zh": "{0} 月份：{1} ≠ {2}", "en": "{0}: {1} ≠ {2}"}),
    (r"(.+?)：期限 (\S+) → 実際 (\S+)", {"zh": "{0}：期限 {1} → 实际 {2}", "en": "{0}: due {1} → paid {2}"}),
    (r"使われていない回答：(.+)", {"zh": "未被使用的回答：{0}", "en": "Unused answers: {0}"}),
    (r"存在しない参照：(.+)", {"zh": "不存在的引用：{0}", "en": "References that do not exist: {0}"}),
    (r"未払費用（社会保険料）＝(\d{4}-\d{2})分 会社負担",
     {"zh": "未払費用（社保）＝{0} 月份公司负担", "en": "Accrued social insurance = employer share for {0}"}),
    (r"預り金（社会保険料）＝(\d{4}-\d{2})分 被保険者負担（(\w+)）",
     {"zh": "預り金（社保）＝{0} 月份个人负担（{1}）", "en": "Withheld social insurance = employee share for {0} ({1})"}),
    (r"(.+?)：([\-\d,]+) ≠ ([\-\d,]+)（差 ([+\-]?[\d,]+)）",
     {"zh": "{0}：{1} ≠ {2}（差 {3}）", "en": "{0}: {1} ≠ {2} (difference {3})"}),
    (r"当月に到来する納期限が無い（社保は翌月末、源泉・住民税は翌月10日(・納期の特例)?）。納付予定を落としていれば、その明細が要確認になり B6 が赤になる",
     {"zh": "本月没有到期的缴纳（社保为次月末，源泉税・住民税为次月 10 日{0}）。如果漏了缴纳计划，该流水会进入待确认，B6 会变红",
      "en": "Nothing falls due this month (social insurance at the end of next month, withholding and resident tax on the 10th{0}). "
            "A missed payment would show up as a pending row and turn B6 red"}),
    (r"・納期の特例", {"zh": "・纳期特例", "en": ", or the special schedule"}),
]

_COMPILED = [(re.compile(p), t) for p, t in PATTERNS + RESULT_PATTERNS]

# 方針の説明（company.POLICY_HELP）。エラー文の中に丸ごと入るので、句ごと置き換える
POLICY_HELP_TR = {
    "shaho_collection": ("从工资扣社保的月份：next_month（翌月征收，扣上个月的）/ same_month（当月征收）",
                         "month of salary deduction: next_month (deduct last month's) / same_month"),
    "shaho_rounding": ("本人负担部分的尾数：deduct_half_down（法定，工资扣除）/ cash_half_up / truncate（特约）",
                       "rounding of the employee share: deduct_half_down (statutory) / cash_half_up / truncate"),
    "koyou_rounding": ("雇用保险本人负担部分的尾数（与社保相同的三选一）", "rounding of the employment insurance employee share"),
    "support_rounding": ("子育て支援金本人负担是与健保（＋介护）合并取整，还是分开取整",
                         "round the child-support levy together with health insurance or separately"),
    "koyou_rate_basis": ("雇用保险费率的年度按工资截止日还是支付日判断（一次资料未确认——按公司的做法选）",
                         "decide the employment insurance rate year by the closing date or the pay date"),
    "shaho_expense": ("公司负担的社保：accrual（月末计提未払费用）/ on_payment（缴纳时计费用）",
                      "employer share: accrual (accrue at month end) / on_payment (expense when paid)"),
    "labor_insurance_expense": ("劳动保险的公司负担：monthly_accrual（每月按工资估算计提）/ on_payment（年度更新缴纳时计费用）",
                                "employer labour insurance: monthly_accrual / on_payment"),
    "gensen_nouki_tokurei": ("源泉所得税的纳期特例（是否已获批准）", "special payment schedule for withholding tax (approved?)"),
    "juminzei_nouki_tokurei": ("住民税的纳期特例（是否已获批准）", "special payment schedule for resident tax (approved?)"),
}


def _phrases(text: str, lang: str) -> str:
    from .company import POLICY_HELP
    i = 0 if lang == "zh" else 1
    for k, ja in POLICY_HELP.items():
        if ja in text and k in POLICY_HELP_TR:
            text = text.replace(ja, POLICY_HELP_TR[k][i])
    return text


def _one(msg: str, lang: str) -> str:
    fx = FIXED.get(msg.strip())
    if fx:
        return fx[0 if lang == "zh" else 1]
    for rx, tr in _COMPILED:
        m = rx.fullmatch(msg.strip())
        if m and lang in tr:
            groups = [_phrases(_one(g, lang), lang) if g else "" for g in m.groups()]
            return tr[lang].format(*groups)
    return msg


def translate(msg, lang: str):
    """「；」で区切られた複数のメッセージも一つずつ訳す。ja・未知の言語はそのまま。"""
    if not msg or lang not in ("zh", "en"):
        return msg
    return "；".join(_one(part, lang) for part in str(msg).split("；"))


def _idx(lang):
    return {"zh": 0, "en": 1}.get(lang)


def check_name(cid: str, ja: str, lang: str) -> str:
    i = _idx(lang)
    return ja if i is None or cid not in CHECK_NAMES else CHECK_NAMES[cid][i]


def category_name(cat: str, ja: str, lang: str) -> str:
    i = _idx(lang)
    return ja if i is None or cat not in CATEGORY_NAMES else CATEGORY_NAMES[cat][i]


def result_text(text, lang: str):
    """検査の明細・要確認の題と本文。行ごとに訳し、行頭の字下げ（差額の分解）は残す。"""
    if not text or _idx(lang) is None:
        return text
    out = []
    for line in str(text).split("\n"):
        body = line.lstrip(" ")
        out.append(line[:len(line) - len(body)] + translate(body, lang) if body else line)
    return "\n".join(out)
