# -*- coding: utf-8 -*-
"""月次の作業底稿（xlsx）。中国語（既定）／日本語。

作者の決定 A1：主な顧客は在日華人企業。既定は中国語、`lang="ja"` で日本語。
表示ラベルは data/i18n/workpaper.yaml。推導チェーン・法令の引用・要確認の本文は
訳さない（法令用語は原文が正）。科目は中国語モードで「中国語（日本語）」と併記。

値で書く（数式を使わない）。数式は Excel で再計算するまで値を持たず、openpyxl で
作ったファイルを機械で読み返して検証できないから。検証は tests/test_report.py が
**書き出したファイルを読み戻して**行う（断言はレンダリングの後ろに立つ）。
"""
from __future__ import annotations

import datetime
import pathlib

import yaml
from openpyxl import Workbook
from openpyxl.styles import Alignment, Border, Font, PatternFill, Side
from openpyxl.utils import get_column_letter

from .close import statements
from .core import checks as C
from .judgments import digest
from .jp.calendar import month_end
from .pending import CATEGORY_LABEL

I18N = yaml.safe_load((pathlib.Path(__file__).resolve().parents[2] / "data" / "i18n" / "workpaper.yaml")
                      .read_text(encoding="utf-8"))
LANGS = ("zh", "ja")

HEAD = PatternFill("solid", fgColor="DDEBF7")
BAD = PatternFill("solid", fgColor="F8CBAD")
WARN = PatternFill("solid", fgColor="FFF2CC")
OKF = PatternFill("solid", fgColor="E2EFDA")
THIN = Side(style="thin", color="BFBFBF")
BOX = Border(left=THIN, right=THIN, top=THIN, bottom=THIN)
NUM = "#,##0;[Red]-#,##0"


class L:
    """ラベルの引き当て。lang に無いものは日本語（原文）に落とす。"""

    def __init__(self, lang):
        if lang not in LANGS:
            raise ValueError(f"lang は {LANGS} のどれか：{lang}")
        self.lang = lang

    def sheet(self, k):
        return I18N["sheets"][k][self.lang]

    def t(self, k, **kw):
        return I18N["text"][k][self.lang].format(**kw)

    def head(self, k, **kw):
        return [str(h).format(**kw) for h in I18N["headers"][k][self.lang]]

    def status(self, s):
        return I18N["status"][s][self.lang]

    def check(self, c):
        if self.lang == "ja":
            return c.name
        return (I18N["check_names"].get(c.id) or {}).get("zh", c.name)

    def category(self, cat):
        if self.lang == "ja":
            return CATEGORY_LABEL[cat]
        return I18N["pending_categories"][cat]["zh"]

    def title(self, s):
        return s if self.lang == "ja" else I18N["pending_titles"].get(s, s)

    def kind(self, k):
        return (I18N["voucher_kinds"].get(k) or {}).get(self.lang, k)

    def jkind(self, k):
        return k if self.lang == "ja" else I18N["judgment_kinds"].get(k, k)

    def psource(self, s):
        return s if self.lang == "ja" else I18N["policy_sources"].get(s, s)

    def section(self, s):
        return s if self.lang == "ja" else I18N["sections"].get(s, s)

    def account(self, co, acc):
        """中国語モード：「中国語（日本語）」。日本語モード：日本語。"""
        cn = co.chart[acc].get("cn", "")
        if self.lang == "zh" and cn:
            return f"{cn}（{acc}）"
        return acc

    def other_name(self, co, acc):
        """試算表・BS・PL の「もう一方の言語」列。"""
        return acc if self.lang == "zh" else co.chart[acc].get("cn", "")


def _table(ws, row, headers, rows, widths=None, nums=()):
    for c, h in enumerate(headers, 1):
        cell = ws.cell(row, c, h)
        cell.font, cell.fill, cell.border = Font(bold=True), HEAD, BOX
        cell.alignment = Alignment(horizontal="center", vertical="center", wrap_text=True)
    for r in rows:
        row += 1
        for c, v in enumerate(r, 1):
            cell = ws.cell(row, c, v)
            cell.border = BOX
            if c in nums:
                cell.number_format = NUM
            elif isinstance(v, datetime.date):
                cell.number_format = "yyyy-mm-dd"
            if isinstance(v, str) and len(v) > 40:
                cell.alignment = Alignment(wrap_text=True, vertical="top")
    for i, w in enumerate(widths or [], 1):
        ws.column_dimensions[get_column_letter(i)].width = w
    ws.freeze_panes = ws.cell(row - len(rows) + 1 if rows else row + 1, 1)
    return row + 2


def write(led, month: datetime.date, path, lang: str = "zh") -> dict:
    """書き出して、読み戻し検証用の要約を返す。"""
    lb = L(lang)
    co = led.co
    res = [r for r in led.results if r.month == month][0]
    end = month_end(month.year, month.month)
    wb = Workbook()
    pend = led.pending.number()
    bs = statements(co, res.tb, month, led)
    rep = res.report

    # ---- 表紙
    ws = wb.active
    ws.title = lb.sheet("cover")
    ws["A1"] = lb.t("title", name=co.name)
    ws["A1"].font = Font(bold=True, size=16)
    ws["A2"] = lb.t("period", ym=f"{month:%Y-%m}", start=month, end=end)
    ws["A3"] = lb.t("purpose")
    ws["A3"].alignment = Alignment(wrap_text=True)
    ws.merge_cells("A3:F3")
    ws.row_dimensions[3].height = 36
    if lb.t("language_note"):
        ws["A4"] = lb.t("language_note")
    open_n = sum(1 for p in pend if p.open)
    rows = [(lb.t("checks_summary"), rep.summary()),
            (lb.t("open_pending"), lb.t("count", n=open_n)),
            (lb.t("closed_pending"), lb.t("count", n=len(pend) - open_n)),
            (lb.t("vouchers_month"), lb.t("count", n=len(res.vouchers))),
            (lb.t("ni_month"), bs["net_income_month"]),
            (lb.t("ni_ytd"), bs["net_income_ytd"]),
            (lb.t("assets"), bs["assets"]),
            (lb.t("liabilities"), bs["liabilities"]),
            (lb.t("equity"), bs["equity"])]
    _table(ws, 5, [lb.t("item"), lb.t("value")], rows, widths=[30, 60], nums=(2,))
    ws["A16"] = lb.t("can_close")
    ws["A16"].font = Font(bold=True)
    ws["B16"] = lb.t("ok_verdict") if rep.ok else lb.t("ng_verdict")
    ws["B16"].fill = OKF if rep.ok else BAD
    ws["A18"] = lb.t("hash")
    ws["B18"] = digest(co.judgments)
    ws["A19"] = lb.t("hash_note")

    # ---- チェック
    ws = wb.create_sheet(lb.sheet("checks"))
    rows = [(c.id, lb.check(c), lb.status(c.status), c.n_checked, "\n".join(c.details)) for c in rep.checks]
    _table(ws, 1, lb.head("checks"), rows, widths=[7, 46, 9, 9, 90])
    for i, c in enumerate(rep.checks, 2):
        ws.cell(i, 3).fill = {C.PASS: OKF, C.FAIL: BAD, C.SKIP: WARN}[c.status]

    # ---- 要確認
    ws = wb.create_sheet(lb.sheet("pending"))
    rows = [(p.qid, lb.category(p.category), lb.t("open") if p.open else lb.t("answered"), lb.title(p.title),
             p.detail, p.date, p.amount, p.key) for p in pend]
    _table(ws, 1, lb.head("pending"), rows, widths=[8, 18, 8, 28, 70, 11, 12, 50], nums=(7,))
    for i, p in enumerate(pend, 2):
        ws.cell(i, 3).fill = WARN if p.open else OKF

    # ---- 判断記録（作者の決定 A3：誰が・いつ・なぜ）
    ws = wb.create_sheet(lb.sheet("judgments"))
    used = {k for k, p in led.pending.items.items() if not p.open}
    rows = []
    for j in co.judgments:
        kind, key, value, source, by, at, reason = j.row()
        if j.kind == "回答":
            source = lb.t("used") if j.key in used else lb.t("unused")
        else:
            source = lb.psource(source)
        rows.append((lb.jkind(kind), key, value, source, by, at, reason))
    _table(ws, 1, lb.head("judgments"), rows, widths=[10, 34, 46, 22, 20, 11, 50])

    # ---- 仕訳帳
    ws = wb.create_sheet(lb.sheet("journal"))
    rows = []
    for v in sorted(res.vouchers, key=lambda v: v.vno):
        for l in v.lines:
            rows.append((v.vno, v.date, lb.kind(v.kind), v.narration, lb.account(co, l.account), l.sub,
                         int(l.debit) or None, int(l.credit) or None, l.tax, l.memo,
                         v.evidence_label(), " ／ ".join(v.derivation)))
    _table(ws, 1, lb.head("journal"), rows,
           widths=[6, 11, 10, 28, 22, 18, 12, 12, 11, 16, 26, 90], nums=(7, 8))

    # ---- 試算表
    ws = wb.create_sheet(lb.sheet("tb"))
    keys = sorted(set(res.tb) | set(res.tb_open), key=lambda k: (co.chart[k[0]]["code"], k[1]))
    rows = []
    for k in keys:
        a = co.chart[k[0]]
        o, e = res.tb_open.get(k, 0), res.tb.get(k, 0)
        if o == 0 and e == 0:
            continue
        rows.append((a["code"], lb.account(co, k[0]), lb.other_name(co, k[0]), k[1], o, e - o, e))
    _table(ws, 1, lb.head("tb"), rows, widths=[8, 22, 14, 22, 14, 14, 16], nums=(5, 6, 7))

    # ---- 貸借対照表
    ws = wb.create_sheet(lb.sheet("bs"))
    rows = []
    asset_secs = ("流動資産", "有形固定資産", "無形固定資産", "投資その他の資産")
    for sec in asset_secs + ("流動負債", "固定負債", "株主資本"):
        accs = bs["sections"].get(sec, {})
        sign = 1 if sec in asset_secs else -1
        for acc, bal in sorted(accs.items(), key=lambda x: co.chart[x[0]]["code"]):
            if bal:
                rows.append((lb.section(sec), lb.account(co, acc), lb.other_name(co, acc), sign * bal))
    if bs["unclosed_pl"]:              # 年度末の損益振替の後は繰越利益剰余金に入っているので出さない
        rows.append((lb.section("株主資本"), lb.t("ni_ytd_line"), "", bs["unclosed_pl"]))
    rows += [(lb.t("total"), lb.t("assets"), "", bs["assets"]),
             (lb.t("total"), lb.t("liabilities"), "", bs["liabilities"]),
             (lb.t("total"), lb.t("equity"), "", bs["equity"]),
             (lb.t("check_row"), lb.t("diff_line"), "", bs["assets"] - bs["liabilities"] - bs["equity"])]
    _table(ws, 1, lb.head("bs", end=end), rows, widths=[18, 30, 14, 16], nums=(4,))

    # ---- 損益計算書
    ws = wb.create_sheet(lb.sheet("pl"))
    pl_secs = ("売上高", "売上原価", "販売費及び一般管理費", "営業外収益", "営業外費用", "特別利益", "特別損失", "法人税等")
    accs = sorted(set(bs["ytd"]) | set(bs["month"]), key=lambda a: co.chart[a]["code"])
    rows = []
    for sec in pl_secs:
        for a in accs:
            if co.chart[a]["section"] == sec:
                sign = -1 if co.chart[a]["normal"] == "credit" else 1
                rows.append((lb.section(sec), lb.account(co, a), lb.other_name(co, a),
                             sign * bs["month"].get(a, 0), sign * bs["ytd"].get(a, 0)))
    rows.append(("", lb.t("ni_line"), "", bs["net_income_month"], bs["net_income_ytd"]))
    _table(ws, 1, lb.head("pl"), rows, widths=[20, 30, 14, 14, 16], nums=(4, 5))

    # ---- 給与台帳
    ws = wb.create_sheet(lb.sheet("payroll"))
    rows = []
    for s in res.slips:
        e = co.emp(s.eid)
        rows.append((s.eid, e.display, s.pay_date, s.gross, s.shaho_total,
                     " / ".join(lb.t("month_of", ym=f"{x.month:%Y-%m}") + ("(介護)" if x.care else "") for x in s.shaho),
                     s.koyou, s.taxable, s.income_tax, s.juminzei, s.net, " ／ ".join(s.why)))
    tot = (lb.t("total"), "", "", sum(s.gross for s in res.slips), sum(s.shaho_total for s in res.slips), "",
           sum(s.koyou for s in res.slips), sum(s.taxable for s in res.slips),
           sum(s.income_tax for s in res.slips), sum(s.juminzei for s in res.slips),
           sum(s.net for s in res.slips), "")
    _table(ws, 1, lb.head("payroll"), rows + [tot],
           widths=[6, 12, 11, 12, 12, 18, 10, 12, 11, 10, 12, 90], nums=(4, 5, 7, 8, 9, 10, 11))

    # ---- 社会保険
    ws = wb.create_sheet(lb.sheet("shaho"))
    rows = []
    for m, n in sorted(res.notices.items()):
        ym = lb.t("month_of", ym=f"{m:%Y-%m}")
        for x in n.members:
            rows.append((ym, x.eid, x.smr, x.pension_smr, lb.t("care") if x.care else "",
                         float(x.health_full), float(x.support_full), float(x.pension_full),
                         x.emp_health, x.emp_support, x.emp_pension, x.emp_total))
        rows.append((ym, lb.t("notice"), "", "", "", n.health, "", n.pension,
                     lb.t("contribution"), n.contribution, lb.t("company_share"), n.company))
    _table(ws, 1, lb.head("shaho"), rows,
           widths=[10, 8, 11, 11, 6, 12, 11, 12, 10, 10, 10, 10], nums=(3, 4, 6, 7, 8, 9, 10, 11, 12))

    # ---- 銀行照合
    ws = wb.create_sheet(lb.sheet("bank"))
    claim = {}
    for bid, mr in res.match.items():
        for rid, lab, exp, act, *_ in mr.claims:
            claim[rid] = f"{lb.t('matched')}：{lab}"
    rows, flagged = [], []
    for bid, rws in res.bank_rows.items():
        for r in rws:
            cb = r.claimed_by or ""
            if r.id in claim:
                how = claim[r.id]
            elif cb.startswith("rule:"):
                how = f"{lb.t('rule')}：{cb[5:]}"
            elif cb.startswith("decision:"):
                how = f"{lb.t('answer')}：decisions.yaml"
            else:
                how = lb.sheet("pending")
                flagged.append(len(rows))
            rows.append((r.label, r.date, r.desc, r.outflow or None, r.inflow or None, r.balance, how))
    _table(ws, 1, lb.head("bank"), rows, widths=[16, 11, 30, 12, 12, 14, 50], nums=(4, 5, 6))
    for i in flagged:
        ws.cell(i + 2, 7).fill = WARN

    # ---- 消費税（税区分の集計と概算。申告額は会計担当者が確定させる）
    from .jp import shouhi
    from .jp.depreciation import fy_bounds
    ws = wb.create_sheet(lb.sheet("ct"))
    fs = fy_bounds(month, co.fy_end_month)[0]
    m_sum = shouhi.summary(co, res.vouchers)
    y_sum = shouhi.summary(co, [v for v in led.vouchers if fs <= v.date <= end])
    rows = []
    for cat in sorted(set(m_sum["rows"]) | set(y_sum["rows"])):
        mb, mt = m_sum["rows"].get(cat, (0, 0))
        yb, yt = y_sum["rows"].get(cat, (0, 0))
        rows.append((cat, mb, mt, yb, yt))
    rows.append((lb.t("ct_estimate"), "", m_sum["estimate"], "", y_sum["estimate"]))
    r = _table(ws, 1, lb.head("ct"), rows, widths=[22, 14, 14, 14, 14], nums=(2, 3, 4, 5))
    ws.cell(r, 1, y_sum["basis"])
    ws.cell(r + 1, 1, " / ".join(f"{k}: {v}" for k, v in co.ct.items() if v is not None))

    # ---- 労働保険の年度更新（6・7 月、計算表を作れたときだけ）
    calc = led.labor_calcs.get(month.year) if month.month in (6, 7) else None
    if calc is not None:
        ws = wb.create_sheet(lb.sheet("labor"))
        r = _table(ws, 1, lb.head("labor"), calc.lines, widths=[70, 16], nums=(2,))
        ws.cell(r, 1, lb.t("labor_note"))

    # ---- 法人税等の計算表（年度末の月、作れたときだけ）
    if res.corp_tax is not None:
        ws = wb.create_sheet(lb.sheet("corp"))
        r = _table(ws, 1, lb.head("corp"), res.corp_tax["lines"], widths=[10, 70, 16, 28], nums=(3,))
        ws.cell(r, 1, lb.t("corp_note"))

    # ---- 出典
    ws = wb.create_sheet(lb.sheet("sources"))
    r = led.rates
    src = I18N["sources"]
    rows = [(src["kenpo"][lang], r._kenpo["source"]["file"], r._kenpo["source"]["sha256"][:16]),
            (src["koyou"][lang], r._koyou["source"]["file"], r._koyou["source"]["sha256"][:16]),
            (src["rousai"][lang], r._rousai["source"]["file"], r._rousai["source"]["sha256"][:16]),
            (src["wh"][lang], r._wh["source"]["page"], r._wh["source"]["sha256"]["01-07.xls"][:16]),
            (src["wb"][lang], r._wb["source"]["page"], r._wb["source"]["sha256"][:16])]
    _table(ws, 1, lb.head("sources"), rows, widths=[26, 90, 20])

    wb.save(path)
    return dict(vouchers=len(res.vouchers), pending=len(pend), open=open_n, lang=lang,
                pending_rows_in_bank=len(flagged),
                debit=sum(int(l.debit) for v in res.vouchers for l in v.lines),
                credit=sum(int(l.credit) for v in res.vouchers for l in v.lines))
