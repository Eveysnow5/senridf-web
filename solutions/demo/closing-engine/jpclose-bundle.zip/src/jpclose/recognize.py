# -*- coding: utf-8 -*-
"""利用者が入れた表（Excel・CSV）が何かを見分ける（作者 2026-10-12：画面の「表を入れる」入口）。

利用者はフォルダの決まり（bank/ に明細、直下に入力ブック）を知らなくてよい——入れたファイルの**中身**を見て、
画面が置き場所を決める。見分けるのは今のところ 2 種類：

  workbook   入力ブック（「公司」「方针」の表がある）→ 公司资料.xlsx として直下に
  bank       銀行の明細。**会社が登録した列名**（入力ブックの「银行账户」）で読める → bank/ に
  bank_other 銀行の明細らしい（日付・残高・入金か出金の見出しがある）が、登録した列名では読めない
             → 置かない。bank/ に置くと明細の取り込みが失敗して締められなくなる（列名の自動認識は次の段）
  opening    期首残高（弥生会計の「勘定科目の期首残高データ」の様式）→ 入力ブックの「期初余额」の表に入れる
             （入れるのは webev.import_opening。ファイルは置かない）
  journal    仕訳（弥生インポート形式。弥生会計の仕訳日記帳の書き出しも同じ形）→ 置かない。同じ期間の銀行明細と
             組んで銀行ルールの候補を作る（webev.import_journal）
  workpaper  年報の財務工作底稿（資産負債表・序時账の表がある Excel。中国式の決算ワークペーパーの書式）→ 置かない。まだ読めないので、
             何なのかと、いまできることを知らせる（「分からない」とは言わない）
  unknown    分からない → 置かない（当てずっぽうで決めない）

判定の根拠は why（日本語の文）と、画面が自分の言語で言い直すための項目（found＝見つけた見出し、
want＝登録した列名、checked＝登録と照らしたか）で返す。

見分けるのは「出どころごとの読み手」（下の READERS）。新しい出どころは読み手を 1 つ足す——classify は変えない。
"""
from __future__ import annotations

import csv
import io
import pathlib
import re

from . import bank as bankmod
from . import workbook as wbmod
from .workbook import find_workbook

WORKBOOK, BANK, BANK_OTHER, OPENING, JOURNAL, WORKPAPER, UNKNOWN = ("workbook", "bank", "bank_other", "opening", "journal",
                                                             "workpaper", "unknown")
HEAD_ROWS = 10                                      # 見出し行を探す範囲（bank._xlsx_table と同じ）

# 銀行の明細に出てくる見出しの言い方（大手行・ネット銀行のダウンロード）。「らしさ」の判定だけに使う——
# 実際に読むのは会社が登録した列名
_DATE = re.compile(r"日付|年月日|取引日|入出金日|勘定日")
_BAL = re.compile(r"残高")
_IN = re.compile(r"入金|お預入|お預り|預入金額|預り金額")
_OUT = re.compile(r"出金|お引出|お支払|支払金額|引出金額")


def _grid(path) -> tuple[list, str]:
    """先頭 HEAD_ROWS 行（文字列）と、読めなかった理由。"""
    p = pathlib.Path(path)
    if p.suffix.lower() == ".csv":
        try:
            text, _ = bankmod._decode(p.read_bytes())
        except ValueError as e:
            return [], str(e)
        rows = []
        for i, r in enumerate(csv.reader(io.StringIO(text))):
            if i >= HEAD_ROWS:
                break
            rows.append([c.strip() for c in r])
        return rows, ""
    from openpyxl import load_workbook
    try:
        wb = load_workbook(p, read_only=True, data_only=True)
    except Exception as e:                           # 壊れた・暗号化された・xlsx でない
        return [], f"Excel として開けません（{type(e).__name__}）"
    try:
        ws = wb.worksheets[0]
        rows = [[str(c).strip() if c is not None else "" for c in r]
                for r in ws.iter_rows(min_row=1, max_row=HEAD_ROWS, values_only=True)]
    finally:
        wb.close()
    return rows, ""


def _is_workbook(path) -> bool:
    if pathlib.Path(path).suffix.lower() not in (".xlsx", ".xlsm"):
        return False
    from openpyxl import load_workbook
    try:
        wb = load_workbook(path, read_only=True)
    except Exception:                                # 壊れた xlsx は入力ブックではない
        return False
    try:
        return wbmod.is_input_book(wb.sheetnames)
    finally:
        wb.close()                                   # 閉じないと Windows でファイルが掴まれたままになる


def registered_columns(root) -> list:
    """会社が登録した明細の列名：[(口座 id, [日付, 摘要, 入金, 出金, 残高])]。入力ブックが無い・読めないなら空。"""
    wb = find_workbook(root)
    if wb is None:
        return []
    from openpyxl import load_workbook
    from .workbook import _rows
    try:
        book = load_workbook(wb, read_only=True, data_only=True)
    except Exception:                                # 入力ブックが壊れている → 登録なしとして扱う（締めの方で報告される）
        return []
    try:
        ws = wbmod.sheet(book, "银行账户")
        if ws is None:
            return []
        out = []
        for _, d in _rows(ws):
            cols = [str(d.get(k) or "").strip() for k in ("date", "desc", "in", "out", "balance")]
            if d.get("id") and all(cols):
                out.append((str(d["id"]), cols))
        return out
    finally:
        book.close()


# ------------------------------------------------------------------ 出どころごとの読み手
# 入れられた表が「どこから来た何か」を見分けるのは、出どころごとに 1 つの読み手（Reader）。classify は上から順に尋ねるだけ。
# 新しい出どころ（会計ソフト・給与ソフトの書き出し、ほかの銀行の明細…）は、ここに読み手を 1 つ足す：
#   · detect(ctx)：その表だと言えるなら classify の答え（kind・why・置き先に要る項目）を返す。言えなければ None
#     —— 見分けるのは**見出し・表の名前のような、その書き出しに必ずある目印**で。数や並びの「らしさ」で当てない
#   · 実物の書き出しを見てから書く（見ていない様式の読み手は作らない：作りものの見本で通しても、本物で外れる）
#   · 中身を読んで締めに渡すところ（bank.load_all・workbook.to_folder に当たるもの）は、その読み手と一緒に足す
class Context:
    """1 つのファイルについて、読み手たちが共有するもの（先頭の行・登録した列名は一度だけ読む）。"""

    def __init__(self, path, root=None):
        self.path, self.root = pathlib.Path(path), root
        self._grid = self._reg = None

    @property
    def rows(self) -> list:
        if self._grid is None:
            self._grid = _grid(self.path)
        return self._grid[0]

    @property
    def problem(self) -> str:
        if self._grid is None:
            self._grid = _grid(self.path)
        return self._grid[1]

    @property
    def registered(self) -> list:
        if self._reg is None:
            self._reg = registered_columns(self.root) if self.root is not None else []
        return self._reg


class Reader:
    def __init__(self, rid: str, detect, needs_rows: bool = True):
        self.id, self.detect, self.needs_rows = rid, detect, needs_rows


def _detect_workbook(ctx):
    if _is_workbook(ctx.path):
        return dict(kind=WORKBOOK, why="「公司」「方针」の表があります")
    return None


def _detect_bank_registered(ctx):
    """会社が登録した列名がそろった見出しがある。"""
    for bank_id, cols in ctx.registered:
        for r in ctx.rows:
            if all(c in r for c in cols):
                return dict(kind=BANK, why=f"口座 {bank_id} の列名（{'・'.join(cols)}）がそろっています",
                            bank=bank_id, found=cols, checked=True)
    return None


def _detect_bank_headings(ctx):
    """明細らしい見出し（日付・残高・入金か出金）がある。登録した列名とは合わなかったもの。"""
    reg = ctx.registered
    for r in ctx.rows:
        heads = [c for c in r if c]
        hit = {k: next((c for c in heads if rx.search(c)), None)
               for k, rx in (("date", _DATE), ("balance", _BAL), ("in", _IN), ("out", _OUT))}
        if hit["date"] and hit["balance"] and (hit["in"] or hit["out"]):
            heads_found = [v for v in hit.values() if v]
            found = "・".join(heads_found)
            if not reg:
                # 入力ブックがまだ無い：登録と比べられない。明細として置く（入力ブックが来たら締めの前の確認で列名を見る）
                return dict(kind=BANK, why=f"明細の見出し（{found}）があります（列名の登録はまだ確認していません）",
                            bank="", found=heads_found, checked=False)
            want = "／".join("・".join(c) for _, c in reg)
            return dict(kind=BANK_OTHER, found=heads_found, want=[c for _, c in reg],
                        why=f"明細の見出し（{found}）はありますが、登録した列名（{want}）と違います")
    return None


def _detect_yayoi_opening(ctx):
    """弥生会計の期首残高データ（見出しなし・6 項目・3 項目めが 借方／貸方）。様式は弥生の公開のサポート情報から
    ——弥生会計が実際に書き出したファイルはまだ見ていない（yayoi.py の冒頭）。"""
    from . import yayoi
    if ctx.path.suffix.lower() == ".csv" and yayoi.looks_like_opening(ctx.rows):
        return dict(kind=OPENING, why="弥生会計の期首残高データの形（6 項目・貸借区分）です")
    return None


def _detect_yayoi_journal(ctx):
    """弥生インポート形式の仕訳（見出しなし・25 項目以上・1 項目めが識別フラグ 2000／2110／2100／2101）。"""
    from . import yayoi
    if ctx.path.suffix.lower() == ".csv" and yayoi.looks_like_journal(ctx.rows):
        return dict(kind=JOURNAL, why="弥生インポート形式の仕訳です（25 項目・識別フラグ）")
    return None


def _detect_workpaper(ctx):
    """財務ワークペーパー：表の名前に「资产负债表」と「序时账」がある Excel（見出しの形はまだ読まない＝目印だけ）。"""
    if ctx.path.suffix.lower() not in (".xlsx", ".xlsm"):
        return None
    from openpyxl import load_workbook
    try:
        wb = load_workbook(ctx.path, read_only=True)
    except Exception:
        return None
    try:
        names = wb.sheetnames
    finally:
        wb.close()
    if any("资产负债表" in n or "資産負債表" in n for n in names) and any("序时账" in n or "序時帳" in n for n in names):
        return dict(kind=WORKPAPER, why="年次の財務ワークペーパーです（貸借対照表と仕訳帳の表の名前で判断しました）",
                    sheets=[n for n in names if "资产负债表" in n or "序时账" in n][:6])
    return None


READERS = [
    Reader("workbook", _detect_workbook, needs_rows=False),
    Reader("workpaper", _detect_workpaper, needs_rows=False),
    Reader("yayoi_opening", _detect_yayoi_opening),
    Reader("yayoi_journal", _detect_yayoi_journal),
    Reader("bank_registered", _detect_bank_registered),
    Reader("bank_headings", _detect_bank_headings),
]


def classify(path, root=None) -> dict:
    """path の表が何か。root は会社フォルダ（登録した列名を見る。無ければ「らしさ」だけで判定）。
    答えには reader（見分けた読み手の id）が付く。どの読み手も言えなければ unknown。"""
    ctx = Context(path, root)
    name = ctx.path.name
    for rd in READERS:
        if rd.needs_rows and ctx.problem:               # 開けない・文字コードが分からない
            return dict(kind=UNKNOWN, why=ctx.problem, name=name)
        hit = rd.detect(ctx)
        if hit:
            return dict(hit, name=name, reader=rd.id)
    return dict(kind=UNKNOWN, why="入力ブックでも銀行の明細でもありません（見出しで判定できません）", name=name)
