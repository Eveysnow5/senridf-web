# -*- coding: utf-8 -*-
"""要確認（会計担当者の判断を待つ事項）。

## 原則

「導出できない取引は推測しない」。銀行明細の性質・処分の意思・方針の選択・
一次資料で裏の取れない前提は、全部ここに出す。会計担当者が回答すると
（会社ディレクトリの decisions.yaml）、次の実行で仕訳になる／前提が確定する。

## キーと番号

  key   安定した指紋（例 "bank:main:2026-06-12:-5500:ｱﾏｿﾞﾝ"）。回答はこの key に紐づける。
        Q 番号は実行ごとに振り直すので、回答を Q 番号に紐づけると取り違える。
  Q-001 底稿での表示番号（その実行の中だけで一意）

## 回答の腐り

decisions.yaml に回答があるのに、該当する要確認がもう出てこない →「空振りの回答」として警告。
回答が古くなったまま残ると、いつか別の取引に誤って当たる。
"""
from __future__ import annotations

import datetime
from dataclasses import dataclass, field

CATEGORY_ORDER = ["setting", "closing", "bank_unmatched", "bank_ambiguous", "expected_missing",
                  "amount_mismatch", "balance", "payroll", "evidence", "assumption", "stale_decision"]
CATEGORY_LABEL = {
    "setting": "設定・方針", "closing": "決算（年度末の確認）", "bank_unmatched": "銀行明細（ルール無し）",
    "bank_ambiguous": "銀行明細（候補が複数）", "expected_missing": "予定の支払が無い",
    "amount_mismatch": "金額の不一致", "balance": "残高の説明", "payroll": "給与", "evidence": "根拠書類",
    "assumption": "前提（一次資料で未確認）", "stale_decision": "使われなかった回答",
}


@dataclass
class Pending:
    key: str
    category: str
    title: str
    detail: str
    date: datetime.date | None = None
    amount: int | None = None
    options: list = field(default_factory=list)
    qid: str = ""
    resolved_by: dict | None = None
    data: dict = field(default_factory=dict)         # 推論（hints）に使う構造化した値：予定額・期限・明細の額など

    @property
    def open(self) -> bool:
        return self.resolved_by is None


@dataclass
class PendingBook:
    items: dict = field(default_factory=dict)       # key → Pending

    def add(self, p: Pending) -> Pending:
        if p.category not in CATEGORY_ORDER:
            raise ValueError(f"未知の区分 {p.category}")
        if p.key in self.items:                      # 同じ事項は一つに（月をまたいで同じ前提など）
            return self.items[p.key]
        self.items[p.key] = p
        return p

    def resolve(self, decisions: dict):
        """回答を当てる。回答されたが該当なしのものを返す（空振り）。"""
        used = set()
        for k, p in self.items.items():
            if k in decisions:
                p.resolved_by = decisions[k]
                used.add(k)
        return sorted(set(decisions) - used)

    def number(self):
        ordered = sorted(self.items.values(),
                         key=lambda p: (CATEGORY_ORDER.index(p.category), p.date or datetime.date.min, p.key))
        for i, p in enumerate(ordered, 1):
            p.qid = f"Q-{i:03d}"
        return ordered

    def open_items(self):
        return [p for p in self.number() if p.open]
