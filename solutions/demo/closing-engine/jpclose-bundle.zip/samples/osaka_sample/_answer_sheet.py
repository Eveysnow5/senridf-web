# -*- coding: utf-8 -*-
"""架空印刷（大阪）の答え合わせ表・銀行明細・期首残高を作る。**エンジンを import しない。**

東京サンプルと同じ約束（印字された折半額を使う／月分・介護該否は手で書く）。
方針はすべて東京と逆：当月徴収・支援金は健保と合算して丸め・特約で切捨て・
会社負担は納付時費用・源泉と住民税は納期の特例・雇用保険の年度は締日で判定。

賞与だけは標準賞与額 291,000 が等級表に無い値なので、印字値ではなく
「標準賞与額 × 料率」を素朴に計算する（ここは独立性が弱い——底稿の検証で補う）。
"""
from __future__ import annotations

import csv
import io
import pathlib
from decimal import Decimal as D

import yaml

HERE = pathlib.Path(__file__).resolve().parent
DATA = HERE.parents[1] / "data" / "jp"

TABLE = {}
with open(DATA / "shakai_hoken" / "kyoukaikenpo_r08_table.csv", encoding="utf-8") as f:
    for r in csv.DictReader(f):
        if r["pref"] == "大阪":
            TABLE[int(r["smr"])] = r
WH = yaml.safe_load((DATA / "gensen" / "withholding_monthly_2026.yaml").read_text(encoding="utf-8"))
WB = yaml.safe_load((DATA / "gensen" / "withholding_bonus_2026.yaml").read_text(encoding="utf-8"))


def trunc(x) -> int:
    return int(D(x))                      # 正の値だけを扱うので int() は切捨て


def kou(x, n):
    for b in WH["brackets"]:
        if b["lower"] <= x < b["upper"]:
            return b["kou"][n]
    raise SystemExit(f"甲欄の区間外 {x}")


def bonus_rate(prev, n):
    for r in WB["kou"][str(n)]:
        if (r["lower"] is None or r["lower"] <= prev) and (r["upper"] is None or prev < r["upper"]):
            return D(r["rate"])
    raise SystemExit("賞与算出率表に該当なし")


# ---------------------------------------------------------------- 手で書く表
# 月分 → {従業員: (標準報酬月額, 介護該当か)}
#   F01 1961-07-15 生 → 満65歳到達 7/14 → 7月分から介護なし
#   F02 6/30 退職（月末）→ 喪失 7/1 → 6月分まで
#   F03 1985-12-01 生 → 満40歳到達 2025-11-30 → 介護あり。7月分から月額変更 280,000
INSURED = {
    "2026-04": {"F01": (500000, True), "F02": (260000, False), "F03": (240000, True)},
    "2026-05": {"F01": (500000, True), "F02": (260000, False), "F03": (240000, True)},
    "2026-06": {"F01": (500000, True), "F02": (260000, False), "F03": (240000, True)},
    "2026-07": {"F01": (500000, False), "F03": (280000, True)},
}


def monthly_shaho(eid, month):
    smr, care = INSURED[month][eid]
    r = TABLE[smr]
    h_half = D(r["hc_half"] if care else r["health_half"]) + D(r["support_half"])    # 4月分以降なので支援金あり
    h_full = D(r["hc_full"] if care else r["health_full"]) + D(r["support_full"])
    return dict(emp=trunc(h_half) + trunc(D(r["pension_half"])),       # 支援金は健保と合算して切捨て
                health_full=h_full, pension_full=D(r["pension_full"]), contrib_full=D(smr) * D("0.0036"))


BONUS = {"2026-06": {"F03": 291400}}
BONUS_DATE = "2026-06-30"


def bonus_shaho(eid, month, amount):
    std = amount // 1000 * 1000
    smr, care = INSURED[month][eid]
    h_rate = D("0.1013") + (D("0.0162") if care else 0) + D("0.0023")      # 大阪 健保・介護・支援金
    hf = D(std) * h_rate
    pf = D(std) * D("0.183")
    return dict(std=std, emp_health=trunc(hf / 2), emp_pension=trunc(pf / 2),
                health_full=hf, pension_full=pf, contrib_full=D(std) * D("0.0036"))


PAY = {
    "2026-05": {"date": "2026-05-29",          # 5/31 は日曜 → 前営業日
                "F01": {"役員報酬": 500000}, "F02": {"基本給": 230000, "皆勤手当": 10000, "通勤手当": 15000},
                "F03": {"基本給": 260000, "皆勤手当": 10000, "通勤手当": 6000}},
    "2026-06": {"date": "2026-06-30",
                "F01": {"役員報酬": 500000}, "F02": {"基本給": 230000, "皆勤手当": 10000, "通勤手当": 15000},
                "F03": {"基本給": 260000, "皆勤手当": 10000, "通勤手当": 6000}},
    "2026-07": {"date": "2026-07-31",
                "F01": {"役員報酬": 500000},
                "F03": {"基本給": 260000, "皆勤手当": 10000, "通勤手当": 6000}},
}
JUMIN = {"F01": {"2026-05": 28000, "2026-06": 29500, "2026-07": 29500},
         "F02": {"2026-05": 8500, "2026-06": 8800},
         "F03": {"2026-05": 11000, "2026-06": 11600, "2026-07": 11600}}
DEP = {"F01": 1, "F02": 0, "F03": 2}
KOYOU = {"F02", "F03"}


def slip(pm, eid):
    items = PAY[pm][eid]
    gross = sum(items.values())
    sh = monthly_shaho(eid, pm)["emp"]                  # 当月徴収
    ko = trunc(D(gross) * D("0.005")) if eid in KOYOU else 0
    # 通勤手当の非課税限度（手で書く）：F02 マイカー片道 12km → 7,300＋駐車場 3,000＝10,300、F03 定期 6,000
    limit = {"F02": 10300, "F03": 6000}.get(eid, 0)
    excess = max(0, items.get("通勤手当", 0) - limit)
    taxable = sum(v for k, v in items.items() if k != "通勤手当") + excess - sh - ko
    tax = kou(taxable, DEP[eid])
    jm = JUMIN[eid].get(pm, 0)
    return dict(gross=gross, shaho=sh, koyou=ko, taxable=taxable, tax=tax, jumin=jm,
                net=gross - sh - ko - tax - jm)


def build():
    exp = {"slips": {}, "notices": {}, "bonus": {}}
    for pm in PAY:
        exp["slips"][pm] = {e: slip(pm, e) for e in PAY[pm] if e != "date"}
    # 賞与
    for pm, xs in BONUS.items():
        for eid, amt in xs.items():
            b = bonus_shaho(eid, pm, amt)
            ko = trunc(D(amt) * D("0.005")) if eid in KOYOU else 0
            prev = exp["slips"]["2026-05"][eid]["taxable"]
            base = amt - b["emp_health"] - b["emp_pension"] - ko
            rate = bonus_rate(prev, DEP[eid])
            tax = trunc(D(base) * rate / 100)
            exp["bonus"][pm] = {eid: dict(amount=amt, std=b["std"], emp_health=b["emp_health"],
                                          emp_pension=b["emp_pension"], koyou=ko, prev_taxable=prev,
                                          rate=str(rate), tax=tax, net=amt - b["emp_health"] - b["emp_pension"] - ko - tax)}
    for m in INSURED:
        xs = [monthly_shaho(e, m) for e in INSURED[m]]
        for pm, bx in BONUS.items():
            if pm == m:
                xs += [bonus_shaho(e, m, a) | {"emp": bonus_shaho(e, m, a)["emp_health"] + bonus_shaho(e, m, a)["emp_pension"]}
                       for e, a in bx.items()]
        h = trunc(sum(x["health_full"] for x in xs))
        p = trunc(sum(x["pension_full"] for x in xs))
        c = trunc(sum(x["contrib_full"] for x in xs))
        emp = sum(x["emp"] for x in xs)
        exp["notices"][m] = dict(total=h + p + c, health=h, pension=p, contribution=c, employee=emp,
                                 company=h + p + c - emp)

    # 労働保険の年度更新（2026-07-10 納付）。手で計算する：
    #   確定 2025年度：賃金 6,300,000（雇用・労災同額）×（雇用 14.5/1000 ＋ 労災[46 印刷] 3.5/1000）＝ 113,400
    #   一般拠出金：6,300,000 × 0.02/1000 ＝ 126
    #   概算 2026年度：6,300,000 ×（13.5/1000 ＋ 3.5/1000）＝ 107,100
    #   前年度概算 110,000 → 不足 3,400。納付 107,100 ＋ 3,400 ＋ 126 ＝ 110,626
    #   簡便法：預り金（雇用保険）17,920 を消し込み、残り 92,706 を法定福利費
    exp["labor_2026"] = dict(final=113400, general=126, estimate=107100, paid=110000, diff=3400,
                             payment=110626, withheld=17920, expense=110626 - 17920)
    n = exp["notices"]
    OPEN_GENSEN, OPEN_JUMIN = 96520, 237500
    gensen_may_jun = sum(s["tax"] for pm in ("2026-05", "2026-06") for s in exp["slips"][pm].values()) \
        + sum(b["tax"] for b in exp["bonus"]["2026-06"].values())
    jumin_may = sum(s["jumin"] for s in exp["slips"]["2026-05"].values())
    exp["tokurei"] = dict(gensen_0710=OPEN_GENSEN + gensen_may_jun, jumin_0610=OPEN_JUMIN + jumin_may)

    # 期首残高（2026-04-30）。4月分の被保険者負担は当月徴収なので 4/30 の給与で控除済み・未納付
    april_emp = n["2026-04"]["employee"]
    bank0 = 3600000
    bal = [("普通預金", "架空信金", bank0, 0), ("売掛金", "ナニワ商会", 900000, 0),
           ("工具器具備品", "FA01", 440000, 0), ("減価償却累計額", "FA01", 0, 29333),
           ("預り金", "社会保険料", 0, april_emp), ("預り金", "源泉所得税", 0, OPEN_GENSEN),
           ("預り金", "住民税", 0, OPEN_JUMIN),
           # 雇用保険の被保険者負担：2025 年度分 17,920 ＋ 2026 年 4 月分（F02 1,275・F03 1,380）
           ("預り金", "雇用保険", 0, 17920 + 1275 + 1380),
           ("資本金", "", 0, 2000000),
           ("売上高", "", 0, 3200000), ("役員報酬", "", 2000000, 0), ("給料手当", "", 1880000, 0),
           ("法定福利費", "", 520000, 0), ("地代家賃", "", 528000, 0), ("減価償却費", "", 29333, 0)]
    plug = sum(d for _, _, d, _ in bal) - sum(c for _, _, _, c in bal)
    bal.append(("繰越利益剰余金", "", 0, plug))
    lines = ["# 自動生成：_answer_sheet.py。期首（2026-04-30）の試算表。年度途中なので 1〜4 月の損益科目を含む。",
             "as_of: 2026-04-30", "balances:"]
    for acc, sub, d, c in bal:
        s = f"  - {{account: {acc}" + (f", sub: {sub}" if sub else "") + (f", debit: {d}}}" if d else f", credit: {c}}}")
        lines.append(s)
    (HERE / "opening_balances.yaml").write_text("\n".join(lines) + "\n", encoding="utf-8")

    tx = []
    def out(d, desc, a): tx.append((d, desc, a, 0))
    def inn(d, desc, a): tx.append((d, desc, 0, a))
    s5, s6, s7 = exp["slips"]["2026-05"], exp["slips"]["2026-06"], exp["slips"]["2026-07"]
    inn("2026-05-15", "ﾌﾘｺﾐ ﾅﾆﾜｼﾖｳｶｲ", 900000)
    out("2026-05-26", "ﾔﾁﾝ ｶｸｳﾋﾞﾙ", 132000)
    for e in ("F01", "F02", "F03"):
        out("2026-05-29", "ｷﾕｳﾖ", s5[e]["net"])
        out("2026-05-29", "ﾌﾘｺﾐﾃｽｳﾘﾖｳ", 330)
    out("2026-06-01", "ｼﾔﾎ ﾈﾝｷﾝｷｺｳ", n["2026-04"]["total"])       # 4月分（5/31 日曜→6/1）
    out("2026-06-10", "ｼﾞﾕｳﾐﾝｾﾞｲ ﾄｸﾁﾖｳ", exp["tokurei"]["jumin_0610"])
    out("2026-06-12", "ｶ-ﾄﾞ ｱﾏｿﾞﾝ", 8800)
    inn("2026-06-15", "ﾌﾘｺﾐ ﾅﾆﾜｼﾖｳｶｲ", 1100000)
    out("2026-06-26", "ﾔﾁﾝ ｶｸｳﾋﾞﾙ", 132000)
    for e in ("F01", "F02", "F03"):
        out("2026-06-30", "ｷﾕｳﾖ", s6[e]["net"])
        out("2026-06-30", "ﾌﾘｺﾐﾃｽｳﾘﾖｳ", 330)
    out("2026-06-30", "ｼﾖｳﾖ", exp["bonus"]["2026-06"]["F03"]["net"])
    out("2026-06-30", "ｼﾔﾎ ﾈﾝｷﾝｷｺｳ", n["2026-05"]["total"])
    out("2026-07-10", "ｹﾞﾝｾﾝｼﾖﾄｸｾﾞｲ ﾉｳｷﾄｸﾚｲ", exp["tokurei"]["gensen_0710"])
    out("2026-07-10", "ﾛｳﾄﾞｳﾎｹﾝﾘﾖｳ ﾈﾝﾄﾞｺｳｼﾝ", exp["labor_2026"]["payment"])
    inn("2026-07-15", "ﾌﾘｺﾐ ﾅﾆﾜｼﾖｳｶｲ", 1050000)
    out("2026-07-27", "ﾔﾁﾝ ｶｸｳﾋﾞﾙ", 132000)
    for e in ("F01", "F03"):
        out("2026-07-31", "ｷﾕｳﾖ", s7[e]["net"])
        out("2026-07-31", "ﾌﾘｺﾐﾃｽｳﾘﾖｳ", 330)
    out("2026-07-31", "ｼﾔﾎ ﾈﾝｷﾝｷｺｳ", n["2026-06"]["total"])       # 6月分（賞与分を含む）
    tx.sort(key=lambda t: t[0])
    rows, b = [], bank0
    for d, desc, o, i in tx:
        b = b - o + i
        rows.append((d, desc, o, i, b))

    def write(name, lo, hi):
        buf = io.StringIO()
        w = csv.writer(buf, lineterminator="\n")
        w.writerow(["日付", "内容", "出金金額", "入金金額", "残高"])
        for d, desc, o, i, bb in rows:
            if lo <= d <= hi:
                w.writerow([d, desc, o or "", i or "", bb])
        (HERE / "bank" / name).write_bytes(buf.getvalue().encode("utf-8-sig"))
    (HERE / "bank").mkdir(exist_ok=True)
    write("2026-05_06.csv", "2026-05-01", "2026-06-30")       # 6 月が二つのファイルに重複している
    write("2026-06_07.csv", "2026-06-01", "2026-07-31")
    exp["bank_closing"] = rows[-1][4]
    head = "# 自動生成：_answer_sheet.py（エンジンと独立に作った期待値）。手で直さないこと。\n"
    (HERE / "expected.yaml").write_text(head + yaml.safe_dump(exp, allow_unicode=True, sort_keys=False),
                                        encoding="utf-8")
    return exp


if __name__ == "__main__":
    e = build()
    for m, n in e["notices"].items():
        print(m, "告知", n["total"], "被保険者", n["employee"], "会社", n["company"])
    for pm, ss in e["slips"].items():
        print(pm, {k: (v["shaho"], v["koyou"], v["tax"], v["net"]) for k, v in ss.items()})
    print("賞与", e["bonus"])
    print("特例", e["tokurei"], "期末銀行残高", e["bank_closing"])
