# -*- coding: utf-8 -*-
"""架空商事の「答え合わせ表」と銀行明細 CSV を作る。**エンジンを import しない。**

エンジンと独立に期待値を作るための約束：
  · 社会保険料は協会けんぽの**印字された折半額**（kyoukaikenpo_r08_table.csv）を使う。
    エンジンは「料率×標準報酬月額」で計算するので、経路が違う。
  · どの月分を控除するか・介護の該否・被保険者か否かは、**下の表に手で書く**。
    エンジンの暦関数（is_care_insured 等）を使うと、同じ誤りを共有してしまう。
  · 源泉は公表の月額表（区間表）を直接引く。
  · 端数処理は「50銭以下切捨て・50銭超切上げ」を素朴に書く。

生成物：
  expected.yaml           各月の給与明細・告知額・納付予定（テストが突き合わせる）
  bank/2026Q1.csv         銀行明細（cp932、残高付き）——エンジンの取り込みを cp932 で試すため
"""
from __future__ import annotations

import csv
import io
import pathlib
from decimal import Decimal as D

import yaml

HERE = pathlib.Path(__file__).resolve().parent
DATA = HERE.parents[1] / "data" / "jp"

TABLE = {}
with open(DATA / "shakai_hoken" / "kyoukaikenpo_r08_table.csv", encoding="utf-8") as f:
    for r in csv.DictReader(f):
        if r["pref"] == "東京":
            TABLE[int(r["smr"])] = r
WH = yaml.safe_load((DATA / "gensen" / "withholding_monthly_2026.yaml").read_text(encoding="utf-8"))


def emp_round(x: D) -> int:
    """50銭以下切捨て・50銭超切上げ。"""
    i = int(x)
    return i + 1 if x - i > D("0.5") else i


def kou(x, n):
    for b in WH["brackets"]:
        if b["lower"] <= x < b["upper"]:
            return b["kou"][n]
    raise SystemExit(f"甲欄の区間外 {x}")


def otsu(x):
    if x < 105000:
        return int(D(x) * D("0.03063"))          # 円未満切捨て（エンジンと同じ前提）
    for b in WH["brackets"]:
        if b["lower"] <= x < b["upper"]:
            return b["otsu"]
    raise SystemExit(f"乙欄の区間外 {x}")


# ---------------------------------------------------------------- 手で書く表
SMR = {"E01": 410000, "E02": 260000, "E03": 200000}
# 月分 → {従業員: 介護該当か}。被保険者でない人は載せない。
#   E02 は 1986-05-01 生まれ → 満40歳到達 4/30 → 4月分から介護
#   E03 は 4/15 取得（4月分から）、6/20 退社 → 喪失 6/21 → 5月分まで
INSURED = {
    "2026-03": {"E01": True, "E02": False},
    "2026-04": {"E01": True, "E02": True, "E03": False},
    "2026-05": {"E01": True, "E02": True, "E03": False},
    "2026-06": {"E01": True, "E02": True},
}
SUPPORT_FROM = "2026-04"            # 支援金は 4月分から


def shaho(eid, month):
    care = INSURED[month][eid]
    r = TABLE[SMR[eid]]
    health_half = D(r["hc_half"] if care else r["health_half"])
    support_half = D(r["support_half"]) if month >= SUPPORT_FROM else D(0)
    pension_half = D(r["pension_half"])
    health_full = D(r["hc_full"] if care else r["health_full"])
    support_full = D(r["support_full"]) if month >= SUPPORT_FROM else D(0)
    pension_full = D(r["pension_full"])
    emp = emp_round(health_half) + emp_round(support_half) + emp_round(pension_half)
    return dict(emp=emp, health_full=health_full + support_full, pension_full=pension_full,
                contribution_full=D(SMR[eid]) * D("0.0036"))


def notice(month):
    xs = {e: shaho(e, month) for e in INSURED[month]}
    h = int(sum(x["health_full"] for x in xs.values()))
    p = int(sum(x["pension_full"] for x in xs.values()))
    c = int(sum(x["contribution_full"] for x in xs.values()))
    emp = sum(x["emp"] for x in xs.values())
    return dict(total=h + p + c, health=h, pension=p, contribution=c, employee=emp, company=h + p + c - emp)


# 支給（固定給＋月次入力）と、その月の給与で控除する月分（翌月徴収）
PAY = {
    "2026-04": {"date": "2026-04-24",       # 4/25 は土曜 → 前営業日
                "E01": {"役員報酬": 400000},
                "E02": {"基本給": 240000, "通勤手当": 12300, "残業手当": 18500},
                "E03": {"基本給": 106667, "通勤手当": 8000}},
    "2026-05": {"date": "2026-05-25",
                "E01": {"役員報酬": 400000},
                "E02": {"基本給": 240000, "通勤手当": 12300},
                "E03": {"基本給": 200000, "通勤手当": 8000}},
    "2026-06": {"date": "2026-06-25",
                "E01": {"役員報酬": 400000},
                "E02": {"基本給": 240000, "通勤手当": 12300, "残業手当": 22700},
                "E03": {"基本給": 133333, "通勤手当": 8000}},
}
DEDUCT_MONTH = {"2026-04": "2026-03", "2026-05": "2026-04", "2026-06": "2026-05"}
JUMIN = {"E01": {"2026-04": 21000, "2026-05": 21000, "2026-06": 22600},
         "E02": {"2026-04": 9800, "2026-05": 9800, "2026-06": 10200}}
KOYOU = {"E02", "E03"}
COLUMN = {"E01": ("kou", 2), "E02": ("kou", 0), "E03": ("otsu", 0)}


def slip(pm, eid):
    items = PAY[pm][eid]
    gross = sum(items.values())
    dm = DEDUCT_MONTH[pm]
    sh = shaho(eid, dm)["emp"] if eid in INSURED[dm] else 0
    kw = sum(v for k, v in items.items() if k in ("基本給", "残業手当", "通勤手当"))
    ko = emp_round(D(kw) * D("0.005")) if eid in KOYOU else 0
    taxable = sum(v for k, v in items.items() if k != "通勤手当") - sh - ko
    col, n = COLUMN[eid]
    tax = kou(taxable, n) if col == "kou" else otsu(taxable)
    jm = JUMIN.get(eid, {}).get(pm, 0)
    return dict(gross=gross, shaho=sh, koyou=ko, taxable=taxable, tax=tax, jumin=jm,
                net=gross - sh - ko - tax - jm)


def build():
    exp = {"slips": {}, "notices": {}}
    for pm in PAY:
        exp["slips"][pm] = {e: slip(pm, e) for e in ("E01", "E02", "E03")}
    for m in INSURED:
        exp["notices"][m] = notice(m)

    gensen = {pm: sum(s["tax"] for s in exp["slips"][pm].values()) for pm in PAY}
    jumin = {pm: sum(s["jumin"] for s in exp["slips"][pm].values()) for pm in PAY}
    OPEN_GENSEN, OPEN_JUMIN = 18730, 30800
    n = exp["notices"]
    exp["opening"] = dict(gensen=OPEN_GENSEN, jumin=OPEN_JUMIN, shaho_company_march=n["2026-03"]["company"])

    tx = []      # (日付, 摘要, 出金, 入金)
    def out(d, desc, a): tx.append((d, desc, a, 0))
    def inn(d, desc, a): tx.append((d, desc, 0, a))
    # 4 月
    out("2026/04/10", "ｾﾞｲｷﾝ ｹﾞﾝｾﾝｼﾖﾄｸｾﾞｲ", OPEN_GENSEN)
    out("2026/04/10", "ｾﾞｲｷﾝ ﾄｸﾍﾞﾂﾁﾖｳｼﾕｳ", OPEN_JUMIN)
    inn("2026/04/15", "ﾌﾘｺﾐ ﾐﾗｲﾄﾚｰﾃﾞｲﾝｸﾞ(ｶ", 700000)
    out("2026/04/20", "ﾃﾞﾝｷﾘﾖｳｷﾝ", 18920)
    for e in ("E01", "E02", "E03"):
        out("2026/04/24", "ｷﾕｳﾖ ﾌﾘｺﾐ", exp["slips"]["2026-04"][e]["net"])
        out("2026/04/24", "ﾌﾘｺﾐﾃｽｳﾘﾖｳ", 440)
    out("2026/04/27", "ﾔﾁﾝ ｶｸｳﾌﾄﾞｳｻﾝ", 165000)
    out("2026/04/30", "ｼﾔｶｲﾎｹﾝﾘﾖｳ ﾈﾝｷﾝｷｺｳ", n["2026-03"]["total"])
    # 5 月
    out("2026/05/01", "ﾌﾘｺﾐ ｶｸｳｼﾞﾄﾞｳｼﾔ", 2640000)          # 車両（回答で計上する）
    out("2026/05/11", "ｾﾞｲｷﾝ ｹﾞﾝｾﾝｼﾖﾄｸｾﾞｲ", gensen["2026-04"])   # 5/10 は日曜
    out("2026/05/11", "ｾﾞｲｷﾝ ﾄｸﾍﾞﾂﾁﾖｳｼﾕｳ", jumin["2026-04"])
    out("2026/05/12", "ｶ-ﾄﾞ ﾋｷｵﾄｼ ｱﾏｿﾞﾝ", 12980)          # 回答で消耗品費
    inn("2026/05/15", "ﾌﾘｺﾐ ﾐﾗｲﾄﾚｰﾃﾞｲﾝｸﾞ(ｶ", 500000)
    out("2026/05/20", "ﾃﾞﾝｷﾘﾖｳｷﾝ", 17450)
    for e in ("E01", "E02", "E03"):
        out("2026/05/25", "ｷﾕｳﾖ ﾌﾘｺﾐ", exp["slips"]["2026-05"][e]["net"])
        out("2026/05/25", "ﾌﾘｺﾐﾃｽｳﾘﾖｳ", 440)
    out("2026/05/27", "ﾔﾁﾝ ｶｸｳﾌﾄﾞｳｻﾝ", 165000)
    inn("2026/05/29", "ﾌﾘｺﾐ ﾐﾗｲﾄﾚｰﾃﾞｲﾝｸﾞ(ｶ", 880000)
    # 6 月（4月分の社保は 5/31 日曜 → 6/1。5月分は 6/30。同額が同月に二回来る）
    out("2026/06/01", "ｼﾔｶｲﾎｹﾝﾘﾖｳ ﾈﾝｷﾝｷｺｳ", n["2026-04"]["total"])
    out("2026/06/10", "ｾﾞｲｷﾝ ｹﾞﾝｾﾝｼﾖﾄｸｾﾞｲ", gensen["2026-05"])
    out("2026/06/10", "ｾﾞｲｷﾝ ﾄｸﾍﾞﾂﾁﾖｳｼﾕｳ", jumin["2026-05"])
    out("2026/06/15", "ﾌﾘｺﾐ ﾔﾏﾀﾞ ﾀﾛｳ", 50000)               # 正体不明：回答しないまま残す
    out("2026/06/19", "ﾃﾞﾝｷﾘﾖｳｷﾝ", 19300)
    for e in ("E01", "E02", "E03"):
        out("2026/06/25", "ｷﾕｳﾖ ﾌﾘｺﾐ", exp["slips"]["2026-06"][e]["net"])
        out("2026/06/25", "ﾌﾘｺﾐﾃｽｳﾘﾖｳ", 440)
    out("2026/06/26", "ﾔﾁﾝ ｶｸｳﾌﾄﾞｳｻﾝ", 165000)             # 6/27 は土曜
    out("2026/06/30", "ｼﾔｶｲﾎｹﾝﾘﾖｳ ﾈﾝｷﾝｷｺｳ", n["2026-05"]["total"])
    inn("2026/06/30", "ﾌﾘｺﾐ ﾐﾗｲﾄﾚｰﾃﾞｲﾝｸﾞ(ｶ", 990000)

    tx.sort(key=lambda t: t[0])                                  # 安定ソート
    bal = 4800000
    buf = io.StringIO()
    w = csv.writer(buf, lineterminator="\r\n")
    w.writerow(["取引日", "摘要", "お引出し", "お預入れ", "残高"])
    for d, desc, o, i in tx:
        bal = bal - o + i
        w.writerow([d, desc, o or "", i or "", bal])
    (HERE / "bank").mkdir(exist_ok=True)
    (HERE / "bank" / "2026Q1.csv").write_bytes(buf.getvalue().encode("cp932"))
    exp["bank_closing"] = bal
    exp["gensen_by_pay_month"] = gensen
    exp["jumin_by_pay_month"] = jumin
    head = "# 自動生成：_answer_sheet.py（エンジンと独立に作った期待値）。手で直さないこと。\n"
    (HERE / "expected.yaml").write_text(head + yaml.safe_dump(exp, allow_unicode=True, sort_keys=False),
                                        encoding="utf-8")
    return exp


if __name__ == "__main__":
    e = build()
    for m, n in e["notices"].items():
        print(m, "告知", n["total"], "被保険者", n["employee"], "会社", n["company"])
    for pm, ss in e["slips"].items():
        print(pm, {k: (v["shaho"], v["koyou"], v["tax"], v["net"]) for k, v in ss.items()})
    print("期末銀行残高", e["bank_closing"])
